

using System.Net.WebSockets;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

//加入WebSocket處理服務
builder.Services.AddSingleton<WebSocketsSample.Service.WebSocketHandler>();
//builder.Services.AddSingleton<WebSocketsSample.Controllers.WebSocketController>();

var app = builder.Build();



// <snippet_UseWebSockets>
var webSocketOptions = new WebSocketOptions
{
    KeepAliveInterval = TimeSpan.FromMinutes(2)
};

// app.Use(async (context, next) =>
// {
//     if (context.Request.Path == "/ws")
//     {
//         if (context.WebSockets.IsWebSocketRequest)
//         {
//             using (WebSocket ws = await context.WebSockets.AcceptWebSocketAsync())
//             {
//                 var wsHandler = context.RequestServices.GetRequiredService<WebSocketsSample.Service.WebSocketHandler>();
//                 await wsHandler.ProcessWebSocket(ws);
//             }
//         }
//         else 
//             context.Response.StatusCode = (int)System.Net.HttpStatusCode.BadRequest;
//     }
//     else await next();
// });

app.UseWebSockets(webSocketOptions);
// </snippet_UseWebSockets>

app.UseDefaultFiles();
app.UseStaticFiles();

app.MapControllers();

app.Run();
