using System.Net.WebSockets;

namespace WebSocketsSample.Snippets;

internal class BackgroundSocketProcessor
{
    internal static void AddSocket(WebSocket webSocket, TaskCompletionSource<object> socketFinishedTcs) { }
}
