using System.Collections.Concurrent;
using System.Net.WebSockets;
using System.Text;
using Microsoft.AspNetCore.Mvc;

namespace WebSocketsSample.Controllers;

// <snippet>
public class WebSocketController : ControllerBase
{

    ConcurrentDictionary<int, WebSocket> WebSockets = new ConcurrentDictionary<int, WebSocket>();

    [HttpGet("/ws")]
    public async Task Get()
    {
        // if (HttpContext.WebSockets.IsWebSocketRequest)
        // {
        //     using var webSocket = await HttpContext.WebSockets.AcceptWebSocketAsync();
        //     await Echo(webSocket);
        // }
        // else
        // {
        //     HttpContext.Response.StatusCode = StatusCodes.Status400BadRequest;
        // }

         if (HttpContext.WebSockets.IsWebSocketRequest)
        {
            using (WebSocket ws = await HttpContext.WebSockets.AcceptWebSocketAsync())
            {
                var wsHandler = HttpContext.RequestServices.GetRequiredService<Service.WebSocketHandler>();
                await wsHandler.ProcessWebSocket(ws);
            }
        }
        else 
            HttpContext.Response.StatusCode = (int)System.Net.HttpStatusCode.BadRequest;

  
    }
    // </snippet>

    private async Task Echo(WebSocket webSocket)
    {
        WebSockets.TryAdd(webSocket.GetHashCode(), webSocket);
        var buffer = new byte[1024 * 4];
        var receiveResult = await webSocket.ReceiveAsync(
            new ArraySegment<byte>(buffer), CancellationToken.None);

        var cmd = Encoding.UTF8.GetString(buffer, 0, receiveResult.Count);

        while (!receiveResult.CloseStatus.HasValue)
        {
            // await webSocket.SendAsync(
            //     new ArraySegment<byte>(buffer, 0, receiveResult.Count),
            //     receiveResult.MessageType,
            //     receiveResult.EndOfMessage,
            //     CancellationToken.None);


            Broadcast(cmd);

            receiveResult = await webSocket.ReceiveAsync(
                new ArraySegment<byte>(buffer), CancellationToken.None);
        }

        await webSocket.CloseAsync(
            receiveResult.CloseStatus.Value,
            receiveResult.CloseStatusDescription,
            CancellationToken.None);

        //WebSockets.TryRemove(webSocket.GetHashCode(), out var removed);
        Broadcast(cmd);
    }

    public void Broadcast(string message)
    {
        var buff = Encoding.UTF8.GetBytes(message);
        var data = new ArraySegment<byte>(buff, 0, buff.Length);
        Parallel.ForEach(WebSockets.Values, async (webSocket) =>
        {
            if (webSocket.State == WebSocketState.Open)
                await webSocket.SendAsync(data, WebSocketMessageType.Text, true, CancellationToken.None);
        });
    }
}
