﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Encodings.Web;
using System.Text.Unicode;

namespace HierarchyPoc
{
    class Program
    {
        static void Main(string[] args)
        {
            var jsonString =
                System
                    .IO
                    .File
                    .ReadAllText(Directory.GetCurrentDirectory() +
                    "/QueryHierarchy.json");

            var herList =
                JsonSerializer.Deserialize<List<Hierarchy>>(jsonString);

            var hierarchyRadars = GetHierarchyRadars(herList);


            //儲存結果成Json
            var options = new JsonSerializerOptions
            {
                //解決中文編碼問題
                Encoder = JavaScriptEncoder.Create(UnicodeRanges.BasicLatin, UnicodeRanges.CjkUnifiedIdeographs),
                WriteIndented = true
            };
            string hierarchyRadarsStr = JsonSerializer.Serialize(hierarchyRadars, options);
            string fileName = "QueryHierarchyResult.json";
            File.WriteAllText(fileName, hierarchyRadarsStr);

            Console.WriteLine("Hello World!");
        }

        public static List<Hierarchy>
        GetHierarchyRadars(List<Hierarchy> Hierarchylist)
        {
            for (int i = 0; i < Hierarchylist.Count; i++)
            {
                if (Hierarchylist[i].subOrg == null) continue;

                if (
                    hasSubOrg(Hierarchylist[i].subOrg) &&
                    !Hierarchylist[i].isCounted
                )
                {
                    //遞迴計算子部門                    
                    Hierarchylist[i].subOrg =
                         GetHierarchyRadars(Hierarchylist[i].subOrg);
                }

                if (!Hierarchylist[i].isCounted || subOrgIsCounted(Hierarchylist[i]))
                {
                    var radarsTemplate = GetRadarsTemp();

                    for (int j = 0; j < Hierarchylist[i].subOrg.Count; j++)
                    {
                        //計算子部門的radarLevelCount
                        if (Hierarchylist[i].subOrg[j].radars.Count != 0)
                        {
                            GetRadarsCount(radarsTemplate,
                            Hierarchylist[i].subOrg[j].radars);
                        }
                    }

                    //加入同部門的radarLevelCount (子部門+同部門)
                    var totalRadars =
                        GetRadarsCount(radarsTemplate, Hierarchylist[i].radars);

                    Hierarchylist[i].radars = totalRadars;

                    Hierarchylist[i].isCounted = true;
                }

            }

            return Hierarchylist;
        }

        //定義好所有要計算的Level和SkillType
        public static List<Radars> GetRadarsTemp()
        {
            List<Radars> radarsTemplate = new List<Radars>();

            radarsTemplate
                .Add(new Radars() { skillLevel = "1", skillType = "廠務建廠" });


            //Level-1
            radarsTemplate
                .Add(new Radars()
                { skillLevel = "1", skillType = "建廠生產線規劃" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "1", skillType = "自動化流程設計(廠端FA)" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "1", skillType = "自動化設備開發" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "1", skillType = "數位化技術" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "1", skillType = "影像辨識/量測" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "1", skillType = "預測式生產" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "1", skillType = "機台設備預警" });

            radarsTemplate
                .Add(new Radars() { skillLevel = "1", skillType = "智控中心" });


            //Level-2
            radarsTemplate
                .Add(new Radars()
                { skillLevel = "2", skillType = "建廠生產線規劃" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "2", skillType = "自動化流程設計(廠端FA)" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "2", skillType = "自動化設備開發" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "2", skillType = "數位化技術" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "2", skillType = "影像辨識/量測" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "2", skillType = "預測式生產" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "2", skillType = "機台設備預警" });

            radarsTemplate
                .Add(new Radars() { skillLevel = "2", skillType = "智控中心" });

            //Level-3
            radarsTemplate
                .Add(new Radars()
                { skillLevel = "3", skillType = "建廠生產線規劃" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "3", skillType = "自動化流程設計(廠端FA)" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "3", skillType = "自動化設備開發" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "3", skillType = "數位化技術" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "3", skillType = "影像辨識/量測" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "3", skillType = "預測式生產" });

            radarsTemplate
                .Add(new Radars()
                { skillLevel = "3", skillType = "機台設備預警" });

            radarsTemplate
                .Add(new Radars() { skillLevel = "3", skillType = "智控中心" });


            return radarsTemplate;
        }

        //計算該階層的radarLevelCount
        public static List<Radars>
        GetRadarsCount(List<Radars> radarsTemplate, List<Radars> empRadars)
        {
            for (int rt = 0; rt < radarsTemplate.Count; rt++)
            {
                var radarLevelCount = 0;
                for (int hr = 0; hr < empRadars.Count; hr++)
                {
                    if (
                        empRadars[hr].skillLevel ==
                        radarsTemplate[rt].skillLevel &&
                        empRadars[hr].skillType == radarsTemplate[rt].skillType
                    )
                    {
                        radarLevelCount += empRadars[hr].radarLevelCount;
                    }
                }
                radarsTemplate[rt].radarLevelCount += radarLevelCount;
            }

            return radarsTemplate;
        }

        //檢查有沒有子部門
        public static bool hasSubOrg(List<Hierarchy> Hierarchylist)
        {
            foreach (var item in Hierarchylist)
            {
                if (item.subOrg != null && item.subOrg.Count > 0) return true;
            }

            return false;
        }

        //檢查子部門是否都計算過技能
        public static bool subOrgIsCounted(Hierarchy Hierarchy)
        {
            foreach (var item in Hierarchy.subOrg)
            {
                if (!item.isCounted) return false;
            }

            return true;
        }
    }
}
