using System;
using System.Collections.Generic;

namespace HierarchyPoc
{
    public class Hierarchy
    {
        public string bossNo { get; set; }
        public string empNo { get; set; }
        public string empName { get; set; }
        public string orgId { get; set; }
        public string bossLevel { get; set; }
        public List<Hierarchy> subOrg { get; set; }
        public List<Radars> radars { get; set; }
        public List<Pyramids> pyramid { get; set; }

        public bool isCounted{ get; set; }
    }
    public class Radars
    {
        // public string UserDepartment { get; set; }
        public string skillLevel { get; set; }
        public string skillType { get; set; }
        public int radarLevelCount { get; set; }
        public int radarLevelTotalCount{get;set;}
        public double radarLevelPercent { get; set; }
    }
    public class Pyramids
    {
        public string skillLevel { get; set; }
        public int personLevelCount { get; set; }
        public int personCount { get; set; }
        public double personLevelPercent { get; set; }
    }    
    
}
