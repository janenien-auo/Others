﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;



namespace AMS_Sample
{
    class Program
    {
        static AMSService.AlarmHandleService ams = new AMSService.AlarmHandleService();
        
        public static class Setting
        {
            public static string AmsSenderStatus { get; set; }
        }

        static void Main(string[] args)
        {
            try
            {
                AMSService.AlarmSendWithParamMessage req = new AMSService.AlarmSendWithParamMessage();
                req.FactoryID = "K1 ";   // 不可修改
                req.SubSystemID = "GSS";    // , 不可修改
                req.EqpID = "";     // 機台編號，可有可無
                req.AlarmInfoID = "AC_GSS_120808";      //  EF_GSS_工號 
                req.AlarmSubject = "AMS GSS TEST120808";  // 可修改
                req.AlarmContent = "AMS GSS TEST120808";  // 可修改
                req.AlarmContentType = "TEXT";  // 不可修改

                AMSService.AlarmHandleService service = new AMSService.AlarmHandleService();
                service.Timeout = 30000;
                AMSService.ReturnMessage res = service.AlarmSendWithParam(req);
                if (res.ReturnStatus == AMSService.ReturnStatus.OK)
                {
                    //Success
                    Console.WriteLine("AMS sent Successful!");
                }
                else
                {
                    //Error
                    Console.WriteLine("AMS sent Fail ...");
                }

                //Global.SaveConfig();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            //Global.WriteLog("OEE_AMS end");
        }

    }
}
