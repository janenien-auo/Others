using System;
using System.Collections.Generic;
using System.Linq;
using AUO.TechDev.Web.Domain.Dashboard;
using AUO.TechDev.Web.Domain.Skill;
using AUO.TechDev.Web.Repository;
using AUO.TechDev.Web.Repository.Dapper_ORM;

namespace AUO.TechDev.Web.Service.Dashboard
{
    public class DashboardService
    {
        SkillRepository skillRepository;
        public DashboardService(IDapper dapper)
        {
            skillRepository = new SkillRepository(dapper);

        }


        public List<GetDeepResponse> GetDeep(string site, List<string> skillIds)
        {
            var feedbackImpls = skillRepository.GetSkillFeedbackImplWithSummary(site, skillIds);


            var orderbyDatas = feedbackImpls
                                .OrderBy(o => o.SkillID)
                                .ThenBy(o => o.Fab);


            var groupbyDatas = from c in orderbyDatas
                               group c by new
                               {
                                   c.Site,
                                   c.SkillID,
                                   c.SkillName,
                                   c.Fab,
                               } into g
                               select new GetDeepResponseTemp()
                               {
                                   SkillID = g.Key.SkillID,
                                   SkillName = g.Key.SkillName,
                                   Fab = g.Key.Fab,                                 
                                   ScoreInfos = g.ToList(),
                               };


            var calcScorelist = new List<SkillScore>();

            foreach (var item in groupbyDatas)
            {

                var totalScore = (decimal)item.ScoreInfos.Sum(o => o.Weight);
                var roadItemCount = (decimal)item.ScoreInfos.Count();
                var score = Math.Round((decimal)(totalScore / roadItemCount), 2,MidpointRounding.AwayFromZero);

                var tempData = new SkillScore()
                {
                    SkillID = item.SkillID,
                    SkillName = item.SkillName,
                    Fab = item.Fab,
                    Score = score
                };

                calcScorelist.Add(tempData);
            }


            var result = from c in calcScorelist
                         group c by new
                         {
                             c.SkillID,
                             c.SkillName
                         } into g
                         select new GetDeepResponse()
                         {
                             SkillID = g.Key.SkillID,
                             SkillName = g.Key.SkillName,
                             ScoreInfos = g.ToList(),
                         };


            return result.ToList();
        }

        public List<GetWidthResponse> GetWidth(string site, List<string> skillIds)
        {
            var feedbackImpls = skillRepository.GetSkillFeedbackImplWithSummary(site, skillIds);


            var orderbyDatas = feedbackImpls
                                .OrderBy(o => o.SkillID)
                                .ThenBy(o => o.Fab)
                                .ThenBy(o => o.Level);


            var groupbyDatas = from c in orderbyDatas
                               group c by new
                               {
                                   c.Site,
                                   c.SkillID,
                                   c.SkillName,
                                   c.Fab,                                   
                                   c.Level
                               } into g
                               select new GetWidthResponseTemp()
                               {
                                   SkillID = g.Key.SkillID,
                                   SkillName = g.Key.SkillName,
                                   Fab = g.Key.Fab,                                  
                                   Level = g.Key.Level,
                                   ScoreInfos = g.ToList(),
                               };


            var calcScorelist = new List<SkillScore>();

            foreach (var item in groupbyDatas)
            {

                var feedbackCount = (decimal)item.ScoreInfos.Count(o => o.Weight > 0);
                var roadItemCount = (decimal)item.ScoreInfos.Count();
                var score = Math.Round((decimal)(feedbackCount / roadItemCount),2,MidpointRounding.AwayFromZero);

                var tempData = new SkillScore()
                {
                    SkillID = item.SkillID,
                    SkillName = item.SkillName,
                    Fab = item.Fab,                  
                    Level = item.Level,
                    Score = score
                };

                calcScorelist.Add(tempData);
            }


            var widthScoreInfos = from c in calcScorelist
                                  group c by new
                                  {
                                      c.SkillID,
                                      c.SkillName,                                 
                                      c.Level
                                  } into g
                                  select new WidthScoreInfo()
                                  {
                                      SkillID = g.Key.SkillID,
                                      SkillName = g.Key.SkillName,                                  
                                      Level = g.Key.Level,
                                      Scores = g.ToList(),
                                  };

            var GetWidthResponses = from c in widthScoreInfos
                                    group c by new
                                    {
                                        c.SkillID,
                                        c.SkillName                                      
                                       
                                    } into g
                                    select new GetWidthResponse()
                                    {
                                        SkillID = g.Key.SkillID,
                                        SkillName = g.Key.SkillName,    
                                        ScoreInfos = g.ToList(),
                                    };


            return GetWidthResponses.ToList();
        }
    }
}
