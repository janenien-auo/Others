using System;
using System.Collections.Generic;
using System.Linq;
using AUO.TechDev.Web.Domain.Parameter;
using AUO.TechDev.Web.Repository;
using AUO.TechDev.Web.Repository.Dapper_ORM;

namespace AUO.TechDev.Web.Service.Parameter
{
    public class ParameterService
    {
        ParameterRepository parameterRepository;
        public ParameterService(IDapper dapper)
        {
            parameterRepository = new ParameterRepository(dapper);

        }

        public List<GetParameterResponse> GetParameters(List<string> req)
        {
            var parameters = parameterRepository.GetParameters(req);

            var result = new List<GetParameterResponse>();

            var tmpPara =
               parameters.GroupBy(o => o.Type)
               .ToDictionary(o => o.Key, o => o.ToList());

            foreach (var p in tmpPara)
            {
                result.Add(new GetParameterResponse()
                {
                    Type = p.Key,
                    Values = p.Value
                });
            }

            return result;
        }

        public List<GetSiteResponse> GetSite()
        {
            var parameters = parameterRepository.GetConstant("SITE");

            var result = from c in parameters
                         group c by new
                         {
                             c.Name
                         } into g
                         select new GetSiteResponse()
                         {
                             Group = g.Key.Name,
                             Fabs = g.Select(o => o.Value).ToList()
                         };

            return result.ToList();
        }
    }
}
