using System;
using System.Collections.Generic;
using System.Linq;
using AUO.TechDev.Web.Domain;
using AUO.TechDev.Web.Domain.Skill;
using AUO.TechDev.Web.Repository;
using AUO.TechDev.Web.Repository.Dapper_ORM;
using Microsoft.Extensions.Configuration;

namespace AUO.TechDev.Web.Service.Skill
{
    public class SkillService
    {
        SkillRepository skillRepository;
        SkillCustomRepository skillCustomRepository;
        public SkillService(IDapper dapper, IConfiguration config)
        {
            skillRepository = new SkillRepository(dapper);
            skillCustomRepository = new SkillCustomRepository(config);
        }

        public SkillFullInfo GetSkillInfo(AUO.TechDev.Web.Domain.Skill.Skill req)
        {
            var skill = skillRepository.GetSkill(req.SkillID);
            var roadmaps = skillRepository.GetSkillRoadmap(req);
            var siteSettings = skillRepository.GetSkillSiteSetting(req);


            var result = new SkillFullInfo()
            {
                SkillID = skill.SkillID,
                SkillName = skill.SkillName,
                CreateFab = skill.Fab,
                CreateUserId = skill.UserID,
                SiteSettings = siteSettings,
                Roadmaps = roadmaps
            };

            return result;
        }

        public GetSkillFeedbackImpl GetSkillFeedbackImpls(AUO.TechDev.Web.Domain.Skill.Skill req)
        {
            var feedbackImpls = skillRepository.GetSkillFeedbackImpls(req);



            if (feedbackImpls.Count == 0)
                return null;

            var result = new GetSkillFeedbackImpl()
            {
                SkillID = feedbackImpls[0].SkillID,
                SkillName = feedbackImpls[0].SkillName,
                Fab = feedbackImpls[0].Fab,
                FeedbackImpls = feedbackImpls
            };

            return result;
        }

        public int UpsertSkillFeedbackImpls(GetSkillFeedbackImpl req)
        {
            var feedbackImpls = skillRepository.GetSkillFeedbackImpls(new AUO.TechDev.Web.Domain.Skill.Skill()
            {
                SkillID = req.SkillID,
                Fab = req.Fab
            });


            foreach (var item in req.FeedbackImpls)
            {
                item.SkillID = req.SkillID;
                item.Fab = req.Fab;
                item.UserID = req.UserID;
                item.Status = "Verifying";// 因為要走送審流程    
            }

            var feedbackImpledList = feedbackImpls.Where(o => o.ImplWay > 0);

            var updateRows = 0;
            if (feedbackImpledList.Count() == 0)
                updateRows = skillRepository.InsertSkillFeedbackImpls(req.FeedbackImpls);
            else if (req.FeedbackImpls.Count == feedbackImpledList.Count())
                updateRows = skillRepository.UpdateSkillFeedbackImpls(req.FeedbackImpls);
            else
            {
                //取出更新和新增的資料
                var updateList = new List<SkillFeedbackImpl>();
                var insertList = new List<SkillFeedbackImpl>();
                foreach (var item in req.FeedbackImpls)
                {
                    var isItemExist = feedbackImpledList.Where(o => o.SkillRoadmapID == item.SkillRoadmapID).Count() == 1;
                    if (isItemExist)
                        updateList.Add(item);
                    else
                        insertList.Add(item);
                }
                updateRows = skillCustomRepository.UpsertSkillFeedbackImpls(updateList, insertList);
            }

            if (updateRows == req.FeedbackImpls.Count)
            {
                //TODO:送審-呼叫FlowER
                return updateRows;
            }
            else
            {
                throw new Exception("Update rows is diff");
            }

        }


        public List<GetSkillFeedbackImplSummary> GetSkillFeedbackImpSummary(string site, List<string> skillIds)
        {
            var feedbackImpls = skillRepository.GetSkillFeedbackImplWithSummary(site, skillIds);


            var orderbyDatas = feedbackImpls
                                .OrderBy(o => o.Site)
                                .ThenBy(o => o.SkillID)
                                .ThenBy(o => o.SkillRoadmapID)
                                .ThenBy(o => o.Fab);


            var groupbyDatas = from c in orderbyDatas
                               group c by new
                               {
                                   c.Site,
                                   c.SkillID,
                                   c.SkillName,
                                   c.SkillRoadmapID,
                                   c.SkillRoadmapName,
                               } into g
                               select new GetSkillFeedbackImplSummary()
                               {

                                   Site = g.Key.Site,
                                   SkillID = g.Key.SkillID,
                                   SkillName = g.Key.SkillName,
                                   SkillRoadmapID = g.Key.SkillRoadmapID,
                                   SkillRoadmapName = g.Key.SkillRoadmapName,
                                   FeedbackImpls = g.ToList(),
                               };


            return groupbyDatas.ToList();
        }

        //Skill設定給不同Fab的情境
        public GetSkillFeedbackImplSummaryV2 GetSkillFeedbackImpSummaryV2(string site, List<string> skillIds)
        {
            var feedbackImpls = skillRepository.GetSkillFeedbackImplWithSummary(site, skillIds);


            var orderbyDatas = feedbackImpls
                                .OrderBy(o => o.Site)
                                .ThenBy(o => o.SkillID)
                                .ThenBy(o => o.SkillRoadmapID)
                                .ThenBy(o => o.Fab);


            var groupbyDatas = from c in orderbyDatas
                               group c by new
                               {
                                   c.Site,
                                   c.SkillID,
                                   c.SkillName,
                                   c.SkillRoadmapID,
                                   c.SkillRoadmapName,
                               } into g
                               select new GetSkillFeedbackImplSummary()
                               {

                                   Site = g.Key.Site,
                                   SkillID = g.Key.SkillID,
                                   SkillName = g.Key.SkillName,
                                   SkillRoadmapID = g.Key.SkillRoadmapID,
                                   SkillRoadmapName = g.Key.SkillRoadmapName,
                                   FeedbackImpls = g.ToList(),
                               };


            var SkillFeedbackImplSummarys = groupbyDatas.ToList();


            var allFabs = skillRepository.GetSkillSiteSettingBySiteAndSkill(site, skillIds);

            foreach (var data in SkillFeedbackImplSummarys)
            {
                var newFeedbackImpls = new List<SkillFeedbackImpSummary>();

                foreach (var fab in allFabs)
                {
                    var feedback = data.FeedbackImpls.Where(o => o.Fab == fab).FirstOrDefault();

                    if (feedback == null)
                    {
                        feedback = new SkillFeedbackImpSummary()
                        {
                            Fab = fab,
                            ImplWay = null
                        };

                    }
                    newFeedbackImpls.Add(feedback);
                }
                data.FeedbackImpls = newFeedbackImpls;
            }

            var result = new GetSkillFeedbackImplSummaryV2();
            result.Fabs = allFabs;
            result.SkillFeedbackImplSummarys = SkillFeedbackImplSummarys;

            return result;
        }

        public void UpdateSkillInfo(SkillFullInfo skillInfo)
        {

            AUO.TechDev.Web.Domain.Skill.Skill skill = new AUO.TechDev.Web.Domain.Skill.Skill()
            {
                SkillID = skillInfo.SkillID.Value
            };

            var skillFullInfo = GetSkillInfo(skill);






        }

    }
}
