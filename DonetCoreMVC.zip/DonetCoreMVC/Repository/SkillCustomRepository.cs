using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using AUO.TechDev.Web.Domain;
using AUO.TechDev.Web.Domain.Skill;
using AUO.TechDev.Web.Repository.Dapper_ORM;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace AUO.TechDev.Web.Repository
{
    public class SkillCustomRepository
    {

        private readonly IConfiguration _config;

        public SkillCustomRepository(IConfiguration config)
        {
            _config = config;
        }

        private string Connectionstring = "TechDevDatabase";


        public int InsertSkillFullInfo(SkillFullInfo skillFullInfo)
        {

            Skill skill = new Skill()
            {
                SkillName = skillFullInfo.SkillName,
                Fab = skillFullInfo.CreateFab,
                Status = "Offline",
                UserID = skillFullInfo.CreateUserId
            };
            List<SkillSiteSetting> stiteSettings = skillFullInfo.SiteSettings;
            List<SkillRoadmap> skillRoadmaps = skillFullInfo.Roadmaps;


            string insertSkillSQL = @"INSERT INTO [dbo].[Skill]
                                     ([SkillName]
                                     ,[Description]
                                     ,[Status]
                                     ,[Fab]                                   
                                     ,[UserID]
                                     )
                                       VALUES
                                     (@SkillName
                                     ,@Description
                                     ,@Status
                                     ,@Fab                                   
                                     ,@UserID )
                                     
                                     SELECT CAST(SCOPE_IDENTITY() as int)  ";


            string insertSiteSettingSQL = @"INSERT INTO [dbo].[SkillSiteSetting]
                                         ([SkillID]
                                         ,[Fab]                                        
                                         ,[UserID])
                                   VALUES
                                         (@SkillID
                                         ,@Fab                                       
                                         ,@UserID)";

            string insertRoadmapSQL = @"INSERT INTO [dbo].[SkillRoadmap]
                                        ([SkillRoadmapName]
                                        ,[SkillID]
                                        ,[Description]
                                        ,[Type]
                                        ,[Fab]                                      
                                        ,[UserID])
                                  VALUES
                                        (@SkillRoadmapName
                                        ,@SkillID
                                        ,@Description
                                        ,@Type
                                        ,@Fab                                      
                                        ,@UserID)";


            int skiillId = skillFullInfo.SkillID == null ? 0 : skillFullInfo.SkillID.Value;
            using IDbConnection db = new SqlConnection(_config.GetConnectionString(Connectionstring));
            try
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using var tran = db.BeginTransaction();
                try
                {
                    //Insert Skill    

                    if (skiillId == 0)
                    {
                        skiillId = db.ExecuteScalar<int>(insertSkillSQL, skill, transaction: tran, commandType: CommandType.Text);
                    }

                    //Insert SiteSettings
                    var sitesDatas = stiteSettings.Select(c => { c.SkillID = skiillId; c.UserId = skillFullInfo.CreateUserId; return c; }).ToList();
                    var siteAffectedRows = db.Execute(insertSiteSettingSQL, sitesDatas, transaction: tran, commandType: CommandType.Text);

                    //Insert SkillRoadmaps
                    var roadmapDatas = skillRoadmaps.Select(c =>
                    {
                        c.SkillID = skiillId;
                        c.Fab = skillFullInfo.CreateFab;
                        c.UserId = skillFullInfo.CreateUserId;
                        return c;
                    }).ToList();
                    var roadmapAffectedRows = db.Execute(insertRoadmapSQL, roadmapDatas, transaction: tran, commandType: CommandType.Text);

                    tran.Commit();
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }

            return skiillId;
        }



        public int UpsertSkillFeedbackImpls(List<SkillFeedbackImpl> updateList, List<SkillFeedbackImpl> insertList)
        {


            string updateSQL = @"UPDATE [dbo].[SkillFeedbackImpl]
                            SET [ImplWay] = @ImplWay
                               ,[Comment] = @Comment
                               ,[Status] = @Status
                               ,[UserID] = @UserID     
                               ,[LastUpdateDate] = getutcdate()
                            WHERE  [SkillID] = @SkillID 
                            and  [SkillRoadmapID] = @SkillRoadmapID 
                            and [Fab] = @Fab
                                     
                            SELECT CAST(SCOPE_IDENTITY() as int)  ";



            string insertSQL = @"INSERT INTO [dbo].[SkillFeedbackImpl]
                             ([SkillID]
                             ,[SkillRoadmapID]
                             ,[Fab]                            
                             ,[ImplWay]
                             ,[Comment]
                             ,[Status]
                             ,[UserID]
                             )
                       VALUES
                             (@SkillID
                             ,@SkillRoadmapID
                             ,@Fab                           
                             ,@ImplWay
                             ,@Comment
                             ,@Status
                             ,@UserID
                            )
                                     
                             SELECT CAST(SCOPE_IDENTITY() as int)  ";


            int totalUpdateRowCount = 0;
            using IDbConnection db = new SqlConnection(_config.GetConnectionString(Connectionstring));
            try
            {
                if (db.State == ConnectionState.Closed)
                    db.Open();

                using var tran = db.BeginTransaction();
                try
                {
                    var updateRowCount = db.Execute(updateSQL, updateList, transaction: tran, commandType: CommandType.Text);

                    if (updateRowCount != updateList.Count)
                        throw new Exception("Update row count is diff");

                    var insertRowCount = db.Execute(insertSQL, insertList, transaction: tran, commandType: CommandType.Text);

                    if (insertRowCount != insertList.Count)
                        throw new Exception("Update row count is diff");

                    totalUpdateRowCount = updateRowCount + insertRowCount;
                    tran.Commit();
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }

            return totalUpdateRowCount;
        }
    }
}
