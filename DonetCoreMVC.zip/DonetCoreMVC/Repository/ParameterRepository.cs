using System.Collections.Generic;
using System.Data;
using AUO.TechDev.Web.Domain.Parameter;

using AUO.TechDev.Web.Repository.Dapper_ORM;
using Dapper;


namespace AUO.TechDev.Web.Repository
{
    public class ParameterRepository
    {

        private readonly IDapper _dapper;

        public ParameterRepository(IDapper dapper)
        {            
                _dapper = dapper;
        }
        public List<ParameterSetting> GetParameters(List<string> types)
        {

            string sql = @"SELECT [ParaID]
                                 ,[ParaVal]
                                 ,[Type]    
                             FROM [AuoTechDev].[dbo].[ParameterSetting]
                             where Type IN @types";

            var dynamicParams = new DynamicParameters();
            dynamicParams.Add("types",types);

            var result = _dapper.GetAll<ParameterSetting>(sql, dynamicParams, commandType: CommandType.Text);
            return result;
        }  

         public List<Constant> GetConstant(string type)
        {

            string sql = @"SELECT [Name]
                                 ,[Value]      
                             FROM [AuoTechDev].[dbo].[Constant]
                             where [Type]=@type";

            var dynamicParams = new DynamicParameters();
            dynamicParams.Add("Type",type);

            var result = _dapper.GetAll<Constant>(sql, dynamicParams, commandType: CommandType.Text);
            return result;
        }  
    }
}
