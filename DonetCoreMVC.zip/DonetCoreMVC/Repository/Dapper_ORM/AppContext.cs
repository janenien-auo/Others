using System;
using Microsoft.EntityFrameworkCore;

namespace AUO.TechDev.Web.Repository.Dapper_ORM
{
     public class AppContext : DbContext  
    {  
        public AppContext() { }  
        public AppContext(DbContextOptions<AppContext> options) : base(options) { }  
    }  
}
