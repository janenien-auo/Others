using System;

namespace AUO.TechDev.Web.Repository.Base
{
    public interface ISkillRepository
    {
    
       
    }
}
