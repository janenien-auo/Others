using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using AUO.TechDev.Web.Domain;
using AUO.TechDev.Web.Domain.Skill;
using AUO.TechDev.Web.Repository.Dapper_ORM;
using Dapper;


namespace AUO.TechDev.Web.Repository
{
    public class SkillRepository
    {

        private readonly IDapper _dapper;

        public SkillRepository(IDapper dapper)
        {
            _dapper = dapper;
        }
        public List<Skill> GetSkills(Skill req)
        {

            string sql = @"SELECT [SkillID]
                        ,[SkillName]
                        ,[Description]
                        ,[Status]
                        ,[Fab]	                  
                        ,[UserID]
                        ,[CreationDate]
                        ,[LastUpdateDate]
                        FROM [dbo].[Skill]
                         where Fab = 'MMFA' or Fab=@Fab";

            var dynamicParams = new DynamicParameters();
            dynamicParams.AddDynamicParams(req);

            var result = _dapper.GetAll<Skill>(sql, dynamicParams, commandType: CommandType.Text);
            return result;
        }

        public Skill GetSkill(int skillId)
        {

            string sql = @"SELECT top(1) [SkillID]
                                        ,[SkillName]     
                                        ,[Fab]
                                        ,[UserID]     
                                    FROM [dbo].[Skill]
                                    where SkillID=@SkillID";

            var dynamicParams = new DynamicParameters();
            dynamicParams.Add("SkillID", skillId);

            var result = _dapper.Get<Skill>(sql, dynamicParams, commandType: CommandType.Text);
            return result;
        }


        public int CreateSkills(Skill req)
        {

            string sql = @"INSERT INTO [dbo].[Skill]
                        ([SkillName]
                        ,[Description]
                        ,[Status]
                        ,[Fab]                      
                        ,[UserID]
                         )
                         VALUES
                        (@SkillName
                        ,@Description
                        ,@Status
                        ,@Fab                       
                        ,@UserID
                        )";

            var dynamicParams = new DynamicParameters();
            dynamicParams.AddDynamicParams(req);

            var result = _dapper.Insert<int>(sql, dynamicParams, commandType: CommandType.Text);
            return result;
        }

        public List<SkillRoadmap> GetSkillRoadmap(Skill req)
        {

            string sql = @"SELECT s.[SkillID]
                              ,s.[SkillName]
                        	  ,r.[SkillRoadmapID]
                              ,r.[SkillRoadmapName]
                        	  ,r.[Description]
                        	  ,r.[Type]
                        	  ,r.[Fab]	 
                        	  ,case when(
                        	      SELECT top 1 [ImplWay]
                                  FROM [dbo].[SkillFeedbackImpl]
                                  where SkillID=@SkillID and SkillRoadmapID=r.SkillRoadmapID
                        	    )  
                        		 IS NULL then 0
                        		else 1
                        		end as IsUse
                          FROM [dbo].[Skill] as s 
                          inner join  [dbo].[SkillRoadmap] as r on s.SkillID=r.SkillID  
                          where s.[SkillID]= @SkillID";

            var dynamicParams = new DynamicParameters();
            dynamicParams.AddDynamicParams(req);

            var result = _dapper.GetAll<SkillRoadmap>(sql, dynamicParams, commandType: CommandType.Text);
            return result;
        }


        public List<SkillSiteSetting> GetSkillSiteSetting(Skill req)
        {

            string sql = @"SELECT [SkillID]
                       ,[Fab]                         
                   FROM [dbo].[SkillSiteSetting]
                   where [SkillID]=@SkillID";

            var dynamicParams = new DynamicParameters();
            dynamicParams.AddDynamicParams(req);

            var result = _dapper.GetAll<SkillSiteSetting>(sql, dynamicParams, commandType: CommandType.Text);
            return result;
        }


        public List<SkillFeedbackImpl> GetSkillFeedbackImpls(Skill req)
        {

            string sql = @"SELECT s.[SkillID]
                                  ,s.[SkillName]
                                  ,r.[SkillRoadmapID]
                            	  ,r.[SkillRoadmapName]     
                                  ,f.[ImplWay]
                                  ,f.[Comment]
                                  ,f.[Status]
                                  ,f.[UserID]
                            	  ,f.[Fab]  	   
                              FROM   [dbo].[Skill] as s 
                              inner join  [dbo].[SkillRoadmap] as r on s.[SkillID]=r.[SkillID]
                              left join  [dbo].[SkillFeedbackImpl] as f on f.[SkillRoadmapID]=r.[SkillRoadmapID] and f.Fab=@Fab
                              where s.SkillID=@SkillID ";

            var dynamicParams = new DynamicParameters();
            dynamicParams.AddDynamicParams(req);

            var result = _dapper.GetAll<SkillFeedbackImpl>(sql, dynamicParams, commandType: CommandType.Text);
            return result;
        }

        public int UpdateSkillFeedbackImpls(List<SkillFeedbackImpl> items)
        {

            string sql = @"UPDATE [dbo].[SkillFeedbackImpl]
                            SET [ImplWay] = @ImplWay
                               ,[Comment] = @Comment
                               ,[Status] = @Status
                               ,[UserID] = @UserID     
                               ,[LastUpdateDate] = getutcdate()
                          WHERE  [SkillID] = @SkillID 
                            and  [SkillRoadmapID] = @SkillRoadmapID 
                            and [Fab] = @Fab";


            var result = _dapper.Execute(sql, items.ToArray<Object>(), commandType: CommandType.Text);
            return result;
        }

        public int InsertSkillFeedbackImpls(List<SkillFeedbackImpl> items)
        {

            string sql = @"INSERT INTO [dbo].[SkillFeedbackImpl]
                             ([SkillID]
                             ,[SkillRoadmapID]
                             ,[Fab]                            
                             ,[ImplWay]
                             ,[Comment]
                             ,[Status]
                             ,[UserID]
                             )
                       VALUES
                             (@SkillID
                             ,@SkillRoadmapID
                             ,@Fab                           
                             ,@ImplWay
                             ,@Comment
                             ,@Status
                             ,@UserID
                            )";

            var result = _dapper.Execute(sql, items.ToArray<Object>(), commandType: CommandType.Text);
            return result;
        }



        public List<SkillFeedbackImpSummary> GetSkillFeedbackImplWithSummary(string site, List<string> skillIds)
        {

            string sql = @"SELECT  c2.Name as Site
                                   ,f.[SkillID]
                                   ,s.[SkillName]
                                   ,f.[SkillRoadmapID]
                            	   ,r.[SkillRoadmapName]
                                   ,r.Type as [Level]
                                   ,f.[Fab]                                  
                                   ,f.[ImplWay]
                            	   ,c.[Value] as [Weight]
                                   ,f.[Comment]
                                   ,f.[Status]       
                              FROM [AuoTechDev].[dbo].[SkillFeedbackImpl] as f 
                              inner join  [dbo].[SkillRoadmap] as r on f.[SkillRoadmapID]=r.[SkillRoadmapID]
                              inner join  [dbo].[Skill] as s  on  f.SkillID=s.SkillID
                              inner join  [dbo].[Constant] as c on c.[Type]='IMPL_WAY' and f.[ImplWay]=c.[Name]
                              inner join  [dbo].[Constant] as c2 on c2.[Type]='SITE' and f.[Fab]=c2.Value
                              where f.fab in (
                              SELECT  [Value] as Fab      
                              FROM [dbo].[Constant]
                              where [Type]='SITE' and [Name]=@Site
                              ) and f.[SkillID] in @SkillID";

            var dynamicParams = new DynamicParameters();
            dynamicParams.Add("Site", site);
            dynamicParams.Add("SkillID", skillIds);

            var result = _dapper.GetAll<SkillFeedbackImpSummary>(sql, dynamicParams, commandType: CommandType.Text);
            return result;
        }


        public List<string> GetSkillSiteSettingBySiteAndSkill(string site, List<string> skillIds)
        {

            string sql = @"SELECT distinct [Fab]     
                                 FROM [dbo].[SkillSiteSetting] as s
                                 inner join  [dbo].[Constant] as c2 on c2.[Type]='SITE' and s.[Fab]=c2.Value
                                 where SkillID in @SkillID and c2.[Name]=@Site 
                                  ORDER BY [Fab] ";

            var dynamicParams = new DynamicParameters();
            dynamicParams.Add("Site", site);
            dynamicParams.Add("SkillID", skillIds);

            var result = _dapper.GetAll<string>(sql, dynamicParams, commandType: CommandType.Text);
            return result;
        }
    }
}
