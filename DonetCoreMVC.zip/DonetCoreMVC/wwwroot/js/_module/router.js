


//Path請統一定義小寫
var routerPages = {
    name: "首頁",
    path: "/home/index",
    class: "fas fa-home",
    layer: 1,
    children: [
        {
            name: "技術深度",
            path: "/dashboard/deep",
            class: "fas fa-tachometer-alt",
            layer: 2
        },
        {
            name: "技術廣度",
            path: "/dashboard/width",
            class: "fas fa-tachometer-alt",
            layer: 2
        },
        {
            name: "落地衡量彙總表",
            path: "/dashboard/feedbacksummary",
            class: "fas fa-tachometer-alt",
            layer: 2
        },
        {
            name: "技能清單",
            path: "/skill/skilllist",
            class: "fas fa-list",
            layer: 2,
            children: [
                {
                    name: "技能建立表",
                    path: "/skill/createskill",
                    class: "fas fa-list-alt",
                    layer: 3,
                },
                {
                    name: "落地衡量表",
                    path: "/skill/feedbackimpl",
                    class: "fas fa-edit",
                    layer: 3,
                }
            ]
        }
    ]
};

var currentRouters = [];

function getRouters() {
    currentRouters = [];

    var currentPage = window.location.pathname.toLowerCase();

    findCurrentPath(currentPage, routerPages.children, routerPages);

}

var currentPages = [];
function findCurrentPath(currentPath, pages, self) {


    //因此次沒有Home頁，所以先Mark
    // if (self.layer == 1) {//root頁
    //     currentRouters.push({
    //         name: routerPages.name,
    //         path: routerPages.path,
    //         class: routerPages.class
    //     });
    // }

    var findItme = false;

    currentPages = pages;

    currentPages.filter(function (item, index) {

        if (currentPath == item.path) {
            currentRouters.push({
                name: item.name,
                path: item.path,
                class: item.class
            });
            findItme = true;
        }
        else if (item.children && !findItme) { //中階層
            currentRouters.push({
                name: item.name,
                path: item.path,
                class: item.class
            });
            return findCurrentPath(currentPath, item.children, item);
        }
        else if (!item.children && !findItme && currentPages.length - 1 == index) { //找到最末節點但依舊找不到，需要先把先前加入的item清除,並重新加上root節點
            currentRouters = [];
            currentRouters.push({
                name: routerPages.name,
                path: routerPages.path,
                class: routerPages.class
            });
        }
    })

}