var store = new Vuex.Store({
    state: {
        isApiTest:true,
        userInfo: {},
        showloading:false,
        routers : {
            name: "Home",
            path: "/Home/index",
            class: "fas fa-home",
            layer:1,
            children: [                         
                {
                    name: "技術深度",
                    path: "/Dashboard/Deep",
                    class: "fas fa-tachometer-alt",
                    layer: 2
                },
                {
                    name: "技術廣度",
                    path: "/Dashboard/Width",
                    class: "fas fa-tachometer-alt",
                    layer: 2
                },
                {
                    name: "Feedback Summary",
                    path: "/Dashboard/FeedbackSummary",
                    class: "fas fa-tachometer-alt",
                    layer: 2
                },
                {
                    name: "Skill",
                    path: "/Skill/SkillList",
                    class: "fas fa-list",   
                    layer: 2,
                    children: [
                        {
                            name: "Create Skill",
                            path: "/Skill/CreateSkill",
                            class: "fas fa-list-alt",
                            layer: 3,
                        },
                        {
                            name: "Feedback Implement",
                            path: "/Skill/FeedbackImpl",
                            class: "fas fa-edit",
                            layer: 3,
                        }
                    ]
                }
            ]
        },
    },
    mutations: {
        setUserInfo: function (state, value) {
            state.userInfo = value;
            window.localStorage.setItem('userInfo', JSON.stringify(value));
        },
        setShowLoading: function (state, value) {
            state.showloading = value;          
        }
    },
    getters: {
        getUserInfo: function (state) {
            if (!state.userInfo) {
                var json = window.localStorage.getItem('userInfo');
                state.userInfo = JSON.parse(json);
            }               

            return state.userInfo
        },
        getIsApiTest: function (state) {
            return state.isApiTest
        },
        getShowLoading: function (state) {
            return state.showloading
        }
    }
});