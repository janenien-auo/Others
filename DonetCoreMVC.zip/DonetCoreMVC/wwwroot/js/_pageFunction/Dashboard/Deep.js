var deepApp = new Vue({
    el: "#deepApp",
    store: store,
    data: {
        //TODO:跟CAP對接取得Fab和UserId
        user_info: {
            fab: "MMFA",
            user_id: "2105182"
        },
        skillList: [],
        selectskills: [],
        sites: [],
        selectSite: "LCD1",
        skillScoreList: []
    },
    created: function () {
        this.getSite();
        this.getSkillList();
    },
    mounted: function () {
        this.init();
    },
    methods: {
        init: function () {
            //this.drawChart();
        },

        getSite: function () {
            var self = this;


            getSite(store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        self.sites = response.data.data;
                    }
                });
        },

        getSkillList: function () {
            var self = this;

            var params = {
                fab: self.user_info.fab
            };

            getSkillList(params, store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        self.skillList = response.data.data;


                        self.selectSite = self.sites[0].group;
                        self.selectskills.push(self.skillList[0].skill_id);

                        self.getDeep();
                    }
                });
        },

        getDeep: function () {
            var self = this;

            var params = {
                site: self.selectSite,
                skillIds: self.selectskills.join()
            };
            getDeep(params, store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        self.skillScoreList = response.data.data;
                        Vue.nextTick()
                            .then(function () {
                                self.drawAllChart();
                            })
                    }
                });
        },

        drawAllChart: function () {

            var self = this;
            this.skillScoreList.forEach(function (item) {
                self.drawChart(item);
            });

        },
        drawChart: function (data) {


            var title_text = data.skill_name;
            var yAxis_data = data.score_infos.map(function (item) {
                return item['fab'];
            });

            var series_data = data.score_infos.map(function (item) {
                return item['score'];
            });

            var option = {
                title: {
                    text: title_text,
                    textStyle: {
                        color: '#1cb3fc'
                    },

                },
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                grid: {
                    left: '3%',
                    right: '4%',
                    bottom: '3%',
                    containLabel: true
                },
                xAxis: {
                    type: 'value',
                    boundaryGap: [0, 0.01]
                },
                yAxis: {
                    type: 'category',
                    data: yAxis_data
                },
                series: [
                    {
                        name: '',
                        type: 'bar',
                        data: series_data,
                        color: '#0e4696'
                    }
                ]
            };
            //初始化echarts例項
            var myChart = echarts.init(document.getElementById('myChart' + data.skill_id));

            //使用制定的配置項和資料顯示圖表
            myChart.setOption(option);
        }


        // drawChart: function () {


        //     var option = {
        //         title: {
        //             text: '  Image Recognition  & Deep Learning',
        //             textStyle: {
        //                 color: '#1cb3fc'
        //             },

        //         },
        //         tooltip: {
        //             trigger: 'axis',
        //             axisPointer: {
        //                 type: 'shadow'
        //             }
        //         },
        //         grid: {
        //             left: '3%',
        //             right: '4%',
        //             bottom: '3%',
        //             containLabel: true
        //         },
        //         xAxis: {
        //             type: 'value',
        //             boundaryGap: [0, 0.01]
        //         },
        //         yAxis: {
        //             type: 'category',
        //             data: ['3C', '4A', '5A', '6A', '7A', '8A']
        //         },
        //         series: [
        //             {
        //                 name: '',
        //                 type: 'bar',
        //                 data: [1.6, 4, 2.8, 3.2, 2, 3.2],
        //                 color: '#0e4696'
        //             }
        //         ]
        //     };
        //     //初始化echarts例項
        //     var myChart1 = echarts.init(document.getElementById('myChart1'));
        //     var myChart2 = echarts.init(document.getElementById('myChart2'));
        //     var myChart3 = echarts.init(document.getElementById('myChart3'));
        //     var myChart4 = echarts.init(document.getElementById('myChart4'));
        //     var myChart5 = echarts.init(document.getElementById('myChart5'));
        //     var myChart6 = echarts.init(document.getElementById('myChart6'));
        //     var myChart7 = echarts.init(document.getElementById('myChart7'));
        //     var myChart8 = echarts.init(document.getElementById('myChart8'));

        //     //使用制定的配置項和資料顯示圖表
        //     myChart1.setOption(option);
        //     myChart2.setOption(option);
        //     myChart3.setOption(option);
        //     myChart4.setOption(option);
        //     myChart5.setOption(option);
        //     myChart6.setOption(option);
        //     myChart7.setOption(option);
        //     myChart8.setOption(option);

        // }


    }
});
