var widthApp = new Vue({
    el: "#widthApp",
    store: store,
    data: {
        //TODO:跟CAP對接取得Fab和UserId
        user_info: {
            fab: "MMFA",
            user_id: "2105182"
        },
        skillList: [],
        selectskills: [],
        sites: [],
        selectSite: "LCD1",
        skillScoreList: [],
        groupSetting:3,
        skillScoreList_Group: []
    },
    created: function () {
        this.getSite();
        this.getSkillList();
    },
    mounted: function () {
        this.init();
    },
    methods: {
        init: function () {
            //this.drawChart();
        },

        getSite: function () {
            var self = this;


            getSite(store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        self.sites = response.data.data;
                    }
                });
        },

        getSkillList: function () {
            var self = this;

            var params = {
                fab: self.user_info.fab
            };

            getSkillList(params, store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        self.skillList = response.data.data;


                        self.selectSite = self.sites[0].group;
                        self.selectskills.push(self.skillList[0].skill_id);

                        self.getWidth();
                    }
                });
        },

        getWidth: function () {
            var self = this;

            var params = {
                site: self.selectSite,
                skillIds: self.selectskills.join()
            };
            getWidth(params, store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        self.skillScoreList = response.data.data;
                        self.skillScoreList_Group = self.group(self.skillScoreList, self.groupSetting);

                        Vue.nextTick()
                            .then(function () {
                                self.drawAllChart();
                            })
                    }
                });
        },

        drawAllChart: function () {

            var self = this;
            this.skillScoreList.forEach(function (item) {
                self.drawChart(item);
            });

        },
        drawChart: function (data) {

            var maxVal = 1;
            var title_text = data.skill_name;

            //準備Base的資料
            var indicatorBase = [];
            var series_data_Base = [];
            data.score_infos[0].scores.forEach(function (item) {
                indicatorBase.push({
                    name: item.fab,
                    max: maxVal
                })

                series_data_Base.push(item.score);
            });

            //準備Future的資料
            var indicatorFuture = [];
            var series_data_Future = [];
            data.score_infos[1].scores.forEach(function (item) {
                indicatorFuture.push({
                    name: item.fab,
                    max: maxVal
                })

                series_data_Future.push(item.score);
            });
          
            var radar_bg = "#052037";
            var radar_line = "#1CB3FC";

            option = {
                "title": {
                    "text": title_text,
                    textStyle: {
                        fontSize: "15",
                        color: '#07cafb'
                    }
                },
                "radar": [
                    {
                        "indicator": indicatorBase,
                        "center": [
                            "50%",
                            "25%"
                        ],
                        "radius": 120,
                        "startAngle": 90,
                        "splitNumber": 4,
                        "splitArea": {
                            "areaStyle": {
                                "color": [
                                    radar_bg
                                ]
                            }
                        }
                    },
                    {
                        "indicator": indicatorFuture,
                        "center": [
                            "50%",
                            "70%"
                        ],
                        "radius": 120,
                        "startAngle": 90,
                        "splitNumber": 4,
                        "splitArea": {
                            "areaStyle": {
                                "color": [
                                    radar_bg
                                ]
                            }
                        }
                    }
                ],
                "series": [
                    {
                        "name": "Base",
                        "type": "radar",
                        "radarIndex": 0,
                        "data": [
                            {
                                "value": series_data_Base,
                                lineStyle: {
                                    color: radar_line
                                }
                            }
                        ],
                        label: {
                            show: true,
                            color: "#63d4f1"
                        }
                    },
                    {
                        "name": "Future",
                        "type": "radar",
                        "radarIndex": 1,
                        "data": [
                            {
                                "value": series_data_Future,
                                lineStyle: {
                                    color: radar_line
                                }
                            }
                        ],
                        label: {
                            show: true,
                            color: "#63d4f1"
                        }
                    }
                ]
            };


            //初始化echarts例項
            var myChart = echarts.init(document.getElementById('myChart' + data.skill_id));

            //使用制定的配置項和資料顯示圖表
            myChart.setOption(option);
        },


        group: function (array, subGroupLength) {
            var index = 0;
            var newArray = [];

            while (index < array.length) {
                newArray.push(array.slice(index, index += subGroupLength));
            }

            return newArray;
        }

    }
});
