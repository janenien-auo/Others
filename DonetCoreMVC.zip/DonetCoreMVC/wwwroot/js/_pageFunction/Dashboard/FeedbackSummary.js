

var feedbackSummaryApp = new Vue({
    el: "#feedbackSummaryApp",
    store: store,
    data: {
        //TODO:跟CAP對接取得Fab和UserId
        user_info: {
            fab: "MMFA",
            user_id: "2105182"
        },
        skillList: [],
        selectskills: [],
        sites: [],
        selectSite: "LCD1",
        skillFeedbackImplList: [],
        showList: [],
        pagination: {
            current_page: 1,
            page_size: 10,
            total: 100
        },
        fabColumns: []
    },
    created: function () {
        this.getSite();
        this.getSkillList();
    },
    mounted: function () {
        this.init();
    },
    methods: {
        init: function () {

        },

        getSite: function () {
            var self = this;


            getSite(store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        self.sites = response.data.data;
                    }
                });
        },

        getSkillList: function () {
            var self = this;

            var params = {
                fab: self.user_info.fab
            };

            getSkillList(params, store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        self.skillList = response.data.data;


                        self.selectSite = self.sites[0].group;
                        self.selectskills.push(self.skillList[0].skill_id);

                        self.getFeedbackImplSummary();
                    }
                });
        },

        getFeedbackImplSummary: function () {
            var self = this;

            var params = {
                site: self.selectSite,
                skillIds: self.selectskills.join()
            };
            getFeedbackImplSummaryV2(params, store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        self.skillFeedbackImplList = response.data.data.skill_feedback_impl_summarys;
                        self.fabColumns=response.data.data.fabs;
                        self.pagination.total = self.skillFeedbackImplList.length;
                       
                        self.handleCurrentChange(1);
                    }
                });
        },
        handleCurrentChange: function (current_page) {
            var startIndex = (current_page - 1) * this.pagination.page_size;
            var endIndex = current_page * this.pagination.page_size;
            if (endIndex > this.skillFeedbackImplList.length) {
                endIndex = this.skillFeedbackImplList.length;
            }
            this.showList = this.skillFeedbackImplList.slice(startIndex, endIndex);

        },

        getIcon: function (impl_way) {

            switch (impl_way) {
                case "1":
                    {
                        return 'fas fa-crown';
                    }
                case "2":
                    {
                        return 'fas fa-gem';
                    }
                case "3":
                    {
                        return 'fas fa-circle';
                    }
                case "4":
                    {
                        return 'fas fa-times-circle';
                    }

                default:
                    return '';
            }

        },

        getStyle: function (impl_way) {
            switch (impl_way) {
                case "1":
                    {
                        return 'color:red';
                    }
                case "2":
                    {
                        return 'color:blue;';
                    }
                case "3":
                    {
                        return 'color:yellow;';
                    }
                case "4":
                    {
                        return 'color:Gray;';
                    }

                default:
                    return '';
            }
        },

        exportExcel: function () {

            window.open('/api/skill/ExportExcel?site=' + this.selectSite + "&skillIds=" + this.selectskills.join());
        }

      
    }
});
