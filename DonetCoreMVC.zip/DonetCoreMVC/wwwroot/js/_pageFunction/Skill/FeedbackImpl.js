
var feedbackImplApp = new Vue({
    el: "#feedbackImplApp",
    store: store,
    data: {
        //TODO:跟CAP對接取得Fab和UserId
        user_info: {
            fab: "L6A_Cell",
            user_id: "2105182"
        },
        skill_id: null,
        impl_options: [],
        feedbackImpls_info: {}
    },
    mounted: function () {
        this.init();
    },
    methods: {
        init: function () {

            store.commit('setShowLoading', true);

            this.getImplwayOption();
            //確認Url有帶skillid
            this.skill_id = getUrlParameterByName("skill_id", window.location.href.toLocaleLowerCase());
            if (this.skill_id) {
                this.getFeedbackimpl();
                
            }
            else {
                //TODO:不能沒有SkillID顯示錯誤訊息，返回前一頁
            }

            store.commit('setShowLoading', false);
        },

        getFeedbackimpl: function () {
            var self = this;

            var params = {
                skill_id: self.skill_id,
                fab: self.user_info.fab
            };
            getFeedbackimpl(params, store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        self.feedbackImpls_info = response.data.data;

                    }
                });
        },

        getImplwayOption: function () {
            var self = this;

            var params = {
                types: "IMPL_WAY"
            };

            getImplwayOption(params, store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        self.impl_options = response.data.data[0].values;
                    }
                });
        },



        save: function () {
            var self = this;
            this.$confirm('確定要儲存嗎?', '提示', {
                confirmButtonText: '確定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(function () {
                self.UpdateFeedbackimpl();
            })
        },

        UpdateFeedbackimpl: function () {
            var self = this;

            //TODO:欄位檢查
        
            store.commit('setShowLoading', true);

            self.feedbackImpls_info.user_id = self.user_info.user_id;
            self.feedbackImpls_info.fab = self.user_info.fab;
            UpdateFeedbackimpl(this.feedbackImpls_info, store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        store.commit('setShowLoading', false);

                        //顯示更新成功，轉導到SkillList
                        self.$message({
                            type: 'success',
                            message: '儲存成功'
                        });

                        setInterval(function () {
                            window.location.href = "/skill/SkillList";
                        }, 1000);

                    }
                });

        }


    }
});
