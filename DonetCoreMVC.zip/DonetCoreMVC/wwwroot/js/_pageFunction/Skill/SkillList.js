

var skillListApp = new Vue({
    el: "#skillListApp",
    store: store,
    data: {
         //TODO:跟CAP對接取得Fab和UserId
         user_info: {
            fab: "MMFA",
            user_id: "2105182"
        },
        skillAllList: [],
        showList: [],
        pagination: {
            current_page: 1,
            page_size: 10,
            total: 100
        }
    },
    mounted: function () {
        this.init();
    },
    methods: {
        init: function () {
            this.getSkillList();
        },

        getSkillList: function () {
            var self = this;

            var params = {
                fab: self.user_info.fab
            };
            getSkillList(params, store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        self.skillAllList = response.data.data;
                        self.pagination.total = self.skillAllList.length;
                        self.handleCurrentChange(1);
                    }
                });
        },
        viewSkillInfo: function (row) {
            window.location.href = "/skill/createSkill" + "?skill_id=" + row.skill_id;
        },
        viewRoadmap:function(row){
            window.location.href = "/skill/FeedbackImpl" + "?skill_id=" + row.skill_id;
        },
        handleCurrentChange: function (current_page) {
            var startIndex = (current_page - 1) * this.pagination.page_size;
            var endIndex = current_page * this.pagination.page_size;
            if (endIndex > this.skillAllList.length) {
                endIndex = this.skillAllList.length;
            }
            this.showList = this.skillAllList.slice(startIndex, endIndex);

        }
    }
});
