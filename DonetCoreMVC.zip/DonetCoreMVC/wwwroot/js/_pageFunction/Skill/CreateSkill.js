//1.MMFA和廠端都可以建立技能
//2.MMFA和廠端都可以設定Roadmap,但已經新增如果儲存就不能刪除，下次修改只能新增
//3.廠端不可修改MMFA的Roadmap
//4.MMFA需要設定哪些廠端要填寫,第一次新增可以任意修改，但儲存後就不能刪除，只能新增，避免廠端已經填寫回饋表
//5.廠端建立的技能廠端自己填寫
//6.已經被廠端回饋的Roadmap不能刪除



var createSkillApp = new Vue({
    el: "#createSkillApp",
    store: store,
    data: {
        //TODO:跟CAP對接取得Fab和UserId
        user_info: {
            fab: "MMFA",
            user_id: "2105182"
        },
        skill_info: {
            skill_id: null,
            skill_name: "",
            create_fab: "",
            create_stage: null,
            create_user_id: "",
            site_settings: [],
            roadmaps: []
        },
        /*設定Fab */
        allfabs: [],
        origin_select_fabs: [],
        can_select_fabs: [],
        select_fabs: [],
        /*設定Roadmap */
        origin_set_roadmaps: [],
        new_set_roadmaps: [],
        newRoadmap: {
            skill_roadmap_name: "",
            description: "",
            type: "",
            fab: "",
            user_id: ""
        }
    },
    mounted: function () {
        this.init();
    },
    methods: {
        init: function () {
            this.getFabs();
            //確認Url有帶skillid,skillid有值代表修改，沒值代表新增
            this.skill_info.skill_id = getUrlParameterByName("skill_id", window.location.href.toLocaleLowerCase());
            if (this.skill_info.skill_id) {
                this.getSkillInfo();
            }
            else {
                //如果建立者是MMFA就預設所有廠區都要填寫，如果市廠端自己建立就是建立的廠端自己要填寫
                if (this.user_info.fab == "MMFA") {
                    this.can_select_fabs = this.allfabs;
                    this.select_fabs = this.allfabs;
                } else {
                    this.select_fabs.push(this.user_info.fab);
                }
            }
        },

        getSkillInfo: function () {
            var self = this;

            var params = {
                skill_id: self.skill_info.skill_id
            };
            getSkillInfo(params, store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        self.skill_info = response.data.data;

                        //取得前一次設定的Fab
                        self.skill_info.site_settings.forEach(function (item) {
                            self.origin_select_fabs.push(item.fab);
                        });

                        //設定這次編輯可以選擇的Fab
                        self.allfabs.forEach(function (fab) {
                            if (self.origin_select_fabs.indexOf(fab) == -1) {
                                self.can_select_fabs.push(fab);
                            }
                        });

                        self.origin_set_roadmaps = self.skill_info.roadmaps;

                    }
                });
        },

        getFabs: function () {
            var self = this;


            self.allfabs = [];
            self.skill_info.site_settings = [];
            getSite(store.getters.getIsApiTest)
                .then(function (response) {
                    if (response.data.status == "success") {
                        var sites = response.data.data;
                        sites.forEach(function (site) {
                            site.fabs.forEach(function (fab) {
                                self.allfabs.push(fab);
                            });
                        });

                    }
                });
        },

        save: function () {
            var self = this;
            this.$confirm('確定要儲存嗎?', '提示', {
                confirmButtonText: '確定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(function () {
                store.commit('setShowLoading', true);
                self.createSkill();
            })
        },

        createSkill: function () {
            var self = this;

            self.skill_info.create_fab=this.user_info.fab;
            self.skill_info.create_user_id=this.user_info.user_id;
            self.skill_info.site_settings = [];
            self.select_fabs.forEach(function (fab) {
                self.skill_info.site_settings.push({
                    fab: fab,
                    user_id: self.user_info.user_id
                });
            });

            self.skill_info.roadmaps = self.new_set_roadmaps;


            createSkill(this.skill_info, store.getters.getIsApiTest)
                .then(function (response) {

                    store.commit('setShowLoading', false);
                    if (response.data.status == "success") {
                        //顯示更新成功，轉導到SkillList
                        self.$message({
                            type: 'info',
                            message: '儲存成功'
                        });

                        window.location.href = "/skill/SkillList";
                    }


                });

        },

        addRoadmap: function (data) {
            this.newRoadmap.fab = this.user_info.fab;
            this.newRoadmap.user_id = this.user_info.user_id;

            var data = Object.assign({}, this.newRoadmap)
            this.new_set_roadmaps.push(data);
        },

        deleteRoadmap: function (data) {
            //TODO:清除new_set_roadmaps的資料


            var result = this.new_set_roadmaps.filter(function (item) {
                return item.skill_roadmap_name != data.skill_roadmap_name ||
                    item.description != data.description ||
                    item.type != data.type;

            });

            this.new_set_roadmaps = result;

        }


    }
});
