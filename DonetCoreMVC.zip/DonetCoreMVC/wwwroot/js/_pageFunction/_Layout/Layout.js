
var layoutApp = new Vue({
    el: "#layoutApp",
    store: store,
    data: {
        routers: []
       
    },
    computed: {
        showLoading:function() {
            return this.$store.getters.getShowLoading
        }      
    },  
    mounted: function () {
        this.init();
    },
    methods: {
        init: function () {
            this.getRouters();
        },

        getRouters: function () {
            //這些資訊設定在/js/_module/router.js
            getRouters();
            this.routers = currentRouters;
        }
    }
});
