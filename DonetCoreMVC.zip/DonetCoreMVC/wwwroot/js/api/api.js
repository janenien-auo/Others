/*定義axios config*/
var config = {
    // baseURL: "",
    timeout: 2000,

}

var request = axios.create(config);



function getSite(isApiTest) {

    var apiUrl = "/api/Parameter/GetSite";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(request);
    mock.onGet(apiUrl).reply(200, {
        "status": "success",
        "data": [
            {
                "group": "LCD1",
                "fabs": [
                    "L6A_Array",
                    "L3C",
                    "L4A",
                    "L5AB_Array",
                    "L5AB_Cell",
                    "L5C_Array",
                    "L5C_Cell",
                    "L6A_Cell"
                ]
            },
            {
                "group": "LCD2",
                "fabs": [
                    "L7A_Array",
                    "L8A_Array",
                    "L3A",
                    "L4A",
                    "L6B_Array",
                    "L6B_Cell",
                    "L7A_Cell",
                    "L7B_Array",
                    "L7B_Cell",
                    "L8A_Cell",
                    "L8B_Array",
                    "L8B_Cell"
                ]
            },
            {
                "group": "CF",
                "fabs": [
                    "L5C",
                    "CA45D",
                    "C5E",
                    "C6C"
                ]
            }
        ],
        "message": null
    });

    if (!isApiTest) {
        mock.restore();
    }

    return request.get(apiUrl);

}

function getWidth(query, isApiTest) {

    var apiUrl = "/api/Dashboard/GetWidth";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(request);
    mock.onGet(apiUrl).reply(200, {
        "status": "success",
        "data": [
            {
                "skill_id": 1,
                "skill_name": "Image Recognition&Deep Learning",
                "score_infos": [
                    {
                        "skill_id": 1,
                        "skill_name": "Image Recognition&Deep Learning",
                        "fab": null,
                        "level": "Base",
                        "scores": [
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L3C",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L4A",
                                "level": "Base",
                                "score": 0.67
                            },
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L5AB_Array",
                                "level": "Base",
                                "score": 0.67
                            },
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L5AB_Cell",
                                "level": "Base",
                                "score": 0.33
                            },
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L5C_Array",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L6A_Array",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L6A_Cell",
                                "level": "Base",
                                "score": 0.67
                            }
                        ]
                    },
                    {
                        "skill_id": 1,
                        "skill_name": "Image Recognition&Deep Learning",
                        "fab": null,
                        "level": "Future",
                        "scores": [
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L3C",
                                "level": "Future",
                                "score": 0.67
                            },
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L4A",
                                "level": "Future",
                                "score": 0.67
                            },
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L5AB_Array",
                                "level": "Future",
                                "score": 0.67
                            },
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L5AB_Cell",
                                "level": "Future",
                                "score": 0
                            },
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L5C_Array",
                                "level": "Future",
                                "score": 0.67
                            },
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L6A_Array",
                                "level": "Future",
                                "score": 0.5
                            },
                            {
                                "skill_id": 1,
                                "skill_name": "Image Recognition&Deep Learning",
                                "fab": "L6A_Cell",
                                "level": "Future",
                                "score": 0.33
                            }
                        ]
                    }
                ]
            },
            {
                "skill_id": 2,
                "skill_name": "Equipment Health Diagnosis設備預警",
                "score_infos": [
                    {
                        "skill_id": 2,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "fab": null,
                        "level": "Base",
                        "scores": [
                            {
                                "skill_id": 2,
                                "skill_name": "Equipment Health Diagnosis設備預警",
                                "fab": "L3C",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 2,
                                "skill_name": "Equipment Health Diagnosis設備預警",
                                "fab": "L4A",
                                "level": "Base",
                                "score": 0.67
                            },
                            {
                                "skill_id": 2,
                                "skill_name": "Equipment Health Diagnosis設備預警",
                                "fab": "L5AB_Array",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 2,
                                "skill_name": "Equipment Health Diagnosis設備預警",
                                "fab": "L6A_Array",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 2,
                                "skill_name": "Equipment Health Diagnosis設備預警",
                                "fab": "L6A_Cell",
                                "level": "Base",
                                "score": 1
                            }
                        ]
                    },
                    {
                        "skill_id": 2,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "fab": null,
                        "level": "Future",
                        "scores": [
                            {
                                "skill_id": 2,
                                "skill_name": "Equipment Health Diagnosis設備預警",
                                "fab": "L3C",
                                "level": "Future",
                                "score": 0
                            },
                            {
                                "skill_id": 2,
                                "skill_name": "Equipment Health Diagnosis設備預警",
                                "fab": "L4A",
                                "level": "Future",
                                "score": 1
                            },
                            {
                                "skill_id": 2,
                                "skill_name": "Equipment Health Diagnosis設備預警",
                                "fab": "L5AB_Array",
                                "level": "Future",
                                "score": 1
                            },
                            {
                                "skill_id": 2,
                                "skill_name": "Equipment Health Diagnosis設備預警",
                                "fab": "L6A_Array",
                                "level": "Future",
                                "score": 0
                            },
                            {
                                "skill_id": 2,
                                "skill_name": "Equipment Health Diagnosis設備預警",
                                "fab": "L6A_Cell",
                                "level": "Future",
                                "score": 1
                            }
                        ]
                    }
                ]
            },
            {
                "skill_id": 5,
                "skill_name": "Image Recognition&Deep Learning 5",
                "score_infos": [
                    {
                        "skill_id": 5,
                        "skill_name": "Image Recognition&Deep Learning 5",
                        "fab": null,
                        "level": "Base",
                        "scores": [
                            {
                                "skill_id": 5,
                                "skill_name": "Image Recognition&Deep Learning 5",
                                "fab": "L3C",
                                "level": "Base",
                                "score": 0
                            },
                            {
                                "skill_id": 5,
                                "skill_name": "Image Recognition&Deep Learning 5",
                                "fab": "L4A",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 5,
                                "skill_name": "Image Recognition&Deep Learning 5",
                                "fab": "L5AB_Array",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 5,
                                "skill_name": "Image Recognition&Deep Learning 5",
                                "fab": "L6A_Array",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 5,
                                "skill_name": "Image Recognition&Deep Learning 5",
                                "fab": "L6A_Cell",
                                "level": "Base",
                                "score": 1
                            }
                        ]
                    },
                    {
                        "skill_id": 5,
                        "skill_name": "Image Recognition&Deep Learning 5",
                        "fab": null,
                        "level": "Future",
                        "scores": [
                            {
                                "skill_id": 5,
                                "skill_name": "Image Recognition&Deep Learning 5",
                                "fab": "L3C",
                                "level": "Future",
                                "score": 0.33
                            },
                            {
                                "skill_id": 5,
                                "skill_name": "Image Recognition&Deep Learning 5",
                                "fab": "L4A",
                                "level": "Future",
                                "score": 0.67
                            },
                            {
                                "skill_id": 5,
                                "skill_name": "Image Recognition&Deep Learning 5",
                                "fab": "L5AB_Array",
                                "level": "Future",
                                "score": 1
                            },
                            {
                                "skill_id": 5,
                                "skill_name": "Image Recognition&Deep Learning 5",
                                "fab": "L6A_Array",
                                "level": "Future",
                                "score": 0.33
                            },
                            {
                                "skill_id": 5,
                                "skill_name": "Image Recognition&Deep Learning 5",
                                "fab": "L6A_Cell",
                                "level": "Future",
                                "score": 0.67
                            }
                        ]
                    }
                ]
            },
            {
                "skill_id": 17,
                "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                "score_infos": [
                    {
                        "skill_id": 17,
                        "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                        "fab": null,
                        "level": "Base",
                        "scores": [
                            {
                                "skill_id": 17,
                                "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                                "fab": "L3C",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 17,
                                "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                                "fab": "L4A",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 17,
                                "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                                "fab": "L5AB_Array",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 17,
                                "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                                "fab": "L6A_Array",
                                "level": "Base",
                                "score": 0.5
                            },
                            {
                                "skill_id": 17,
                                "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                                "fab": "L6A_Cell",
                                "level": "Base",
                                "score": 1
                            }
                        ]
                    },
                    {
                        "skill_id": 17,
                        "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                        "fab": null,
                        "level": "Future",
                        "scores": [
                            {
                                "skill_id": 17,
                                "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                                "fab": "L3C",
                                "level": "Future",
                                "score": 1
                            },
                            {
                                "skill_id": 17,
                                "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                                "fab": "L4A",
                                "level": "Future",
                                "score": 1
                            },
                            {
                                "skill_id": 17,
                                "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                                "fab": "L5AB_Array",
                                "level": "Future",
                                "score": 0.5
                            },
                            {
                                "skill_id": 17,
                                "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                                "fab": "L6A_Array",
                                "level": "Future",
                                "score": 0
                            },
                            {
                                "skill_id": 17,
                                "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                                "fab": "L6A_Cell",
                                "level": "Future",
                                "score": 1
                            }
                        ]
                    }
                ]
            },
            {
                "skill_id": 1013,
                "skill_name": "Image Recognition&Deep Learning-Test0616-1701",
                "score_infos": [
                    {
                        "skill_id": 1013,
                        "skill_name": "Image Recognition&Deep Learning-Test0616-1701",
                        "fab": null,
                        "level": "Base",
                        "scores": [
                            {
                                "skill_id": 1013,
                                "skill_name": "Image Recognition&Deep Learning-Test0616-1701",
                                "fab": "L3C",
                                "level": "Base",
                                "score": 0.5
                            },
                            {
                                "skill_id": 1013,
                                "skill_name": "Image Recognition&Deep Learning-Test0616-1701",
                                "fab": "L4A",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 1013,
                                "skill_name": "Image Recognition&Deep Learning-Test0616-1701",
                                "fab": "L5AB_Array",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 1013,
                                "skill_name": "Image Recognition&Deep Learning-Test0616-1701",
                                "fab": "L6A_Array",
                                "level": "Base",
                                "score": 1
                            },
                            {
                                "skill_id": 1013,
                                "skill_name": "Image Recognition&Deep Learning-Test0616-1701",
                                "fab": "L6A_Cell",
                                "level": "Base",
                                "score": 1
                            }
                        ]
                    },
                    {
                        "skill_id": 1013,
                        "skill_name": "Image Recognition&Deep Learning-Test0616-1701",
                        "fab": null,
                        "level": "Future",
                        "scores": [
                            {
                                "skill_id": 1013,
                                "skill_name": "Image Recognition&Deep Learning-Test0616-1701",
                                "fab": "L3C",
                                "level": "Future",
                                "score": 0
                            },
                            {
                                "skill_id": 1013,
                                "skill_name": "Image Recognition&Deep Learning-Test0616-1701",
                                "fab": "L4A",
                                "level": "Future",
                                "score": 0
                            },
                            {
                                "skill_id": 1013,
                                "skill_name": "Image Recognition&Deep Learning-Test0616-1701",
                                "fab": "L5AB_Array",
                                "level": "Future",
                                "score": 0.5
                            },
                            {
                                "skill_id": 1013,
                                "skill_name": "Image Recognition&Deep Learning-Test0616-1701",
                                "fab": "L6A_Array",
                                "level": "Future",
                                "score": 1
                            },
                            {
                                "skill_id": 1013,
                                "skill_name": "Image Recognition&Deep Learning-Test0616-1701",
                                "fab": "L6A_Cell",
                                "level": "Future",
                                "score": 1
                            }
                        ]
                    }
                ]
            }
        ],
        "message": null
    });

    if (!isApiTest) {
        mock.restore();
    }

    return request.get(apiUrl, { params: query });
}

function getDeep(query, isApiTest) {

    var apiUrl = "/api/Dashboard/GetDeep";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(request);
    mock.onGet(apiUrl).reply(200, {
        "status": "success",
        "data": [
            {
                "skill_id": 1,
                "skill_name": "Image Recognition&Deep Learning",
                "fab": null,
                "score_infos": [
                    {
                        "skill_id": 1,
                        "skill_name": "Image Recognition&Deep Learning",
                        "fab": "L3C",
                        "level": null,
                        "score": 6.83
                    },
                    {
                        "skill_id": 1,
                        "skill_name": "Image Recognition&Deep Learning",
                        "fab": "L4A",
                        "level": null,
                        "score": 6.67
                    },
                    {
                        "skill_id": 1,
                        "skill_name": "Image Recognition&Deep Learning",
                        "fab": "L5AB_Array",
                        "level": null,
                        "score": 6.67
                    },
                    {
                        "skill_id": 1,
                        "skill_name": "Image Recognition&Deep Learning",
                        "fab": "L5AB_Cell",
                        "level": null,
                        "score": 1.67
                    },
                    {
                        "skill_id": 1,
                        "skill_name": "Image Recognition&Deep Learning",
                        "fab": "L5C_Array",
                        "level": null,
                        "score": 7.17
                    },
                    {
                        "skill_id": 1,
                        "skill_name": "Image Recognition&Deep Learning",
                        "fab": "L6A_Array",
                        "level": null,
                        "score": 5.75
                    },
                    {
                        "skill_id": 1,
                        "skill_name": "Image Recognition&Deep Learning",
                        "fab": "L6A_Cell",
                        "level": null,
                        "score": 3.5
                    }
                ]
            },
            {
                "skill_id": 2,
                "skill_name": "Equipment Health Diagnosis設備預警",
                "fab": null,
                "score_infos": [
                    {
                        "skill_id": 2,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "fab": "L3C",
                        "level": null,
                        "score": 5.75
                    },
                    {
                        "skill_id": 2,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "fab": "L4A",
                        "level": null,
                        "score": 7.5
                    },
                    {
                        "skill_id": 2,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "fab": "L5AB_Array",
                        "level": null,
                        "score": 5
                    },
                    {
                        "skill_id": 2,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "fab": "L6A_Array",
                        "level": null,
                        "score": 5.75
                    },
                    {
                        "skill_id": 2,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "fab": "L6A_Cell",
                        "level": null,
                        "score": 9
                    }
                ]
            },
            {
                "skill_id": 3,
                "skill_name": "Equipment Health Diagnosis設備預警2",
                "fab": null,
                "score_infos": [
                   
                    {
                        "skill_id": 3,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "fab": "L6A_Array",
                        "level": null,
                        "score": 5.75
                    },
                    {
                        "skill_id": 3,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "fab": "L6A_Cell",
                        "level": null,
                        "score": 9
                    }
                ]
            },
            {
                "skill_id": 4,
                "skill_name": "Equipment Health Diagnosis",
                "fab": null,
                "score_infos": [
                   
                    {
                        "skill_id": 4,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "fab": "L6A_Array",
                        "level": null,
                        "score":8
                    },
                    {
                        "skill_id": 4,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "fab": "L6A_Cell",
                        "level": null,
                        "score": 6
                    }
                ]
            }
        ],
        "message": null
    });

    if (!isApiTest) {
        mock.restore();
    }

    return request.get(apiUrl, { params: query });
}


function getSkillList(query, isApiTest) {

    var apiUrl = "/api/skill/list";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(request);
    mock.onGet(apiUrl).reply(200, {
        "status": "success",
        "data": [
            {
                "skill_id": 1,
                "skill_name": "Image Recognition&Deep Learning",
                "description": "",
                "status": "Online",
                "fab": "MMFA",
                "user_id": "2105182",
                "last_update_date": "06/06/2021 05:46:30"
            },
            {
                "skill_id": 2,
                "skill_name": "Equipment Health Diagnosis設備預警",
                "description": "",
                "status": "Offline",
                "fab": "MMFA",
                "user_id": "2105182",
                "last_update_date": "06/06/2021 05:46:30"
            },
            {
                "skill_id": 3,
                "skill_name": "Prediction & Virtual Metrology預測預警",
                "description": "",
                "status": "Online",
                "fab": "L6A_Array",
                "user_id": "2105182",
                "last_update_date": "06/06/2021 05:46:30"
            },
            {
                "skill_id": 5,
                "skill_name": "Image Recognition&Deep Learning2",
                "description": "test2",
                "status": "Offline",
                "fab": "MMFA",
                "user_id": "2105182",
                "last_update_date": "06/09/2021 14:12:02"
            },
            {
                "skill_id": 6,
                "skill_name": "Image Recognition&Deep Learning2",
                "description": "test2",
                "status": "Offline",
                "fab": "MMFA",
                "user_id": "2105182",
                "last_update_date": "06/09/2021 14:13:54"
            },
            {
                "skill_id": 7,
                "skill_name": "Image Recognition&Deep Learning2",
                "description": "test2",
                "status": "Offline",
                "fab": "MMFA",
                "user_id": "2105182",
                "last_update_date": "06/09/2021 14:18:31"
            },
            {
                "skill_id": 17,
                "skill_name": "Image Recognition&Deep Learning-Test0614-1103",
                "description": null,
                "status": "Offline",
                "fab": "MMFA",
                "user_id": "2105182",
                "last_update_date": "06/14/2021 03:51:51"
            },
            {
                "skill_id": 8,
                "skill_name": "Image Recognition&Deep Learning2",
                "description": "test2",
                "status": "Offline",
                "fab": "MMFA",
                "user_id": "2105182",
                "last_update_date": "06/09/2021 14:20:21"
            },
            {
                "skill_id": 9,
                "skill_name": "Image Recognition&Deep Learning2",
                "description": "test2",
                "status": "Offline",
                "fab": "MMFA",
                "user_id": "2105182",
                "last_update_date": "06/09/2021 14:21:42"
            },
            {
                "skill_id": 10,
                "skill_name": "Image Recognition&Deep Learning2",
                "description": "test2",
                "status": "Offline",
                "fab": "MMFA",
                "user_id": "2105182",
                "last_update_date": "06/09/2021 14:24:41"
            },
            {
                "skill_id": 11,
                "skill_name": "Image Recognition&Deep Learning2",
                "description": "test2",
                "status": "Offline",
                "fab": "MMFA",
                "user_id": "2105182",
                "last_update_date": "06/09/2021 14:25:05"
            }
        ],
        "message": null
    });

    if (!isApiTest) {
        mock.restore();
    }

    return request.get(apiUrl, { params: query });
}

function getImplwayOption(query, isApiTest) {

    var apiUrl = "/api/Parameter/GetParameters";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(request);
    mock.onGet(apiUrl).reply(200, {
        "status": "success",
        "data": [
            {
                "type": "IMPL_WAY",
                "values": [
                    {
                        "para_id": 1,
                        "para_val": "學產&技術Team0->-1開發",
                        "type": "IMPL_WAY"
                    },
                    {
                        "para_id": 2,
                        "para_val": "獨立進行 (副廠下單位自行平展1->N)",
                        "type": "IMPL_WAY"
                    },
                    {
                        "para_id": 3,
                        "para_val": "共同進行 (與副廠之外的單位合作1->N",
                        "type": "IMPL_WAY"
                    },
                    {
                        "para_id": 4,
                        "para_val": "未使用",
                        "type": "IMPL_WAY"
                    }
                ]
            },
            {
                "type": "SKILL_TYPE",
                "values": [
                    {
                        "para_id": 5,
                        "para_val": "底層技術Base",
                        "type": "SKILL_TYPE"
                    },
                    {
                        "para_id": 6,
                        "para_val": "進階技術Future",
                        "type": "SKILL_TYPE"
                    }
                ]
            }
        ],
        "message": null
    });

    if (!isApiTest) {
        mock.restore();
    }

    return request.get(apiUrl, { params: query });
}


function getSkillInfo(query, isApiTest) {

    var apiUrl = "/api/skill/SkillInfo";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(request);
    mock.onGet(apiUrl).reply(200, {
        "status": "success",
        "data": {
            "skill_id": 1,
            "skill_name": "Image Recognition&Deep Learning",
            "create_fab": null,
            "create_user_id": null,
            "site_settings": [
                {
                    "skill_id": 1,
                    "fab": "L6A_Array",
                    "user_id": null
                },
                {
                    "skill_id": 1,
                    "fab": "L6A_CF",
                    "user_id": null
                },
                {
                    "skill_id": 1,
                    "fab": "L7A_Array",
                    "user_id": null
                }
            ],
            "roadmaps": [
                {
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 1,
                    "skill_roadmap_name": "Defect Generation",
                    "description": "缺陷生成（增量集），針對缺陷少見且資料缺乏，生成相同特徵的缺陷",
                    "type": "Base",
                    "fab": null,
                    "user_id": null
                },
                {
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 2,
                    "skill_roadmap_name": "Model Transformation",
                    "description": "不同產品Ｍodel進行AI模型轉移",
                    "type": "Base",
                    "fab": null,
                    "user_id": null
                },
                {
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 3,
                    "skill_roadmap_name": "Reinforcement Learning",
                    "description": "增強學習，目前使用在Array Auto repair",
                    "type": "Future",
                    "fab": null,
                    "user_id": null
                },
                {
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 4,
                    "skill_roadmap_name": "AVI Application (Moire, Demura, Mura Judge)",
                    "description": "自動偵測檢查，主要為應用在光箱為主",
                    "type": "Future",
                    "fab": null,
                    "user_id": null
                }
            ]
        },
        "message": null
    });

    if (!isApiTest) {
        mock.restore();
    }

    return request.get(apiUrl, { params: query });
}

function createSkill(data, isApiTest) {

    var apiUrl = "/api/skill/CreateSkillFullInfo";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(request);
    mock.onPost(apiUrl).reply(200, {
        "status": "success",
        "data": null,
        "message": null
    });

    if (!isApiTest) {
        mock.restore();
    }

    return request.post(apiUrl, data);
}

function getFeedbackimpl(query, isApiTest) {

    var apiUrl = "/api/skill/FeedbackImpls";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(request);
    mock.onGet(apiUrl).reply(200, {
        "status": "success",
        "data": {
            "skill_id": 1,
            "skill_name": "Image Recognition&Deep Learning",
            "user_id": null,
            "fab": "L6A_Array",
            "feedback_impls": [
                {
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 1,
                    "skill_roadmap_name": "Defect Generation",
                    "impl_way": "3",
                    "comment": "智控中心Alarm code文字偵測/解析/ 推薦Action, 目前無熟悉NLP人員",
                    "status": "Verifying",
                    "user_id": "2105182",
                    "fab": "L6A_Array"
                },
                {
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 2,
                    "skill_roadmap_name": "Model Transformation",
                    "impl_way": "2",
                    "comment": "2021年產學專案:低成本室內定位技術應用於FAB之即時安全監控與進階工位管理(Array提出)",
                    "status": "Verifying",
                    "user_id": "2105182",
                    "fab": "L6A_Array"
                },
                {
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 3,
                    "skill_roadmap_name": "Reinforcement Learning",
                    "impl_way": "3",
                    "comment": "沒有需求",
                    "status": "Verifying",
                    "user_id": "2105182",
                    "fab": "L6A_Array"
                },
                {
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 4,
                    "skill_roadmap_name": "AVI Application (Moire, Demura, Mura Judge)",
                    "impl_way": "3",
                    "comment": "沒有需求",
                    "status": "Verifying",
                    "user_id": "2105182",
                    "fab": "L6A_Array"
                }
            ]
        },
        "message": null
    });

    if (!isApiTest) {
        mock.restore();
    }

    return request.get(apiUrl, { params: query });
}

function UpdateFeedbackimpl(data, isApiTest) {

    var apiUrl = "/api/skill/UpsertSkillFeedbackImpls";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(request);
    mock.onPost(apiUrl).reply(200, {
        "status": "success",
        "data": null,
        "message": null
    });

    if (!isApiTest) {
        mock.restore();
    }

    return request.post(apiUrl, data);
}


function getFeedbackImplSummary(query, isApiTest) {

    var apiUrl = "/api/skill/SkillFeedbackImplSummary";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(request);
    mock.onGet(apiUrl).reply(200, {
        "status": "success",
        "data": [
            {
                "site": "LCD1",
                "skill_id": 1,
                "skill_name": "Image Recognition&Deep Learning",
                "skill_roadmap_id": 1,
                "skill_roadmap_name": "Defect Generation",
                "feedback_impls": [
                    {
                        "site": "LCD1",
                        "skill_id": 1,
                        "skill_name": "Image Recognition&Deep Learning",
                        "skill_roadmap_id": 1,
                        "skill_roadmap_name": "Defect Generation",
                        "level": "Base",
                        "impl_way": "3",
                        "weight": 5,
                        "comment": "智控中心Alarm code文字偵測/解析/ 推薦Action, 目前無熟悉NLP人員",
                        "status": "Verifying",
                        "user_id": null,
                        "fab": "L6A_Array"
                    }
                ]
            },
            {
                "site": "LCD1",
                "skill_id": 1,
                "skill_name": "Image Recognition&Deep Learning",
                "skill_roadmap_id": 2,
                "skill_roadmap_name": "Model Transformation",
                "feedback_impls": [
                    {
                        "site": "LCD1",
                        "skill_id": 1,
                        "skill_name": "Image Recognition&Deep Learning",
                        "skill_roadmap_id": 2,
                        "skill_roadmap_name": "Model Transformation",
                        "level": "Base",
                        "impl_way": "2",
                        "weight": 8,
                        "comment": "2021年產學專案:低成本室內定位技術應用於FAB之即時安全監控與進階工位管理(Array提出)",
                        "status": "Verifying",
                        "user_id": null,
                        "fab": "L6A_Array"
                    }
                ]
            },
            {
                "site": "LCD1",
                "skill_id": 1,
                "skill_name": "Image Recognition&Deep Learning",
                "skill_roadmap_id": 3,
                "skill_roadmap_name": "Reinforcement Learning",
                "feedback_impls": [
                    {
                        "site": "LCD1",
                        "skill_id": 1,
                        "skill_name": "Image Recognition&Deep Learning",
                        "skill_roadmap_id": 3,
                        "skill_roadmap_name": "Reinforcement Learning",
                        "level": "Future",
                        "impl_way": "3",
                        "weight": 5,
                        "comment": "沒有需求",
                        "status": "Verifying",
                        "user_id": null,
                        "fab": "L6A_Array"
                    }
                ]
            },
            {
                "site": "LCD1",
                "skill_id": 1,
                "skill_name": "Image Recognition&Deep Learning",
                "skill_roadmap_id": 4,
                "skill_roadmap_name": "AVI Application (Moire, Demura, Mura Judge)",
                "feedback_impls": [
                    {
                        "site": "LCD1",
                        "skill_id": 1,
                        "skill_name": "Image Recognition&Deep Learning",
                        "skill_roadmap_id": 4,
                        "skill_roadmap_name": "AVI Application (Moire, Demura, Mura Judge)",
                        "level": "Future",
                        "impl_way": "3",
                        "weight": 5,
                        "comment": "沒有需求",
                        "status": "Verifying",
                        "user_id": null,
                        "fab": "L6A_Array"
                    }
                ]
            },
            {
                "site": "LCD1",
                "skill_id": 2,
                "skill_name": "Equipment Health Diagnosis設備預警",
                "skill_roadmap_id": 5,
                "skill_roadmap_name": "DAQ / IoT",
                "feedback_impls": [
                    {
                        "site": "LCD1",
                        "skill_id": 2,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "skill_roadmap_id": 5,
                        "skill_roadmap_name": "DAQ / IoT",
                        "level": "Base",
                        "impl_way": "1",
                        "weight": 10,
                        "comment": "ImplWay1",
                        "status": "Pass",
                        "user_id": null,
                        "fab": "L6A_Array"
                    }
                ]
            },
            {
                "site": "LCD1",
                "skill_id": 2,
                "skill_name": "Equipment Health Diagnosis設備預警",
                "skill_roadmap_id": 6,
                "skill_roadmap_name": "DAQ / Data Polling",
                "feedback_impls": [
                    {
                        "site": "LCD1",
                        "skill_id": 2,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "skill_roadmap_id": 6,
                        "skill_roadmap_name": "DAQ / Data Polling",
                        "level": "Base",
                        "impl_way": "3",
                        "weight": 5,
                        "comment": "ImplWay3",
                        "status": "Fail",
                        "user_id": null,
                        "fab": "L6A_Array"
                    }
                ]
            },
            {
                "site": "LCD1",
                "skill_id": 2,
                "skill_name": "Equipment Health Diagnosis設備預警",
                "skill_roadmap_id": 7,
                "skill_roadmap_name": "Audio Detect & Analysis",
                "feedback_impls": [
                    {
                        "site": "LCD1",
                        "skill_id": 2,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "skill_roadmap_id": 7,
                        "skill_roadmap_name": "Audio Detect & Analysis",
                        "level": "Base",
                        "impl_way": "2",
                        "weight": 8,
                        "comment": "ImplWay2",
                        "status": "Verifying",
                        "user_id": null,
                        "fab": "L6A_Array"
                    }
                ]
            },
            {
                "site": "LCD1",
                "skill_id": 2,
                "skill_name": "Equipment Health Diagnosis設備預警",
                "skill_roadmap_id": 8,
                "skill_roadmap_name": "Audio de-noise",
                "feedback_impls": [
                    {
                        "site": "LCD1",
                        "skill_id": 2,
                        "skill_name": "Equipment Health Diagnosis設備預警",
                        "skill_roadmap_id": 8,
                        "skill_roadmap_name": "Audio de-noise",
                        "level": "Future",
                        "impl_way": "4",
                        "weight": 0,
                        "comment": "沒有需求",
                        "status": "Pass",
                        "user_id": null,
                        "fab": "L6A_Array"
                    }
                ]
            }
        ],
        "message": null
    });

    if (!isApiTest) {
        mock.restore();
    }

    return request.get(apiUrl, { params: query });
}

function getFeedbackImplSummaryV2(query, isApiTest) {

    var apiUrl = "/api/skill/SkillFeedbackImplSummaryV2";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(request);
    mock.onGet(apiUrl).reply(200, {
        "status": "success",
        "data": {
            "fabs": [
                "L3C",
                "L4A",
                "L5AB_Array",
                "L5AB_Cell",
                "L5C_Array",
                "L6A_Array",
                "L6A_Cell"
            ],
            "skill_feedback_impl_summarys": [
                {
                    "site": "LCD1",
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 1,
                    "skill_roadmap_name": "Defect Generation",
                    "feedback_impls": [
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 1,
                            "skill_roadmap_name": "Defect Generation",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "T1",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L3C"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 1,
                            "skill_roadmap_name": "Defect Generation",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "L4A-Test1",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L4A"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 1,
                            "skill_roadmap_name": "Defect Generation",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "ss",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 1,
                            "skill_roadmap_name": "Defect Generation",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "ww",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Cell"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 1,
                            "skill_roadmap_name": "Defect Generation",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "uu",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5C_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 1,
                            "skill_roadmap_name": "Defect Generation",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "Test智控中心Alarm code文字偵測/解析/ 推薦Action, 目前無熟悉NLP人員",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 1,
                            "skill_roadmap_name": "Defect Generation",
                            "level": "Base",
                            "impl_way": "2",
                            "weight": 8,
                            "comment": "ImplWay2-update-0623",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Cell"
                        }
                    ]
                },
                {
                    "site": "LCD1",
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 2,
                    "skill_roadmap_name": "Model Transformation",
                    "feedback_impls": [
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 2,
                            "skill_roadmap_name": "Model Transformation",
                            "level": "Base",
                            "impl_way": "2",
                            "weight": 8,
                            "comment": "T2",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L3C"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 2,
                            "skill_roadmap_name": "Model Transformation",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "L4A-Test2",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L4A"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 2,
                            "skill_roadmap_name": "Model Transformation",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "ss",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 2,
                            "skill_roadmap_name": "Model Transformation",
                            "level": "Base",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "ww",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Cell"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 2,
                            "skill_roadmap_name": "Model Transformation",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "uu",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5C_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 2,
                            "skill_roadmap_name": "Model Transformation",
                            "level": "Base",
                            "impl_way": "2",
                            "weight": 8,
                            "comment": "Test2021年產學專案:低成本室內定位技術應用於FAB之即時安全監控與進階工位管理(Array提出)",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 2,
                            "skill_roadmap_name": "Model Transformation",
                            "level": "Base",
                            "impl_way": "2",
                            "weight": 8,
                            "comment": "ImplWay3-update-0623",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Cell"
                        }
                    ]
                },
                {
                    "site": "LCD1",
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 3,
                    "skill_roadmap_name": "Reinforcement Learning",
                    "feedback_impls": [
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 3,
                            "skill_roadmap_name": "Reinforcement Learning",
                            "level": "Future",
                            "impl_way": "3",
                            "weight": 5,
                            "comment": "T3",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L3C"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 3,
                            "skill_roadmap_name": "Reinforcement Learning",
                            "level": "Future",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "L4A-Test3",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L4A"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 3,
                            "skill_roadmap_name": "Reinforcement Learning",
                            "level": "Future",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "ss",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 3,
                            "skill_roadmap_name": "Reinforcement Learning",
                            "level": "Future",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "ww",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Cell"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 3,
                            "skill_roadmap_name": "Reinforcement Learning",
                            "level": "Future",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "uu",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5C_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 3,
                            "skill_roadmap_name": "Reinforcement Learning",
                            "level": "Future",
                            "impl_way": "3",
                            "weight": 5,
                            "comment": "沒有需求Test",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 3,
                            "skill_roadmap_name": "Reinforcement Learning",
                            "level": "Future",
                            "impl_way": "3",
                            "weight": 5,
                            "comment": "ImplWay3-update-0623",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Cell"
                        }
                    ]
                },
                {
                    "site": "LCD1",
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 4,
                    "skill_roadmap_name": "AVI Application (Moire, Demura, Mura Judge)",
                    "feedback_impls": [
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 4,
                            "skill_roadmap_name": "AVI Application (Moire, Demura, Mura Judge)",
                            "level": "Future",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "T4",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L3C"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 4,
                            "skill_roadmap_name": "AVI Application (Moire, Demura, Mura Judge)",
                            "level": "Future",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "L4A-Test4",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L4A"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 4,
                            "skill_roadmap_name": "AVI Application (Moire, Demura, Mura Judge)",
                            "level": "Future",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "ss",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 4,
                            "skill_roadmap_name": "AVI Application (Moire, Demura, Mura Judge)",
                            "level": "Future",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "ww",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Cell"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 4,
                            "skill_roadmap_name": "AVI Application (Moire, Demura, Mura Judge)",
                            "level": "Future",
                            "impl_way": "2",
                            "weight": 8,
                            "comment": "uu",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5C_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 4,
                            "skill_roadmap_name": "AVI Application (Moire, Demura, Mura Judge)",
                            "level": "Future",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "沒有需求Test",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 4,
                            "skill_roadmap_name": "AVI Application (Moire, Demura, Mura Judge)",
                            "level": "Future",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "沒有需求-update-0623",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Cell"
                        }
                    ]
                },
                {
                    "site": "LCD1",
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 17,
                    "skill_roadmap_name": "AA",
                    "feedback_impls": [
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 17,
                            "skill_roadmap_name": "AA",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "T5",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L3C"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 17,
                            "skill_roadmap_name": "AA",
                            "level": "Base",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "L4A-Test5",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L4A"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 17,
                            "skill_roadmap_name": "AA",
                            "level": "Base",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "ss",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 17,
                            "skill_roadmap_name": "AA",
                            "level": "Base",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "ww",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Cell"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 17,
                            "skill_roadmap_name": "AA",
                            "level": "Base",
                            "impl_way": "3",
                            "weight": 5,
                            "comment": "uu",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5C_Array"
                        },
                        {
                            "site": null,
                            "skill_id": 0,
                            "skill_name": null,
                            "skill_roadmap_id": 0,
                            "skill_roadmap_name": null,
                            "level": null,
                            "impl_way": null,
                            "weight": 0,
                            "comment": null,
                            "status": null,
                            "user_id": null,
                            "fab": "L6A_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 17,
                            "skill_roadmap_name": "AA",
                            "level": "Base",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "沒有需求0623",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Cell"
                        }
                    ]
                },
                {
                    "site": "LCD1",
                    "skill_id": 1,
                    "skill_name": "Image Recognition&Deep Learning",
                    "skill_roadmap_id": 18,
                    "skill_roadmap_name": "BB",
                    "feedback_impls": [
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 18,
                            "skill_roadmap_name": "BB",
                            "level": "Future",
                            "impl_way": "2",
                            "weight": 8,
                            "comment": "T6",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L3C"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 18,
                            "skill_roadmap_name": "BB",
                            "level": "Future",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "L4A-Test6",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L4A"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 18,
                            "skill_roadmap_name": "BB",
                            "level": "Future",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "ss",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 18,
                            "skill_roadmap_name": "BB",
                            "level": "Future",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "ww",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Cell"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 18,
                            "skill_roadmap_name": "BB",
                            "level": "Future",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "uu",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5C_Array"
                        },
                        {
                            "site": null,
                            "skill_id": 0,
                            "skill_name": null,
                            "skill_roadmap_id": 0,
                            "skill_roadmap_name": null,
                            "level": null,
                            "impl_way": null,
                            "weight": 0,
                            "comment": null,
                            "status": null,
                            "user_id": null,
                            "fab": "L6A_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 1,
                            "skill_name": "Image Recognition&Deep Learning",
                            "skill_roadmap_id": 18,
                            "skill_roadmap_name": "BB",
                            "level": "Future",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "沒有需求0623",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Cell"
                        }
                    ]
                },
                {
                    "site": "LCD1",
                    "skill_id": 2,
                    "skill_name": "Equipment Health Diagnosis設備預警",
                    "skill_roadmap_id": 5,
                    "skill_roadmap_name": "DAQ / IoT",
                    "feedback_impls": [
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 5,
                            "skill_roadmap_name": "DAQ / IoT",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": null,
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L3C"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 5,
                            "skill_roadmap_name": "DAQ / IoT",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": null,
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L4A"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 5,
                            "skill_roadmap_name": "DAQ / IoT",
                            "level": "Base",
                            "impl_way": "3",
                            "weight": 5,
                            "comment": null,
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Array"
                        },
                        {
                            "site": null,
                            "skill_id": 0,
                            "skill_name": null,
                            "skill_roadmap_id": 0,
                            "skill_roadmap_name": null,
                            "level": null,
                            "impl_way": null,
                            "weight": 0,
                            "comment": null,
                            "status": null,
                            "user_id": null,
                            "fab": "L5AB_Cell"
                        },
                        {
                            "site": null,
                            "skill_id": 0,
                            "skill_name": null,
                            "skill_roadmap_id": 0,
                            "skill_roadmap_name": null,
                            "level": null,
                            "impl_way": null,
                            "weight": 0,
                            "comment": null,
                            "status": null,
                            "user_id": null,
                            "fab": "L5C_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 5,
                            "skill_roadmap_name": "DAQ / IoT",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "ImplWay1",
                            "status": "Pass",
                            "user_id": null,
                            "fab": "L6A_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 5,
                            "skill_roadmap_name": "DAQ / IoT",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "ss",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Cell"
                        }
                    ]
                },
                {
                    "site": "LCD1",
                    "skill_id": 2,
                    "skill_name": "Equipment Health Diagnosis設備預警",
                    "skill_roadmap_id": 6,
                    "skill_roadmap_name": "DAQ / Data Polling",
                    "feedback_impls": [
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 6,
                            "skill_roadmap_name": "DAQ / Data Polling",
                            "level": "Base",
                            "impl_way": "2",
                            "weight": 8,
                            "comment": null,
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L3C"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 6,
                            "skill_roadmap_name": "DAQ / Data Polling",
                            "level": "Base",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": null,
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L4A"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 6,
                            "skill_roadmap_name": "DAQ / Data Polling",
                            "level": "Base",
                            "impl_way": "3",
                            "weight": 5,
                            "comment": null,
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Array"
                        },
                        {
                            "site": null,
                            "skill_id": 0,
                            "skill_name": null,
                            "skill_roadmap_id": 0,
                            "skill_roadmap_name": null,
                            "level": null,
                            "impl_way": null,
                            "weight": 0,
                            "comment": null,
                            "status": null,
                            "user_id": null,
                            "fab": "L5AB_Cell"
                        },
                        {
                            "site": null,
                            "skill_id": 0,
                            "skill_name": null,
                            "skill_roadmap_id": 0,
                            "skill_roadmap_name": null,
                            "level": null,
                            "impl_way": null,
                            "weight": 0,
                            "comment": null,
                            "status": null,
                            "user_id": null,
                            "fab": "L5C_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 6,
                            "skill_roadmap_name": "DAQ / Data Polling",
                            "level": "Base",
                            "impl_way": "3",
                            "weight": 5,
                            "comment": "ImplWay3",
                            "status": "Fail",
                            "user_id": null,
                            "fab": "L6A_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 6,
                            "skill_roadmap_name": "DAQ / Data Polling",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": "ss",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Cell"
                        }
                    ]
                },
                {
                    "site": "LCD1",
                    "skill_id": 2,
                    "skill_name": "Equipment Health Diagnosis設備預警",
                    "skill_roadmap_id": 7,
                    "skill_roadmap_name": "Audio Detect & Analysis",
                    "feedback_impls": [
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 7,
                            "skill_roadmap_name": "Audio Detect & Analysis",
                            "level": "Base",
                            "impl_way": "3",
                            "weight": 5,
                            "comment": null,
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L3C"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 7,
                            "skill_roadmap_name": "Audio Detect & Analysis",
                            "level": "Base",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": null,
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L4A"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 7,
                            "skill_roadmap_name": "Audio Detect & Analysis",
                            "level": "Base",
                            "impl_way": "3",
                            "weight": 5,
                            "comment": null,
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Array"
                        },
                        {
                            "site": null,
                            "skill_id": 0,
                            "skill_name": null,
                            "skill_roadmap_id": 0,
                            "skill_roadmap_name": null,
                            "level": null,
                            "impl_way": null,
                            "weight": 0,
                            "comment": null,
                            "status": null,
                            "user_id": null,
                            "fab": "L5AB_Cell"
                        },
                        {
                            "site": null,
                            "skill_id": 0,
                            "skill_name": null,
                            "skill_roadmap_id": 0,
                            "skill_roadmap_name": null,
                            "level": null,
                            "impl_way": null,
                            "weight": 0,
                            "comment": null,
                            "status": null,
                            "user_id": null,
                            "fab": "L5C_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 7,
                            "skill_roadmap_name": "Audio Detect & Analysis",
                            "level": "Base",
                            "impl_way": "2",
                            "weight": 8,
                            "comment": "ImplWay2",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 7,
                            "skill_roadmap_name": "Audio Detect & Analysis",
                            "level": "Base",
                            "impl_way": "2",
                            "weight": 8,
                            "comment": "ss",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Cell"
                        }
                    ]
                },
                {
                    "site": "LCD1",
                    "skill_id": 2,
                    "skill_name": "Equipment Health Diagnosis設備預警",
                    "skill_roadmap_id": 8,
                    "skill_roadmap_name": "Audio de-noise",
                    "feedback_impls": [
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 8,
                            "skill_roadmap_name": "Audio de-noise",
                            "level": "Future",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": null,
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L3C"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 8,
                            "skill_roadmap_name": "Audio de-noise",
                            "level": "Future",
                            "impl_way": "1",
                            "weight": 10,
                            "comment": null,
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L4A"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 8,
                            "skill_roadmap_name": "Audio de-noise",
                            "level": "Future",
                            "impl_way": "3",
                            "weight": 5,
                            "comment": null,
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L5AB_Array"
                        },
                        {
                            "site": null,
                            "skill_id": 0,
                            "skill_name": null,
                            "skill_roadmap_id": 0,
                            "skill_roadmap_name": null,
                            "level": null,
                            "impl_way": null,
                            "weight": 0,
                            "comment": null,
                            "status": null,
                            "user_id": null,
                            "fab": "L5AB_Cell"
                        },
                        {
                            "site": null,
                            "skill_id": 0,
                            "skill_name": null,
                            "skill_roadmap_id": 0,
                            "skill_roadmap_name": null,
                            "level": null,
                            "impl_way": null,
                            "weight": 0,
                            "comment": null,
                            "status": null,
                            "user_id": null,
                            "fab": "L5C_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 8,
                            "skill_roadmap_name": "Audio de-noise",
                            "level": "Future",
                            "impl_way": "4",
                            "weight": 0,
                            "comment": "沒有需求",
                            "status": "Pass",
                            "user_id": null,
                            "fab": "L6A_Array"
                        },
                        {
                            "site": "LCD1",
                            "skill_id": 2,
                            "skill_name": "Equipment Health Diagnosis設備預警",
                            "skill_roadmap_id": 8,
                            "skill_roadmap_name": "Audio de-noise",
                            "level": "Future",
                            "impl_way": "2",
                            "weight": 8,
                            "comment": "ss",
                            "status": "Verifying",
                            "user_id": null,
                            "fab": "L6A_Cell"
                        }
                    ]
                }
            ]
        },
        "message": null
    });

    if (!isApiTest) {
        mock.restore();
    }

    return request.get(apiUrl, { params: query });
}



