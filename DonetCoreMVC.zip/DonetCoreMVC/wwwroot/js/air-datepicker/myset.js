$('.datepicker-here').datepicker({
    autoClose: true,
})