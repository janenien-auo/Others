﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;


namespace AUO.TechDev.Web.Controllers
{
    public class SkillController : Controller
    {
        private readonly ILogger<SkillController> _logger;

        public SkillController(ILogger<SkillController> logger)
        {
            _logger = logger;
        }

        public IActionResult SkillList()
        {
            return View();
        }

        public IActionResult CreateSkill()
        {
            return View();
        }

         public IActionResult FeedbackImpl()
        {
            return View();
        }
      
    }
}
