using System;
using AUO.TechDev.Web.Domain;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;

namespace AUO.TechDev.Web.Controllers
{
    [TypeFilter(typeof(ResultFilter))]
    //[TypeFilter(typeof(ExceptionFilter))]
    public class ApiController : ControllerBase
    {
    }

    public class ResultFilter : IResultFilter
    {
        public void OnResultExecuting(ResultExecutingContext context)
        {
            if (context.Result is ObjectResult objectResult)
            {
                objectResult.Value = new JSend { status = "success", data = objectResult!=null ? objectResult.Value: null };
            }
        }
        public void OnResultExecuted(ResultExecutedContext context)
        {
        }
    }
}
