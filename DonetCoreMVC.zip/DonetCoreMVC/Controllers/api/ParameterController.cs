using System;
using System.Collections.Generic;
using System.Linq;
using AUO.TechDev.Web.Controllers;
using AUO.TechDev.Web.Domain;
using AUO.TechDev.Web.Domain.Parameter;
using AUO.TechDev.Web.Domain.Skill;
using AUO.TechDev.Web.Repository;
using AUO.TechDev.Web.Repository.Dapper_ORM;
using AUO.TechDev.Web.Service.Parameter;
using AUO.TechDev.Web.Service.Skill;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace AUO.TechDev.Web.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    public class ParameterController : ApiController
    {

        private readonly IDapper _dapper;       
         ParameterService parameterService;

        public ParameterController(IDapper dapper)
        {
            _dapper = dapper;            
             parameterService=new ParameterService(_dapper);
        }
     
        [HttpGet("GetParameters")]
        public ActionResult<List<GetParameterResponse>> Get(string types)
        {
            var result = parameterService.GetParameters(types.Split(',').ToList());

            return result;

        }  

         [HttpGet("GetSite")]
        public ActionResult<List<GetSiteResponse>> Get()
        {
            var result = parameterService.GetSite();

            return result;
        }  
    }
}
