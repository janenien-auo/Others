using System.Collections.Generic;
using System.Linq;
using AUO.TechDev.Web.Domain.Dashboard;
using AUO.TechDev.Web.Repository.Dapper_ORM;
using AUO.TechDev.Web.Service.Dashboard;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace AUO.TechDev.Web.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    public class DashboardController : ApiController
    {       
        DashboardService dsashboardService;

        public DashboardController(IDapper dapper, IConfiguration config)
        {            
            dsashboardService = new DashboardService(dapper);     
        }

       

        [HttpGet("GetDeep")]
        public ActionResult<List<GetDeepResponse>> GetDeep(string site,string skillIds)
        {
            List<string> ids=skillIds.Split(',').ToList();
            var result = dsashboardService.GetDeep(site,ids);

            return result;
        }   

         [HttpGet("GetWidth")]
        public ActionResult<List<GetWidthResponse>> GetWidth(string site,string skillIds)
        {
            List<string> ids=skillIds.Split(',').ToList();
            var result = dsashboardService.GetWidth(site,ids);

            return result;
        }   
    }
}
