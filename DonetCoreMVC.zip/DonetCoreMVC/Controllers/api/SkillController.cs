using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AUO.TechDev.Web.Controllers;
using AUO.TechDev.Web.Domain;
using AUO.TechDev.Web.Domain.Skill;
using AUO.TechDev.Web.Repository;
using AUO.TechDev.Web.Repository.Dapper_ORM;
using AUO.TechDev.Web.Service.Skill;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace AUO.TechDev.Web.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    public class SkillController : ApiController
    {
        SkillRepository skillRepository;
        SkillCustomRepository skillCustomRepository;
        SkillService skillService;

        public SkillController(IDapper dapper, IConfiguration config)
        {
            skillRepository = new SkillRepository(dapper);
            skillService = new SkillService(dapper,config);
            skillCustomRepository = new SkillCustomRepository(config);
        }


        [HttpGet("List")]
        public ActionResult<List<Skill>> Get(string fab, string stage)
        {
            var result = skillRepository.GetSkills(new Skill()
            {
                Fab = fab
            });

            return result;

        }

        [HttpGet("SkillInfo")]
        public ActionResult<SkillFullInfo> Get(int skill_id)
        {
            var result = skillService.GetSkillInfo(new Skill()
            {
                SkillID = skill_id
            });

            return result;
        }

        [HttpGet("FeedbackImpls")]
        public ActionResult<GetSkillFeedbackImpl> Get(int skill_id, string fab)
        {
            var result = skillService.GetSkillFeedbackImpls(new Skill()
            {
                SkillID = skill_id,
                Fab = fab
            });

            return result;
        }

        [HttpPost("CreateSkill")]
        public ActionResult<Skill> Post([FromBody] Skill skill)
        {
            var result = skillRepository.CreateSkills(skill);

            if (result >= 0) return null;
            else throw new Exception("No data insert");
        }


        [HttpPost("UpsertSkillFeedbackImpls")]
        public ActionResult<Skill> Post([FromBody] GetSkillFeedbackImpl feedbackImpls)
        {
            var result = skillService.UpsertSkillFeedbackImpls(feedbackImpls);

            if (result >= 0) return null;
            else throw new Exception("No data Update or Insert");
        }



        [HttpPost("CreateSkillFullInfo")]
        public ActionResult<Skill> Post([FromBody] SkillFullInfo skillFullInfo)
        {
            var result = skillCustomRepository.InsertSkillFullInfo(skillFullInfo);

            if (result >= 0) return null;
            else throw new Exception("No data Update or Insert");
        }

        [HttpGet("SkillFeedbackImplSummary")]
        public ActionResult<List<GetSkillFeedbackImplSummary>> GetSummary(string site, string skillIds)
        {

            List<string> ids = skillIds.Split(',').ToList();
            var result = skillService.GetSkillFeedbackImpSummary(site, ids);

            return result;
        }

        [HttpGet("SkillFeedbackImplSummaryV2")]
        public ActionResult<GetSkillFeedbackImplSummaryV2> GetSummaryV2(string site, string skillIds)
        {

            List<string> ids = skillIds.Split(',').ToList();
            var result = skillService.GetSkillFeedbackImpSummaryV2(site, ids);

            return result;
        }

        [HttpGet("ExportExcel")]
        public ActionResult ExportExcel(string site, string skillIds)
        {
            List<string> ids = skillIds.Split(',').ToList();
            var skillFeedbackImpSummary = skillService.GetSkillFeedbackImpSummaryV2(site, ids);

            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("FeedbackImp");
                var currentRow = 1;
                var currentColumnNo = 1;

                //準備第一欄資訊-欄位名稱
                worksheet.Cell(currentRow, currentColumnNo++).Value = "Site";
                worksheet.Cell(currentRow, currentColumnNo++).Value = "Skill Name";
                worksheet.Cell(currentRow, currentColumnNo++).Value = "Roadmap";

                foreach (var f in skillFeedbackImpSummary.Fabs)
                {
                    worksheet.Cell(currentRow, currentColumnNo++).Value = f;
                }

                //資料內容

                foreach (var data in skillFeedbackImpSummary.SkillFeedbackImplSummarys)
                {
                    currentColumnNo = 1;
                    currentRow++;
                    worksheet.Cell(currentRow, currentColumnNo++).Value = data.Site;
                    worksheet.Cell(currentRow, currentColumnNo++).Value = data.SkillName;
                    worksheet.Cell(currentRow, currentColumnNo++).Value = data.SkillRoadmapName;

                    foreach (var d in data.FeedbackImpls)
                    {
                        string val = "";

                        switch (d.ImplWay)
                        {
                            case "1":
                                val = "A";
                                break;
                            case "2":
                                val = "B";
                                break;
                            case "3":
                                val = "C";
                                break;
                            case "4":
                                val = "D";
                                break;
                            default:
                                val = "";
                                break;
                        }
                        worksheet.Cell(currentRow, currentColumnNo++).Value = val;
                    }
                }

                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    var content = stream.ToArray();

                    return File(
                        content,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "SkillFeedbackImplSummary.xlsx");
                }
            }
        }
    }
}
