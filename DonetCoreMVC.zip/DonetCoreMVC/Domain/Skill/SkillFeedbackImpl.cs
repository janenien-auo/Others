namespace AUO.TechDev.Web.Domain
{
    public class SkillFeedbackImpl
    {
        public int SkillID { get; set; }//*

        public string SkillName { get; set; }

        public int SkillRoadmapID { get; set; }//***

        public string SkillRoadmapName { get; set; }

        public int ImplWay { get; set; }//***     

        public string Comment { get; set; }//***

        public string Status { get; set; }//*

        public string UserID { get; set; }//*

        public string Fab { get; set; }//*      

    }
}