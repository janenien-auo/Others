namespace AUO.TechDev.Web.Domain
{
    public class SkillRoadmap
    {
        public int? SkillID { get; set; }

        public string SkillName { get; set; }

        public int? SkillRoadmapID { get; set; }

        public string SkillRoadmapName { get; set; }

        public string Description { get; set; }

        public string Type { get; set; }

        public string Fab { get; set; }
      
        public string UserId { get; set; }

        public bool IsUse { get; set; }


    }
}