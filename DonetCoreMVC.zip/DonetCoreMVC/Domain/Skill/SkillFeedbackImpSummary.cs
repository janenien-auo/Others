namespace AUO.TechDev.Web.Domain
{
    public class SkillFeedbackImpSummary
    {
        public string Site { get; set; }//*

        public int SkillID { get; set; }//*

        public string SkillName { get; set; }

        public int SkillRoadmapID { get; set; }//***

        public string SkillRoadmapName { get; set; }

        public string Level { get; set; }

        public string ImplWay { get; set; }//***     

        public int Weight { get; set; }//*

        public string Comment { get; set; }//***

        public string Status { get; set; }//*

        public string UserID { get; set; }//*

        public string Fab { get; set; }//*      

    }
}