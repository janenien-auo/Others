using System;
using System.Collections.Generic;

namespace AUO.TechDev.Web.Domain.Skill
{
    public class GetSkillFeedbackImpl
    {
        public int SkillID { get; set; }
        public string SkillName { get; set; }
        public string UserID { get; set; }

        public string Fab { get; set; }    

        public List<SkillFeedbackImpl> FeedbackImpls { get; set; }

    }
}
