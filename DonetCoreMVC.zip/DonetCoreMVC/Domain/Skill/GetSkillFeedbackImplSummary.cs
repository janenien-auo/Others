using System;
using System.Collections.Generic;

namespace AUO.TechDev.Web.Domain.Skill
{
    public class GetSkillFeedbackImplSummary
    {
        public string Site { get; set; }
        public int SkillID { get; set; }
        public string SkillName { get; set; }       
        public int SkillRoadmapID { get; set; }
        public string SkillRoadmapName { get; set; }

        public List<SkillFeedbackImpSummary> FeedbackImpls { get; set; }


    }
}
