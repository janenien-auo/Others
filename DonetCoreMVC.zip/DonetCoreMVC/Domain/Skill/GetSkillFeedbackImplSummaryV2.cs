using System;
using System.Collections.Generic;

namespace AUO.TechDev.Web.Domain.Skill
{
    public class GetSkillFeedbackImplSummaryV2
    {
        public List<string> Fabs { get; set; }     

        public List<GetSkillFeedbackImplSummary> SkillFeedbackImplSummarys { get; set; }

    }
}
