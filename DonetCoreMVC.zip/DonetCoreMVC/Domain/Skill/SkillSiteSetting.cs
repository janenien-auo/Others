namespace AUO.TechDev.Web.Domain
{
    public class SkillSiteSetting
    {
        public int? SkillID { get; set; }
        public string Fab { get; set; }      
        public string UserId { get; set; }
    }
}