using System;
using System.Collections.Generic;

namespace AUO.TechDev.Web.Domain.Skill
{
    public class SkillFullInfo
    {

        public  int? SkillID { get; set; }
        public string SkillName { get; set; }

        public string CreateFab{ get; set; }     

        public string CreateUserId{ get; set; }

        public List<SkillSiteSetting> SiteSettings { get; set; }

        public List<SkillRoadmap> Roadmaps { get; set; }


    }
}
