using System;
using Microsoft.AspNetCore.Mvc;

namespace AUO.TechDev.Web.Domain.Skill
{
    [BindProperties]
    public class Skill
    {
        public int SkillID { get; set; }

        public string SkillName { get; set; }

        public string Description { get; set; }

        public string Status { get; set; }

        public string Fab { get; set; }      

        public string UserID { get; set; }

        public string LastUpdateDate { get; set; }

    }
}
