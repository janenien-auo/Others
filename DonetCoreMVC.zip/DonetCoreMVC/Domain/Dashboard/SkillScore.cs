using System;
using Microsoft.AspNetCore.Mvc;

namespace AUO.TechDev.Web.Domain.Dashboard
{
    [BindProperties]
    public class SkillScore
    {

        public int SkillID { get; set; }

        public string SkillName { get; set; }

        public string Fab { get; set; }       

        public string Level { get; set; }

        public decimal Score { get; set; }

    }
}
