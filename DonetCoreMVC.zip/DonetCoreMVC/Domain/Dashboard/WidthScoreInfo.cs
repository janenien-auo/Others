using System;
using System.Collections.Generic;

namespace AUO.TechDev.Web.Domain.Dashboard
{
    public class WidthScoreInfo
    {        
         public int SkillID { get; set; }
        public string SkillName { get; set; }

        public string Fab { get; set; }      

         public string Level { get; set; }

         public List<SkillScore> Scores { get; set; }       
    }
}
