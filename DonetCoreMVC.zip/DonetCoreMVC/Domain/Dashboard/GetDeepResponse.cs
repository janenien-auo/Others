using System;
using System.Collections.Generic;

namespace AUO.TechDev.Web.Domain.Dashboard
{
    public class GetDeepResponse
    {
         public int SkillID { get; set; }
        public string SkillName { get; set; }

        public string Fab { get; set; }        

        public List<SkillScore> ScoreInfos { get; set; }
    }

     public class GetDeepResponseTemp
    {
         public int SkillID { get; set; }
        public string SkillName { get; set; }

        public string Fab { get; set; }       

        public List<SkillFeedbackImpSummary> ScoreInfos { get; set; }
    }
}
