using System;

namespace AUO.TechDev.Web.Domain
{
    public class JSend {
        public string status { get; set; }

        public object data { get; set; }

        public string message { get; set; }

        public JSend(object d = null) {
            if (d == null) data = null;
            else this.data = d;
        }
    }
}
