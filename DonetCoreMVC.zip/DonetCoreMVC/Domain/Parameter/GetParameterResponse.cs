using System;
using System.Collections.Generic;

namespace AUO.TechDev.Web.Domain.Parameter
{
    public class GetParameterResponse
    {
        public string Type { get; set; }

        public List<ParameterSetting> Values { get; set; }
    }
}
