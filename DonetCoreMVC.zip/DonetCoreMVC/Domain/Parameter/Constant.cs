using System;

namespace AUO.TechDev.Web.Domain.Parameter
{
    public class Constant
    {
        public string Name { get; set; }

        public string Value { get; set; }
    }
}
