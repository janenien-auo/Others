using System;
using System.Collections.Generic;

namespace AUO.TechDev.Web.Domain.Parameter
{
    public class GetSiteResponse
    {
        public string Group { get; set; }

        public List<string> Fabs { get; set; }
    }
}
