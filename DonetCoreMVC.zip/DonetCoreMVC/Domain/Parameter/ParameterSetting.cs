using System;

namespace AUO.TechDev.Web.Domain.Parameter
{
    public class ParameterSetting
    {
        public int ParaID { get; set; }
        public string ParaVal { get; set; }
        public string Type { get; set; }
    }
}
