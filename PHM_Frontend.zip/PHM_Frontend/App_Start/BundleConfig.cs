﻿using System.Web;
using System.Web.Optimization;

namespace PHM_Frontend {
    public class BundleConfig {
        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles) {

            #region JS

            bundles.Add(new ScriptBundle("~/bundles/HomeIndex").Include(
              "~/Scripts/Common/SupportIE.js",
              "~/Scripts/Common/Log.js",
              "~/Scripts/Common/UrlHelper.js",             
              "~/Scripts/Vuex/store.js",
             "~/Scripts/Home/Index.js"
             // ,"~/Scripts/Layout/UserInfo.js"
             ));

            bundles.Add(new ScriptBundle("~/bundles/RedriectUrl").Include(
           "~/Scripts/Project/RedriectUrl.js"
           ));

            bundles.Add(new ScriptBundle("~/bundles/echarts").Include(
            "~/Scripts/ECharts/echarts.min.js",
             "~/Scripts/ECharts/echarts-liquidfill.js"

            ));

            bundles.Add(new ScriptBundle("~/bundles/alertifyjs").Include(
            //"~/ui-jQuery/alertify-js/alertify.min.js"
            "~/ui-jQuery/alertify-js/alertify.js"
            //"~/ui-jQuery/alertify-js/alertify@1.3.1.js"

            ));


            bundles.Add(new ScriptBundle("~/bundles/ProjectList").Include(
                "~/Scripts/Project/ProjectList.js"
               ));


            bundles.Add(new ScriptBundle("~/bundles/ProjectInfo").Include(
                "~/Scripts/Project/ProjectInfo.js"));


            bundles.Add(new ScriptBundle("~/bundles/UploadFiles").Include(
                "~/Scripts/Project/UploadFiles.js"));

            bundles.Add(new ScriptBundle("~/bundles/OnlineHome").Include(
                "~/Scripts/Online/OnlineHome.js"));


            bundles.Add(new ScriptBundle("~/bundles/ToolList").Include(
                "~/Scripts/Online/ToolList.js"));

            bundles.Add(new ScriptBundle("~/bundles/ToolDetail").Include(
                "~/Scripts/Online/ToolDetail.js"));

            bundles.Add(new ScriptBundle("~/bundles/CheckData").Include(
                "~/Scripts/Project/CheckData.js"));


            bundles.Add(new ScriptBundle("~/bundles/FrequencyTransform").Include(
                "~/Scripts/Project/FrequencyTransform.js"));


            bundles.Add(new ScriptBundle("~/bundles/FrequencyTransformPreview").Include(
                "~/Scripts/Project/FrequencyTransformPreview.js"));

            bundles.Add(new ScriptBundle("~/bundles/FeatureExtraction").Include(
                "~/Scripts/Project/FeatureExtraction.js"));

            bundles.Add(new ScriptBundle("~/bundles/FeatureExtractionPreview").Include(
                "~/Scripts/Project/FeatureExtractionPreview.js"));

            bundles.Add(new ScriptBundle("~/bundles/DataLabeling").Include(
                "~/Scripts/Project/DataLabeling.js"));



            bundles.Add(new ScriptBundle("~/bundles/FeatureEngineering").Include(
             "~/Scripts/Project/FeatureEngineering.js"));


            bundles.Add(new ScriptBundle("~/bundles/SplitData").Include(
                "~/Scripts/Project/SplitData.js"));

            bundles.Add(new ScriptBundle("~/bundles/XDICheck").Include(
                "~/Scripts/Project/XDICheck.js"));

            bundles.Add(new ScriptBundle("~/bundles/DataProcess").Include(
              "~/Scripts/Project/DataProcess.js"));


            bundles.Add(new ScriptBundle("~/bundles/FeatureSelection").Include(
                 "~/Scripts/Project/FeatureSelection.js"));


            bundles.Add(new ScriptBundle("~/bundles/ModelResult").Include(
                 "~/Scripts/Project/ModelResult.js"));

            //Add by amanda 2020-09-04 11:02
            bundles.Add(new ScriptBundle("~/bundles/ProjectContiList").Include(
                "~/Scripts/ProjectConti/ProjectContiList.js"));
            bundles.Add(new ScriptBundle("~/bundles/ParameterSelect").Include(
                "~/Scripts/ProjectConti/ParameterSelect.js"));
            bundles.Add(new ScriptBundle("~/bundles/Imputation").Include(
               "~/Scripts/fuse/fuse.js",
                "~/Scripts/ProjectConti/Imputation.js"));
            bundles.Add(new ScriptBundle("~/bundles/RedriectContiUrl").Include(
                "~/Scripts/ProjectConti/RedriectContiUrl.js"));
            bundles.Add(new ScriptBundle("~/bundles/UserMaintain").Include(
                "~/Scripts/Home/UserMaintain.js"));
            bundles.Add(new ScriptBundle("~/bundles/FeatureEngineeringConti").Include(
                "~/Scripts/ProjectConti/FeatureEngineeringConti.js"));
            bundles.Add(new ScriptBundle("~/bundles/Segmentation").Include(
                "~/Scripts/fuse/fuse.js",
                "~/Scripts/ProjectConti/Segmentation.js"));
            bundles.Add(new ScriptBundle("~/bundles/DataFilter").Include(
                "~/Scripts/ProjectConti/DataFilter.js"));
            bundles.Add(new ScriptBundle("~/bundles/DataLabeling").Include(
                "~/Scripts/ProjectConti/DataLabeling.js"));

            //Raw Data  
            bundles.Add(new ScriptBundle("~/bundles/RedriectRawdataUrl").Include(
               "~/Scripts/ProjectRawdata/RedriectRawdataUrl.js"));


            bundles.Add(new ScriptBundle("~/bundles/ProjectRawDataList").Include(
              "~/Scripts/ProjectRawData/ProjectRawDataList.js"));


            bundles.Add(new ScriptBundle("~/bundles/ParameterSelectRawData").Include(
              "~/Scripts/ProjectRawData/ParameterSelectRawData.js"));
            bundles.Add(new ScriptBundle("~/bundles/DataFilterRawData").Include(
             "~/Scripts/ProjectRawData/DataFilterRawData.js"));
            bundles.Add(new ScriptBundle("~/bundles/ParameterSelectRawData").Include(
              "~/Scripts/ProjectRawData/ParameterSelectRawData.js"));
            bundles.Add(new ScriptBundle("~/bundles/FeatureEngineeringRawData").Include(
             "~/Scripts/ProjectRawData/FeatureEngineeringRawData.js"));



            






            bundles.Add(new ScriptBundle("~/bundles/WaitingandMailAlert").Include(
                 "~/Scripts/Project/WaitingandMailAlert.js"));


            bundles.Add(new ScriptBundle("~/bundles/Error").Include(
       "~/Scripts/Error/Error.js"));


            bundles.Add(new ScriptBundle("~/bundles/Polyfill").Include(
                "~/Scripts/babel/babel-polyfill.min.js"
                , "~/Scripts/Vue/polyfill.js"));


            bundles.Add(new ScriptBundle("~/bundles/ElementUI").Include(
                 "~/Scripts/ElementUI/element-ui.js"));

            bundles.Add(new ScriptBundle("~/bundles/Vue").Include(
                 "~/Scripts/Vue/vue.2.6.11.js"
                , "~/Scripts/Vue/vuex.js"
                , "~/Scripts/Vue/vee-validate.min.js"
                ));

            bundles.Add(new ScriptBundle("~/bundles/axios").Include(
                  "~/Scripts/axios/es6-promise.min.js"
                , "~/Scripts/axios/es6-promise.auto.min.js"
                , "~/Scripts/axios/axios.min.js"
                , "~/Scripts/axios/axios-mock-adapter.min.js"));

            //bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
            //            "~/Scripts/jquery-{version}.js"));       


            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery.min.js"));


            bundles.Add(new StyleBundle("~/bundles/loadingJS").Include(
            "~/ui-jQuery/loading/loading.js"
             ));

            bundles.Add(new StyleBundle("~/bundles/AllPageCommonJS").Include(
              "~/Scripts/Common/SupportIE.js",
              "~/Scripts/Common/Log.js",
              "~/Scripts/Common/UrlHelper.js",
              "~/Scripts/Vuex/store.js",
              "~/Scripts/Layout/UserInfo.js",
              "~/Scripts/moment.js",
               //"~/Scripts/jquery.als-1.7.min.js",
              "~/Scripts/jquery.marquee.min.js",
              "~/Scripts/Layout/Announcement.js",
              "~/Scripts/Layout/Menu.js"

            ));

            bundles.Add(new ScriptBundle("~/bundles/OnlineLayout").Include(
             "~/Scripts/Layout/OnlineLayout.js",
              "~/Scripts/api/api.js"
             ));

            bundles.Add(new ScriptBundle("~/bundles/CreateProjectLayout").Include(
            "~/Scripts/api/api.js",
            "~/Scripts/Layout/CreateProjectLayout.js"
           
            ));

            //add by amanda 2020-09-04 15:17
            bundles.Add(new ScriptBundle("~/bundles/CreateProjectLayoutConti").Include(
            "~/Scripts/api/api.js",
            "~/Scripts/Layout/CreateProjectLayoutConti.js"

            ));


            bundles.Add(new ScriptBundle("~/bundles/CreateProjectLayoutRawData").Include(
           "~/Scripts/api/api.js",
           "~/Scripts/Layout/CreateProjectLayoutRawData.js"

           ));

            bundles.Add(new ScriptBundle("~/bundles/OfflineLayout").Include(
            "~/Scripts/Layout/OfflineLayout.js"
            ));

            //add by amanda 2020-09-07 10:49
            bundles.Add(new ScriptBundle("~/bundles/OfflineLayoutConti").Include(
                "~/Scripts/Layout/OfflineLayoutConti.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/OnlineModelList").Include(
            "~/Scripts/online/OnlineModelList.js",
            "~/Scripts/fuse/fuse.js",
            "~/Scripts/api/api.js"
           ));

            bundles.Add(new ScriptBundle("~/bundles/ToolMapping").Include(
            "~/Scripts/online/ToolMapping.js"
             ));

            bundles.Add(new ScriptBundle("~/bundles/DataHealth").Include(
           "~/Scripts/online/DataHealth.js"
           ));

            bundles.Add(new ScriptBundle("~/bundles/EStoneEventList").Include(
             "~/Scripts/online/EStoneEventList.js",
             "~/Scripts/fuse/fuse.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/RecordHistroy").Include(
             "~/Scripts/online/RecordHistory.js",
             "~/Scripts/fuse/fuse.js"
            ));

            
            bundles.Add(new ScriptBundle("~/bundles/CloseEStone").Include(
           "~/Scripts/online/CloseEStone.js"
           ));


            bundles.Add(new ScriptBundle("~/bundles/RecordSetting").Include(
           "~/Scripts/online/RecordSetting.js"
           ));

            bundles.Add(new ScriptBundle("~/bundles/jueryDatatables").Include(
                  "~/Scripts/jquery-3.3.1.min.js",
                 "~/Scripts/jqueryDatatables/jquery.dataTables.min.js"
           ));
            

           bundles.Add(new ScriptBundle("~/bundles/confirmModePage").Include(
                  "~/Scripts/online/confirmModePage.js"
           ));


            //~/bundles/TrainingMaterials
            bundles.Add(new ScriptBundle("~/bundles/TrainingMaterials").Include(
               "~/Scripts/Home/TrainingMaterials.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/Announcement").Include(
              "~/Scripts/Home/Announcement.js"
           ));


            //CustomAlgorithm
            bundles.Add(new ScriptBundle("~/bundles/AlgorithmList").Include(
            "~/Scripts/CustomAlgorithm/AlgorithmList.js"
            ));
            
           
            bundles.Add(new ScriptBundle("~/bundles/CreateAlgorithm").Include(
            "~/Scripts/CustomAlgorithm/CreateAlgorithm.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/VersionList").Include(
          "~/Scripts/CustomAlgorithm/VersionList.js"
          ));

            bundles.Add(new ScriptBundle("~/bundles/CreateVersion").Include(
          "~/Scripts/CustomAlgorithm/CreateVersion.js"
          ));


            #endregion

            #region CSS

            bundles.Add(new StyleBundle("~/Style/alertifyjs").Include(
             "~/ui-jQuery/alertify-js/alertify.core.css"
           , "~/ui-jQuery/alertify-js/alertify.default.css"
             ));

            bundles.Add(new StyleBundle("~/Style/loadingCSS").Include(
              "~/ui-jQuery/loading/loading-style.css"
            ));

            bundles.Add(new StyleBundle("~/Style/jqueryDatatablesCss").Include(
            "~/Style/jqueryDatatables/jquery.dataTables.min.css"
           ));

            bundles.Add(new StyleBundle("~/Style/OnlineMonitor").Include(            
             "~/_css/OnlineMonitor.css"
            ));


            bundles.Add(new StyleBundle("~/Style/allPageCss").Include(
              "~/_css/fonts/noto-sans-tc.css",
              "~/_css/fonts/roboto.css",
              "~/_css/w3css-v4/w3pro.css",
              "~/_css/w3css-v4/w3color.css",
              "~/_css/css-default/default.css",
              "~/_css/css-default/default-font.css",
              "~/_css/w3css-v4/w3-fix.css",
              "~/_css/w3css-v4/w3-easy-layout.css",
              "~/_css/w3css-v4/w3-easy-edit.css",
              "~/_css/w3css-v4/w3-fix-unit.css",
              "~/_css/w3css-v4/w3-fix-font.css",
              "~/_css/w3css-v4/w3-mui-color.css",
              "~/_css/w3css-v4/w3-fix-color.css",
              "~/_css/layout.css",
              "~/_css/layout-style.css",
              "~/_css/layout-index-main.css"
             
             ));

            #endregion


            //BundleTable.EnableOptimizations = true;

        }
    }
}
