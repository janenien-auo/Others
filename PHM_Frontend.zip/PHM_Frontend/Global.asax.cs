﻿using cimuac;
using Newtonsoft.Json;
using NLog;
using PHM_Frontend.Controllers.api;
using PHM_Frontend.DTO.Authentication;
using PHM_Frontend.DTO.Config;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;

namespace PHM_Frontend {
    public class MvcApplication : System.Web.HttpApplication {

        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public Configuration Configuration { get; set; }


        protected void Application_Start() {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            WebApiConfig.Register(GlobalConfiguration.Configuration);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            //登入驗證
            UCLCtx.setConfigPath(@"D:\AP Backup\Reaver\Smart_VM\config\");
        }


        //Mark Jane:改用前端去調用Auth API 驗證
        //protected void Application_BeginRequest(Object source, EventArgs e) {
           
        //    string _sAuthorityKey = "";
        //    if (Request["authkey"] != null)
        //        _sAuthorityKey = Request["authkey"].ToString();
        //    else {
        //        if (Request.Cookies["AuthorityKey"] != null)
        //            _sAuthorityKey = Request.Cookies["AuthorityKey"].Value;
        //    }

        //    AuthenticationController authentication = new AuthenticationController();
        //    //authentication.CheckKey(_sAuthorityKey, Request, Response);
        //    authentication.CheckKey(_sAuthorityKey);

        //}




        protected void Application_Error(object sender, EventArgs e) {
            Exception exception = Server.GetLastError();
            Response.Clear();

            HttpException httpException = exception as HttpException;

            string errorMsg = exception.Message;

            //logger.Error(httpException);

            if (httpException != null) {
                string action;

                switch (httpException.GetHttpCode()) {
                    case 404:
                        // page not found
                        action = "ErrorHandle";
                        errorMsg = "Page Not Found";
                        break;
                    case 500:
                        // server error
                        action = "ErrorHandle";
                        break;
                    default:
                        action = "General";
                        break;
                }

                // clear error on server
                Server.ClearError();

                Response.Redirect(String.Format("~/Error/{0}/?message={1}", action, errorMsg));
            }
        }
    }
}
