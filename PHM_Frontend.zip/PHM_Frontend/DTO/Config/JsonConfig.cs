﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PHM_Frontend.DTO.Config {
    public class JsonConfig {
        public DBConnection DBConnection { get; set; }
        public ProxyInfo ProxyInfo { get; set; }
        public WebServiceURL WebServiceURL { get; set; }
        public WebServiceURL_Chamber WebServiceURL_Chamber { get; set; }
        public UserPhotoServer UserPhotoServer { get; set; }
        public OpenDataInfor OpenDataInfor { get; set; }
        public AuthorizationSetting AuthorizationSetting { get; set; }

        public string TrainingMaterialsFilePath { get; set; }

        public string AnnouncementMaterialsFilePath { get; set; }
        public string AllFab { get; set; }
        public string SiteID { get; set; }
    }

    public class DBConnection {
        public string User { get; set; }

        public string Fab { get; set; }
    }

    public class ProxyInfo {
        public string Host { get; set; }

        public int Port { get; set; }
    }

    public class WebServiceURL {
        public string L6A { get; set; }
        public string M11 { get; set; }
        public string P01 { get; set; }
        public string L5C { get; set; }
        public string L7A { get; set; }
        public string L7B { get; set; }
        public string L8A { get; set; }
        public string L8B { get; set; }
        public string L6B { get; set; }
        public string L4B { get; set; }
        public string L6K { get; set; }
        public string L5D { get; set; }
        public string L3D { get; set; }
        public string L4A { get; set; }
        public string L5A { get; set; }
        public string L5B { get; set; }
        public string L3C { get; set; }
        public string C4A { get; set; }
        public string C5D { get; set; }
        public string C5E { get; set; }
        public string C6C { get; set; }
        public string M02 { get; set; }
        public string M01 { get; set; }
        public string S11 { get; set; }
        public string S13 { get; set; }
        public string S17 { get; set; }
        public string S01 { get; set; }
        public string S02 { get; set; }
        public string S06 { get; set; }
    }

    public class WebServiceURL_Chamber {
        public string L6A { get; set; }
        public string M11 { get; set; }
        public string P01 { get; set; }
        public string L5C { get; set; }
        public string L7A { get; set; }
        public string L7B { get; set; }
        public string L8A { get; set; }
        public string L8B { get; set; }
        public string L6B { get; set; }
        public string L4B { get; set; }
        public string L6K { get; set; }
        public string L5D { get; set; }
        public string L3D { get; set; }
        public string L4A { get; set; }
        public string L5A { get; set; }
        public string L5B { get; set; }
        public string L3C { get; set; }
        public string C4A { get; set; }
        public string C5D { get; set; }
        public string C5E { get; set; }
        public string C6C { get; set; }
        public string M02 { get; set; }
        public string M01 { get; set; }
        public string S11 { get; set; }
        public string S13 { get; set; }
        public string S17 { get; set; }
        public string S01 { get; set; }
        public string S02 { get; set; }
        public string S06 { get; set; }

    }


    public class UserPhotoServer {
        public string IP { get; set; }

        public string Domain { get; set; }

    }

    public class OpenDataInfor {
        public string UID { get; set; }

        public string PWD { get; set; }

    }

    public class AuthorizationSetting {
        public bool NeedToLogin { get; set; }

        public string UserDataServer { get; set; }

        public int SessionExpirationMins { get; set; }
    }

}