﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PHM_Frontend.DTO.Authentication {
    public class RtnUAC {
        public string Status { get; set; }
        public string ErrorMsg { get; set; }
        public string AuthorityKey { get; set; }       

        public UserInfo UserInfo { get; set; }
    }

    public class UserInfo {
        public string UserId { get; set; }

        public string UserName { get; set; }

        public string UserEmail { get; set; }

        public string PhotoUrl { get; set; }

        public string UserSite { get; set; }

        public string UserDeptID { get; set; }

        public string Fab { get; set; }

        public string InputAccount { get; set; }



    }
}