﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PHM_Frontend.DTO.Basicinfor {
    public class GetChambersReqest {
        public string FABSITE { get; set; }
        public string TOOLID { get; set; }
        public string DATATYPE { get; set; }
    }

    public class GetChambersResponse {
        public string chamber { get; set; }
    }
}