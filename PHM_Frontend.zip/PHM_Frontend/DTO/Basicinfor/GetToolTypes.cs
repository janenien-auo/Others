﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PHM_Frontend.DTO.Basicinfor {
    public class GetToolTypesReqest {
        public string FABSITE { get; set; }
        public string PROCESSTYPE { get; set; }
        public string MODULENAME { get; set; }
        public string DATATYPE { get; set; }

    }

    public class GetToolTypesResponse {
        public string tool_type { get; set; }
    }
}