﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PHM_Frontend.DTO.Basicinfor {
    public class GetFunctionsReqest {
        public string FABSITE { get; set; }
        public string PROCESSTYPE { get; set; }
        public string DATATYPE { get; set; }
    }

    public class GetFunctionsResponse {
        public string func { get; set; }
    }
}