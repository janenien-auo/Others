﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PHM_Frontend.DTO.Basicinfor {
    public class GetFabsReqest {
        public string SITEID { get; set; }
    }

    public class GetFabsResponse {
        public string fab { get; set; }
    }
}