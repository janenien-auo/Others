﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PHM_Frontend.DTO.Basicinfor {
    public class GetModulesReqest {
        public string FABSITE { get; set; }
        public string DATATYPE { get; set; }

    }

    public class GetModulesResponse {
        public string stage { get; set; }
    }
}