﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PHM_Frontend.DTO.Basicinfor {
    public class GetToolsReqest {
        public string FABSITE { get; set; }
        public string PROCESSTYPE { get; set; }
        public string MODULENAME { get; set; }
        public string TOOLTYPE { get; set; }
        public string DATATYPE { get; set; }
    }

    public class GetToolsResponse {
        public string tool { get; set; }
    }
}