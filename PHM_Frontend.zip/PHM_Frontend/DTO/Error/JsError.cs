﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PHM_Frontend.DTO.Error {
    public class JsError {

        public string msg { get; set; }

        public string url { get; set; }

        public string line { get; set; }
    }
}