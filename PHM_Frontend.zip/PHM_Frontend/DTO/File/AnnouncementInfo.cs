﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PHM_Frontend.DTO.File {
    public class AnnouncementInfo {

        public string format { get; set; }

        public string show_title { get; set; }

        public List<AnnouncementContents> contents { get; set; }

        public string folder_path { get; set; }

        public List<string> files { get; set; }
    }


    public class AnnouncementContents {
        public ShowTopInfo show_top_info { get; set; }

        public string content { get; set; }
    }


    public class ShowTopInfo {

        public Nullable<DateTime> start_time { get; set; }

        public Nullable<DateTime> end_time { get; set; }

    }
}