﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PHM_Frontend.DTO.File {
    public class TrainingMaterial {
        public string Folder { get; set; }
        public List<string> Files { get; set; }

    }   
}