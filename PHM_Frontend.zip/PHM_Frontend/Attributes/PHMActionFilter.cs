﻿using PHM_Frontend.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Http.Filters;
using System.Net.Http;

namespace PHM_Frontend.Filter {
    public class PHMActionFilter : System.Web.Http.Filters.ActionFilterAttribute {
        public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext) {

            var objectContent = actionExecutedContext.Response.Content as ObjectContent;
            var jsendResult = new JSend(objectContent.Value) { status = "OK" };
           
            actionExecutedContext.Response = actionExecutedContext.Request.CreateResponse(
                HttpStatusCode.OK, jsendResult);

            actionExecutedContext.Response.Headers.Add("Access-Control-Allow-Origin", "*");

        }
    }
}