﻿using PHM_Frontend.Cache;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PHM_Frontend.Attributes {

    public class PHMAuthorize : AuthorizeAttribute {
        public override void OnAuthorization(AuthorizationContext filterContext) {           

            if (!PHMCache.GetJsonConfig().AuthorizationSetting.NeedToLogin) return;

            base.OnAuthorization(filterContext);

        }    


    }
}