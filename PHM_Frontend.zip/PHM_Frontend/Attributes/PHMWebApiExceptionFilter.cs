﻿using NLog;
using PHM_Frontend.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Filters;

namespace PHM_Frontend.Filter {
    public class PHMWebApiExceptionFilter : ExceptionFilterAttribute {

        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();
        public override void OnException(HttpActionExecutedContext actionExecutedContext) {
           
            var jsendResult = new JSend() {
                status = "error",
                message = actionExecutedContext.Exception.Message
            };
           
            //Log
            logger.Error(actionExecutedContext.Exception);

            actionExecutedContext.Response = actionExecutedContext.Request.CreateResponse(
                HttpStatusCode.InternalServerError, jsendResult);

            base.OnException(actionExecutedContext);
        }
    }
}