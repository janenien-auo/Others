﻿using Dapper;
using PHM_Frontend.DTO.Basicinfor;
using PHM_Frontend.Cache;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Data;
using System.Collections;
using System.Reflection;
using PHM_Frontend.Extensions;
using System.Net;
using Newtonsoft.Json;
using NLog;

namespace PHM_Frontend.Repository {
    public class BasicinforRepository {
        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();

        Root.DB.hyMSSQL centralDB;
        Root.DB.hyMSSQL siteDB;

        public BasicinforRepository(string user, string fab) {

            siteDB = new APCDB.Common().getNew_SiteDB(user, fab);
            centralDB = new APCDB.Common().getNew_CentralDB_APC(user, fab);


        }

        public List<GetToolResponse> GetTools(GetToolRequest req) {
            #region SQL
            string sql = @"SELECT distinct  [TOOLID] as tool   
                           FROM [APC].[dbo].[BASICINFOR]
                           where FABSITE=@FABSITE";
            #endregion

            using (SqlConnection conn = new SqlConnection(siteDB.Connection.ConnectionString)) {
                conn.Open();
                SqlTransaction trans = conn.BeginTransaction();
                var datas = conn.Query<GetToolResponse>(sql: sql, param: req, transaction: trans);
                trans.Commit();
                return datas != null ? datas.ToList() : null;
            }

        }


        public List<GetFabsResponse> GetFabs(GetFabsReqest req) {

            string sql = "";
            if (PHMCache.GetJsonConfig().SiteID == "TC") {
                #region SQL
                sql = @"select CASE fabid WHEN '5AB' THEN 'L5B' ELSE 'L' + fabid END fab 
                           FROM [APC].[dbo].[FAB]
                           where SITEID IN ('LT') AND APCControl = 1 AND FABID not in ('VM','P01','M01','M02') 
                           UNION
                           SELECT distinct CASE WHEN FABID IN ('M11','M01','M02','P01','C4A','C5D','C5E','C6C') THEN FABID WHEN FABID IN ('7-2') THEN 'L7B' WHEN FABID IN ('5AB') THEN 'L5A' ELSE 'L' + fabid END fab
                           FROM [APC].[dbo].[FAB]
                           where SITEID IN ('TC','HL','LT','LK','HY','HC','AUKS','TN','KH','AUSG') AND APCControl = 1 AND FABID not in ('VM','P01')
                           ";
                #endregion
            }
            else if (PHMCache.GetJsonConfig().SiteID == "AUKS") {

                #region SQL
                sql = @"select distinct 'L' + fabid END fab 
                           FROM [APC].[dbo].[FAB]
                           where SITEID = '" + PHMCache.GetJsonConfig().SiteID + "' AND APCControl = 1";

                #endregion
            }
            else {
                #region SQL
                sql = @"select distinct fabid as fab 
                           FROM [APC].[dbo].[FAB]
                           where SITEID = '" + PHMCache.GetJsonConfig().SiteID + "' AND APCControl = 1";

                #endregion
            }


            try {

                using (SqlConnection conn = new SqlConnection(siteDB.Connection.ConnectionString)) {
                    conn.Open();
                    SqlTransaction trans = conn.BeginTransaction();
                    var datas = conn.Query<GetFabsResponse>(sql: sql, param: req, transaction: trans);
                    trans.Commit();
                    return datas != null ? datas.ToList() : null;
                }
            }
            catch (Exception e) {
                logger.Error(e);

                DataTable dt = new DataTable();
                dt.Columns.Add(new DataColumn("fab", typeof(String)));
                DataRow dr;
                for (int i = 0; i < PHMCache.GetJsonConfig().AllFab.Split(',').Length; i++) {
                    dr = dt.NewRow();
                    dr["fab"] = PHMCache.GetJsonConfig().AllFab.Split(',')[i].Trim();
                    dt.Rows.Add(dr);
                }
                var datas = dt.ToList<GetFabsResponse>().OrderBy(o => o.fab);
                return datas != null && datas.Any() ? datas.ToList() : null;

            }

        }


        public List<GetModulesResponse> GetModules(GetModulesReqest req) {


            try {

                string _url = "";
                #region get url
                if (req.FABSITE.Trim() == "6A" || req.FABSITE.Trim() == "L6A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6A.Trim();
                else if (req.FABSITE.Trim() == "M11" || req.FABSITE.Trim() == "LM11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M11.Trim();
                else if (req.FABSITE.Trim() == "P01" || req.FABSITE.Trim() == "LP01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.P01.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "7A" || req.FABSITE.Trim() == "L7A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7A.Trim();
                else if (req.FABSITE.Trim() == "7-2" || req.FABSITE.Trim() == "L7B" || req.FABSITE.Trim() == "L7-2")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7B.Trim();
                else if (req.FABSITE.Trim() == "8A" || req.FABSITE.Trim() == "L8A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8A.Trim();
                else if (req.FABSITE.Trim() == "8B" || req.FABSITE.Trim() == "L8B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8B.Trim();
                else if (req.FABSITE.Trim() == "6B" || req.FABSITE.Trim() == "L6B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6B.Trim();
                else if (req.FABSITE.Trim() == "4B" || req.FABSITE.Trim() == "L4B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4B.Trim();
                else if (req.FABSITE.Trim() == "6K" || req.FABSITE.Trim() == "L6K")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6K.Trim();
                else if (req.FABSITE.Trim() == "3D" || req.FABSITE.Trim() == "L3D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3D.Trim();
                else if (req.FABSITE.Trim() == "5D" || req.FABSITE.Trim() == "L5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5D.Trim();
                else if (req.FABSITE.Trim() == "4A" || req.FABSITE.Trim() == "L4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4A.Trim();
                else if (req.FABSITE.Trim() == "5A" || req.FABSITE.Trim() == "L5A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5A.Trim();
                else if (req.FABSITE.Trim() == "5B" || req.FABSITE.Trim() == "L5B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5B.Trim();
                else if (req.FABSITE.Trim() == "3C" || req.FABSITE.Trim() == "L3C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3C.Trim();
                else if (req.FABSITE.Trim() == "C4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C4A.Trim();
                else if (req.FABSITE.Trim() == "C5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5D.Trim();
                else if (req.FABSITE.Trim() == "C6C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C6C.Trim();
                else if (req.FABSITE.Trim() == "C5E")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5E.Trim();
                else if (req.FABSITE.Trim() == "M02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M02.Trim();
                else if (req.FABSITE.Trim() == "M01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M01.Trim();
                else if (req.FABSITE.Trim() == "S11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S11.Trim();
                else if (req.FABSITE.Trim() == "S13")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S13.Trim();
                else if (req.FABSITE.Trim() == "S17")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S17.Trim();
                else if (req.FABSITE.Trim() == "S01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S01.Trim();
                else if (req.FABSITE.Trim() == "S02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S02.Trim();
                else if (req.FABSITE.Trim() == "S06")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S06.Trim();
                #endregion
                DataTable dt = new DataTable();

                logger.Log(LogLevel.Info, $"url:{_url}");

                //string AllDataType = "APC,CONTINUOUS";
                string AllDataType = req.DATATYPE;
                for (int i = 0; i < AllDataType.Split(',').Length; i++) {
                    DataConfig.InputJsonBasicinfor _input = new DataConfig.InputJsonBasicinfor();
                    _input.user = PHMCache.GetJsonConfig().OpenDataInfor.UID.Trim();
                    _input.password = PHMCache.GetJsonConfig().OpenDataInfor.PWD.Trim();
                    _input.FABSITE = req.FABSITE.Replace("L7B", "7-2").Replace("L5A", "5AB").Replace("L5B", "5AB").Replace("L", "");
                    _input.DATATYPE = AllDataType.Split(',')[i].Trim();
                    _input.PROCESSTYPE = "";
                    _input.MODULENAME = "";
                    _input.TOOLVENDER = "";
                    _input.TOOLTYPE = "";
                    _input.ziped = "false";
                    string InputJson = JsonConvert.SerializeObject(_input);
                    string ReportResult = "";

                    //logger.Log(LogLevel.Info, $"InputJson:{InputJson}");

                    WebClient client = new WebClient();
                    #region proxy
                    WebProxy proxy = null;
                    if (req.FABSITE == "L8B")//10.37.9.111
                        proxy = new WebProxy("10.37.9.111", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L6B" || req.FABSITE == "M02")
                        proxy = new WebProxy("10.31.10.188", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L4A" || req.FABSITE == "L5A" || req.FABSITE == "L5B")
                        proxy = new WebProxy("10.88.95.1", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3D" || req.FABSITE == "L5D")
                        proxy = new WebProxy("10.22.10.134", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3C" || req.FABSITE == "L4B")
                        proxy = null;
                    else if (req.FABSITE == "L6K")
                        proxy = new WebProxy("10.12.129.10", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        proxy = new WebProxy("10.34.128.199", PHMCache.GetJsonConfig().ProxyInfo.Port);//
                    else if (req.FABSITE == "C5E")
                        proxy = new WebProxy("10.34.129.100", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S11" || req.FABSITE == "S13" || req.FABSITE == "S17")
                        proxy = new WebProxy("10.9.9.5", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S01" || req.FABSITE == "S02" || req.FABSITE == "S06")
                        proxy = new WebProxy("10.6.114.50", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else
                        proxy = new WebProxy(PHMCache.GetJsonConfig().ProxyInfo.Host, PHMCache.GetJsonConfig().ProxyInfo.Port);




                    if (proxy != null)
                        client.Proxy = proxy;

                    if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        System.Net.ServicePointManager.Expect100Continue = false;
                    #endregion

                    string targetAddress = _url + "/" + "Get_Basicinfor";
                    client.Encoding = System.Text.Encoding.UTF8; ;
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    ReportResult = client.UploadString(targetAddress, InputJson);
                    DataConfig.rtnMsgShell Introduction = JsonConvert.DeserializeObject<DataConfig.rtnMsgShell>(ReportResult);

                    DataTable dtWbsData = new DataTable();
                    dtWbsData = Introduction.data.Data;
                    if (dtWbsData != null) {
                        if (dt.Columns.Count == 0)
                            dt = dtWbsData.Clone();
                        dt.Merge(dtWbsData);
                    }//if (dtWbsData != null) {
                }//for (int i = 0; i < AllDataType.Split('.').Length; i++) {

                DataTable dtSort = dt.DefaultView.ToTable(true, new string[] { "PROCESSTYPE" });
                dtSort.Columns[0].ColumnName = "stage";

                var datas = dtSort.ToList<GetModulesResponse>().OrderBy(o => o.stage);

                return datas != null && datas.Any() ? datas.ToList() : null;
            }
            catch (Exception e) {
                logger.Error(e);
                throw e;
            }

        }

        public List<GetModulesResponse> xxxGetModulesConti(GetModulesReqest req) {


            try {

                string _url = "";
                #region get url
                if (req.FABSITE.Trim() == "6A" || req.FABSITE.Trim() == "L6A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6A.Trim();
                else if (req.FABSITE.Trim() == "M11" || req.FABSITE.Trim() == "LM11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M11.Trim();
                else if (req.FABSITE.Trim() == "P01" || req.FABSITE.Trim() == "LP01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.P01.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "7A" || req.FABSITE.Trim() == "L7A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7A.Trim();
                else if (req.FABSITE.Trim() == "7-2" || req.FABSITE.Trim() == "L7B" || req.FABSITE.Trim() == "L7-2")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7B.Trim();
                else if (req.FABSITE.Trim() == "8A" || req.FABSITE.Trim() == "L8A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8A.Trim();
                else if (req.FABSITE.Trim() == "8B" || req.FABSITE.Trim() == "L8B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8B.Trim();
                else if (req.FABSITE.Trim() == "6B" || req.FABSITE.Trim() == "L6B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6B.Trim();
                else if (req.FABSITE.Trim() == "4B" || req.FABSITE.Trim() == "L4B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4B.Trim();
                else if (req.FABSITE.Trim() == "6K" || req.FABSITE.Trim() == "L6K")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6K.Trim();
                else if (req.FABSITE.Trim() == "3D" || req.FABSITE.Trim() == "L3D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3D.Trim();
                else if (req.FABSITE.Trim() == "5D" || req.FABSITE.Trim() == "L5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5D.Trim();
                else if (req.FABSITE.Trim() == "4A" || req.FABSITE.Trim() == "L4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4A.Trim();
                else if (req.FABSITE.Trim() == "5A" || req.FABSITE.Trim() == "L5A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5A.Trim();
                else if (req.FABSITE.Trim() == "5B" || req.FABSITE.Trim() == "L5B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5B.Trim();
                else if (req.FABSITE.Trim() == "3C" || req.FABSITE.Trim() == "L3C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3C.Trim();
                else if (req.FABSITE.Trim() == "C4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C4A.Trim();
                else if (req.FABSITE.Trim() == "C5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5D.Trim();
                else if (req.FABSITE.Trim() == "C6C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C6C.Trim();
                else if (req.FABSITE.Trim() == "C5E")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5E.Trim();
                else if (req.FABSITE.Trim() == "M02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M02.Trim();
                else if (req.FABSITE.Trim() == "M01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M01.Trim();
                else if (req.FABSITE.Trim() == "S11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S11.Trim();
                else if (req.FABSITE.Trim() == "S13")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S13.Trim();
                else if (req.FABSITE.Trim() == "S17")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S17.Trim();
                else if (req.FABSITE.Trim() == "S01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S01.Trim();
                else if (req.FABSITE.Trim() == "S02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S02.Trim();
                else if (req.FABSITE.Trim() == "S06")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S06.Trim();
                #endregion
                DataTable dt = new DataTable();

                logger.Log(LogLevel.Info, $"url:{_url}");

                string AllDataType = "CONTINUOUS";
                for (int i = 0; i < AllDataType.Split(',').Length; i++) {
                    DataConfig.InputJsonBasicinfor _input = new DataConfig.InputJsonBasicinfor();
                    _input.user = PHMCache.GetJsonConfig().OpenDataInfor.UID.Trim();
                    _input.password = PHMCache.GetJsonConfig().OpenDataInfor.PWD.Trim();
                    _input.FABSITE = req.FABSITE.Replace("L7B", "7-2").Replace("L5A", "5AB").Replace("L5B", "5AB").Replace("L", "");
                    _input.DATATYPE = AllDataType.Split(',')[i].Trim();
                    _input.PROCESSTYPE = "";
                    _input.MODULENAME = "";
                    _input.TOOLVENDER = "";
                    _input.TOOLTYPE = "";
                    _input.ziped = "false";
                    string InputJson = JsonConvert.SerializeObject(_input);
                    string ReportResult = "";

                    //logger.Log(LogLevel.Info, $"InputJson:{InputJson}");

                    WebClient client = new WebClient();
                    #region proxy
                    WebProxy proxy = null;
                    if (req.FABSITE == "L8B")//10.37.9.111
                        proxy = new WebProxy("10.37.9.111", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L6B" || req.FABSITE == "M02")
                        proxy = new WebProxy("10.31.10.188", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L4A" || req.FABSITE == "L5A" || req.FABSITE == "L5B")
                        proxy = new WebProxy("10.88.95.1", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3D" || req.FABSITE == "L5D")
                        proxy = new WebProxy("10.22.10.134", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3C" || req.FABSITE == "L4B")
                        proxy = null;
                    else if (req.FABSITE == "L6K")
                        proxy = new WebProxy("10.12.129.10", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        proxy = new WebProxy("10.34.128.199", PHMCache.GetJsonConfig().ProxyInfo.Port);//
                    else if (req.FABSITE == "C5E")
                        proxy = new WebProxy("10.34.129.100", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S11" || req.FABSITE == "S13" || req.FABSITE == "S17")
                        proxy = new WebProxy("10.9.9.5", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S01" || req.FABSITE == "S02" || req.FABSITE == "S06")
                        proxy = new WebProxy("10.6.114.50", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else
                        proxy = new WebProxy(PHMCache.GetJsonConfig().ProxyInfo.Host, PHMCache.GetJsonConfig().ProxyInfo.Port);




                    if (proxy != null)
                        client.Proxy = proxy;

                    if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        System.Net.ServicePointManager.Expect100Continue = false;
                    #endregion

                    string targetAddress = _url + "/" + "Get_Basicinfor";
                    client.Encoding = System.Text.Encoding.UTF8; ;
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    ReportResult = client.UploadString(targetAddress, InputJson);
                    DataConfig.rtnMsgShell Introduction = JsonConvert.DeserializeObject<DataConfig.rtnMsgShell>(ReportResult);

                    DataTable dtWbsData = new DataTable();
                    dtWbsData = Introduction.data.Data;
                    if (dtWbsData != null) {
                        if (dt.Columns.Count == 0)
                            dt = dtWbsData.Clone();
                        dt.Merge(dtWbsData);
                    }//if (dtWbsData != null) {
                }//for (int i = 0; i < AllDataType.Split('.').Length; i++) {

                DataTable dtSort = dt.DefaultView.ToTable(true, new string[] { "PROCESSTYPE" });
                dtSort.Columns[0].ColumnName = "stage";

                var datas = dtSort.ToList<GetModulesResponse>().OrderBy(o => o.stage);

                return datas != null && datas.Any() ? datas.ToList() : null;
            }
            catch (Exception e) {
                logger.Error(e);
                throw e;
            }

        }

        public List<GetFunctionsResponse> GetFunctions(GetFunctionsReqest req) {


            try {
                string _url = "";
                #region get url
                if (req.FABSITE.Trim() == "6A" || req.FABSITE.Trim() == "L6A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6A.Trim();
                else if (req.FABSITE.Trim() == "M11" || req.FABSITE.Trim() == "LM11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M11.Trim();
                else if (req.FABSITE.Trim() == "P01" || req.FABSITE.Trim() == "LP01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.P01.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "7A" || req.FABSITE.Trim() == "L7A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7A.Trim();
                else if (req.FABSITE.Trim() == "7-2" || req.FABSITE.Trim() == "L7B" || req.FABSITE.Trim() == "L7-2")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7B.Trim();
                else if (req.FABSITE.Trim() == "8A" || req.FABSITE.Trim() == "L8A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8A.Trim();
                else if (req.FABSITE.Trim() == "8B" || req.FABSITE.Trim() == "L8B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8B.Trim();
                else if (req.FABSITE.Trim() == "6B" || req.FABSITE.Trim() == "L6B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6B.Trim();
                else if (req.FABSITE.Trim() == "4B" || req.FABSITE.Trim() == "L4B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4B.Trim();
                else if (req.FABSITE.Trim() == "6K" || req.FABSITE.Trim() == "L6K")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6K.Trim();
                else if (req.FABSITE.Trim() == "3D" || req.FABSITE.Trim() == "L3D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3D.Trim();
                else if (req.FABSITE.Trim() == "5D" || req.FABSITE.Trim() == "L5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5D.Trim();
                else if (req.FABSITE.Trim() == "4A" || req.FABSITE.Trim() == "L4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4A.Trim();
                else if (req.FABSITE.Trim() == "5A" || req.FABSITE.Trim() == "L5A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5A.Trim();
                else if (req.FABSITE.Trim() == "5B" || req.FABSITE.Trim() == "L5B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5B.Trim();
                else if (req.FABSITE.Trim() == "3C" || req.FABSITE.Trim() == "L3C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3C.Trim();
                else if (req.FABSITE.Trim() == "C4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C4A.Trim();
                else if (req.FABSITE.Trim() == "C5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5D.Trim();
                else if (req.FABSITE.Trim() == "C6C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C6C.Trim();
                else if (req.FABSITE.Trim() == "C5E")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5E.Trim();
                else if (req.FABSITE.Trim() == "M02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M02.Trim();
                else if (req.FABSITE.Trim() == "M01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M01.Trim();
                else if (req.FABSITE.Trim() == "S11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S11.Trim();
                else if (req.FABSITE.Trim() == "S13")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S13.Trim();
                else if (req.FABSITE.Trim() == "S17")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S17.Trim();
                else if (req.FABSITE.Trim() == "S01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S01.Trim();
                else if (req.FABSITE.Trim() == "S02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S02.Trim();
                else if (req.FABSITE.Trim() == "S06")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S06.Trim();
                #endregion


                DataTable dt = new DataTable();

                //string AllDataType = "APC,CONTINUOUS";
                string AllDataType = req.DATATYPE;
                for (int i = 0; i < AllDataType.Split(',').Length; i++) {
                    DataConfig.InputJsonBasicinfor _input = new DataConfig.InputJsonBasicinfor();
                    _input.user = PHMCache.GetJsonConfig().OpenDataInfor.UID.Trim();
                    _input.password = PHMCache.GetJsonConfig().OpenDataInfor.PWD.Trim();
                    _input.FABSITE = req.FABSITE.Replace("L7B", "7-2").Replace("L5A", "5AB").Replace("L5B", "5AB").Replace("L", "");
                    _input.DATATYPE = AllDataType.Split(',')[i].Trim();
                    _input.PROCESSTYPE = req.PROCESSTYPE;
                    _input.MODULENAME = "";
                    _input.TOOLVENDER = "";
                    _input.TOOLTYPE = "";
                    _input.ziped = "false";
                    string InputJson = JsonConvert.SerializeObject(_input);
                    string ReportResult = "";

                    WebClient client = new WebClient();
                    #region proxy
                    WebProxy proxy = null;
                    if (req.FABSITE == "L8B")//10.37.9.111
                        proxy = new WebProxy("10.37.9.111", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L6B" || req.FABSITE == "M02")
                        proxy = new WebProxy("10.31.10.188", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L4A" || req.FABSITE == "L5A" || req.FABSITE == "L5B")
                        proxy = new WebProxy("10.88.95.1", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3D" || req.FABSITE == "L5D")
                        proxy = new WebProxy("10.22.10.134", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3C" || req.FABSITE == "L4B")
                        proxy = null;
                    else if (req.FABSITE == "L6K")
                        proxy = new WebProxy("10.12.129.10", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        proxy = new WebProxy("10.34.128.199", PHMCache.GetJsonConfig().ProxyInfo.Port);//
                    else if (req.FABSITE == "C5E")
                        proxy = new WebProxy("10.34.129.100", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S11" || req.FABSITE == "S13" || req.FABSITE == "S17")
                        proxy = new WebProxy("10.9.9.5", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S01" || req.FABSITE == "S02" || req.FABSITE == "S06")
                        proxy = new WebProxy("10.6.114.50", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else
                        proxy = new WebProxy(PHMCache.GetJsonConfig().ProxyInfo.Host, PHMCache.GetJsonConfig().ProxyInfo.Port);




                    if (proxy != null)
                        client.Proxy = proxy;

                    if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        System.Net.ServicePointManager.Expect100Continue = false;
                    #endregion

                    string targetAddress = _url + "/" + "Get_Basicinfor";
                    client.Encoding = System.Text.Encoding.UTF8; ;
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    ReportResult = client.UploadString(targetAddress, InputJson);
                    DataConfig.rtnMsgShell Introduction = JsonConvert.DeserializeObject<DataConfig.rtnMsgShell>(ReportResult);

                    DataTable dtWbsData = new DataTable();
                    dtWbsData = Introduction.data.Data;
                    if (dtWbsData != null) {
                        if (dt.Columns.Count == 0)
                            dt = dtWbsData.Clone();
                        dt.Merge(dtWbsData);
                    }//if (dtWbsData != null) {
                }//for (int i = 0; i < AllDataType.Split('.').Length; i++) {

                DataTable dtSort = dt.DefaultView.ToTable(true, new string[] { "MODULENAME" });
                dtSort.Columns[0].ColumnName = "func";

                var datas = dtSort.ToList<GetFunctionsResponse>();
                return datas != null && datas.Any() ? datas.ToList() : null;
            }
            catch (Exception e) {
                throw e;
            }

        }

        public List<GetFunctionsResponse> xxxGetFunctionsConti(GetFunctionsReqest req) {


            try {
                string _url = "";
                #region get url
                if (req.FABSITE.Trim() == "6A" || req.FABSITE.Trim() == "L6A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6A.Trim();
                else if (req.FABSITE.Trim() == "M11" || req.FABSITE.Trim() == "LM11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M11.Trim();
                else if (req.FABSITE.Trim() == "P01" || req.FABSITE.Trim() == "LP01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.P01.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "7A" || req.FABSITE.Trim() == "L7A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7A.Trim();
                else if (req.FABSITE.Trim() == "7-2" || req.FABSITE.Trim() == "L7B" || req.FABSITE.Trim() == "L7-2")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7B.Trim();
                else if (req.FABSITE.Trim() == "8A" || req.FABSITE.Trim() == "L8A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8A.Trim();
                else if (req.FABSITE.Trim() == "8B" || req.FABSITE.Trim() == "L8B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8B.Trim();
                else if (req.FABSITE.Trim() == "6B" || req.FABSITE.Trim() == "L6B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6B.Trim();
                else if (req.FABSITE.Trim() == "4B" || req.FABSITE.Trim() == "L4B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4B.Trim();
                else if (req.FABSITE.Trim() == "6K" || req.FABSITE.Trim() == "L6K")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6K.Trim();
                else if (req.FABSITE.Trim() == "3D" || req.FABSITE.Trim() == "L3D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3D.Trim();
                else if (req.FABSITE.Trim() == "5D" || req.FABSITE.Trim() == "L5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5D.Trim();
                else if (req.FABSITE.Trim() == "4A" || req.FABSITE.Trim() == "L4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4A.Trim();
                else if (req.FABSITE.Trim() == "5A" || req.FABSITE.Trim() == "L5A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5A.Trim();
                else if (req.FABSITE.Trim() == "5B" || req.FABSITE.Trim() == "L5B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5B.Trim();
                else if (req.FABSITE.Trim() == "3C" || req.FABSITE.Trim() == "L3C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3C.Trim();
                else if (req.FABSITE.Trim() == "C4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C4A.Trim();
                else if (req.FABSITE.Trim() == "C5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5D.Trim();
                else if (req.FABSITE.Trim() == "C6C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C6C.Trim();
                else if (req.FABSITE.Trim() == "C5E")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5E.Trim();
                else if (req.FABSITE.Trim() == "M02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M02.Trim();
                else if (req.FABSITE.Trim() == "M01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M01.Trim();
                else if (req.FABSITE.Trim() == "S11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S11.Trim();
                else if (req.FABSITE.Trim() == "S13")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S13.Trim();
                else if (req.FABSITE.Trim() == "S17")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S17.Trim();
                else if (req.FABSITE.Trim() == "S01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S01.Trim();
                else if (req.FABSITE.Trim() == "S02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S02.Trim();
                else if (req.FABSITE.Trim() == "S06")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S06.Trim();
                #endregion


                DataTable dt = new DataTable();

                string AllDataType = "CONTINUOUS";
                for (int i = 0; i < AllDataType.Split(',').Length; i++) {
                    DataConfig.InputJsonBasicinfor _input = new DataConfig.InputJsonBasicinfor();
                    _input.user = PHMCache.GetJsonConfig().OpenDataInfor.UID.Trim();
                    _input.password = PHMCache.GetJsonConfig().OpenDataInfor.PWD.Trim();
                    _input.FABSITE = req.FABSITE.Replace("L7B", "7-2").Replace("L5A", "5AB").Replace("L5B", "5AB").Replace("L", "");
                    _input.DATATYPE = AllDataType.Split(',')[i].Trim();
                    _input.PROCESSTYPE = req.PROCESSTYPE;
                    _input.MODULENAME = "";
                    _input.TOOLVENDER = "";
                    _input.TOOLTYPE = "";
                    _input.ziped = "false";
                    string InputJson = JsonConvert.SerializeObject(_input);
                    string ReportResult = "";

                    WebClient client = new WebClient();
                    #region proxy
                    WebProxy proxy = null;
                    if (req.FABSITE == "L8B")//10.37.9.111
                        proxy = new WebProxy("10.37.9.111", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L6B" || req.FABSITE == "M02")
                        proxy = new WebProxy("10.31.10.188", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L4A" || req.FABSITE == "L5A" || req.FABSITE == "L5B")
                        proxy = new WebProxy("10.88.95.1", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3D" || req.FABSITE == "L5D")
                        proxy = new WebProxy("10.22.10.134", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3C" || req.FABSITE == "L4B")
                        proxy = null;
                    else if (req.FABSITE == "L6K")
                        proxy = new WebProxy("10.12.129.10", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        proxy = new WebProxy("10.34.128.199", PHMCache.GetJsonConfig().ProxyInfo.Port);//
                    else if (req.FABSITE == "C5E")
                        proxy = new WebProxy("10.34.129.100", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S11" || req.FABSITE == "S13" || req.FABSITE == "S17")
                        proxy = new WebProxy("10.9.9.5", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S01" || req.FABSITE == "S02" || req.FABSITE == "S06")
                        proxy = new WebProxy("10.6.114.50", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else
                        proxy = new WebProxy(PHMCache.GetJsonConfig().ProxyInfo.Host, PHMCache.GetJsonConfig().ProxyInfo.Port);




                    if (proxy != null)
                        client.Proxy = proxy;

                    if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        System.Net.ServicePointManager.Expect100Continue = false;
                    #endregion

                    string targetAddress = _url + "/" + "Get_Basicinfor";
                    client.Encoding = System.Text.Encoding.UTF8; ;
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    ReportResult = client.UploadString(targetAddress, InputJson);
                    DataConfig.rtnMsgShell Introduction = JsonConvert.DeserializeObject<DataConfig.rtnMsgShell>(ReportResult);

                    DataTable dtWbsData = new DataTable();
                    dtWbsData = Introduction.data.Data;
                    if (dtWbsData != null) {
                        if (dt.Columns.Count == 0)
                            dt = dtWbsData.Clone();
                        dt.Merge(dtWbsData);
                    }//if (dtWbsData != null) {
                }//for (int i = 0; i < AllDataType.Split('.').Length; i++) {

                DataTable dtSort = dt.DefaultView.ToTable(true, new string[] { "MODULENAME" });
                dtSort.Columns[0].ColumnName = "func";

                var datas = dtSort.ToList<GetFunctionsResponse>();
                return datas != null && datas.Any() ? datas.ToList() : null;
            }
            catch (Exception e) {
                throw e;
            }

        }

        public List<GetToolTypesResponse> GetToolTypes(GetToolTypesReqest req) {


            try {
                string _url = "";
                #region get url
                if (req.FABSITE.Trim() == "6A" || req.FABSITE.Trim() == "L6A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6A.Trim();
                else if (req.FABSITE.Trim() == "M11" || req.FABSITE.Trim() == "LM11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M11.Trim();
                else if (req.FABSITE.Trim() == "P01" || req.FABSITE.Trim() == "LP01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.P01.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "7A" || req.FABSITE.Trim() == "L7A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7A.Trim();
                else if (req.FABSITE.Trim() == "7-2" || req.FABSITE.Trim() == "L7B" || req.FABSITE.Trim() == "L7-2")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7B.Trim();
                else if (req.FABSITE.Trim() == "8A" || req.FABSITE.Trim() == "L8A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8A.Trim();
                else if (req.FABSITE.Trim() == "8B" || req.FABSITE.Trim() == "L8B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8B.Trim();
                else if (req.FABSITE.Trim() == "6B" || req.FABSITE.Trim() == "L6B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6B.Trim();
                else if (req.FABSITE.Trim() == "4B" || req.FABSITE.Trim() == "L4B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4B.Trim();
                else if (req.FABSITE.Trim() == "6K" || req.FABSITE.Trim() == "L6K")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6K.Trim();
                else if (req.FABSITE.Trim() == "3D" || req.FABSITE.Trim() == "L3D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3D.Trim();
                else if (req.FABSITE.Trim() == "5D" || req.FABSITE.Trim() == "L5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5D.Trim();
                else if (req.FABSITE.Trim() == "4A" || req.FABSITE.Trim() == "L4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4A.Trim();
                else if (req.FABSITE.Trim() == "5A" || req.FABSITE.Trim() == "L5A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5A.Trim();
                else if (req.FABSITE.Trim() == "5B" || req.FABSITE.Trim() == "L5B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5B.Trim();
                else if (req.FABSITE.Trim() == "3C" || req.FABSITE.Trim() == "L3C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3C.Trim();
                else if (req.FABSITE.Trim() == "C4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C4A.Trim();
                else if (req.FABSITE.Trim() == "C5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5D.Trim();
                else if (req.FABSITE.Trim() == "C6C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C6C.Trim();
                else if (req.FABSITE.Trim() == "C5E")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5E.Trim();
                else if (req.FABSITE.Trim() == "M02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M02.Trim();
                else if (req.FABSITE.Trim() == "M01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M01.Trim();
                else if (req.FABSITE.Trim() == "S11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S11.Trim();
                else if (req.FABSITE.Trim() == "S13")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S13.Trim();
                else if (req.FABSITE.Trim() == "S17")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S17.Trim();
                else if (req.FABSITE.Trim() == "S01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S01.Trim();
                else if (req.FABSITE.Trim() == "S02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S02.Trim();
                else if (req.FABSITE.Trim() == "S06")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S06.Trim();
                #endregion
                DataTable dt = new DataTable();

                //string AllDataType = "APC,CONTINUOUS";
                string AllDataType = req.DATATYPE;
                for (int i = 0; i < AllDataType.Split(',').Length; i++) {
                    DataConfig.InputJsonBasicinfor _input = new DataConfig.InputJsonBasicinfor();
                    _input.user = PHMCache.GetJsonConfig().OpenDataInfor.UID.Trim();
                    _input.password = PHMCache.GetJsonConfig().OpenDataInfor.PWD.Trim();
                    _input.FABSITE = req.FABSITE.Replace("L7B", "7-2").Replace("L5A", "5AB").Replace("L5B", "5AB").Replace("L", "");
                    _input.DATATYPE = AllDataType.Split(',')[i].Trim();
                    _input.PROCESSTYPE = req.PROCESSTYPE;
                    _input.MODULENAME = req.MODULENAME;
                    _input.TOOLVENDER = "";
                    _input.TOOLTYPE = "";
                    _input.ziped = "false";
                    string InputJson = JsonConvert.SerializeObject(_input);
                    string ReportResult = "";

                    WebClient client = new WebClient();
                    #region proxy
                    WebProxy proxy = null;
                    if (req.FABSITE == "L8B")//10.37.9.111
                        proxy = new WebProxy("10.37.9.111", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L6B" || req.FABSITE == "M02")
                        proxy = new WebProxy("10.31.10.188", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L4A" || req.FABSITE == "L5A" || req.FABSITE == "L5B")
                        proxy = new WebProxy("10.88.95.1", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3D" || req.FABSITE == "L5D")
                        proxy = new WebProxy("10.22.10.134", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3C" || req.FABSITE == "L4B")
                        proxy = null;
                    else if (req.FABSITE == "L6K")
                        proxy = new WebProxy("10.12.129.10", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        proxy = new WebProxy("10.34.128.199", PHMCache.GetJsonConfig().ProxyInfo.Port);//
                    else if (req.FABSITE == "C5E")
                        proxy = new WebProxy("10.34.129.100", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S11" || req.FABSITE == "S13" || req.FABSITE == "S17")
                        proxy = new WebProxy("10.9.9.5", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S01" || req.FABSITE == "S02" || req.FABSITE == "S06")
                        proxy = new WebProxy("10.6.114.50", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else
                        proxy = new WebProxy(PHMCache.GetJsonConfig().ProxyInfo.Host, PHMCache.GetJsonConfig().ProxyInfo.Port);




                    if (proxy != null)
                        client.Proxy = proxy;

                    if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        System.Net.ServicePointManager.Expect100Continue = false;
                    #endregion

                    string targetAddress = _url + "/" + "Get_Basicinfor";
                    client.Encoding = System.Text.Encoding.UTF8; ;
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    ReportResult = client.UploadString(targetAddress, InputJson);
                    DataConfig.rtnMsgShell Introduction = JsonConvert.DeserializeObject<DataConfig.rtnMsgShell>(ReportResult);

                    DataTable dtWbsData = new DataTable();
                    dtWbsData = Introduction.data.Data;
                    if (dtWbsData != null) {
                        if (dt.Columns.Count == 0)
                            dt = dtWbsData.Clone();
                        dt.Merge(dtWbsData);
                    }//if (dtWbsData != null) {
                }//for (int i = 0; i < AllDataType.Split('.').Length; i++) {

                DataTable dtSort = dt.DefaultView.ToTable(true, new string[] { "TOOLTYPE" });
                dtSort.Columns[0].ColumnName = "tool_type";

                var datas = dtSort.ToList<GetToolTypesResponse>();
                return datas != null && datas.Any() ? datas.ToList() : null;
            }
            catch (Exception e) {
                throw e;
            }

        }

        public List<GetToolTypesResponse> xxxGetToolTypesConti(GetToolTypesReqest req) {


            try {
                string _url = "";
                #region get url
                if (req.FABSITE.Trim() == "6A" || req.FABSITE.Trim() == "L6A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6A.Trim();
                else if (req.FABSITE.Trim() == "M11" || req.FABSITE.Trim() == "LM11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M11.Trim();
                else if (req.FABSITE.Trim() == "P01" || req.FABSITE.Trim() == "LP01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.P01.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "7A" || req.FABSITE.Trim() == "L7A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7A.Trim();
                else if (req.FABSITE.Trim() == "7-2" || req.FABSITE.Trim() == "L7B" || req.FABSITE.Trim() == "L7-2")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7B.Trim();
                else if (req.FABSITE.Trim() == "8A" || req.FABSITE.Trim() == "L8A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8A.Trim();
                else if (req.FABSITE.Trim() == "8B" || req.FABSITE.Trim() == "L8B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8B.Trim();
                else if (req.FABSITE.Trim() == "6B" || req.FABSITE.Trim() == "L6B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6B.Trim();
                else if (req.FABSITE.Trim() == "4B" || req.FABSITE.Trim() == "L4B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4B.Trim();
                else if (req.FABSITE.Trim() == "6K" || req.FABSITE.Trim() == "L6K")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6K.Trim();
                else if (req.FABSITE.Trim() == "3D" || req.FABSITE.Trim() == "L3D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3D.Trim();
                else if (req.FABSITE.Trim() == "5D" || req.FABSITE.Trim() == "L5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5D.Trim();
                else if (req.FABSITE.Trim() == "4A" || req.FABSITE.Trim() == "L4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4A.Trim();
                else if (req.FABSITE.Trim() == "5A" || req.FABSITE.Trim() == "L5A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5A.Trim();
                else if (req.FABSITE.Trim() == "5B" || req.FABSITE.Trim() == "L5B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5B.Trim();
                else if (req.FABSITE.Trim() == "3C" || req.FABSITE.Trim() == "L3C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3C.Trim();
                else if (req.FABSITE.Trim() == "C4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C4A.Trim();
                else if (req.FABSITE.Trim() == "C5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5D.Trim();
                else if (req.FABSITE.Trim() == "C6C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C6C.Trim();
                else if (req.FABSITE.Trim() == "C5E")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5E.Trim();
                else if (req.FABSITE.Trim() == "M02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M02.Trim();
                else if (req.FABSITE.Trim() == "M01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M01.Trim();
                else if (req.FABSITE.Trim() == "S11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S11.Trim();
                else if (req.FABSITE.Trim() == "S13")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S13.Trim();
                else if (req.FABSITE.Trim() == "S17")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S17.Trim();
                else if (req.FABSITE.Trim() == "S01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S01.Trim();
                else if (req.FABSITE.Trim() == "S02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S02.Trim();
                else if (req.FABSITE.Trim() == "S06")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S06.Trim();
                #endregion
                DataTable dt = new DataTable();

                string AllDataType = "CONTINUOUS";
                for (int i = 0; i < AllDataType.Split(',').Length; i++) {
                    DataConfig.InputJsonBasicinfor _input = new DataConfig.InputJsonBasicinfor();
                    _input.user = PHMCache.GetJsonConfig().OpenDataInfor.UID.Trim();
                    _input.password = PHMCache.GetJsonConfig().OpenDataInfor.PWD.Trim();
                    _input.FABSITE = req.FABSITE.Replace("L7B", "7-2").Replace("L5A", "5AB").Replace("L5B", "5AB").Replace("L", "");
                    _input.DATATYPE = AllDataType.Split(',')[i].Trim();
                    _input.PROCESSTYPE = req.PROCESSTYPE;
                    _input.MODULENAME = req.MODULENAME;
                    _input.TOOLVENDER = "";
                    _input.TOOLTYPE = "";
                    _input.ziped = "false";
                    string InputJson = JsonConvert.SerializeObject(_input);
                    string ReportResult = "";

                    WebClient client = new WebClient();
                    #region proxy
                    WebProxy proxy = null;
                    if (req.FABSITE == "L8B")//10.37.9.111
                        proxy = new WebProxy("10.37.9.111", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L6B" || req.FABSITE == "M02")
                        proxy = new WebProxy("10.31.10.188", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L4A" || req.FABSITE == "L5A" || req.FABSITE == "L5B")
                        proxy = new WebProxy("10.88.95.1", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3D" || req.FABSITE == "L5D")
                        proxy = new WebProxy("10.22.10.134", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3C" || req.FABSITE == "L4B")
                        proxy = null;
                    else if (req.FABSITE == "L6K")
                        proxy = new WebProxy("10.12.129.10", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        proxy = new WebProxy("10.34.128.199", PHMCache.GetJsonConfig().ProxyInfo.Port);//
                    else if (req.FABSITE == "C5E")
                        proxy = new WebProxy("10.34.129.100", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S11" || req.FABSITE == "S13" || req.FABSITE == "S17")
                        proxy = new WebProxy("10.9.9.5", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S01" || req.FABSITE == "S02" || req.FABSITE == "S06")
                        proxy = new WebProxy("10.6.114.50", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else
                        proxy = new WebProxy(PHMCache.GetJsonConfig().ProxyInfo.Host, PHMCache.GetJsonConfig().ProxyInfo.Port);




                    if (proxy != null)
                        client.Proxy = proxy;

                    if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        System.Net.ServicePointManager.Expect100Continue = false;
                    #endregion

                    string targetAddress = _url + "/" + "Get_Basicinfor";
                    client.Encoding = System.Text.Encoding.UTF8; ;
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    ReportResult = client.UploadString(targetAddress, InputJson);
                    DataConfig.rtnMsgShell Introduction = JsonConvert.DeserializeObject<DataConfig.rtnMsgShell>(ReportResult);

                    DataTable dtWbsData = new DataTable();
                    dtWbsData = Introduction.data.Data;
                    if (dtWbsData != null) {
                        if (dt.Columns.Count == 0)
                            dt = dtWbsData.Clone();
                        dt.Merge(dtWbsData);
                    }//if (dtWbsData != null) {
                }//for (int i = 0; i < AllDataType.Split('.').Length; i++) {

                DataTable dtSort = dt.DefaultView.ToTable(true, new string[] { "TOOLTYPE" });
                dtSort.Columns[0].ColumnName = "tool_type";

                var datas = dtSort.ToList<GetToolTypesResponse>();
                return datas != null && datas.Any() ? datas.ToList() : null;
            }
            catch (Exception e) {
                throw e;
            }

        }

        public List<GetToolsResponse> GetTools(GetToolsReqest req) {


            try {
                string _url = "";
                #region get url
                if (req.FABSITE.Trim() == "6A" || req.FABSITE.Trim() == "L6A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6A.Trim();
                else if (req.FABSITE.Trim() == "M11" || req.FABSITE.Trim() == "LM11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M11.Trim();
                else if (req.FABSITE.Trim() == "P01" || req.FABSITE.Trim() == "LP01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.P01.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "7A" || req.FABSITE.Trim() == "L7A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7A.Trim();
                else if (req.FABSITE.Trim() == "7-2" || req.FABSITE.Trim() == "L7B" || req.FABSITE.Trim() == "L7-2")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7B.Trim();
                else if (req.FABSITE.Trim() == "8A" || req.FABSITE.Trim() == "L8A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8A.Trim();
                else if (req.FABSITE.Trim() == "8B" || req.FABSITE.Trim() == "L8B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8B.Trim();
                else if (req.FABSITE.Trim() == "6B" || req.FABSITE.Trim() == "L6B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6B.Trim();
                else if (req.FABSITE.Trim() == "4B" || req.FABSITE.Trim() == "L4B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4B.Trim();
                else if (req.FABSITE.Trim() == "6K" || req.FABSITE.Trim() == "L6K")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6K.Trim();
                else if (req.FABSITE.Trim() == "3D" || req.FABSITE.Trim() == "L3D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3D.Trim();
                else if (req.FABSITE.Trim() == "5D" || req.FABSITE.Trim() == "L5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5D.Trim();
                else if (req.FABSITE.Trim() == "4A" || req.FABSITE.Trim() == "L4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4A.Trim();
                else if (req.FABSITE.Trim() == "5A" || req.FABSITE.Trim() == "L5A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5A.Trim();
                else if (req.FABSITE.Trim() == "5B" || req.FABSITE.Trim() == "L5B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5B.Trim();
                else if (req.FABSITE.Trim() == "3C" || req.FABSITE.Trim() == "L3C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3C.Trim();
                else if (req.FABSITE.Trim() == "C4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C4A.Trim();
                else if (req.FABSITE.Trim() == "C5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5D.Trim();
                else if (req.FABSITE.Trim() == "C6C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C6C.Trim();
                else if (req.FABSITE.Trim() == "C5E")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5E.Trim();
                else if (req.FABSITE.Trim() == "M02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M02.Trim();
                else if (req.FABSITE.Trim() == "M01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M01.Trim();
                else if (req.FABSITE.Trim() == "S11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S11.Trim();
                else if (req.FABSITE.Trim() == "S13")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S13.Trim();
                else if (req.FABSITE.Trim() == "S17")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S17.Trim();
                else if (req.FABSITE.Trim() == "S01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S01.Trim();
                else if (req.FABSITE.Trim() == "S02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S02.Trim();
                else if (req.FABSITE.Trim() == "S06")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S06.Trim();
                #endregion
                DataTable dt = new DataTable();

                //string AllDataType = "APC,CONTINUOUS";
                string AllDataType = req.DATATYPE;
                for (int i = 0; i < AllDataType.Split(',').Length; i++) {
                    DataConfig.InputJsonBasicinfor _input = new DataConfig.InputJsonBasicinfor();
                    _input.user = PHMCache.GetJsonConfig().OpenDataInfor.UID.Trim();
                    _input.password = PHMCache.GetJsonConfig().OpenDataInfor.PWD.Trim();
                    _input.FABSITE = req.FABSITE.Replace("L7B", "7-2").Replace("L5A", "5AB").Replace("L5B", "5AB").Replace("L", "");
                    _input.DATATYPE = AllDataType.Split(',')[i].Trim();
                    _input.PROCESSTYPE = req.PROCESSTYPE;
                    _input.MODULENAME = req.MODULENAME;
                    _input.TOOLVENDER = "";
                    _input.TOOLTYPE = req.TOOLTYPE;
                    _input.ziped = "false";
                    string InputJson = JsonConvert.SerializeObject(_input);
                    string ReportResult = "";

                    WebClient client = new WebClient();
                    #region proxy
                    WebProxy proxy = null;
                    if (req.FABSITE == "L8B")//10.37.9.111
                        proxy = new WebProxy("10.37.9.111", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L6B" || req.FABSITE == "M02")
                        proxy = new WebProxy("10.31.10.188", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L4A" || req.FABSITE == "L5A" || req.FABSITE == "L5B")
                        proxy = new WebProxy("10.88.95.1", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3D" || req.FABSITE == "L5D")
                        proxy = new WebProxy("10.22.10.134", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3C" || req.FABSITE == "L4B")
                        proxy = null;
                    else if (req.FABSITE == "L6K")
                        proxy = new WebProxy("10.12.129.10", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        proxy = new WebProxy("10.34.128.199", PHMCache.GetJsonConfig().ProxyInfo.Port);//
                    else if (req.FABSITE == "C5E")
                        proxy = new WebProxy("10.34.129.100", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S11" || req.FABSITE == "S13" || req.FABSITE == "S17")
                        proxy = new WebProxy("10.9.9.5", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S01" || req.FABSITE == "S02" || req.FABSITE == "S06")
                        proxy = new WebProxy("10.6.114.50", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else
                        proxy = new WebProxy(PHMCache.GetJsonConfig().ProxyInfo.Host, PHMCache.GetJsonConfig().ProxyInfo.Port);




                    if (proxy != null)
                        client.Proxy = proxy;

                    if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        System.Net.ServicePointManager.Expect100Continue = false;
                    #endregion

                    string targetAddress = _url + "/" + "Get_Basicinfor";
                    client.Encoding = System.Text.Encoding.UTF8; ;
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    ReportResult = client.UploadString(targetAddress, InputJson);
                    DataConfig.rtnMsgShell Introduction = JsonConvert.DeserializeObject<DataConfig.rtnMsgShell>(ReportResult);

                    DataTable dtWbsData = new DataTable();
                    dtWbsData = Introduction.data.Data;
                    if (dtWbsData != null) {
                        if (dt.Columns.Count == 0)
                            dt = dtWbsData.Clone();
                        dt.Merge(dtWbsData);
                    }//if (dtWbsData != null) {
                }//for (int i = 0; i < AllDataType.Split('.').Length; i++) {

                DataTable dtSort = dt.DefaultView.ToTable(true, new string[] { "TOOLID" });
                dtSort.Columns[0].ColumnName = "tool";


                var datas = dtSort.ToList<GetToolsResponse>();
                return datas != null && datas.Any() ? datas.ToList() : null;
            }
            catch (Exception e) {
                logger.Error(e);
                throw e;
            }

        }

        public List<GetToolsResponse> xxxGetToolsConti(GetToolsReqest req) {


            try {
                string _url = "";
                #region get url
                if (req.FABSITE.Trim() == "6A" || req.FABSITE.Trim() == "L6A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6A.Trim();
                else if (req.FABSITE.Trim() == "M11" || req.FABSITE.Trim() == "LM11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M11.Trim();
                else if (req.FABSITE.Trim() == "P01" || req.FABSITE.Trim() == "LP01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.P01.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5C.Trim();
                else if (req.FABSITE.Trim() == "7A" || req.FABSITE.Trim() == "L7A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7A.Trim();
                else if (req.FABSITE.Trim() == "7-2" || req.FABSITE.Trim() == "L7B" || req.FABSITE.Trim() == "L7-2")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L7B.Trim();
                else if (req.FABSITE.Trim() == "8A" || req.FABSITE.Trim() == "L8A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8A.Trim();
                else if (req.FABSITE.Trim() == "8B" || req.FABSITE.Trim() == "L8B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L8B.Trim();
                else if (req.FABSITE.Trim() == "6B" || req.FABSITE.Trim() == "L6B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6B.Trim();
                else if (req.FABSITE.Trim() == "4B" || req.FABSITE.Trim() == "L4B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4B.Trim();
                else if (req.FABSITE.Trim() == "6K" || req.FABSITE.Trim() == "L6K")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L6K.Trim();
                else if (req.FABSITE.Trim() == "3D" || req.FABSITE.Trim() == "L3D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3D.Trim();
                else if (req.FABSITE.Trim() == "5D" || req.FABSITE.Trim() == "L5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5D.Trim();
                else if (req.FABSITE.Trim() == "4A" || req.FABSITE.Trim() == "L4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L4A.Trim();
                else if (req.FABSITE.Trim() == "5A" || req.FABSITE.Trim() == "L5A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5A.Trim();
                else if (req.FABSITE.Trim() == "5B" || req.FABSITE.Trim() == "L5B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L5B.Trim();
                else if (req.FABSITE.Trim() == "3C" || req.FABSITE.Trim() == "L3C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.L3C.Trim();
                else if (req.FABSITE.Trim() == "C4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C4A.Trim();
                else if (req.FABSITE.Trim() == "C5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5D.Trim();
                else if (req.FABSITE.Trim() == "C6C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C6C.Trim();
                else if (req.FABSITE.Trim() == "C5E")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.C5E.Trim();
                else if (req.FABSITE.Trim() == "M02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M02.Trim();
                else if (req.FABSITE.Trim() == "M01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.M01.Trim();
                else if (req.FABSITE.Trim() == "S11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S11.Trim();
                else if (req.FABSITE.Trim() == "S13")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S13.Trim();
                else if (req.FABSITE.Trim() == "S17")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S17.Trim();
                else if (req.FABSITE.Trim() == "S01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S01.Trim();
                else if (req.FABSITE.Trim() == "S02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S02.Trim();
                else if (req.FABSITE.Trim() == "S06")
                    _url = PHMCache.GetJsonConfig().WebServiceURL.S06.Trim();
                #endregion
                DataTable dt = new DataTable();

                string AllDataType = "CONTINUOUS";
                for (int i = 0; i < AllDataType.Split(',').Length; i++) {
                    DataConfig.InputJsonBasicinfor _input = new DataConfig.InputJsonBasicinfor();
                    _input.user = PHMCache.GetJsonConfig().OpenDataInfor.UID.Trim();
                    _input.password = PHMCache.GetJsonConfig().OpenDataInfor.PWD.Trim();
                    _input.FABSITE = req.FABSITE.Replace("L7B", "7-2").Replace("L5A", "5AB").Replace("L5B", "5AB").Replace("L", "");
                    _input.DATATYPE = AllDataType.Split(',')[i].Trim();
                    _input.PROCESSTYPE = req.PROCESSTYPE;
                    _input.MODULENAME = req.MODULENAME;
                    _input.TOOLVENDER = "";
                    _input.TOOLTYPE = req.TOOLTYPE;
                    _input.ziped = "false";
                    string InputJson = JsonConvert.SerializeObject(_input);
                    string ReportResult = "";

                    WebClient client = new WebClient();
                    #region proxy
                    WebProxy proxy = null;
                    if (req.FABSITE == "L8B")//10.37.9.111
                        proxy = new WebProxy("10.37.9.111", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L6B" || req.FABSITE == "M02")
                        proxy = new WebProxy("10.31.10.188", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L4A" || req.FABSITE == "L5A" || req.FABSITE == "L5B")
                        proxy = new WebProxy("10.88.95.1", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3D" || req.FABSITE == "L5D")
                        proxy = new WebProxy("10.22.10.134", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3C" || req.FABSITE == "L4B")
                        proxy = null;
                    else if (req.FABSITE == "L6K")
                        proxy = new WebProxy("10.12.129.10", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        proxy = new WebProxy("10.34.128.199", PHMCache.GetJsonConfig().ProxyInfo.Port);//
                    else if (req.FABSITE == "C5E")
                        proxy = new WebProxy("10.34.129.100", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S11" || req.FABSITE == "S13" || req.FABSITE == "S17")
                        proxy = new WebProxy("10.9.9.5", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S01" || req.FABSITE == "S02" || req.FABSITE == "S06")
                        proxy = new WebProxy("10.6.114.50", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else
                        proxy = new WebProxy(PHMCache.GetJsonConfig().ProxyInfo.Host, PHMCache.GetJsonConfig().ProxyInfo.Port);




                    if (proxy != null)
                        client.Proxy = proxy;

                    if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        System.Net.ServicePointManager.Expect100Continue = false;
                    #endregion

                    string targetAddress = _url + "/" + "Get_Basicinfor";
                    client.Encoding = System.Text.Encoding.UTF8; ;
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    ReportResult = client.UploadString(targetAddress, InputJson);
                    DataConfig.rtnMsgShell Introduction = JsonConvert.DeserializeObject<DataConfig.rtnMsgShell>(ReportResult);

                    DataTable dtWbsData = new DataTable();
                    dtWbsData = Introduction.data.Data;
                    if (dtWbsData != null) {
                        if (dt.Columns.Count == 0)
                            dt = dtWbsData.Clone();
                        dt.Merge(dtWbsData);
                    }//if (dtWbsData != null) {
                }//for (int i = 0; i < AllDataType.Split('.').Length; i++) {

                DataTable dtSort = dt.DefaultView.ToTable(true, new string[] { "TOOLID" });
                dtSort.Columns[0].ColumnName = "tool";


                var datas = dtSort.ToList<GetToolsResponse>();
                return datas != null && datas.Any() ? datas.ToList() : null;
            }
            catch (Exception e) {
                logger.Error(e);
                throw e;
            }

        }

        public List<GetChambersResponse> GetChambers(GetChambersReqest req) {


            try {
                string _url = "";
                #region get url
                if (req.FABSITE.Trim() == "6A" || req.FABSITE.Trim() == "L6A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L6A.Trim();
                else if (req.FABSITE.Trim() == "M11" || req.FABSITE.Trim() == "LM11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.M11.Trim();
                else if (req.FABSITE.Trim() == "P01" || req.FABSITE.Trim() == "LP01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.P01.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L5C.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L5C.Trim();
                else if (req.FABSITE.Trim() == "7A" || req.FABSITE.Trim() == "L7A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L7A.Trim();
                else if (req.FABSITE.Trim() == "7-2" || req.FABSITE.Trim() == "L7B" || req.FABSITE.Trim() == "L7-2")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L7B.Trim();
                else if (req.FABSITE.Trim() == "8A" || req.FABSITE.Trim() == "L8A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L8A.Trim();
                else if (req.FABSITE.Trim() == "8B" || req.FABSITE.Trim() == "L8B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L8B.Trim();
                else if (req.FABSITE.Trim() == "6B" || req.FABSITE.Trim() == "L6B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L6B.Trim();
                else if (req.FABSITE.Trim() == "4B" || req.FABSITE.Trim() == "L4B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L4B.Trim();
                else if (req.FABSITE.Trim() == "6K" || req.FABSITE.Trim() == "L6K")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L6K.Trim();
                else if (req.FABSITE.Trim() == "3D" || req.FABSITE.Trim() == "L3D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L3D.Trim();
                else if (req.FABSITE.Trim() == "5D" || req.FABSITE.Trim() == "L5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L5D.Trim();
                else if (req.FABSITE.Trim() == "4A" || req.FABSITE.Trim() == "L4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L4A.Trim();
                else if (req.FABSITE.Trim() == "5A" || req.FABSITE.Trim() == "L5A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L5A.Trim();
                else if (req.FABSITE.Trim() == "5B" || req.FABSITE.Trim() == "L5B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L5B.Trim();
                else if (req.FABSITE.Trim() == "3C" || req.FABSITE.Trim() == "L3C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L3C.Trim();
                else if (req.FABSITE.Trim() == "C4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.C4A.Trim();
                else if (req.FABSITE.Trim() == "C5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.C5D.Trim();
                else if (req.FABSITE.Trim() == "C6C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.C6C.Trim();
                else if (req.FABSITE.Trim() == "C5E")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.C5E.Trim();
                else if (req.FABSITE.Trim() == "M02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.M02.Trim();
                else if (req.FABSITE.Trim() == "M01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.M01.Trim();
                else if (req.FABSITE.Trim() == "S11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.S11.Trim();
                else if (req.FABSITE.Trim() == "S13")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.S13.Trim();
                else if (req.FABSITE.Trim() == "S17")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.S17.Trim();
                else if (req.FABSITE.Trim() == "S01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.S01.Trim();
                else if (req.FABSITE.Trim() == "S02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.S02.Trim();
                else if (req.FABSITE.Trim() == "S06")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.S06.Trim();
                #endregion


                DataTable dt = new DataTable();
                //string AllDataType = "RD,CONTINUOUS";
                string AllDataType = req.DATATYPE;
                for (int i = 0; i < AllDataType.Split(',').Length; i++) {
                    DataConfig.InputJsonChamber _input = new DataConfig.InputJsonChamber();
                    _input.user = PHMCache.GetJsonConfig().OpenDataInfor.UID.Trim();
                    _input.password = PHMCache.GetJsonConfig().OpenDataInfor.PWD.Trim();
                    _input.FABSITE = req.FABSITE.Replace("L7B", "7-2").Replace("L5A", "5AB").Replace("L5B", "5AB").Replace("L", "");
                    _input.TOOLID = req.TOOLID;
                    _input.DATATYPE = AllDataType.Split(',')[i].Trim();
                    _input.ziped = "false";
                    string InputJson = JsonConvert.SerializeObject(_input);
                    string ReportResult = "";

                    WebClient client = new WebClient();
                    #region proxy
                    WebProxy proxy = null;
                    if (req.FABSITE == "L8B")//10.37.9.111
                        proxy = new WebProxy("10.37.9.111", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L6B" || req.FABSITE == "M02")
                        proxy = new WebProxy("10.31.10.188", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L4A" || req.FABSITE == "L5A" || req.FABSITE == "L5B")
                        proxy = new WebProxy("10.88.95.1", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3D" || req.FABSITE == "L5D")
                        proxy = new WebProxy("10.22.10.134", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3C" || req.FABSITE == "L4B")
                        proxy = null;
                    else if (req.FABSITE == "L6K")
                        proxy = new WebProxy("10.12.129.10", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        proxy = new WebProxy("10.34.128.199", PHMCache.GetJsonConfig().ProxyInfo.Port);//
                    else if (req.FABSITE == "C5E")
                        proxy = new WebProxy("10.34.129.100", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S11" || req.FABSITE == "S13" || req.FABSITE == "S17")
                        proxy = new WebProxy("10.9.9.5", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S01" || req.FABSITE == "S02" || req.FABSITE == "S06")
                        proxy = new WebProxy("10.6.114.50", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else
                        proxy = new WebProxy(PHMCache.GetJsonConfig().ProxyInfo.Host, PHMCache.GetJsonConfig().ProxyInfo.Port);




                    if (proxy != null)
                        client.Proxy = proxy;

                    if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        System.Net.ServicePointManager.Expect100Continue = false;
                    #endregion

                    string targetAddress = _url + "/" + "Get_Chamber";
                    client.Encoding = System.Text.Encoding.UTF8; ;
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    ReportResult = client.UploadString(targetAddress, InputJson);
                    DataConfig.rtnMsgShell Introduction = JsonConvert.DeserializeObject<DataConfig.rtnMsgShell>(ReportResult);
                    DataTable dtWbsData = new DataTable();
                    dtWbsData = Introduction.data.Data;
                    if (dtWbsData != null) {
                        if (dt.Columns.Count == 0)
                            dt = dtWbsData.Clone();
                        dt.Merge(dtWbsData);
                    }
                    else {
                        if(dt.Columns.Count == 0) {
                            dt.Columns.Add(new DataColumn("CHAMBER", typeof(String)));
                        }
                    }//if (dtWbsData != null) {

                }//for (int i = 0; i < AllDataType.Split(',').Length; i++) {
                DataTable dtSort = dt.DefaultView.ToTable(true, new string[] { "CHAMBER" });
                dtSort.Columns[0].ColumnName = "chamber";

                var datas = dtSort.ToList<GetChambersResponse>();
                return datas != null && datas.Any() ? datas.ToList() : null;
            }
            catch (Exception e) {
                logger.Error(e);
                throw e;
            }



        }

        public List<GetChambersResponse> xxxGetChambersConti(GetChambersReqest req) {


            try {
                string _url = "";
                #region get url
                if (req.FABSITE.Trim() == "6A" || req.FABSITE.Trim() == "L6A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L6A.Trim();
                else if (req.FABSITE.Trim() == "M11" || req.FABSITE.Trim() == "LM11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.M11.Trim();
                else if (req.FABSITE.Trim() == "P01" || req.FABSITE.Trim() == "LP01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.P01.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L5C.Trim();
                else if (req.FABSITE.Trim() == "5C" || req.FABSITE.Trim() == "L5C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L5C.Trim();
                else if (req.FABSITE.Trim() == "7A" || req.FABSITE.Trim() == "L7A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L7A.Trim();
                else if (req.FABSITE.Trim() == "7-2" || req.FABSITE.Trim() == "L7B" || req.FABSITE.Trim() == "L7-2")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L7B.Trim();
                else if (req.FABSITE.Trim() == "8A" || req.FABSITE.Trim() == "L8A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L8A.Trim();
                else if (req.FABSITE.Trim() == "8B" || req.FABSITE.Trim() == "L8B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L8B.Trim();
                else if (req.FABSITE.Trim() == "6B" || req.FABSITE.Trim() == "L6B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L6B.Trim();
                else if (req.FABSITE.Trim() == "4B" || req.FABSITE.Trim() == "L4B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L4B.Trim();
                else if (req.FABSITE.Trim() == "6K" || req.FABSITE.Trim() == "L6K")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L6K.Trim();
                else if (req.FABSITE.Trim() == "3D" || req.FABSITE.Trim() == "L3D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L3D.Trim();
                else if (req.FABSITE.Trim() == "5D" || req.FABSITE.Trim() == "L5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L5D.Trim();
                else if (req.FABSITE.Trim() == "4A" || req.FABSITE.Trim() == "L4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L4A.Trim();
                else if (req.FABSITE.Trim() == "5A" || req.FABSITE.Trim() == "L5A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L5A.Trim();
                else if (req.FABSITE.Trim() == "5B" || req.FABSITE.Trim() == "L5B")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L5B.Trim();
                else if (req.FABSITE.Trim() == "3C" || req.FABSITE.Trim() == "L3C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.L3C.Trim();
                else if (req.FABSITE.Trim() == "C4A")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.C4A.Trim();
                else if (req.FABSITE.Trim() == "C5D")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.C5D.Trim();
                else if (req.FABSITE.Trim() == "C6C")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.C6C.Trim();
                else if (req.FABSITE.Trim() == "C5E")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.C5E.Trim();
                else if (req.FABSITE.Trim() == "M02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.M02.Trim();
                else if (req.FABSITE.Trim() == "M01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.M01.Trim();
                else if (req.FABSITE.Trim() == "S11")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.S11.Trim();
                else if (req.FABSITE.Trim() == "S13")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.S13.Trim();
                else if (req.FABSITE.Trim() == "S17")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.S17.Trim();
                else if (req.FABSITE.Trim() == "S01")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.S01.Trim();
                else if (req.FABSITE.Trim() == "S02")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.S02.Trim();
                else if (req.FABSITE.Trim() == "S06")
                    _url = PHMCache.GetJsonConfig().WebServiceURL_Chamber.S06.Trim();
                #endregion


                DataTable dt = new DataTable();
                string AllDataType = "CONTINUOUS";
                for (int i = 0; i < AllDataType.Split(',').Length; i++) {
                    DataConfig.InputJsonChamber _input = new DataConfig.InputJsonChamber();
                    _input.user = PHMCache.GetJsonConfig().OpenDataInfor.UID.Trim();
                    _input.password = PHMCache.GetJsonConfig().OpenDataInfor.PWD.Trim();
                    _input.FABSITE = req.FABSITE.Replace("L7B", "7-2").Replace("L5A", "5AB").Replace("L5B", "5AB").Replace("L", "");
                    _input.TOOLID = req.TOOLID;
                    _input.DATATYPE = AllDataType.Split(',')[i].Trim();
                    _input.ziped = "false";
                    string InputJson = JsonConvert.SerializeObject(_input);
                    string ReportResult = "";

                    WebClient client = new WebClient();
                    #region proxy
                    WebProxy proxy = null;
                    if (req.FABSITE == "L8B")//10.37.9.111
                        proxy = new WebProxy("10.37.9.111", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L6B" || req.FABSITE == "M02")
                        proxy = new WebProxy("10.31.10.188", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L4A" || req.FABSITE == "L5A" || req.FABSITE == "L5B")
                        proxy = new WebProxy("10.88.95.1", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3D" || req.FABSITE == "L5D")
                        proxy = new WebProxy("10.22.10.134", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "L3C" || req.FABSITE == "L4B")
                        proxy = null;
                    else if (req.FABSITE == "L6K")
                        proxy = new WebProxy("10.12.129.10", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        proxy = new WebProxy("10.34.128.199", PHMCache.GetJsonConfig().ProxyInfo.Port);//
                    else if (req.FABSITE == "C5E")
                        proxy = new WebProxy("10.34.129.100", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S11" || req.FABSITE == "S13" || req.FABSITE == "S17")
                        proxy = new WebProxy("10.9.9.5", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else if (req.FABSITE == "S01" || req.FABSITE == "S02" || req.FABSITE == "S06")
                        proxy = new WebProxy("10.6.114.50", PHMCache.GetJsonConfig().ProxyInfo.Port);
                    else
                        proxy = new WebProxy(PHMCache.GetJsonConfig().ProxyInfo.Host, PHMCache.GetJsonConfig().ProxyInfo.Port);




                    if (proxy != null)
                        client.Proxy = proxy;

                    if (req.FABSITE == "C4A" || req.FABSITE == "C5D" || req.FABSITE == "C6C")
                        System.Net.ServicePointManager.Expect100Continue = false;
                    #endregion

                    string targetAddress = _url + "/" + "Get_Chamber";
                    client.Encoding = System.Text.Encoding.UTF8; ;
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    ReportResult = client.UploadString(targetAddress, InputJson);
                    DataConfig.rtnMsgShell Introduction = JsonConvert.DeserializeObject<DataConfig.rtnMsgShell>(ReportResult);
                    DataTable dtWbsData = new DataTable();
                    dtWbsData = Introduction.data.Data;
                    if (dtWbsData != null) {
                        if (dt.Columns.Count == 0)
                            dt = dtWbsData.Clone();
                        dt.Merge(dtWbsData);
                    }
                    else {
                        if (dt.Columns.Count == 0) {
                            dt.Columns.Add(new DataColumn("CHAMBER", typeof(String)));
                        }
                    }//if (dtWbsData != null) {

                }//for (int i = 0; i < AllDataType.Split(',').Length; i++) {
                DataTable dtSort = dt.DefaultView.ToTable(true, new string[] { "CHAMBER" });
                dtSort.Columns[0].ColumnName = "chamber";

                var datas = dtSort.ToList<GetChambersResponse>();
                return datas != null && datas.Any() ? datas.ToList() : null;
            }
            catch (Exception e) {
                logger.Error(e);
                throw e;
            }



        }
    }
}