﻿var app = new Vue({
    el: '#app', 
    store,
    data: {      
        pageInfo: {}
    },
    mounted: function () {
        store.commit("setDefaultProjectId");
        store.commit("setDefaultModelId");
        store.commit("setProjectInfo");  

        var self = this;
        self.getStatusInfo();
    },
    methods: {       
        getStatusInfo: function () {
            var self = this;
            if (store.getters.getCurrentDataSource == "raw_data" && store.getters.getOfflineModelStatus > 2000) {
                var pageInfo = store.getters.getStatusInfosRawData.find(function (page) {
                    return page.offline_model_status == store.getters.getOfflineModelStatus;
                });
                self.pageInfo = pageInfo;
            }
            else {
                var pageInfo = store.getters.getStatusInfos.find(function (page) {
                    return page.offline_model_status == store.getters.getOfflineModelStatus;
                });
                self.pageInfo = pageInfo;
            }

            //var pageInfo = store.getters.getStatusInfos.find(function (page) {
            //    return page.offline_model_status == store.getters.getOfflineModelStatus;
            //});
            self.pageInfo = pageInfo;

            store.commit('setShowLoading', false);                     
        },

        resetData: function () {
            var self = this;
            if (self.pageInfo.extensionInfo.needToResetStatus) {
                var apiUrl = "/model_training";


                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onPut(apiUrl).reply(200, { "code": 200, "data": {}, "description": "Successful response", "status": "OK" });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                axios({
                    method: 'put',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    data: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                        offline_model_status: self.pageInfo.extensionInfo.updateStatus
                    }
                })
                    .then(function (response) {
                        if (response.data.status == "OK")
                            window.location.href = self.pageInfo.extensionInfo.backUrl;
                        else
                            alertify.alert("操作失敗，請重新操作，謝謝!");
                    })
                    .catch(function (err) {
                        alertify.alert(err);
                    })

            }
            else {
                window.location.href = self.pageInfo.extensionInfo.backUrl;
            }


           
        }
    }
})