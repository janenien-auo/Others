﻿//var logError = require('Log').logError;
//var getUrlParameterByName = require('UrlHelper').getUrlParameterByName;

var store = new Vuex.Store({
    state: {
        env: "prd",//控制環境,
        isApiTest: false,
        isShowRawDatafunc: true,
        isShowCustomAlgorithm: true,
        homePage: "/Home/Index",//首頁
        showLoading: false,//控制是否要顯示Loading       
        offlineApiUrl: "http://tcapcphmd01:8001", //呼叫API的連結 
        onlineApiUrl: "http://tcapcphmd01:7000", //呼叫API的連結
        applications: ["Robot", "Pump", "MOTOR", "DRIVER", "BEARING", "CYLINDER", "GUIDE BLOCK", "WHEEL", "CHAMBER DOOR", "STAGE", "BALLSCREW", "GEAR" ],
        marchieParts: ["Motor", "Reducer"],
        spectrumMethodInfos: [
            {
                patameter: "FFT",
                spectrum: "Fast Fourier Transform",
                explain: "FFT computes the Discrete Fourier Transform of a sequence."
            },
            {
                patameter: "PSD",
                spectrum: "Power Spectral Density",
                explain:
                    "PSD describe the distribution of power into frequency components composing that signal."
            },
            {
                patameter: "DWT",
                spectrum: "Discrete Wavelet Transform",
                explain:
                    "DWT is any wavelet transform for which the wavelets are discretely sampled."
            },
            {
                patameter: "WP",
                spectrum: "Wavelet Packets",
                explain:
                    "WP is a wavelet transform where the discrete-time(sampled) signal is passed through more filters than the DWT."
            },
            {
                patameter: "Time_Domain",
                spectrum: "Wavelet Packets",
                explain:
                    "WP is a wavelet transform where the discrete-time(sampled) signal is passed through more filters than the DWT."
            }
        ],
        spectrumMethodInfos_rawdata: [
            {            
                limitStep:["Step"],
                patameter: "WP",
                spectrum: "Wavelet Packets",
                explain:
                    "WP is a wavelet transform where the discrete-time(sampled) signal is passed through more filters than the DWT."
            },
            {
                patameter: "Time_Domain",
                spectrum: "",
                explain: "Time Domain computes the transitory response of a sequence, and it indicates the flow of both mechanical and electrical energies."
            },
            {
                patameter: "Time_Domain_Diff",
                spectrum: "Time Domain Differential",
                explain: "Time Domain Differential computes the differential of a sequence."
            }
        ],
        statisticalInfos: [
            {
                abbreviation: "Entropy",
                fullname: "Information entropy",
                explain:
                    "Information entropy is the average rate at which information is produced by a stochastic source of data."
            },
            //20200206-總立告知移除
            //{
            //    abbreviation: "Peak2peak",
            //    fullname: "Peak to Peak",
            //    explain: "Peak2peak is the range of values (maximum - minimum)"
            //},
            {
                abbreviation: "Std",
                fullname: "Standard deviation",
                explain:
                    "Standard deviation is a measure of the amount of variation or dispersion of a set of values"
            },
            {
                abbreviation: "Var",
                fullname: "Variance",
                explain:
                    "Variance is the expectation of the squared deviation of a random variable from its mean."
            },
            {
                abbreviation: "Rms",
                fullname: "Root Mean Square",
                explain: "RMS is defined as the square root of the mean square."
            },
            {
                abbreviation: "Mean",
                fullname: "",
                explain: "Mean is the sum of the values divided by the number of values"
            },
            {
                abbreviation: "Skewness",
                fullname: "",
                explain:
                    "Skewness is a measure of the asymmetry of the probability distribution of a real-valued random variable about its mean"
            },
            {
                abbreviation: "Kurtosis",
                fullname: "",
                explain:
                    "Kurtosis is a measure of the 'tailedness' of the probability distribution of a real-valued random variable."
            },
            {
                abbreviation: "Quantile_5",
                fullname: "",
                explain:
                    "Compute the 5-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Quantile_25",
                fullname: "",
                explain:
                    "Compute the 25-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Quantile_50",
                fullname: "",
                explain:
                    "Compute the 50-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Quantile_75",
                fullname: "",
                explain:
                    "Compute the 75-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Quantile_95",
                fullname: "",
                explain:
                    "Compute the 95-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Max",
                fullname: "Maximum",
                explain:
                    "Maximum is the maximum of the values."
            },
            {
                abbreviation: "Min",
                fullname: "Minimum",
                explain:
                    "Minimum is the minimum of the values."
            },
            {
                abbreviation: "Max_Min",
                fullname: "",
                explain:
                    "Max_Min is the range of the values."
            },
            {
                abbreviation: "Crest",
                fullname: "",
                explain:
                    "Crest indicates how extreme the peaks are in a sequence."
            },
            {
                abbreviation: "Clearance",
                fullname: "",
                explain:
                    "Clearance computes peak value divided by the squared mean value of the square roots of the absolute amplitudes. "
            },
            {
                abbreviation: "Shape",
                fullname: "",
                explain:
                    "Shape is a measure of the general shape of a distribution."
            },
            {
                abbreviation: "Impulse",
                fullname: "",
                explain:
                    "Impulse is the reaction of a sequence in response to some external change. "
            }
        ],
        statisticalInfos_conti: [
            {
                abbreviation: "Entropy",
                fullname: "Information entropy",
                explain:
                    "Information entropy is the average rate at which information is produced by a stochastic source of data."
            },
            {
                abbreviation: "Std",
                fullname: "Standard deviation",
                explain:
                    "Standard deviation is a measure of the amount of variation or dispersion of a set of values"
            },
            {
                abbreviation: "Var",
                fullname: "Variance",
                explain:
                    "Variance is the expectation of the squared deviation of a random variable from its mean."
            },
            {
                abbreviation: "Rms",
                fullname: "Root Mean Square",
                explain: "RMS is defined as the square root of the mean square."
            },
            {
                abbreviation: "Mean",
                fullname: "",
                explain: "Mean is the sum of the values divided by the number of values"
            },
            {
                abbreviation: "Skewness",
                fullname: "",
                explain:
                    "Skewness is a measure of the asymmetry of the probability distribution of a real-valued random variable about its mean"
            },
            {
                abbreviation: "Kurtosis",
                fullname: "",
                explain:
                    "Kurtosis is a measure of the 'tailedness' of the probability distribution of a real-valued random variable."
            },
            {
                abbreviation: "Quantile_5",
                fullname: "",
                explain:
                    "Compute the 5-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Quantile_25",
                fullname: "",
                explain:
                    "Compute the 25-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Quantile_50",
                fullname: "",
                explain:
                    "Compute the 50-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Quantile_75",
                fullname: "",
                explain:
                    "Compute the 75-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Quantile_95",
                fullname: "",
                explain:
                    "Compute the 95-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Max",
                fullname: "",
                explain:
                    ""
            },
            {
                abbreviation: "Min",
                fullname: "",
                explain:
                    ""
            },
            {
                abbreviation: "Max_Min",
                fullname: "",
                explain:
                    ""
            },
            {
                abbreviation: "Crest",
                fullname: "",
                explain:
                    ""
            },
            {
                abbreviation: "Clearance",
                fullname: "",
                explain:
                    ""
            },
            {
                abbreviation: "Shape",
                fullname: "",
                explain:
                    ""
            },
            {
                abbreviation: "Impulse",
                fullname: "",
                explain:
                    ""
            }
        ],
        statistical_conti: ["Std", "Rms", "Kurtosis", "Var", "Max_Min", "Skewness"],
        statistical_rawdata: ["Std", "Rms", "Kurtosis", "Var", "Max_Min", "Skewness"],
        modelingAlgorithm: [
            {
                model: "n_neighbors",
                algorithm: "LOF"
            },
            {
                model: "n_neighbors",
                algorithm: "RBF_LOF"
            },
            {
                model: "explained_variance",
                algorithm: "PCA_T2"
            }
        ],
        statusInfos: [
            {
                isShowStep: true,
                showStep: "1",
                title: "Project Register",
                offline_model_status: 100,
                statusName: "Project Register",
                url: "/Project/ProjectInfo",
                needToUpdateStatus: true,
                nextStatus: 200,
                mainStep: true,
                dataTypes: ["SensorRich", "Feature", "Continuous","RawData"]
            },
            {
                isShowStep: true,
                showStep: "2",
                title: "Data Collection",
                offline_model_status: 200,
                statusName: "Data Collection",
                url: "/Project/UploadFiles",
                needToUpdateStatus: true,
                nextStatus: 300,
                mainStep: true,
                dataTypes: ["SensorRich", "Feature"]
            },
            {
                isShowStep: true,
                showStep: "3",
                title: "Feature Engineering",
                offline_model_status: 300,
                statusName: "Feature Engineering",
                url: "/Project/FeatureEngineering",
                needToUpdateStatus: false,
                nextStatus: 600,
                mainStep: true,
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                showStep: "3",
                title: "Feature Engineering",
                offline_model_status: 301,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                offline_model_status: 303,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/Project/FeatureEngineering",
                    updateStatus: 300,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                showStep: "3",
                title: "Feature Engineering",
                offline_model_status: 400,
                statusName: "Feature Engineering",
                url: "/Project/FeatureEngineering",
                needToUpdateStatus: false,
                nextStatus: 600,
                mainStep: true,
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                offline_model_status: 401,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                offline_model_status: 403,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/Project/FeatureEngineering",
                    updateStatus: 400,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                showStep: "3",
                title: "Feature Engineering",
                offline_model_status: 500,
                statusName: "Feature Engineering",
                url: "/Project/FeatureEngineering",
                needToUpdateStatus: false,
                nextStatus: 600,
                mainStep: true,
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                offline_model_status: 501,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                offline_model_status: 503,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/Project/FeatureEngineering",
                    updateStatus: 500,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: true,
                showStep: "4",
                title: "Data Process",
                offline_model_status: 600,
                statusName: "Data Process",
                url: "/Project/DataProcess",
                needToUpdateStatus: false,
                nextStatus: 700,
                mainStep: true,
                dataTypes: ["SensorRich", "Feature", "Continuous", "RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 601,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["SensorRich", "Feature", "Continuous", "RawData"]
            },
            {
                isShowStep: false,
                title: "Data Process",
                offline_model_status: 602,
                statusName: "Data Process",
                url: "/Project/DataProcess",
                needToUpdateStatus: true,
                nextStatus: 700,
                mainStep: false,
                dataTypes: ["SensorRich", "Feature", "Continuous", "RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 603,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/Project/DataProcess",
                    updateStatus: 600,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["SensorRich", "Feature", "Continuous", "RawData"]
            },
            {
                isShowStep: true,
                showStep: "5",
                title: "Feature Selection",
                offline_model_status: 700,
                statusName: "Feature Selection",
                url: "/Project/FeatureSelection",
                needToUpdateStatus: false,
                nextStatus: 702, //nextStatus主要控制要去哪一頁  
                mainStep: true,
                dataTypes: ["SensorRich", "Feature", "Continuous", "RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 701,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["SensorRich", "Feature", "Continuous", "RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 702,
                statusName: "Feature Selection",
                url: "/Project/FeatureSelection",
                needToUpdateStatus: false,
                nextStatus: 800, //nextStatus主要控制要去哪一頁  
                mainStep: false,
                dataTypes: ["SensorRich", "Feature", "Continuous", "RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 703,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/Project/FeatureSelection",
                    updateStatus: 700,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["SensorRich", "Feature", "Continuous", "RawData"]
            },
            {
                isShowStep: true,
                showStep: "6",
                title: "Modeling",
                offline_model_status: 800,
                statusName: "Modeling",
                url: "/Project/ModelResult",
                dataTypes: ["SensorRich", "Feature", "Continuous", "RawData"],
                mainStep: true
            },
            {
                isShowStep: false,
                offline_model_status: 801,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["SensorRich", "Feature", "Continuous","RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 802,
                statusName: "Model Result",
                url: "/Project/ModelResult",
                dataTypes: ["SensorRich", "Feature", "Continuous","RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 803,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/Project/FeatureSelection",
                    updateStatus: 700,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["SensorRich", "Feature", "Continuous","RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 2601,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 2603,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/ProjectRawData/ParameterSelectRawData",
                    updateStatus: 2000,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["RawData"]
            }
        ],
        statusInfosConti: [
            {
                isShowStep: true,
                showStep: "1",
                title: "Parameter Select",
                offline_model_status: 1000,
                statusName: "Parameter Select",
                url: "/ProjectConti/ParameterSelect",
                needToUpdateStatus: true,
                nextStatus: 1100,
                mainStep: true,
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: true,
                showStep: "2",
                title: "Imputation",
                offline_model_status: 1100,
                statusName: "Imputation",
                url: "/ProjectConti/Imputation",
                needToUpdateStatus: true,
                nextStatus: 1200,
                mainStep: true,
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: true,
                showStep: "3",
                title: "Segmentation",
                offline_model_status: 1200,
                statusName: "Segmentation",
                url: "/ProjectConti/Segmentation",
                nextStatus: 1300,
                mainStep: true,
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: false,
                offline_model_status: 1201,
                statusName: "Segmentation Processing",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/ProjectConti/ProjectContiList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: false,
                offline_model_status: 1202,
                statusName: "Segmentation",
                url: "/ProjectConti/Segmentation",
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: false,
                offline_model_status: 1203,
                statusName: "Segmentation Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Segmentation",
                    backUrl: "/ProjectConti/Segmentation",
                    updateStatus: 1200,
                    msg: "Segmentation Error,please reset segmentation to processing,thanks."
                },
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: true,
                showStep: "4",
                title: "Data Filter",
                offline_model_status: 1300,
                statusName: "Data Filter",
                url: "/ProjectConti/DataFilter",
                nextStatus: 1400,
                mainStep: true,
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: false,
                offline_model_status: 1301,
                statusName: "Data Filter Processing",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/ProjectConti/ProjectContiList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: false,
                offline_model_status: 1302,
                statusName: "Data Filter",
                url: "/ProjectConti/DataFilter",
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: false,
                offline_model_status: 1303,
                statusName: "Data Filter Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset DataFilter",
                    backUrl: "/ProjectConti/DataFilter",
                    updateStatus: 1300,
                    msg: "DataFilter Error,please reset DataFilter to processing,thanks."
                },
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: true,
                showStep: "5",
                title: "Feature Engineering",
                offline_model_status: 1400,
                statusName: "Feature Engineering",
                url: "/ProjectConti/FeatureEngineeringConti",
                needToUpdateStatus: false,
                nextStatus: 1500,
                mainStep: true,
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: false,
                offline_model_status: 1401,
                statusName: "Feature Engineering Processing",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/ProjectConti/ProjectContiList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: false,
                offline_model_status: 1402,
                statusName: "Feature Engineering",
                url: "/ProjectConti/FeatureEngineeringConti",
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: false,
                offline_model_status: 1403,
                statusName: "FeatureEngineering Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset FeatureEngineering",
                    backUrl: "/ProjectConti/FeatureEngineeringConti",
                    updateStatus: 1400,
                    msg: "FeatureEngineering Error,please reset FeatureEngineering to processing,thanks."
                },
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: true,
                showStep: "6",
                title: "Data Labeling",
                offline_model_status: 1500,
                statusName: "Data Labeling",
                url: "/ProjectConti/DataLabeling",
                needToUpdateStatus: true,
                nextStatus: 600,
                mainStep: true,
                dataTypes: ["Continuous"]
            },
            {
                isShowStep: false,
                offline_model_status: 600,
                statusName: "Data Process",
                url: "/Project/DataProcess",
                dataTypes: ["Continuous"]
            },

            
        ],
        statusInfosRawData: [
            {
                isShowStep: true,
                showStep: "1",
                title: "Parameter Select",
                offline_model_status: 2000,
                statusName: "Parameter Select",
                url: "/ProjectRawData/ParameterSelectRawData",
                needToUpdateStatus: true,
                nextStatus: 2100,
                mainStep: true,
                dataTypes: ["RawData"]
            },
            {
                isShowStep: true,
                showStep: "2",
                title: "DataFilter",
                offline_model_status: 2100,
                statusName: "DataFilter",
                url: "/ProjectRawData/DataFilterRawData",
                needToUpdateStatus: true,
                nextStatus: 2101,
                mainStep: true,
                dataTypes: ["RawData"]
            },      
            {
                isShowStep: false,
                offline_model_status: 2101,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 2103,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/ProjectRawData/DataFilterRawData",
                    updateStatus: 2100,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["RawData"]
            },
            {
                isShowStep: true,
                showStep: "3",
                title: "Feature Engineering",
                offline_model_status: 2200,
                statusName: "Feature Engineering",
                url: "/ProjectRawData/FeatureEngineeringRawData",
                needToUpdateStatus: true,
                nextStatus: 2201,
                mainStep: true,
                dataTypes: ["RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 2201,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 2203,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/ProjectRawData/DataFilterRawData",
                    updateStatus: 2200,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 2601,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["RawData"]
            },
            {
                isShowStep: false,
                offline_model_status: 2603,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/ProjectRawData/ParameterSelectRawData",
                    updateStatus: 2000,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["RawData"]
            }
            //,
            //{
            //    isShowStep: false,
            //    offline_model_status: 600,
            //    statusName: "Data Process",
            //    url: "/Project/DataProcess",
            //    needToUpdateStatus: false,
            //    nextStatus: 700,
            //    dataTypes: ["RawData"]
            //},
            //{
            //    isShowStep: true,
            //    showStep: "4",
            //    title: "Data Process",
            //    offline_model_status: 600,
            //    statusName: "Data Process",
            //    url: "/Project/DataProcess",
            //    needToUpdateStatus: false,
            //    nextStatus: 700,
            //    mainStep: true,
            //    dataTypes: ["SensorRich", "Feature", "Continuous"]
            //},

        ],
        currentProjectId: "",
        currentModelId: "",
        currentModelType: "",
        offlineModelStatus: 0,
        projectStatus:'',
        currentDataType: "", 
        currentDataSource: "",     
        currentProjectInfo: {},
        modelTypes: ["anomaly_detection", "health_assessment", "prognostic"],
        modelPredictFrequencies: [4, 8, 12, 24],
        onlineModelStatuses: ['online', 'offline', 'stop'],
        userInfo: {},
        authKey: "",
        eventTypes:
            ["PHM Alarm-非預期保養",
            "PHM Alarm-巡檢",
            "巡檢異常",
            "周期性保養",
            "非預期保養"],
        components:
            ["馬達",
            "查無異常",
            "降速運轉",
            "驅動部",
            "皮帶",
            "導螺桿",
            "減速機"],
        solutions:
            ["None",
            "更換",
            "更換Parts",
            "調整張力",
            "保養/清潔",
            "保養/上油潤滑",
                "滑塊主油"],
        samplings:
            ["1",
                "6",
                "10",
            ],
        segmentations: ["regular", "rolling"],
        regulartimes: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24"],
        AllDataSources: ["user_upload", "continuous","raw_data"],
        AllModelType: [],
        AllIdelDefines: [">", "<", "="],
        AllFilterDefines: ["std", "filter_upper_percentage_threshold", "parameter_value_filter"],
        Announcements: [],
        FunctionList: [
            {
                url: "/Project/ProjectList",
                name: "Offline Model List",
                icon: "icon icon-phm-01",
                status: "open",
                id: ""
            },
            {
                url: "/Online/confirmModePage",
                name: "Online Monitor",
                icon: "icon icon-phm-02",
                status: "open",
                id: ""
            },
            {
                url: "",
                name: "System KPI",
                icon: "icon icon-phm-03",
                status: "close",
                id: ""
            },
            {
                //url: "/OpenDoc/PHM-Guide.pdf?v=" + Date.now(),
                url: "/Home/UserMaintain",
                name: "User Maintain",
                icon: "fas fa-users-cog",
                status: "open",
                id: "UserMaintain"
                //,isDownload: true
            },
            {
                //url: "/OpenDoc/PHM-Guide.pdf?v=" + Date.now(),
                url: "/Home/TrainingMaterials",
                name: "Training Materials",
                icon: "icon icon-phm-04",
                status: "open",
                id: "downloadGuide"
                //,isDownload: true
            },
            {
                url: "/Home/Announcement",
                name: "Announcement",
                icon: "fas fa-bullhorn",
                status: "open",
                id: ""
            }
        ]

    },
    mutations: {
        setCurrentProjectId:function(state, value) {
            state.currentProjectId = value;
            window.localStorage.setItem('projectid', value);
        },
        setCurrentModelId:function(state, value) {
            state.currentModelId = value;
            window.localStorage.setItem('modelid', value);
        },
        setCurrentDataType: function(state, value) {
            state.currentDataType = value;
        },
        setCurrentDataSource: function (state, value) {
            state.currentDataSource = value;
        },
        setOfflineModelStatus: function(state, value) {
            state.offlineModelStatus = value;
        },
        setShowLoading: function(state, isShow) {
            state.showLoading = isShow;
        },
        clearCurrentProjectInfo: function(state, fn) {
            state.currentProjectId = '';
            state.currentModelId = '';
            state.currentModelType = '';
            state.offlineModelStatus = '';
            window.localStorage.setItem('projectid', '');
            window.localStorage.setItem('modelid', '');
            window.localStorage.setItem('modeltype', '');
            window.localStorage.setItem('datatype', '');
            if (fn) {
                fn()
            }
        },
        filterCreateProjectStepInfo: function(state) {

            state.createProjectStepInfo = [];

            state.statusInfos.forEach(function (item) {

                if (item.isShowStep == true) {

                    var className = item.url == window.location.pathname ? 'current' : (self.offlineModelStatus < item.offline_model_status || (self.currentDataType != "" && item.dataTypes.indexOf(self.currentDataType) == -1) ? 'disabled' : 'active');

                    state.createProjectStepInfo.push({
                        title: item.title,
                        showStep: item.showStep,
                        className: className,
                        url: item.url
                    });
                }
            });
        },
        setDefaultProjectId: function(state, fn) {

            var projectId = getUrlParameterByName('projectid', window.location.href.toLowerCase());

            if (projectId) {
                state.currentProjectId = projectId;
                window.localStorage.setItem('projectid', projectId);

                if (fn)
                    fn();
                return;
            }

            if (!state.currentProjectId)
                state.currentProjectId = window.localStorage.getItem('projectid');

            if (fn)
                fn();
        },
        setDefaultModelId: function(state) {
            var modelId = getUrlParameterByName('modelid', window.location.href.toLowerCase());

            if (modelId != null) {
                state.currentModelId = modelId;
                window.localStorage.setItem('modelid', modelId);
            }

            if (state.currentModelId == '')
                state.currentModelId = window.localStorage.getItem('modelid')
        },       
        setProjectInfo: function(state, fn) {
            //在mutations裡用同步方式取得

            if (state.env != "prd") {
                var response = {
                    data: {}
                };


                var json = { code: 200, data: { project_list: [{ ai365_project_name: "JaneTest", application: "Robot", chamber_merge: false, data_source: "user_upload", data_type: "SensorRich", fab: "L6A", func: "PHOTO", itime: "2021 - 05 - 06 15: 32: 19", model_id: 3735, model_type: "anomaly_detection", offline_model_status: 802, project_id: 3736, stage: "ARRAY", status: "create", tool_type: "TRACK", user_deptid: "ADTEC2", user_empno: "O1906003" }], total_count: 1 }, description: "Get Project list success", status: "OK" };
                response = json;

                if (response.data.project_list[0]) {
                    state.currentModelType = response.data.project_list[0].model_type;
                    ////add by amanda 2020-10-01
                    if (response.data.project_list[0].data_source == "continuous" && response.data.project_list[0].offline_model_status == 100)
                        state.offlineModelStatus = 1000;//add by amanda 2020-09-04 17:11
                    else
                        state.offlineModelStatus = response.data.project_list[0].offline_model_status;//add by amanda 2020-09-04 17:11
                    state.offlineModelStatus = response.data.project_list[0].offline_model_status;//add by amanda 2020-09-04 17:11


                    state.currentDataType = response.data.project_list[0].data_type;
                    //state.offlineModelStatus = 2200;//JaneTest:為了測試先強制設定2200
                    //state.currentDataType = "raw_data"; //JaneTest:為了測試先強制設定RawData
                    state.currentDataSource = response.data.project_list[0].data_source;//add by amanda 2020-09-04 17:11
                    state.currentProjectInfo = response.data.project_list[0];
                    state.projectStatus = response.data.project_list[0].status;

                    window.localStorage.setItem('fab', response.data.project_list[0].fab);
                    window.localStorage.setItem('stage', response.data.project_list[0].stage);
                    window.localStorage.setItem('func', response.data.project_list[0].func);

                    if (fn) {
                        fn();
                    }
                }

            }
            else {
                $.ajax({
                    type: 'get',
                    async: false,
                    url: state.offlineApiUrl + "/project",
                    data: {
                        "project_id": state.currentProjectId
                    },
                    success: function (response) {

                        if (response.data.project_list[0]) {
                            state.currentModelType = response.data.project_list[0].model_type;
                            ////add by amanda 2020-10-01
                            if (response.data.project_list[0].data_source == "continuous" && response.data.project_list[0].offline_model_status == 100)
                                state.offlineModelStatus = 1000;//add by amanda 2020-09-04 17:11
                            else
                                state.offlineModelStatus = response.data.project_list[0].offline_model_status;//add by amanda 2020-09-04 17:11
                            state.offlineModelStatus = response.data.project_list[0].offline_model_status;//add by amanda 2020-09-04 17:11


                            state.currentDataType = response.data.project_list[0].data_type;
                            //state.offlineModelStatus = 2200;//JaneTest:為了測試先強制設定2200
                            //state.currentDataType = "raw_data"; //JaneTest:為了測試先強制設定RawData
                            state.currentDataSource = response.data.project_list[0].data_source;//add by amanda 2020-09-04 17:11
                            state.currentProjectInfo = response.data.project_list[0];
                            state.projectStatus = response.data.project_list[0].status;

                            window.localStorage.setItem('fab', response.data.project_list[0].fab);
                            window.localStorage.setItem('stage', response.data.project_list[0].stage);
                            window.localStorage.setItem('func', response.data.project_list[0].func);

                            if (fn) {
                                fn();
                            }
                        }
                    },
                    dataType: "json"
                });
            }          

        },

        setUserInfo: function (state, value) {
            state.userInfo = value;
            window.localStorage.setItem('userInfo', JSON.stringify(value));

        },
        setAuthKey: function (state, value) {
            state.authKey = value;
            window.localStorage.setItem('authKey', value);
        },

        setAnnouncements: function (state, value) {
            state.Announcements = value;          
        },
      
    },
    actions: {
        checkAuthKey: function (context) {
            var authkey = getUrlParameterByName('authkey', window.location.href.toLowerCase());
            if (!authkey) authkey = context.getters.getAuthKey;
            if (!authkey) authkey = window.localStorage.getItem('authkey');

            if (authkey) {

                authkey = authkey.toUpperCase();
                $.ajax({
                    type: 'post',
                    async: false,
                    url: "/api/Authentication/CheckAuthorityKey",
                    data: {
                        authorityKey: authkey
                    },
                    success: function (response) {

                        if (response.status == "OK" && response.data.Status == "Pass") {
                            if (response.data.UserInfo) {
                                var userInfo= response.data.UserInfo;
                                if (userInfo.PhotoUrl) {
                                    var img = new Image();

                                    img.onerror = function () {
                                        userInfo.PhotoUrl = "/_img/person-empty-png.png";
                                    };
                                    img.src = userInfo.PhotoUrl;
                                }
                                context.commit("setUserInfo",userInfo);
                            }

                            var returnUrl = getUrlParameterByName("ReturnUrl", window.location.href);
                            if (returnUrl) {
                                window.location.href = returnUrl;
                            }
                        }
                        else if (response.data.Status == "Deny") {

                            if (window.location.pathname != "/") {
                                alertify.error("get data fail. error message = " + response.data.ErrorMsg);
                                window.localStorage.setItem('authkey', '');
                                window.location.reload();
                            }

                        }

                    },
                    dataType: "json"
                });
            }
        },

        login: function (context,obj) {
           
            axios({
                method: 'post',
                url: "/api/Authentication/Login",
                data: {
                    username: obj.username,
                    password: obj.password
                } })
                .then(function (response) {
                    if (response.data.status == "OK" && response.data.data.Status == "Pass") {
                        var returnUrl = getUrlParameterByName("ReturnUrl", window.location.href);
                        var authKey = response.data.data.AuthorityKey;
                        var userInfo = response.data.data.UserInfo;

                        context.commit("setAuthKey", authKey);
                        context.commit("setUserInfo", userInfo);


                        if (obj.callback) {
                            obj.callback()
                        }

                        if (returnUrl) {
                            window.location.href = returnUrl;
                        }
                        else {
                            window.location.href = store.getters.getHomePage;
                        }                       

                    }
                    else {
                        alertify.error("登入失敗");
                    }
                })
                .catch(function (err) {
                    //TODO:Error Handle
                    console.log(err)
                    alertify.alert(err);
                })

        },

        logout: function () {
            var self = this;
            axios({
                method: 'post',
                url: "/api/Authentication/Logout",
                data: {
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        window.localStorage.setItem('authkey', "");
                        window.location.href = "/Home/Index";
                    }
                    else {
                        alertify.error("登出失敗");
                    }
                })

        },

        getAnnouncements: function (context, obj) {

            $.ajax({
                type: 'get',
                async: false,
                url: "/api/File/GetAnnouncements"  ,              
                success: function (response) {
                    if (response.status == "OK") {
                        context.commit("setAnnouncements", response.data);
                        window.localStorage.setItem('Announcements', response.data);
                    }
                }
            });



            //axios({
            //    method: 'get',
            //    url: "/api/File/GetAnnouncements"
            //})
            //    .then(function (response) {
            //        if (response.data.status == "OK") {
            //            context.commit("setAnnouncements", response.data.data);
            //            window.localStorage.setItem('Announcements', response.data.data);
            //        }
            //    })
            //    .catch(function (err) {
            //        //TODO:Error Handle
            //        console.log(err)
            //        alertify.alert(err);
            //    })
        }
    },

    getters: {
        getEnv: function (state) {
            return state.env
        },
        getIsApiTest: function (state) {
            return state.isApiTest
        },
        getIsShowRawDatafunc: function (state) {
            return state.isShowRawDatafunc
        },
        getIsShowCustomAlgorithm: function (state) {
            return state.isShowCustomAlgorithm
        },
        getHomePage: function (state) {
            return state.homePage
        },
        getOfflineApiUrl: function (state) {
            return state.offlineApiUrl
        },
        getOnlineApiUrl: function (state) {
            return state.onlineApiUrl
        },       
        getApplications: function (state) {
            return state.applications
        },
        getMarchieParts: function (state) {
            return state.marchieParts
        },
        getSpectrumMethodInfos: function (state) {
            return state.spectrumMethodInfos
        },
        getSpectrumMethodInfos_rawdata: function (state) {
            return state.spectrumMethodInfos_rawdata
        },
        getStatisticalInfos: function (state) {
            return state.statisticalInfos
        },
        getStatisticalInfos_Conti: function (state) {
            return state.statisticalInfos_conti
        },
        getModelingAlgorithm: function (state) {
            return state.modelingAlgorithm
        },
        getStatusInfos: function (state) {
            return state.statusInfos
        },
        getShowLoading: function (state) {
            return state.showLoading
        },
        getCurrentProjectId: function (state) {
            return state.currentProjectId
        },
        getCurrentModelId: function (state) {
            return state.currentModelId
        },
        getCurrentModelType: function (state) {
            return state.currentModelType
        },
        getOfflineModelStatus: function (state) {
            return state.offlineModelStatus
        },
        getCurrentDataType: function (state) {
            return state.currentDataType
        },
        getCurrentDataSource: function (state) {
            return state.currentDataSource
        },
        getCurrentProjectInfo: function (state) {
            return state.currentProjectInfo
        },
        getmodelTypes: function (state) {
            return state.modelTypes
        },
        getModelPredictFrequencies: function (state) {
            return state.modelPredictFrequencies
        },
        getOnlineModelStatuses: function (state) {
            return state.onlineModelStatuses
        },
        getProjectStatus: function (state) {
            return state.projectStatus
        },
        getUserInfo: function (state) {
            if (!state.userInfo) {
                var json = window.localStorage.getItem('userInfo');
                state.userInfo = JSON.parse(json);
            }               

            return state.userInfo
        },
        getAuthKey: function (state) {
            if (!state.authKey)
                state.authKey = window.localStorage.getItem('authKey');

            return state.authKey
        },
        getEventTypes: function (state) {
            return state.eventTypes
        },
        getComponents: function (state) {
            return state.components
        },
        getSolutions: function (state) {
            return state.solutions
        }, getStatusInfosConti: function (state) {
            return state.statusInfosConti
        },
        getStatusInfosRawData: function (state) {
            return state.statusInfosRawData
        },
        getSamplings: function (state) {
            return state.samplings
        },
        getSegmentations: function (state) {
            return state.segmentations
        },
        getRegulartimes: function (state) {
            return state.regulartimes
        }, getStatisticalDefault_conti: function (state) {
            return state.statistical_conti
        }, getAllDataSources: function (state) {

            if (state.isShowRawDatafunc)
                return state.AllDataSources
            else {
                var array = state.AllDataSources;
                var index = array.indexOf("raw_data");
                if (index > -1) {
                    array.splice(index, 1);
                }
                return array;
            }
        }, getAllIdelDefines: function (state) {
            return state.AllIdelDefines
        }, getAllFilterDefines: function (state) {
            return state.AllFilterDefines
        },
        getAnnouncements: function (state) {
            if (!state.Announcements) {
                var json = window.localStorage.getItem('Announcements');
                state.Announcements = JSON.parse(json);
            }

            return state.Announcements
        },

        getFunctionList: function (state) {
            return state.FunctionList
        },

        

    }
})


//Fuse搜尋
Vue.prototype.$search = function (keyWords, list, searchKeys, options, _threshold) {

    var results = [];

    if (!options) {
        options = {
            includeScore: true,
            threshold: _threshold,            
            location: 0,
            distance: 100
        }
    }

    // 要搜尋的欄位
    if (options.keys)
        options.keys = searchKeys;
    else
        options['keys'] = searchKeys;

    


    return new Promise(function (resolve, reject) {

        var run = new Fuse(results, options)
        //results = run.search({ $and: keyWords });


        keyWords.forEach(function (item) {
            if (item) {
                var run = new Fuse(list, options)
                results = run.search(item);   

                if (results.length > 0) {
                    list = [];
                    results.forEach(function (i) {
                        list.push(i.item)
                    });
                }

            }  
        });


        resolve(results)
    })
}



$(document).ready(function () {
    //if (document.getElementById("downloadGuide")) {
    //    document.getElementById("downloadGuide").href = document.getElementById("downloadGuide").href + '?v=' + Date.now();
    //}
    //else {
    //    setTimeout(function () {
    //        if (document.getElementById("downloadGuide")) {
    //            document.getElementById("downloadGuide").href = document.getElementById("downloadGuide").href + '?v=' + Date.now();
    //        }           
    //    }, 3000);
    //}   

      

});





//監聽頁面出現的錯誤
window.onerror = function (error) {
    store.commit('setShowLoading', false);  
    logError(error);
};

//監聽在Vue內發生的錯誤
Vue.config.errorHandler = function (error) {
    store.commit('setShowLoading', false);  
    logError(error);
    //alertify.error(error);
}

//監聽axios發生的錯誤
axios.interceptors.response.use(function (response) {
    return response;
}, function (error) {
    logError(error);
   
    store.commit('setShowLoading', false);  


    if (error && error.response && error.response.status) {
        if (error.response.data.description) {
            alertify.error(error.response.data.description);
        }
        else {
            alertify.error("呼叫API失敗");
        }

    }
    else if (error && error.response && error.response.data && error.response.data.status) {
        alertify.error(error.response.data.description);
    }
   

    return Promise.reject(error) // this is the important part
})