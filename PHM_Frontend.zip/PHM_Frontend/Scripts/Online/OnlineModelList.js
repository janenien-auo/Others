﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {       
        fabs: [],
        fab: "",
        stages: [],
        stage: "",
        funcs: [],
        func: "",
        onlineModelList: [],
        filterOnlineModelList: [],
        filterOnlineModelListByPage: [],
        keyWord: "",
        //searchKeys: ["ai365_project_name", "fab", "stage", "func", "model_type", "project_id","user_empno"],
        searchKeys: ["user_name", "ai365_project_name", "fab", "stage", "func", "model_type", "project_id","tool","chamber","online_status"],
        selected: [],
        allSelected: false,
        Pagination: {
            current_page: 1,
            page_size: 10,
            total: 0,
            page_sizes: [10,30,50,100],
        },
        listTotalColumns: ['update_time'],
        listShowColumns:[]

    },
    mounted: function () {
        var self = this;

        self.init();

        store.commit('setShowLoading', false);
    },
    methods: {

        init: function () {

            store.commit('setShowLoading', true);

            store.commit('clearCurrentProjectInfo', null);   


            var self = this;

            OnlineLayoutApp.onlineHomeViewMode = 'list';
            OnlineLayoutApp.modelType = '';




            self.getFabs().then(function () {

                var fab = getUrlParameterByName('FAB', window.location.href.toUpperCase());

                if (!fab)
                    fab = window.localStorage.getItem('fab');

                if (fab) {
                    self.fab = fab;
                }
                else {
                    //預設fab
                    if (UserInfoApp.userInfo.UserSite) {
                        self.Fab = UserInfoApp.userInfo.UserSite;
                    }
                    else {
                        if (self.fabs) {
                            self.fab = self.fabs[0].fab;
                        }
                    }
                }
                if (self.fab) self.getStages();

                var stage = getUrlParameterByName('STAGE', window.location.href.toUpperCase());


                if (!stage)
                    stage = window.localStorage.getItem('stage');


                //預設stage
                if (stage) {
                    self.stage = stage;
                    OnlineLayoutApp.stage = stage;
                } else {
                    if (OnlineLayoutApp.stage)
                        self.stage = OnlineLayoutApp.stage;
                    else {
                        if (self.stages) {
                            self.stage = self.stages[0].stage_name;
                        }
                    }
                }
                                              


                if (self.stage) self.getFuncs();

                var func = getUrlParameterByName('FUNC', window.location.href.toUpperCase());

                if (!func)
                    func = window.localStorage.getItem('func');


                //預設Function

                if (func) {
                    self.func = func;
                } else {
                    if (OnlineLayoutApp.func)
                        self.func = OnlineLayoutApp.func;
                    else {
                        if (self.funcs) {
                            self.func = self.funcs[0];
                        }
                    }
                }

                


                self.getOnlineModelList(self.Pagination.current_page).then(function () {

                    //$("#onlineModelTable").DataTable({
                    //    searching: false, //關閉filter功能
                    //    //columnDefs: [{
                    //    //    targets: [3],
                    //    //    orderable: false,
                    //    //}]
                    //});


                    store.commit('setShowLoading', false);

                });

            });
        },        
        
        getFabs: function () {
            var self = this;

            return new Promise(function (resolve, reject) {              

                getBasicInfoDropdownList(store.getters.getIsApiTest)
                    .then(function (response) {
                        self.fabs = response.data.data.select_item;

                        self.stage = "";
                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        
        getStages: function () {
            var self = this;
            self.stage = "";
            self.stages = [];
            self.func = "";
            self.funcs = [];
            self.fabs.forEach(function (item, index) {

                if (item.fab == self.fab) {
                    self.stages = item.stage;
                }
            });
        },

        getFuncs: function () {

            var self = this;
            self.func = "";
            self.funcs = [];
            self.stages.forEach(function (item, index) {

                if (item.stage_name == self.stage) {
                    self.funcs = item.function_list;
                }
            });
        },

        //取得OnlineModelList資料
        getOnlineModelList: function (page) {
            var self = this;

            return new Promise(function (resolve, reject) {         

                var params = {                    
                    func: self.func,
                    fab: self.fab,                   
                    stage: self.stage
                };
                               

                getOnlineModelList(params, store.getters.getIsApiTest)
                    .then(function (response) {

                        self.onlineModelList = response.data.data.model_list;

                        self.onlineModelList.forEach(function (d) {
                            //d['toolChambe'] = d.tool_chamber_flat_unique_list.join('');
                            d['tool'] = d.tool_chamber_flat_unique_list[0];
                            d['chamber'] = d.tool_chamber_flat_unique_list[1];
                        });  


                        self.filterModelList();


                        //為了讓麵包屑回到Model List時，可以保留上一次Query的條件
                        window.localStorage.setItem('fab', self.fab);
                        window.localStorage.setItem('stage', self.stage);
                        window.localStorage.setItem('func', self.func);


                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);
                    })

            })
        },

        //過濾Keyword資料
        filterModelList: function () {

            var self = this;

            if (!self.keyWord) {
                self.filterOnlineModelList = self.onlineModelList;
                self.Pagination.total = self.filterOnlineModelList.length;
                self.handleChangePage(1);
                return;
            }
             
            self.filterOnlineModelList = [];   

            var keywords = self.keyWord.split(' ');

            self.$search(keywords, self.onlineModelList, self.searchKeys, null, 0.1).then(
                function (response) {
                    response.forEach(function (d) {
                        self.filterOnlineModelList.push(d.item);
                    })

                    self.Pagination.total = self.filterOnlineModelList.length;

                    self.handleChangePage(1);
                }
            );     
        },           

        viewDataHealth: function (row) {
            window.location.href = "/online/dataHealth" + "?projectid=" + row.project_id + "&modelid=" + row.model_id;    
        },

        viewModelResult: function (row) {            

            window.location.href = "/online/toollist" + "?projectid=" + row.project_id + "&modelid=" + row.model_id;    
        },

        viewModelSetting: function (row) {
            window.location.href = "/online/toolMapping" + "?projectid=" + row.project_id + "&modelid=" + row.model_id;    
        },

        viewEStoneEventList: function (row) {
            window.location.href = "/online/EStoneEventList" + "?projectid=" + row.project_id + "&modelid=" + row.model_id;
        },

        //查看Record的歷史紀錄
        viewRecordHistory: function (row) {
            window.location.href = "/online/RecordHistory" + "?projectid=" + row.project_id + "&modelid=" + row.model_id;
        },

        //切換OnlineModel的監控的模式(Chart.List)
        changeMode: function () {
            OnlineLayoutApp.onlineHomeViewMode = 'chart';
            window.location = "/online/onlineHome";
        },
        
        //換頁
        handleChangePage: function (val) {
            var self = this;
            self.Pagination.current_page = val;

            var startIndex = (self.Pagination.current_page - 1) * self.Pagination.page_size;
            if (startIndex < 0) startIndex = 0;

            if (startIndex > self.Pagination.total) startIndex = 0;

            var endIndex = (self.Pagination.current_page * self.Pagination.page_size);
            if (endIndex >= self.filterOnlineModelList.length) endIndex = self.filterOnlineModelList.length;
            self.filterOnlineModelListByPage = self.filterOnlineModelList.slice(startIndex, endIndex);
        }
    }



})