﻿var app = new Vue({
    el: '#app', //el為要綁定的div的id(已設定完成)  
    store: store,
    data: {
        //該頁會使用道的變數請統一放在這裡
        Tools: [],
        Tool: "", 
        Chambers: [],
        Chamber: "",
        ModelTypes: [],
        ModelType:"",
        ChartDatas: [],
        ChartLabels: [],
        ChartLabels2: [],
        ChartLabels3: [],
        chartValues: [],
        startTime: moment(new Date()).format('YYYY-MM-DD'),
        endTime: moment(new Date()).format('YYYY-MM-DD'),
        curInt:null,
        isFirst: true,
       
        pickerOptions: {//控制elementUI不能選今天以後的日期
            disabledDate(time) {
                return time.getTime() > Date.now();
            },
        },  
        projectId: '',
        modelId: '',
        projectList: [],
        projectName: '',
    },
    mounted: function () {

        //顯示Loading
        //store.commit('setShowLoading', true);

        var self = this;
        if (getUrlParameterByName('projectid', window.location.href.toLowerCase()) != null)
            self.projectId = getUrlParameterByName('projectid', window.location.href.toLowerCase());
        if (getUrlParameterByName('modelid', window.location.href.toLowerCase()) != null)
            self.modelId = getUrlParameterByName('modelid', window.location.href.toLowerCase());

        if (self.projectId != null && self.modelId != null && self.projectId != "" && self.modelId != "") {


            self.getProjectPromise().then(function () {

                store.commit('setShowLoading', false);

            });

        }

        self.Tool = OnlineLayoutApp.toolId;
        if (OnlineLayoutApp.startTime != "")
            self.startTime = OnlineLayoutApp.startTime;
        if (OnlineLayoutApp.endTime != "")
            self.endTime = OnlineLayoutApp.endTime;
        self.ModelType = OnlineLayoutApp.modelType;
        self.Chamber = OnlineLayoutApp.chamber;
        self.btnQueryClick();

    },

    methods: {
        btnQueryClick: function () {
            var self = this;
            self.isFirst = true;
            self.startTime = self.startTime
            self.endTime = self.endTime;
            self.QueryData();
        },
 
        QueryData: function () {
            var apiUrl = "/toolline";
            //'/dropitem/tool_chamber?model_id=5'
            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet().reply(200, {
                status: "OK",
                data: {
                    tool_id: "ABIEX200",
                    tool_data: [
                        {
                            chamber: "axi_x1",
                            model_list: [
                                {
                                    model_type: "anomaly_detection",
                                    predict_result:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [5.5, 15, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4]
                                    },
                                    mxci:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [5.5, 15, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4],
                                        mxci_threshold: [17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
                                    },
                                    feature_importances:
                                    {
                                        feature_name: ['ct_fft_mean', 'ct_fft_mean2', 'ct_fft_mean3', 'ct_fft_mean4', 'ct_fft_mean5', 'ct_fft_mean6', 'ct_fft_mean7','ct_fft_mean8'],
                                        score: [120, 360, 500, 600, 650, 700, 750, 900]
                                    },
                                    xdi:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [5.5, 15, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4],
                                        xdi_threshold: [15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6]
                                    }
                                },
                                {
                                    model_type: "health_assessment",
                                    predict_result:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: ['1', '1', '0', '0', '0', '1', '1', '2', '0', '0', '2', '1'],
                                        label: ['OK', 'OK', 'NG', 'NG', 'NG', 'OK', 'OK', 'MOTOR', 'NG', 'NG', 'MOTOR','OK']
                                    },
                                    mxci:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [5.5, 15, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4],
                                        mxci_threshold: [17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
                                    },
                                    feature_importances:
                                    {
                                        feature_name: ['ct_fft_mean', 'ct_fft_mean2', 'ct_fft_mean3', 'ct_fft_mean4', 'ct_fft_mean5', 'ct_fft_mean6', 'ct_fft_mean7', 'ct_fft_mean8'],
                                        score: [120, 360, 500, 600, 650, 700, 750, 900]
                                    },
                                    xdi:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [5.5, 15, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4],
                                        xdi_threshold: [15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6]
                                    }
                                },
                                {
                                    model_type: "prognostic",
                                    predict_result:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [6.5, 13, 6.6, 22, 10.5, 15.2, 20.4, 16.5, 22.5, 15.6, 28.2, 23.4],
                                        label: ['OK', 'OK', 'NG', 'NG', 'NG', 'OK', 'OK', 'MOTOR', 'NG', 'NG', 'MOTOR', 'OK']
                                    },
                                    mxci:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [5.5, 15, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4],
                                        mxci_threshold: [17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
                                    },
                                    feature_importances:
                                    {
                                        feature_name: ['ct_fft_mean', 'ct_fft_mean2', 'ct_fft_mean3', 'ct_fft_mean4', 'ct_fft_mean5', 'ct_fft_mean6', 'ct_fft_mean7', 'ct_fft_mean8'],
                                        score: [120, 360, 500, 600, 650, 700, 750, 900]
                                    },
                                    xdi:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [5.5, 15, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4],
                                        xdi_threshold: [15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6, 15.6]
                                    }
                                },
                            ]
                        },
                        {
                            chamber: "axi_x2",
                            model_list: [
                                {
                                    model_type: "anomaly_detection",
                                    predict_result:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [8.5, 12, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4]
                                    },
                                    mxci:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [5.5, 15, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4],
                                        mxci_threshold: [17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
                                    },
                                    feature_importances:
                                    {
                                        feature_name: ['ct_fft_mean', 'ct_fft_mean2', 'ct_fft_mean3', 'ct_fft_mean4', 'ct_fft_mean5', 'ct_fft_mean6', 'ct_fft_mean7', 'ct_fft_mean8'],
                                        score: [100, 260, 300, 550, 750, 900, 950, 1050]
                                    },
                                    xdi:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [5.5, 15, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4],
                                        xdi_threshold: [16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7]
                                    }
                                },
                                {
                                    model_type: "health_assessment",
                                    predict_result:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [8.5, 3, 6.6, 22, 10.5, 15.2, 20.4, 16.5, 22.5, 15.6, 28.2, 23.4],
                                        label: ['OK', 'OK', 'NG', 'NG', 'NG', 'OK', 'OK', 'MOTOR', 'NG', 'NG', 'MOTOR', 'OK']
                                    },
                                    mxci:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [2.5, 25, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4],
                                        mxci_threshold: [16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7]
                                    },
                                    feature_importances:
                                    {
                                        feature_name: ['ct_fft_mean', 'ct_fft_mean2', 'ct_fft_mean3', 'ct_fft_mean4', 'ct_fft_mean5', 'ct_fft_mean6', 'ct_fft_mean7', 'ct_fft_mean8'],
                                        score: [50, 160, 200, 300, 450, 500, 750, 950]
                                    },
                                    xdi:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [10.5, 5, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4],
                                        xdi_threshold: [16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7]
                                    }
                                },
                                {
                                    model_type: "prognostic",
                                    predict_result:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [6.5, 13, 6.6, 22, 10.5, 15.2, 20.4, 16.5, 22.5, 15.6, 28.2, 23.4],
                                        label: ['OK', 'OK', 'NG', 'NG', 'NG', 'OK', 'OK', 'MOTOR', 'NG', 'NG', 'MOTOR', 'OK']
                                    },
                                    mxci:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [5.5, 15, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4],
                                        mxci_threshold: [16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7, 16.7]
                                    },
                                    feature_importances:
                                    {
                                        feature_name: ['ct_fft_mean', 'ct_fft_mean2', 'ct_fft_mean3', 'ct_fft_mean4', 'ct_fft_mean5', 'ct_fft_mean6', 'ct_fft_mean7', 'ct_fft_mean8'],
                                        score: [250, 350, 400, 580, 780, 800, 900, 1150]
                                    },
                                    xdi:
                                    {
                                        check_date: ['2020-04-01', '2020-04-02', '2020-04-03', '2020-04-04', '2020-04-05', '2020-04-06', '2020-04-07', '2020-04-08', '2020-04-09', '2020-04-10', '2020-04-11', '2020-04-12'],
                                        predict: [5.5, 15, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4],
                                        xdi_threshold: [15.7, 15.7, 15.7, 15.7, 15.7, 15.7, 15.7, 15.7, 15.7, 15.7, 15.7, 15.7]
                                    }
                                },
                            ]
                        }

                    ]

                }

            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;

            axios({
                method: 'get',
                baseURL: store.getters.getOnlineApiUrl,
                url: apiUrl,
                params: {
                    tool_id: self.Tool,
                    start_date: moment(self.startTime).local().format('YYYY-MM-DD'),
                    end_date: moment(self.endTime).local().format('YYYY-MM-DD'),
                    project_id: self.projectId,
                    model_id: self.modelId
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.ChartDatas = response.data.data;
                        self.Tools.push(self.ChartDatas.tool_id);
                        if (OnlineLayoutApp.toolId != "")
                            self.Tool = OnlineLayoutApp.toolId;
                        else
                            self.Tool = self.ChartDatas.tool_id;
                        if (OnlineLayoutApp.chamber != "")
                            self.Chamber = OnlineLayoutApp.chamber;
                        else
                            self.Chamber = self.ChartDatas.tool_data[0].chamber;

                        if (self.ChartDatas.tool_data.length == 0) {
                            alertify.alert("No Data");
                        }
                        else {
                            var aryMT = [];
                            let arTmp = self.ChartDatas.tool_data.forEach(function (item, index) {
                                item.model_list.forEach(function (val, idx, array) {

                                    aryMT.push(val.model_type);
                                });
                                
  
                            });
                            //過濾陣列中重複的元素
                            var result = aryMT.filter(function (element, index, arr) {
                                return arr.indexOf(element) === index;
                            });


                            self.ModelTypes = result;//self.ChartDatas.tool_data[0].model_list
                            if (OnlineLayoutApp.modelType != "")
                                self.ModelType = OnlineLayoutApp.modelType;
                            else
                                self.ModelType = self.ChartDatas.tool_data[0].model_list[0].model_type;

                           
                            self.DrawChart();                        
                        }      
                    }

                    store.commit('setShowLoading', false);
                })
            
        },
        getProjectPromise: function () {
            var self = this;


            return new Promise(function (resolve, reject) {


                var apiUrl = "/project";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        total_count: 9527,
                        project_list: [
                            {
                                project_id: 1,
                                ai365_project_name: "test_phm",
                                model_type: "Anomaly Detection",
                                application: "Robot",
                                fab: "L5C",
                                stage: "Array",
                                func: "PHOTO",
                                tool_type: "Robot_LD",
                                offline_model_status: 100,
                                user_name: "Joyce",
                                itime: "2019-12-31 10:58:30",
                                model_id: 1
                            }
                        ]
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: self.projectId,
                    }

                })
                    .then(function (response) {
                        self.projectList = response.data.data.project_list;
                        if (self.projectList.length > 0) {
                            self.projectName = self.projectList[0].fab + "-" + self.projectList[0].stage + "-" +
                                self.projectList[0].func + "-" + self.projectList[0].ai365_project_name + "-" +
                                self.projectList[0].model_type + "_" + self.projectList[0].project_id;

                        }
                        if (self.projectList.length == 0) {
                            alertify.error("No data");
                        }



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        getTools: function () {
            var self = this;
            self.Tool = "";
            self.Tools = [];
            self.Chamber = "";
            self.Chambers = [];
            self.ModelType = "";
            self.ModelTypes = [];
            self.Tools.push(self.ChartDatas.tool_id);
            self.Tool = self.ChartDatas.tool_id;       
        },
        getChambers: function () {
            var self = this;
            self.Chamber = "";
            self.Chambers = [];
            self.ModelType = "";
            self.ModelTypes = [];
            self.Chamber = self.ChartDatas.tool_data[0].chamber;
        },
        getModelTypes: function () {
            var self = this;
            self.ModelType = "";
            self.ModelTypes = [];
            
            var aryMT = [];
            let arTmp = self.ChartDatas.tool_data.forEach(function (item, index) {
                item.model_list.forEach(function (val, idx, array) {

                    aryMT.push(val.model_type);
                });


            });
            //過濾陣列中重複的元素
            var result = aryMT.filter(function (element, index, arr) {
                return arr.indexOf(element) === index;
            });


            self.ModelTypes = result;//self.ChartDatas.tool_data[0].model_list

            
            if (self.ChartDatas.tool_data[0].model_list.length > 0) {
                self.ModelType = self.ChartDatas.tool_data[0].model_list[0].model_type;
                self.DrawChart();
            }

            
        },
        getRatioItem: function () {
            var self = this;
            var _name = "rdoDue";


            var obj = document.getElementsByName(_name);

            var selected = [];
            for (var i = 0; i < obj.length; i++) {

                if (obj[i].checked) {
                    selected.push(obj[i].value);
                }
            }

       



            return selected.join();
        },

        DrawChart: function () {
            var self = this;
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            var _predict_result_ok = [];
            var _predict_result_ng = [];
            var _predict_result = [];
            var _predict_result_x = [];
            var _mxci = [];
            var _mxci_x = [];
            var _mxci_ng = [];
            var _mxci_threshold = [];
            var _feature_importances = [];
            var _feature_importances_x = [];
            var _xdi = [];
            var _xdi_x = [];
            var _xdi_ng = [];
            var _xdi_threshold = [];


            var aryTmp = self.ChartDatas.tool_data.map(function (item, index, array) {
                if (item.chamber == self.Chamber) {
                    item.model_list.map(function (val, idx, ary) {
                        if (val.model_type == self.ModelType) {
                            _predict_result = val.predict_result.predict;
                            if (self.ModelType == "anomaly_detection" || self.ModelType == "health_assessment") {
                                for (var i = 0; i < val.predict_result.label.length; i++) {
                                    if (val.predict_result.label[i] == "OK")
                                        _predict_result_ok.push(val.predict_result.predict[i]);
                                    else
                                        _predict_result_ok.push(null);

                                    if (val.predict_result.label[i] == "NG")
                                        _predict_result_ng.push(val.predict_result.predict[i]);
                                    else
                                        _predict_result_ng.push(null);
                                }
                            } 
                        
                            _predict_result_x = val.predict_result.check_date;
                            _mxci = val.mxci.predict;
                            _mxci_x = val.mxci.check_date;
                            _mxci_threshold = val.mxci.mxci_threshold == undefined ? 0 : val.mxci.mxci_threshold;
                            _feature_importances = val.feature_importances.score;
                            _feature_importances_x = val.feature_importances.feature_name;
                            _xdi = val.xdi.predict;
                            _xdi_x = val.xdi.check_date;
                            _xdi_threshold = val.xdi.xdi_threshold;
                            if (self.ModelType == "anomaly_detection") {
                                self.ChartLabels = val.predict_result.label;
                            } else if (self.ModelType == "health_assessment") {
                                self.chartValues = val.predict_result.predict;
                                self.ChartLabels2 = val.predict_result.label;
                            } else if (self.ModelType == "prognostic") {
                                self.chartValues = val.predict_result.predict;
                                self.ChartLabels3 = val.predict_result.label;
                            }
                            return val;
                        }
                    });
                }
            });
            self.curInt = null;
            self.ClearECharts();

            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];


            var _series = [];
            if (self.ModelType == "anomaly_detection" || self.ModelType == "health_assessment") {
                _series.push({
                    name: "OK", data: _predict_result_ok, type: 'scatter',
                    itemStyle: {
                        color: function (params) {
                            var key = params.dataIndex;

                            if (key === self.curInt) {
                                return '#FFFF00';
                            } else {
                                return arColor[0];
                            }
                        }, symbolSize: function (val) {
                            return val[2] * 40;
                        },
                    },

                });
                _series.push({
                    name: "NG", data: _predict_result_ng, type: 'scatter',
                    itemStyle: {
                        color: function (params) {
                            var key = params.dataIndex;

                            if (key === self.curInt) {
                                return '#FFFF00';
                            } else {
                                return '#F85256';
                            }
                        }, symbolSize: function (val) {
                            return val[2] * 40;
                        },
                    },

                });
            } else {
                _series.push({
                    name: self.ModelType, data: _predict_result, type: 'scatter',
                    itemStyle: {
                        color: function (params) {
                            var key = params.dataIndex;

                            if (key === self.curInt) {
                                return '#FFFF00';
                            } else {
                                return arColor[0];
                            }
                        }, symbolSize: function (val) {
                            return val[2] * 40;
                        },
                    },

                });
            }
            var _specLine = [], _specLine_w = [];
            if (self.ModelType == "health_assessment") {
                for (var i = 0; i < _predict_result.length; i++) {
                    _specLine.push(70);
                }
            } else if (self.ModelType == "anomaly_detection") {
                for (var i = 0; i < _predict_result.length; i++) {
                    _specLine.push(20);
                    _specLine_w.push(50);
                }
            }
            if (self.ModelType == "anomaly_detection") {
                _series.push({ name: "Warning", data: _specLine_w, type: 'line', symbol: 'none', smooth: true, itemStyle: { color: '#FFFF66' } });
            }

            if (self.ModelType == "health_assessment" || self.ModelType == "anomaly_detection") {
                _series.push({ name: "Alarm", data: _specLine, type: 'line', symbol: 'none', smooth: true, itemStyle: { color: '#F05050' } });
            }//if (self.ModelType == "health_assessment" || self.ModelType == "anomaly_detection") {

            //_series.push({ name: self.ModelType, data: _predict_result, type: 'line', symbol: 'none', smooth: true, itemStyle: { color: arColor[0] } });
            var _legend = [];
            
            if (self.ModelType == "health_assessment" || self.ModelType == "anomaly_detection") {
                if (_predict_result_ok.length > 0)
                    _legend.push("OK");
                if (_predict_result_ng.length > 0)
                    _legend.push("NG");
                _legend.push("Alarm");
                if (self.ModelType == "anomaly_detection")
                    _legend.push("Warning");
            } else {
                _legend = [self.ModelType];
            }
            self.DrawECharts("EChart1", "Predict Result", _series, _legend, _predict_result_x, "", "Predict Value");



            _series = [];
            _series.push({
                name: 'MXCI', data: _mxci, type: 'scatter',
                itemStyle: {
                    color: function (params) {
                        var key = params.dataIndex;
                        
                        if (key === self.curInt) {
                            return '#FFFF00';
                        } else {
                            return arColor[0];
                        }
                    }
                },
            });
            var isMXCING = false;
            _series.push({ name: "MXCI_Threshold", data: _mxci_threshold, type: 'line', symbol: 'none', smooth: true, itemStyle: { color: '#FF9326' } });
            for (var i = 0; i < _mxci.length; i++) {
                if (parseFloat(_mxci[i]) < parseFloat(_mxci_threshold[i])) {
                    isMXCING = true;
                    _mxci_ng.push(_mxci[i]);
                } else {
                    _mxci_ng.push(null);
                }
            }//for (var i = 0; i < _mxci.length; i++) {
            _legend = [];

            if (_mxci_ng != null && _mxci_ng.length > 0 && isMXCING == true) {
                //_series.push({ name: 'NG', data: _mxci_ng, type: 'scatter', itemStyle: { color: '#F85256' } });
                _series.push({
                    name: 'NG', data: _mxci_ng, type: 'scatter', itemStyle: {
                        color: function (params) {
                            var key = params.dataIndex;

                            if (key === self.curInt) {
                                return '#FFFF00';
                            } else {
                                return '#F85256';
                            }
                        }
                    },});
                _legend = ["MXCI", "MXCI_Threshold", "NG"];
            } else {
                _legend = ["MXCI", "MXCI_Threshold"];
            }
            
            
           
            self.DrawECharts("EChart2", "MXCI", _series, _legend, _mxci_x, "", "MXCI");




            _series = [];
            _series.push({
                name: 'XDI', data: _xdi, type: 'scatter',
                itemStyle: {
                    color: function (params) {
                        var key = params.dataIndex;

                        if (key === self.curInt) {
                            return '#FFFF00';
                        } else {
                            return arColor[0];
                        }
                    }
                },
            });
            _series.push({ name: "XDI_Threshold", data: _xdi_threshold, type: 'line', symbol: 'none', smooth: true, itemStyle: { color: '#FF9326' } });
            var isXDING = false;
            for (var i = 0; i < _xdi.length; i++) {
                if (parseFloat(_xdi[i]) > parseFloat(_xdi_threshold[i])) {
                    isXDING = true;
                    _xdi_ng.push(_xdi[i]);
                } else {
                    _xdi_ng.push(null);
                }
            }//for (var i = 0; i < _mxci.length; i++) {
            _legend = [];
            if (_xdi_ng != null && _xdi_ng.length > 0 && isXDING == true) {
                //_series.push({ name: 'NG', data: _xdi_ng, type: 'scatter', itemStyle: { color: '#F85256' } });
                _series.push({
                    name: 'NG', data: _xdi_ng, type: 'scatter',
                    itemStyle: {
                        color: function (params) {
                            var key = params.dataIndex;

                            if (key === self.curInt) {
                                return '#FFFF00';
                            } else {
                                return '#F85256';
                            }
                        }
                    },
                });
                _legend = ["XDI", "XDI_Threshold", "NG"];
            } else {
                _legend = ["XDI", "XDI_Threshold"];
            }
  
            self.DrawECharts("EChart3", "XDI", _series, _legend, _xdi_x, "", "XDI");

            //if (self.isFirst == true) {
            //    self.isFirst = false;
            if (parseFloat(_feature_importances[0]) > parseFloat(_feature_importances[_feature_importances.length - 1])) {
                _feature_importances.reverse();
                _feature_importances_x.reverse();
            }
            //}

            _series = [];
            _series.push({ name: '特徵值', data: _feature_importances, connectNulls: true, type: 'bar', symbol: ['none', 'arrow'], smooth: true, itemStyle: { color: arColor[0] } });

            self.DrawChart4('EChart4', _series, _feature_importances, _feature_importances_x);
             
            
        },

        ClearECharts: function () {
            //alert(modeltype)
            if (document.getElementById("EChart1") != null) {
                var myChart1 = echarts.init(document.getElementById("EChart1"), 'default');
                myChart1.clear();
               
            }
            if (document.getElementById("EChart2") != null) {
                var myChart2 = echarts.init(document.getElementById("EChart2"), 'default');
                myChart2.clear();
              
            }
            if (document.getElementById("EChart3") != null) {
                var myChart3 = echarts.init(document.getElementById("EChart3"), 'default');
                myChart3.clear();
               
            }
            if (document.getElementById("EChart4") != null) {
                var myChart4 = echarts.init(document.getElementById("EChart4"), 'default');
                myChart4.clear();
             
            }

        },
        DrawChart4: function (_chartid, _series, _feature_importances, _feature_importances_x) {
            var iStart = 100 - Math.round((20 / parseInt(_feature_importances.length))*100);
            
            var myChart = echarts.init(document.getElementById("EChart4"), 'dark');
            myChart.clear();
            
            /*  去除加载缓冲图 */
            myChart.showLoading({
                text: 'Loading...',
                textStyle: { fontSize: 30, color: '#444' },
                effectOption: { backgroundColor: 'rgba(0, 0, 0, 0)' }
            });






            var option = {
                backgroundColor: '#404040',//'#4E5250',// '#545655',//背景色
                tooltip: {
                    trigger: 'axis',
                    textStyle: {
                        fontSize: 11
                    },
                    formatter: function (params) {

                        var result = params[0].name + '<br>';
                        params.forEach(function (item) {
                            result += '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + item.color + '"></span>';
                            result += item.seriesName + " : " + '<span style="color:#ccffff;font-family: arial;">' + parseFloat(item.data.toFixed(6)) + "</span><br>";
                        });


                        return result;
                    }

                },
                //title: {
                //    text: '特徵重要程度',
                //    textStyle: { color: 'white' },

                //    //subtext: '',
                //    left: 'center'
                //},
                grid: { containLabel: true },
                xAxis: {
                    type: 'value', data: _feature_importances,
                    //  改变x轴颜色
                    axisLine: {
                        show: true,
                        onZero: false,
                        position: 'end',
                        lineStyle: {
                            color: '#DFFFBF',
                            width: 2,//这里是为了突出显示加上的，可以去掉
                        }
                    },
                    // 控制网格线是否显示
                    splitLine: {
                        show: false,
                        //  改变轴线颜色
                        lineStyle: {
                            // 使用深浅的间隔色
                            color: ['red']
                        }
                    },
                    axisTick: {
                        show: false,
                        alignWithLabel: true
                    },
                },
                yAxis: {
                    type: 'category', data: _feature_importances_x, axisLine: {
                        show: true,
                        lineStyle: {
                            color: '#DFFFBF',
                            width: 2,//这里是为了突出显示加上的，可以去掉
                        }
                    },
                    // 去除y轴上的刻度线
                    axisTick: {
                        show: false
                    },
                },
                dataZoom: [
                    {
                        type: 'slider',
                        xAxisIndex: 0,
                        filterMode: 'empty',
                       
                    },
                    {
                        type: 'slider',
                        yAxisIndex: 0,
                        filterMode: 'empty',
                        start: iStart,
                        end: 100
                        
                    },
                    {
                        type: 'inside',
                        xAxisIndex: 0,
                        filterMode: 'empty'
                    },
                    {
                        type: 'inside',
                        yAxisIndex: 0,
                        filterMode: 'empty',
                        start: iStart,
                        end: 100
                    }
                ],
                series: _series
            };


            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option, true);
        },

        DrawECharts: function (_chartid, _titlename, _series, _legend, _xAxis, _xAxisName, _yAxisName) {
           
            var myChart = echarts.init(document.getElementById(_chartid));
            myChart.off('click');//讓點擊失效
            myChart.clear();

            var self = this;
            var _interval = 'auto';
            var _type = 'value';
            if (_chartid == "EChart1" && self.ModelType == "prognostic") {
                _type = 'category';
                _value = null;
            }


            /*  去除加载缓冲图 */
            myChart.showLoading({
                text: 'Loading...',
                textStyle: { fontSize: 30, color: '#444' },
                effectOption: { backgroundColor: 'rgba(0, 0, 0, 0)' }
            });

            var _show = false;
            if (_chartid == "EChart1") {
                _show = true;
            }  
            var _min = null, _max = null;
            if (_chartid == "EChart1" && (self.ModelType == "anomaly_detection" || self.ModelType == "health_assessment")) {
                _min = 0;
                _max = 100;
            }




            var option = {
                backgroundColor: '#404040',//'#4E5250',// '#545655',//背景色
                //title: {
                //    text: _titlename,
                //    textStyle: { color: 'white' },

                //    //subtext: '',
                //    left: 'center'
                //},
                brush: {
                    toolbox: ['lineX', 'clear'],//['rect', 'polygon', 'lineX', 'lineY', 'keep', 'clear'],
                    xAxisIndex: 'all',
                    brushLink: 'all',
                    outOfBrush: {
                        colorAlpha: 0.1
                    }
                },
                tooltip: {
                    trigger: 'axis',
                    textStyle: {
                        fontSize: 11
                    },
                    formatter: function (params) {

                        var result = params[0].name + '<br>';
                        params.forEach(function (item) {
                            if (item.data != null) {
                                result += '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + item.color + '"></span>';
                                result += item.seriesName + " : " + '<span style="color:#ccffff;font-family: arial;">' + parseFloat(item.data).toFixed(6) + "</span><br>";
                            }

                            if (_chartid == "EChart1" && item.seriesName != "SpecLine") {
                                if (self.ModelType == "anomaly_detection") {
                                    if (self.ChartLabels.length > 0) {
                                        if (result.indexOf("Label : ") < 0) {
                                            result += "Label : " + '<span style="color:#ccffff;font-family: arial;">' + self.ChartLabels[params[0].dataIndex] + "</span><br>";
                                        }
                                    }
                                } else if (self.ModelType == "health_assessment") {
                                    if (self.ChartLabels2.length > 0) {
                                        if (result.indexOf("Label : ") < 0) {
                                            result += "Label : " + '<span style="color:#ccffff;font-family: arial;">' + self.ChartLabels2[params[0].dataIndex] + "</span><br>";
                                        }
                                    }
                                } else if (self.ModelType == "prognostic") {
                                    if (self.ChartLabels3.length > 0) {
                                        if (result.indexOf("Label : ") < 0) {
                                            result += "Label : " + '<span style="color:#ccffff;font-family: arial;">' + self.ChartLabels3[params[0].dataIndex] + "</span><br>";
                                        }
                                    }
                                }
                            }//if (_chartid == "EChart1") {

                        });


                        return result;
                    }

                },
                legend: {
                    show: true,
                    //type: 'scroll',
                    orient: 'vertical',
                    //x: 'right',
                    //y: 'top',
                    borderWidth: 1,
                    padding: 2,
                    itemGap: 2,
                    right: '1%',
                    top: '10%',

                    color: '#02B9C4',
                    data: _legend,
                    selected: {


                    },
                    bottom: '50%',
                    textStyle: {
                        color: '#CDEDED',
                        fontSize: '12'
                    },

                    //selected: 1
                },
                grid: {
                    x: '7%',
                    y: '7%',
                    width: '80%',
                    height: '60%',
                    show: false,
                    borderColor: 'red'
                },
                toolbox: {
                    show: true,
                    feature: {
                        mark: { show: true },
                        dataZoom: {

                            show: true, iconStyle: {

                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#ec7063'
                                }
                            }
                        },
                        dataView: {
                            show: false, readOnly: false, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#e59866'
                                }
                            }
                        },
                        restore: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#8e44ad'
                                }
                            }
                        },
                        saveAsImage: {
                            show: true, type: 'png', excludeComponents: ['toolbox'], pixelRatio: 2, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#2ecc71',
                                    shadowColor: 'rgba(0, 0, 0, 0.5)',
                                    shadowBlur: 10
                                }
                            }
                        },
                        //myTool2: {
                        //    show: true,
                        //    itemSize: 25,
                        //    title: 'Undo',
                        //    icon: 'image://../_img/Undo.png', 
                        //    onclick: function () {      

                        //        self.curInt = null;
                        //        myChart.setOption(option)
                        //        myChart.dispatchAction({
                        //            type: 'restore'             //重置 option。
                        //        });
                        //    }
                        //},

                    }
                },
                xAxis: [
                    {
                        name: _xAxisName,
                        nameLocation: 'middle',
                        nameGap: 125,
                        type: 'category',
                        triggerEvent: true,
                        boundaryGap: true,
                        data: _xAxis,



                        axisTick: {
                            show: false,
                            alignWithLabel: true
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变x轴颜色
                        axisLine: {
                            show: true,
                            onZero: false,
                            position: 'end',
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        //  改变x轴字体颜色和大小
                        axisLabel: {
                            show: true,
                            rotate: 90,
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                    }
                ],

                yAxis: [
                    {
                        //  隐藏y轴
                        name: _yAxisName,
                        nameTextStyle: {
                            //color: '#fff',
                            //fontSize: '24'
                            //fontWeight: 'bolder',
                            fontFamily: 'Arial',
                            fontSize: 18,
                            //fontStyle: 'italic',
                            color: 'rgb(249,246,246)',//'#fff',
                            shadowColor: 'rgb(32,31,31)',//'#fff', //默认透明
                            shadowBlur: 10,
  
                        },
                        nameLocation: 'middle',
                        nameGap: 55,
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        onZero: false,
                        onZeroAxisIndex: false,
                        // 去除y轴上的刻度线
                        axisTick: {
                            show: false
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变y轴字体颜色和大小
                        axisLabel: {
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                            formatter: function (value, index) {
                                if (_chartid == "EChart1" && self.ModelType == "prognostic") {
                                    for (var i = 0; i < self.chartValues.length; i++) {

                                        if (parseInt(value) == parseInt(self.chartValues[i]))
                                            return self.ChartLabels3[i];

                                    }//for (var i = 0; i < self.currentHAData.length; i++) {
                                    
                                } else if (_chartid == "EChart1" && (self.ModelType == "anomaly_detection" || self.ModelType == "health_assessment")) {
                                    
                                    return parseInt(value);
                                } else {
                                    return value;
                                }
                            },
                        },
                        type: _type,
                        interval: _interval,
                        triggerEvent: true,
                        min: _min,
                        max: _max
                    }
                ],

                dataZoom: [
                    {
                        type: 'slider',
                        xAxisIndex: 0,
                        start: 0,
                        end: 100
                    },
                    {
                        type: 'inside',
                        xAxisIndex: 0,
                        start: 0,
                        end: 100
                    },
                    {
                        show: _show,
                        type: 'slider',
                        yAxisIndex: 0,
                        start: 0,
                        end: 100,
                        right: '10%'
                    },
                    {
                        show: _show,
                        type: 'inside',
                        yAxisIndex: 0,
                        start: 0,
                        end: 100,
                        right: '10%'
                    }
                ],
                series: _series
            };


            myChart.on('click', function (params) {

                if (self.curInt != null && self.curInt == params.dataIndex)
                    self.curInt = null;
                else
                    self.curInt = params.dataIndex;

                myChart.setOption(option, true);


                myChart.dispatchAction({
                    type: 'restore'             //重置 option。
                });



            });

            myChart.getZr().on('mousedown', function () {
                //alert("鼠标按下");
                // myChart.dispatchAction({
                //    type: 'brush',
                //    areas: [
                //        {
                //            brushType: 'rect',
                //            coordRange: _xAxis,                       
                //            xAxisIndex: 'all'

                //        }
                //    ]
                //});
            });

 






            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option, true);

            // 分别设置每个实例的 group id
            myChart.group = 'group1';
            echarts.connect('group1');
          
           

        },
        renderBrushed: function (params) {
            var brushed = [];
            var brushComponent = params.batch[0];

            for (var sIdx = 0; sIdx < brushComponent.selected.length; sIdx++) {
                var rawIndices = brushComponent.selected[sIdx].dataIndex;
                brushed.push('[Series ' + sIdx + '] ' + rawIndices.join(', '));
            }
            var myChart = echarts.init(document.getElementById("EChart1"));

            myChart.setOption({
                title: {
                    backgroundColor: '#333',
                    text: 'SELECTED DATA INDICES: \n' + brushed.join('\n'),
                    bottom: 0,
                    right: 0,
                    width: 100,
                    textStyle: {
                        fontSize: 12,
                        color: '#fff'
                    }
                }
            });
        },

        chooseDate: function () {
            var self = this;

            if (self.startTime > self.endTime) {
                alertify.error("日期選擇錯誤");

                self.endTime = self.startTime;

            }

        },







               //xxxformat: function date2str(x, y) {
        //    var z = {
        //        M: x.getMonth() + 1,
        //        d: x.getDate(),
        //        h: x.getHours(),
        //        m: x.getMinutes(),
        //        s: x.getSeconds()
        //    };
        //    y = y.replace(/(M+|d+|h+|m+|s+)/g, function (v) {
        //        return ((v.length > 1 ? "0" : "") + eval('z.' + v.slice(-1))).slice(-2)
        //    });

        //    return y.replace(/(y+)/g, function (v) {
        //        return x.getFullYear().toString().slice(-v.length)
        //    });
        //},

    }
})