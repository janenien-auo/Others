﻿$(document).ready(function () {
    var onlineHomeViewMode = OnlineLayoutApp.onlineHomeViewMode; 

    

    switch (onlineHomeViewMode) {

        case 'chart':
            {
                window.location.href = "/online/onlinehome";
                break;
            }
        case 'list':
            {
                window.location.href = "/online/onlinemodellist";
                break;
            }
        default:
    }
});
