﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {   
        toolMappingList: [],
        modelPredictFrequencies: store.getters.getModelPredictFrequencies,
        modelPredictFrequency: store.getters.getModelPredictFrequencies[0],
        onlineModelStatuses: store.getters.getOnlineModelStatuses,
        onlineModelStatus: store.getters.getOnlineModelStatuses[0],
        selectedToolChambers: [],
        allSelected: false,
        projectName: 'This is project name',
        application: '',
        projectId: '',
        modelId: '',
        sendToEstoneSetting: {
            errorPoint: 1,
            totalPoint: 1
        },
        estoneGroupList: [],
        estoneGroup: [],
        onlineStatus: '',
        projectInfo: {}
    },   
    mounted: function () {
        var self = this;
        self.init();
       
    },
    methods: {
        init: function () {

            store.commit('setShowLoading', true);

            var self = this;
            self.projectId = getUrlParameterByName('projectid', window.location.href.toLowerCase());
            self.modelId = getUrlParameterByName('modelid', window.location.href.toLowerCase());

            store.commit("setCurrentProjectId", self.projectId);  

            store.commit("setProjectInfo", null);  
            self.projectInfo = store.getters.getCurrentProjectInfo;
            self.projectName = self.projectInfo.fab + "-" + self.projectInfo.stage + "-"+ self.projectInfo.func + "-" + self.projectInfo.ai365_project_name + "-" + self.projectInfo.model_type + "-"+ self.projectInfo.project_id;

           
            self.getToolMappingList().then(function () {
                self.getEStoneGroupList();
                store.commit('setShowLoading', false);
            });

           

        },    


        getToolMappingList: function () {
            var self = this;

            return new Promise(function (resolve, reject) {
            

                var params = {
                    project_id: self.projectId,
                    model_id: self.modelId
                };


                getToolMappingList(params, false)
                .then(function (response) {
                    self.toolMappingList = response.data.data.tool_chamber_list;

                    var sendToEstoneSettings = response.data.data.alarm_rule.split('/');
                    self.sendToEstoneSetting.errorPoint = parseInt(sendToEstoneSettings[0]);
                    self.sendToEstoneSetting.totalPoint = parseInt(sendToEstoneSettings[1]);

                    self.onlineModelStatus = response.data.data.online_status;

                    var groupList = response.data.data.alarm_notify_group_name_list;
                    self.estoneGroup = groupList;
                    self.estoneGroupList = [];


                    groupList.forEach(function (el) {                       
                        self.estoneGroupList.push(el);                       
                    });


                    self.toolMappingList.forEach(function (el) {
                        if (el.use) {
                            self.selectedToolChambers.push(el.tool_job_mapping_id);
                        }
                    });

                    resolve();
                }).catch(function (err) {
                    store.commit('setShowLoading', false);

                })
            })

        },


        clickCheckbox: function (id) {
            if (!$('#' + id)[0].checked) {
                this.allSelected = false;
            }           

        },

        //選擇全部的按鈕
        selectAll: function () {
            var self = this;
        

            self.selectedToolChambers = [];

            if (!self.allSelected) {
                for (p in self.toolMappingList) {
                    self.selectedToolChambers.push(self.toolMappingList[p].tool_job_mapping_id);
                } 
            }           
           
        },

       
              
        clickSave: function () {
            var self = this;

            if (self.sendToEstoneSetting.errorPoint > self.sendToEstoneSetting.totalPoint) {
                alertify.error("資料設定錯誤");
                return;
            }


            if (self.sendToEstoneSetting.errorPoint == 1 && self.sendToEstoneSetting.totalPoint != 1) {
                alertify.error("Send to Estone Setting can not setting 1,1");

                return;
            }


            alertify.set({ 'labels': { 'ok': "ok", 'cancel': "cancel" } });
            alertify.confirm("儲存編輯中的內容?",
                function (e) {
                    if (e) {
                        //OK
                        self.saveToModel();
                    } else {
                        //Cancel                      
                    }
                });

        },

        saveToModel: function () {          


            console.log('saveToModel');

            var self = this;
                                  


            var alarm_notify_group_name_list = [];
            alarm_notify_group_name_list=self.estoneGroup;

            var modifyToolChamberList = [];

            //確認異動的Item
            self.toolMappingList.forEach(function (el) {
                var result = self.selectedToolChambers.indexOf(el.tool_job_mapping_id);

                var isChecked = result >= 0 ? true : false;

                if (isChecked != el.use) {
                    modifyToolChamberList.push({
                        tool_job_mapping_id: el.tool_job_mapping_id,
                        tool_id: el.tool_id,
                        chamber: el.chamber,
                        source: el.source,
                        use: isChecked

                    });
                }   
            })


            var data = {
                project_id: self.projectId,
                model_id: self.modelId,
                online_status: self.onlineModelStatus,
                alarm_rule: self.sendToEstoneSetting.errorPoint + "/" + self.sendToEstoneSetting.totalPoint,
                alarm_notify_group_name_list: alarm_notify_group_name_list,
                tool_chamber_list: modifyToolChamberList
            };


            console.log(modifyToolChamberList);

            postToolMappingList(data, store.getters.getIsApiTest)
                .then(function (response) {

                    alertify.set({ 'labels': { 'ok': "返回Online Model List", 'cancel': "留在此頁" } });
                    alertify.confirm("儲存完成",
                        function (e) {
                            if (e) {
                                //OK
                                window.location = "/online/onlinemodellist";
                                
                            } else {
                                //Cancel                                    
                            }
                        });

                    

                })
                .catch(function (err) {
                    alert(err);

                })
        },


        getEStoneGroupList: function () {
            var self = this;

            var params = {
                user_id: UserInfoApp.userInfo.UserId//Reaver工號:1110012//
            };
             
            estoneGroupList(params, store.getters.getIsApiTest)
                .then(function (response) {
                    response.data.data.group_list.forEach(function (el) {
                        if (self.estoneGroupList.indexOf(el.group_name) < 0) {
                            self.estoneGroupList.push(el.group_name);
                        }                        
                    });                   
            })  
        }

     

    
     
     

      

       






   



    }
})