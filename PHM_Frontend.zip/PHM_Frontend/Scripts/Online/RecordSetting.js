﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {      
        projectId: '',
        modelId:'',
        closeEstoneList: [],   
        projectName: 'This is project name',
        fabs: [],
        fab: "",
        stages: [],
        stage: "",
        funcs: [],
        func: "",
        toolIds: [],
        toolId: '',
        chambers: [],
        chamber:'',
        eventTypes: store.getters.getEventTypes,
        eventType: '',
        components: store.getters.getComponents,
        component: '',
        alarmCodes: [],
        alarmCode: '',
        solutions: store.getters.getSolutions,
        solution: '',
        actionTime: '',
        note:''
    },   
    mounted: function () {
        var self = this;
        self.init();
       
    },
    methods: {
        init: function () {

            //store.commit('setShowLoading', true);

            var self = this;  


            if (getUrlParameterByName('projectid', window.location.href.toLowerCase()) != null)
                self.projectId = getUrlParameterByName('projectid', window.location.href.toLowerCase());
            if (getUrlParameterByName('modelid', window.location.href.toLowerCase()) != null)
                self.modelId = getUrlParameterByName('modelid', window.location.href.toLowerCase());

            store.commit("setCurrentProjectId", self.projectId);

            store.commit('setProjectInfo', null);
            self.projectInfo = store.getters.getCurrentProjectInfo;
            self.projectName = self.projectInfo.fab + "-" + self.projectInfo.stage + "-" + self.projectInfo.func + "-" + self.projectInfo.ai365_project_name + "-" + self.projectInfo.model_type + "-" + self.projectInfo.project_id;



            self.getFabs().then(function () {

                var fab = getUrlParameterByName('FAB', window.location.href.toUpperCase());

                if (!fab)
                    fab = window.localStorage.getItem('fab');

                if (fab) {
                    self.fab = fab;
                }
                else {
                    //預設fab
                    if (UserInfoApp.userInfo.UserSite) {
                        self.Fab = UserInfoApp.userInfo.UserSite;
                    }
                    else {
                        if (self.fabs) {
                            self.fab = self.fabs[0].fab;
                        }
                    }
                }
                if (self.fab) self.getStages();

                var stage = getUrlParameterByName('STAGE', window.location.href.toUpperCase());


                if (!stage)
                    stage = window.localStorage.getItem('stage');


                //預設stage
                if (stage) {
                    self.stage = stage;
                    OnlineLayoutApp.stage = stage;
                } else {
                    if (OnlineLayoutApp.stage)
                        self.stage = OnlineLayoutApp.stage;
                    else {
                        if (self.stages) {
                            self.stage = self.stages[0].stage_name;
                        }
                    }
                }



                if (self.stage) self.getFuncs();

                var func = getUrlParameterByName('FUNC', window.location.href.toUpperCase());

                if (!func)
                    func = window.localStorage.getItem('func');


                //預設Function

                if (func) {
                    self.func = func;
                } else {
                    if (OnlineLayoutApp.func)
                        self.func = OnlineLayoutApp.func;
                    else {
                        if (self.funcs) {
                            self.func = self.funcs[0];
                        }
                    }
                }

                self.getTools();
                store.commit('setShowLoading', false);               

            });

          
        },    


        getFabs: function () {
            var self = this;

            return new Promise(function (resolve, reject) {

                getBasicInfoDropdownList(store.getters.getIsApiTest)
                    .then(function (response) {
                        self.fabs = response.data.data.select_item;

                        self.stage = "";
                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },

        getStages: function () {
            var self = this;
            self.stage = "";
            self.stages = [];
            self.func = "";
            self.funcs = [];
            self.fabs.forEach(function (item, index) {

                if (item.fab == self.fab) {
                    self.stages = item.stage;
                }
            });
        },

        getFuncs: function () {

            var self = this;
            self.func = "";
            self.funcs = [];
            self.stages.forEach(function (item, index) {

                if (item.stage_name == self.stage) {
                    self.funcs = item.function_list;
                }
            });
        },

        getTools: function () {
            var self = this;

            var params = {
                fab: self.fab,
                stage: self.stage,
                func: self.func
            };
            
            
            getRecordDropdownlist(params, false)
                .then(function (response) {
                    self.toolIds = response.data.data.tool_list;                   
                }).catch(function (err) {
                    store.commit('setShowLoading', false);
                })

        },

        getChambers: function (data) {
            var self = this;
            var tempChambers = self.toolIds.filter(function (el) {
                return el.key == self.toolId;
            });

            self.chambers = tempChambers[0].chamber_list;
            self.chamber = self.chambers[0].key;
        },


        confirm: function () {
            var self = this;

            this.$validator.validateAll().then(function (result) {
                if (result) {
                    self.SaveData();     
                }
                else {
                    alertify.error('欄位資料填寫錯誤');
                }
            })
        },

        SaveData: function () {

            var self = this;

            var data = {
                project_id: self.projectId,
                model_id: self.modelId,
                tool_id: self.toolId,
                chamber: self.chamber,
                event_type: self.eventType,
                component: self.component,
                //alarm_code: self.alarmCode,
                solution: self.solution,
                action_time: moment(self.actionTime).format('YYYY-MM-DD hh:mm'),
                note: self.note,
                source: "user_maintain",               
            };


            postMaintainRecord(data, false)
                .then(function (response) {                                                          

                    alertify.alert('儲存成功!', function () { window.location = "/online/RecordHistory"; });

                }).catch(function (err) {
                    store.commit('setShowLoading', false);
                })



        }
      

       

    }
})