﻿

var app = new Vue({
    el: '#app',
    store: store,
    data: { 
        startTime: moment(new Date()).add(-14, 'days').format('YYYY-MM-DD'),
        endTime: moment(new Date()).format('YYYY-MM-DD'),
        projectName:'',
        recordHistoryList: [],
        filterRecordHistoryList: [],
        filterRecordHistoryListByPage: [],
        keyWord: "",
        //searchKeys: ["ai365_project_name", "fab", "stage", "func", "model_type", "project_id","user_empno"],
        searchKeys: ["tool_id", "chamber", "event_type", "component", "alarm_code", "solution", "note","source"],
        selectedEvents: [],
        allSelected: false,
        Pagination: {
            current_page: 1,
            page_size: 10,
            total: 0
        },
        pickerOptions: {//控制elementUI不能選今天以後的日期
            disabledDate(time) {
                return time.getTime() > Date.now();
            },
        },
        projectInfo: {},
        projectId: '',
        modelId: '',
        projectName: 'This is project name'
    },
    mounted: function () {
        var self = this;
        self.init();
        store.commit('setShowLoading', false);
    },
    methods: {

        init: function () {
            var self = this;


            store.commit('setShowLoading', true);           

            if (!self.projectId)
                self.projectId = window.localStorage.getItem('projectid');

            if (!self.modelId)
                self.modelId = window.localStorage.getItem('modelid');


            if (getUrlParameterByName('projectid', window.location.href.toLowerCase()) != null)
                self.projectId = getUrlParameterByName('projectid', window.location.href.toLowerCase());
            if (getUrlParameterByName('modelid', window.location.href.toLowerCase()) != null)
                self.modelId = getUrlParameterByName('modelid', window.location.href.toLowerCase());


            if (!self.projectId) {
                store.commit('setDefaultProjectId',null);                    
            }
            store.commit("setCurrentProjectId", self.projectId);

            store.commit('setProjectInfo',null);
            self.projectInfo = store.getters.getCurrentProjectInfo;
            self.projectName = self.projectInfo.fab + "-" + self.projectInfo.stage + "-" + self.projectInfo.func + "-" + self.projectInfo.ai365_project_name + "-" + self.projectInfo.model_type + "-" + self.projectInfo.project_id;

            self.projectId = self.projectInfo.project_id;
            self.modelId = self.projectInfo.model_id;     
            store.commit("setCurrentModelId", self.modelId);  


            self.getRecordHistoryList(self.Pagination.current_page).then(function () {
                store.commit('setShowLoading', false);
            });
        },


      

        getRecordHistoryList: function (page) {
            var self = this;

            return new Promise(function (resolve, reject) {
                
                //避免User在其他頁點選查詢造成沒有資料，統一導向第一頁
                if (page)
                    self.Pagination.current_page = page;                

                var params = {
                    project_id: self.projectId,
                    model_id: self.modelId,
                    start_time: self.startTime,
                    end_time: self.endTime,
                    page_no:1,
                    page_size:999999
                };

                getRecordHistoryList(params, false)                
                    .then(function (response) {
                       
                        self.recordHistoryList = response.data.data.maintain_list;
                        self.filterModelList();
                        self.handleChangePage(1);

                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);
                    })

            })
        },


        filterModelList: function () {


            var self = this;

            if (!self.keyWord) {
                self.filterRecordHistoryList = self.recordHistoryList;
                self.Pagination.total = self.filterRecordHistoryList.length;
                self.handleChangePage(1);
                return;
            }

            self.filterRecordHistoryList = [];

            var keywords = self.keyWord.split(' ');

            self.$search(keywords, self.recordHistoryList, self.searchKeys, null, 0.1).then(
                function (response) {
                    response.forEach(function (d) {
                        self.filterRecordHistoryList.push(d.item);
                    })

                    self.Pagination.total = self.filterRecordHistoryList.length;
                    self.handleChangePage(1);
                });                  
        },

        addRecord: function () {
            var self = this;
            window.location.href = "/online/RecordSetting?projectid=" + self.projectId + "&modelid=" + self.modelId;
        },
                     


        //換頁
        handleChangePage: function (val) {
            var self = this;
            self.Pagination.current_page = val;

            var startIndex = (self.Pagination.current_page - 1) * self.Pagination.page_size;
            if (startIndex < 0) startIndex = 0;

            if (startIndex > self.Pagination.total) startIndex = 0;

            var endIndex = (self.Pagination.current_page * self.Pagination.page_size);
            if (endIndex >= self.filterRecordHistoryList.length) endIndex = self.filterRecordHistoryList.length;
            self.filterRecordHistoryListByPage = self.filterRecordHistoryList.slice(startIndex, endIndex);
        },

        chooseDate: function () {
            var self = this;

            if (self.startTime > self.endTime) {
                alertify.error("日期選擇錯誤");

                self.endTime = self.startTime;

            }

        },

    }



})