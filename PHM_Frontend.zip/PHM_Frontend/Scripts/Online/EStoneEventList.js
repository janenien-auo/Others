﻿

var app = new Vue({
    el: '#app',
    store: store,
    data: { 
        eStoneEventList: [],
        filterEStoneEventList: [],
        filterEStoneEventListByPage: [],
        keyWord: "",       
        searchKeys: ["ai365_project_name", "model_type", "fab", "stage", "func", "tool_id", "chamber","machine_part"],
        selectedEvents: [],
        allSelected: false,
        Pagination: {
            current_page: 1,
            page_size: 10,
            total: 0,
            page_sizes: [10, 30, 50, 100],
        },
        projectId: '',
        modelId: '',
        projectName:'',
        selectToolId: '',
        selectChamber: ''
    },
    mounted: function () {
        var self = this;

        self.init();

        store.commit('setShowLoading', false);
    },
    methods: {

        init: function () {
                                 

            store.commit('setShowLoading', true);

            var self = this;

            self.getEStoneEventList(self.Pagination.current_page).then(function () {                
                store.commit('setDefaultProjectId');
                store.commit('setProjectInfo');

                self.projectInfo = store.getters.getCurrentProjectInfo;
                self.projectName = self.projectInfo.fab + "-" + self.projectInfo.stage + "-" + self.projectInfo.func + "-" + self.projectInfo.ai365_project_name + "-" + self.projectInfo.model_type + "-" + self.projectInfo.project_id;

                store.commit('setShowLoading', false);

            });
        },
                    

        getEStoneEventList: function (page) {
            var self = this;

            return new Promise(function (resolve, reject) {
               

                //避免User在其他頁點選查詢造成沒有資料，統一導向第一頁
                if (page)
                    self.Pagination.current_page = page;


                if (!self.projectId)
                    self.projectId = window.localStorage.getItem('projectid');

                if (!self.modelId)
                    self.modelId = window.localStorage.getItem('modelid');


                if (getUrlParameterByName('projectid', window.location.href.toLowerCase()) != null)
                    self.projectId = getUrlParameterByName('projectid', window.location.href.toLowerCase());
                if (getUrlParameterByName('modelid', window.location.href.toLowerCase()) != null)
                    self.modelId = getUrlParameterByName('modelid', window.location.href.toLowerCase());
                          


                var params = {
                    project_id: self.projectId,
                    model_id: self.modelId
                };

                getEStoneEventList(params, false)
                    .then(function (response) {
                       
                        self.eStoneEventList = response.data.data.event_list;

                        self.filterModelList();

                        self.handleChangePage(1);


                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);
                    })

            })
        },


        filterModelList: function () {

            var self = this;

            if (!self.keyWord) {
                self.filterEStoneEventList = self.eStoneEventList;
                self.Pagination.total = self.filterEStoneEventList.length;
                self.handleChangePage(1);
                return;
            }

            self.filterEStoneEventList = [];

            var keywords = self.keyWord.split(' ');

            self.$search(keywords, self.eStoneEventList, self.searchKeys, null, 0.1).then(
                function (response) {
                    response.forEach(function (d) {
                        self.filterEStoneEventList.push(d.item);
                    })

                    self.Pagination.total = self.filterEStoneEventList.length;
                    self.handleChangePage(1);
                });

        },
                          

        selectAll: function () {
            var self = this;

            self.selectedEvents = [];

            if (!self.allSelected) {

                var check = true;
                self.filterEStoneEventListByPage.forEach(function (p) {

                    if (check) {
                        if (self.filterEStoneEventListByPage[0].tool_id == p.tool_id && self.filterEStoneEventListByPage[0].chamber == p.chamber) {
                            self.selectedEvents.push(p.event_id);
                        }
                        else {
                            self.selectedEvents = [];
                            alertify.alert("不可選不同的Tool Chamber組合", function () {
                                self.allSelected = false;
                            });
                            check = false;
                        }    

                    }
                 

                });    

              
            }



        },

        clickCheckbox: function (data) {
            var self = this;   

            if (!$('#' + data.event_id)[0].checked) {
                this.allSelected = false;

                if (self.selectedEvents.length-1 <= 0) {
                    self.selectToolId = '';
                    self.selectChamber = '';

                    self.filterEStoneEventListByPage.forEach(function (item, index) {
                        //el.canSelect = true;
                        self.$set(self.filterEStoneEventListByPage[index], 'canSelect', true);
                    });
                }               
            }
            else {

                if (!self.selectToolId) {
                    self.selectToolId = data.tool_id;
                }

                if (!self.selectChamber) {
                    self.selectChamber = data.chamber;
                }
                                              
               

                self.filterEStoneEventListByPage.forEach(function (el) {
                    if (self.selectToolId == el.tool_id && self.selectChamber == el.chamber) {
                        el.canSelect = true;  
                    }   
                    else {
                        el.canSelect = false;
                        //var eventIndex = self.selectedEvents.indexof(el.event_id);
                        //if (eventIndex> -1) {
                        //    self.selectedEvents.splice(eventIndex, 1);;
                        //}

                    }                        
                });
            }
                      

            if (self.selectToolId && self.selectChamber && (self.selectToolId != data.tool_id || self.selectChamber != data.chamber)) {
                alert("不可選不同的Tool Chamber組合");
            }

        },


        next: function () {
            var self = this;
            var selectedEventNames = [];

            if (self.selectedEvents.length == 0) {
                alertify.alert("請選擇Event");

                return;
            }

            self.filterEStoneEventListByPage.forEach(function (el) {
                if (self.selectedEvents.includes(el.event_id)) {

                    // {{data.fab}}-{{data.stage}}-{{data.func}}-{{data.ai365_project_name}}-{{data.model_type}}-{{data.tool_id}}-{{data.chamber}}-{{data.machine_part}}
                    //var eventName = el.fab + "-" + el.stage + "-" + el.func + "-" + el.ai365_project_name+ "-" + el.model_type + "-" + el.tool_id + "-" + el.chamber + "-" + el.machine_part;
                    selectedEventNames.push({
                        tool_id: el.tool_id,
                        chamber: el.chamber,
                        ngItem: el.machine_part,
                        eventTime: el.notify_time
                    });
                }

            })

            


            var closeEventDetail = {
                project_id: self.projectId,
                model_id: self.modelId,
                tool_id: self.selectToolId,
                chamber: self.selectChamber,             
                event_id_list: self.selectedEvents,
                eventDetail: selectedEventNames
            };

            window.localStorage.setItem('closeeventdetail', JSON.stringify(closeEventDetail));
            window.location.href = "/online/closeEStone";
        },
       


        //換頁
        handleChangePage: function (val) {
            var self = this;
            self.allSelected = false;
            self.selectedEvents = [];
            self.selectToolId = '';
            self.selectChamber = '';

            self.Pagination.current_page = val;

            var startIndex = (self.Pagination.current_page - 1) * self.Pagination.page_size;
            if (startIndex < 0) startIndex = 0;

            if (startIndex > self.Pagination.total) startIndex = 0;

            var endIndex = (self.Pagination.current_page * self.Pagination.page_size);
            if (endIndex >= self.filterEStoneEventList.length) endIndex = self.filterEStoneEventList.length;
            self.filterEStoneEventListByPage = self.filterEStoneEventList.slice(startIndex, endIndex);

            self.filterEStoneEventListByPage.forEach(function (el) {
                el["canSelect"] = true;
            });

        },

        
        
    }



})