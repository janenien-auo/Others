﻿var app = new Vue({
    el: '#app', //el為要綁定的div的id(已設定完成)  
    store: store,
    data: {
        //該頁會使用道的變數請統一放在這裡
        Fabs: [],
        Fab: "",
        Stages: [],
        Stage: "",
        Funcs: [],
        Func: "",
        ChartDatas: [],
        sDataHealth: "--",
        sOnlineRatio: "--",
        sAnomaly: "--",
        sHealth: "--",
        sPrognostic: "--",
        Anomaly: "",
        Health: "",
        Prognostic: "",
        RUL: "",
        OnlineRatio: "",
        DataHealth: "",
        sRUL: "--",
        okAnomaly: 0,
        ngAnomaly: 0,
        okHealth: 0,
        ngHealth: 0,
        okPrognostic: 0,
        ngPrognostic: 0,
        okDataHealth: 0,
        ngDataHealth: 0,
        
        
    },  
    mounted: function () {

        //錨點定位到Chart可全部看到的位置
        $('html, body').animate({
            scrollTop: $("#OnlineLayoutApp").offset().top
        }, 1000);

        OnlineLayoutApp.onlineHomeViewMode = 'chart';
        store.commit('clearCurrentProjectInfo', null);   

        var self = this;
        if (UserInfoApp.userInfo.UserSite != "")
            self.Fab = UserInfoApp.userInfo.UserSite;
        self.getFabs().then(function () {
            self.getStages();     
            self.QueryData();
        });     
        
    },
    methods: {

        getFabs: function () {

            var self = this;

            return new Promise(function (resolve, reject) {

            var apiUrl = "/dropitem/online_filter";
            //'/dropitem/tool_chamber?model_id=5'
            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet().reply(200, {
                status: "OK",
                data: {
                    select_item:
                        [
                            {
                                fab: "L5C",
                                stage: [
                                    {
                                        stage_name: "ARRAY",
                                        function_list: ["ETCH", "INT", "PHOTO", "TF",]
                                    },
                                    {
                                        stage_name: "CELL",
                                        function_list: ["BEOL", "FAC", "ODF", "PI", "SLM"]
                                    },
                                    {
                                        stage_name: "CF",
                                        function_list: ["FAC", "ITO", "PHOTO", "TF"]
                                    }
                                ]
                            },
                            {
                                fab: "L6A",
                                stage: [
                                    {
                                        stage_name: "ARRAY",
                                        function_list: ["ETCH", "FA", "FAC", "INT", "PHOTO", "TF"]
                                    },
                                    {
                                        stage_name: "CELL",
                                        function_list: ["BEOL", "CELL_N3", "CELL_TEST", "CUTTING", "FA", "FAC", "ODF", "PI"]
                                    },
                                    {
                                        stage_name: "CF",
                                        function_list: ["CF", "FA", "FAC", "ITO", "PHOTO"]
                                    }
                                ]
                            }
                        ]
                }

            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

           
            axios({
                method: 'get',
                baseURL: store.getters.getOnlineApiUrl,
                url: apiUrl,
                params: {
                    fab: self.Fab,
                    stage: self.Stage,
                    function: self.Func
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.Fabs = response.data.data.select_item;
                        if (UserInfoApp.userInfo.UserSite)
                            self.Fab = UserInfoApp.userInfo.UserSite;
                        else
                            self.Fab = self.Fabs[0].fab;                                           
                    }
                    resolve();
                    })

            });
        },
        detectZoom: function () {
            var ratio = 0,
                screen = window.screen,
                ua = navigator.userAgent.toLowerCase();

            if (window.devicePixelRatio !== undefined) {
                ratio = window.devicePixelRatio;
            }
            else if (~ua.indexOf('msie')) {
                if (screen.deviceXDPI && screen.logicalXDPI) {
                    ratio = screen.deviceXDPI / screen.logicalXDPI;
                }
            }
            else if (window.outerWidth !== undefined && window.innerWidth !== undefined) {
                ratio = window.outerWidth / window.innerWidth;
            }

            if (ratio) {
                ratio = Math.round(ratio * 100);
            }
            return ratio;
        },      

        getStages: function () {

            var self = this;
            self.Stage = "";
            self.Stages = [];
            self.Func = "";
            self.Funcs = [];
            let arTmp = self.Fabs.filter(function (item, index) {

                if (item.fab == self.Fab) {
                    self.Stages = item.stage;
                    return item.stage;
                }
            });
        },
        getFunctions: function () {

            var self = this;
            self.Func = "";
            self.Funcs = [];
            let arTmp = self.Fabs.filter(function (item, index) {

                if (item.fab == self.Fab) {
                    item.stage.forEach(function (val, idx, array) {
                        if (self.Stage == val.stage_name) {
                            self.Funcs = val.function_list;
                            return val.function_list;
                        }
                    });

                }
            });

            self.QueryData();
        },

        btnQueryClick: function () {
            var self = this;
            
            OnlineLayoutApp.fab = self.Fab;
            OnlineLayoutApp.stage = self.Stage;
            OnlineLayoutApp.func = self.Func;
            if (self.Fab == "" || self.Fab == null) {
                alertify.alert("Please Select Fab !!");
                return;
            }

            self.ClearECharts();
            self.QueryData();
        },

        QueryData: function () {
            var apiUrl = "/home";
            //'/dropitem/tool_chamber?model_id=5'
            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet().reply(200, {
                status: "OK",
                data:
                {
                    chart: {
                        anomaly: { online_count: 100, normal_count: 90 },
                        health: { online_count: 90, normal_count: 80 },
                        prognostic: { online_count: 50, normal_count: 30 }
                    }
                }

            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'get',
                baseURL: store.getters.getOnlineApiUrl,
                url: apiUrl,
                params: {
                    fab: self.Fab,
                    stage: self.Stage,
                    function: self.Func
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.ChartDatas = response.data.data.chart;


                        if (self.ChartDatas.data_health.online_count == null)
                            self.sDataHealth = "--";
                        else {
                            self.okDataHealth = self.ChartDatas.data_health.normal_count;
                            self.ngDataHealth = parseInt(self.ChartDatas.data_health.online_count) - parseInt(self.ChartDatas.data_health.normal_count);

                            if (self.ChartDatas.data_health.online_count == 0) {
                                self.sDataHealth = "0";
                            } else {
                                self.sDataHealth = Math.round((parseFloat(self.ChartDatas.data_health.normal_count) / parseFloat(self.ChartDatas.data_health.online_count)) * 100);
                            }
                        }
                        
                        if (self.ChartDatas.anomaly.online_count == null)
                            self.sAnomaly = "--";
                        else {
                            self.okAnomaly = self.ChartDatas.anomaly.normal_count;
                            self.ngAnomaly = parseInt(self.ChartDatas.anomaly.online_count) - parseInt(self.ChartDatas.anomaly.normal_count);

                            if (self.ChartDatas.anomaly.online_count == 0) {
                                self.sAnomaly = "0";
                            } else {
                                self.sAnomaly = Math.round((parseFloat(self.ChartDatas.anomaly.normal_count) / parseFloat(self.ChartDatas.anomaly.online_count)) * 100);
                            }
                        }



                        if (self.ChartDatas.health.online_count == null) {
                            self.sHealth = "--";
                        } else {
                            self.okHealth = self.ChartDatas.health.normal_count;
                            self.ngHealth = parseInt(self.ChartDatas.health.online_count) - parseInt(self.ChartDatas.health.normal_count);
                            if (self.ChartDatas.health.online_count == 0) {
                                self.sHealth = "0";
                            } else {
                                self.sHealth = Math.round((parseFloat(self.ChartDatas.health.normal_count) / parseFloat(self.ChartDatas.health.online_count)) * 100);
                            }
                        }

                        if (self.ChartDatas.prognostic.online_count == null) {
                            self.sPrognostic = "--";
                        } else {
                            self.okPrognostic = self.ChartDatas.prognostic.normal_count;
                            self.ngPrognostic = parseInt(self.ChartDatas.prognostic.online_count) - parseInt(self.ChartDatas.prognostic.normal_count);
                            if (self.ChartDatas.prognostic.online_count == 0) {
                                self.sPrognostic = "0";
                            } else {
                                self.sPrognostic = Math.round((parseFloat(self.ChartDatas.prognostic.normal_count) / parseFloat(self.ChartDatas.prognostic.online_count)) * 100);
                            }         
                        }            
                        
                        self.Prognostic = "--";//"▲48"; //
                        self.Health = "--";//"▼25";
                        self.Anomaly = "--";//"▼1";
                        self.RUL = "--";
                        self.OnlineRatio = "--";
                        self.DataHealth = "--";






                      
                       
                        OnlineLayoutApp.fab = self.Fab;
                        OnlineLayoutApp.stage = self.Stage;
                        OnlineLayoutApp.function = self.Func;

                        self.DrawChart();

                    }
                })
        },

        ClearECharts: function () {
            //alert(modeltype)
            if (document.getElementById("PieChart") != null) {
                var myChart = echarts.init(document.getElementById("PieChart"), 'default');
                myChart.clear();
            }

            if (document.getElementById("PieChart2") != null) {
                var myChart = echarts.init(document.getElementById("PieChart2"), 'default');
                myChart.clear();
            }

            if (document.getElementById("PieChart3") != null) {
                var myChart = echarts.init(document.getElementById("PieChart3"), 'default');
                myChart.clear();
            }

            if (document.getElementById("PieChart4") != null) {
                var myChart = echarts.init(document.getElementById("PieChart4"), 'default');
                myChart.clear();
            }

            if (document.getElementById("PieChart5") != null) {
                var myChart = echarts.init(document.getElementById("PieChart5"), 'default');
                myChart.clear();
            }

            if (document.getElementById("PieChart6") != null) {
                var myChart = echarts.init(document.getElementById("PieChart6"), 'default');
                myChart.clear();
            }

        },

        DrawChart: function () {
            var self = this;
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];


           

            //self.DrawECharts2("PieChart5", self.sDataHealth, "", "Data Health");
            self.DrawPieCharts("PieChart5", self.sDataHealth, self.okDataHealth, self.ngDataHealth, "Data Health", "Data Health");
            self.DrawECharts2("PieChart6", self.sOnlineRatio, "", "Online Ratio");


            self.sRUL = 0;
            self.DrawPieCharts("PieChart", self.sAnomaly, self.okAnomaly, self.ngAnomaly, "Anomaly Detection", "Anomaly");
            self.DrawPieCharts("PieChart2", self.sHealth, self.okHealth, self.ngHealth, "Health Assessment", "Health Assessment");
            self.DrawPieCharts("PieChart3", self.sPrognostic, self.okPrognostic, self.ngPrognostic, "Prognostics", "Prognostic");
            self.DrawPieCharts("PieChart4", self.sRUL, 1,0, "RUL", "RUL");
            //self.DrawECharts("PieChart", self.sAnomaly, "Anomaly Detection", "Anomaly")
            //self.DrawECharts("PieChart2", self.sHealth, "Health Assessment", "Health Assessment")
            //self.DrawECharts("PieChart3", self.sPrognostic, "Prognostics", "Prognostic")
            //self.DrawECharts("PieChart4", self.sRUL, "RUL", "RUL")
           







        },

        DrawECharts2: function (_chartid, _dValue, _name, _title) {
            var self = this;
            var _color = "", _color2 = "";
            if (_chartid == "PieChart6") {
                _color = "rgb(97,100,57)";
                _color2 = "rgb(72,72,72)";
            }
            else if (_chartid == "PieChart5") {
                _color = "rgb(85,140,55)";
                _color2 = "rgb(54,91,33)";
            }

            var myChart = echarts.init(document.getElementById(_chartid));
            myChart.showLoading();  // 开启 loading 效果

            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            if (_dValue == "--") {
                var img = new Image();
                var canvas = document.createElement('canvas');
                var ctx = canvas.getContext('2d');

                //canvas.width = myChart.getWidth() * window.devicePixelRatio;
                //canvas.height = myChart.getHeight() * window.devicePixelRatio;

                canvas.width = myChart.getWidth();
                canvas.height = myChart.getHeight() ;

                var fullImage = new Image();
                img.onload = function () {
                    ctx.drawImage(img, -1, -1, canvas.width+1, canvas.height+1);
                    //ctx.drawImage(img, 0, 0, canvas.width + 0, canvas.height + 0);
                    fullImage.src = canvas.toDataURL();
                    setTimeout(function () {
                        myChart.resize();
                    }, 100)
                }
                img.src = '../../_img/NA2.png';
                var _series = [];
                _series.push({
                    name: 'MXCI', data: [10,20,30,40,50], type: 'scatter',
                    itemStyle: { color: 'rgba(255,100,0,0)'}
                });

                var msgOption = {
                    backgroundColor: {
                        type: "pattern",
                        repeat: "repeat",
                        image: fullImage,
                    },
                    title: {
                        show: true,
                        textStyle: {
                            fontWeight: 'bolder',
                            fontFamily: 'Arial',
                            fontSize: 18,
                            fontStyle: 'italic',
                            color: 'rgb(249,246,246)',//'#fff',
                            shadowColor: 'rgb(32,31,31)',//'#fff', //默认透明
                            shadowBlur: 10
                        },
                        text: 'Not Available',
                        //effect: 'whirling',
                        //effectOption: {
                        //    backgroundColor: "rgba(50,50,50,0)",//loading的背景
                        //},
                        left: 'center',
                        top: 'top',
                        padding: [
                            15,  // up
                            10, // right
                            5,  // down
                            10, // left
                        ]
                    },
                    xAxis: [
                        {
                            name: _title,
                            nameLocation: 'middle',
                            position: 'bottom',

                            nameTextStyle: {
                                //color: '#fff',
                                //fontSize: '24'
                                fontWeight: 'bolder',
                                fontFamily: 'Arial',
                                fontSize: 18,
                                fontStyle: 'italic',
                                color: 'rgb(249,246,246)',//'#fff',
                                shadowColor: 'rgb(32,31,31)',//'#fff', //默认透明
                                shadowBlur: 10,
                                padding: [
                                    10,  // up
                                    10, // right
                                    5,  // down
                                    10, // left
                                ],
                            },
                            axisTick: {
                                show: false,
                                alignWithLabel: false
                            },
                            // 控制网格线是否显示
                            splitLine: {
                                show: false,
                            },
                            //  改变x轴颜色
                            axisLine: {
                                show: false,
                            },

                            axisLabel: {
                                show: false,
                            },
                        }
                    ],

                    yAxis: [
                        {
                            show: true,
                         
                            // 控制网格线是否显示
                            axisLine: { show: false },
                            // 去除y轴上的刻度线
                            axisTick: { show: false },
                            splitLine: { show: false },



                            //  改变y轴字体颜色和大小
                            axisLabel: {
                                show: false,  
                                lineStyle: {
                                    color: '',
                                    width: 2,//这里是为了突出显示加上的，可以去掉
                                }
                            },

                        }
                    ],
                    series: _series

                };
                myChart.hideLoading();  // 隐藏 loading 效果
                myChart.setOption(msgOption);
                window.addEventListener("resize", function () {
                    myChart.resize();
                });

            } else {
                var option = {
                    title: {
                        text: _title,
                        subtext: '',
                        bottom: 'auto',
                        padding: 20,
                        x: 'center',
                        y: 'bottom',
                        textAlign: 'left',
                        textStyle: {
                            color: 'rgb(187,187,187)', fontSize: 18,
                            fontFamily: 'Arial',
                        }
                    },
                    grid: {
                        top: '15%',
                        left: '8%',
                        right: '0',
                        bottom: '50%',
                        containLabel: true
                    },
                    //backgroundColor: '#151934',
                    series: [{
                        type: 'liquidFill',
                        radius: '60%',
                        color: _color,//['#195ba6'],
                        center: ['50%', '50%'],
                        data: [_dValue / 100],//[0.4544, 0.4544, 0.4544, 0.4544, 0.4544],

                        backgroundStyle: {
                            borderWidth: 2,
                            //borderColor: 'rgb(54,91,33)',//'#1789fb',
                            color: _color2,//'#1c233f',
                        },
                        outline: {
                            itemStyle: {
                                borderWidth: 3,
                                borderColor: 'rgb(85,140,55)',//'#1789fb',
                                borderType: 'dashed',
                            }
                        },
                        label: {
                            normal: { //此处没有生效，本地生效
                                textStyle: {
                                    fontSize: 32,
                                    color: '#e6e6e6',
                                },
                            },
                        },
                    },

                    ]
                };

                myChart.hideLoading();  // 隐藏 loading 效果
                myChart.setOption(option);

                window.addEventListener("resize", function () {
                    myChart.resize();
                });
            }


        },

       
        DrawPieCharts: function (_chartid, _dValue, _ok, _ng, _name, _title) {
            
            var self = this;
            var myChart = echarts.init(document.getElementById(_chartid));
            myChart.showLoading();  // 开启 loading 效果
            if (_dValue == "--") {
                var img = new Image();
                var canvas = document.createElement('canvas');
                var ctx = canvas.getContext('2d');

                //canvas.width = myChart.getWidth() * window.devicePixelRatio;
                //canvas.height = myChart.getHeight() * window.devicePixelRatio;

                canvas.width = myChart.getWidth() ;
                canvas.height = myChart.getHeight() ;

                var fullImage = new Image();
                img.onload = function () {
                    ctx.drawImage(img, -1, -1, canvas.width + 1, canvas.height + 1);
                    //ctx.drawImage(img, 0, 0, canvas.width + 0, canvas.height + 0);
                    fullImage.src = canvas.toDataURL();
                    setTimeout(function () {
                        myChart.resize();
                    }, 100)
                }
                img.src = '../../_img/NA2.png';
                var _series = [];
                _series.push({
                    name: 'MXCI', data: [10, 20, 30, 40, 50], type: 'scatter',
                    itemStyle: { color: 'rgba(255,100,0,0)' }
                });

                var msgOption = {
                    backgroundColor: {
                        type: "pattern",
                        repeat: "repeat",
                        image: fullImage,
                    },
                    title: {
                        show: true,
                        textStyle: {
                            fontWeight: 'bolder',
                            fontFamily: 'Arial',
                            fontSize: 18,
                            fontStyle: 'italic',
                            color: 'rgb(249,246,246)',//'#fff',
                            shadowColor: 'rgb(32,31,31)',//'#fff', //默认透明
                            shadowBlur: 10
                        },
                        text: 'Not Available',
                        //effect: 'whirling',
                        //effectOption: {
                        //    backgroundColor: "rgba(50,50,50,0)",//loading的背景
                        //},
                        left: 'center',
                        top: 'top',
                        padding: [
                            15,  // up
                            10, // right
                            5,  // down
                            10, // left
                        ]
                    },
                    xAxis: [
                        {
                            name: _title,
                            nameLocation: 'middle',
                            position: 'bottom',

                            nameTextStyle: {
                                //color: '#fff',
                                //fontSize: '24'
                                fontWeight: 'bolder',
                                fontFamily: 'Arial',
                                fontSize: 18,
                                fontStyle: 'italic',
                                color: 'rgb(249,246,246)',//'#fff',
                                shadowColor: 'rgb(32,31,31)',//'#fff', //默认透明
                                shadowBlur: 10,
                                padding: [
                                    10,  // up
                                    10, // right
                                    5,  // down
                                    10, // left
                                ],
                            },
                            axisTick: {
                                show: false,
                                alignWithLabel: false
                            },
                            // 控制网格线是否显示
                            splitLine: {
                                show: false,
                            },
                            //  改变x轴颜色
                            axisLine: {
                                show: false,
                            },

                            axisLabel: {
                                show: false,
                            },
                        }
                    ],

                    yAxis: [
                        {
                            show: true,

                            // 控制网格线是否显示
                            axisLine: { show: false },
                            // 去除y轴上的刻度线
                            axisTick: { show: false },
                            splitLine: { show: false },



                            //  改变y轴字体颜色和大小
                            axisLabel: {
                                show: false,
                                lineStyle: {
                                    color: '',
                                    width: 2,//这里是为了突出显示加上的，可以去掉
                                }
                            },

                        }
                    ],
                    series: _series

                };
                myChart.hideLoading();  // 隐藏 loading 效果
                myChart.setOption(msgOption);
                window.addEventListener("resize", function () {
                    myChart.resize();
                });

            } else {

                var _data = [], _legend = [], _graphic = [];

                var isOK = false;

                if (parseInt(_ng) != 0) {
                    _legend.push("NG");
                    _data.push(
                        {
                            value: parseInt(_ng),
                            name: "NG",

                            label: {
                                show: true,
                                position: 'inside'
                            },
                            itemStyle: {
                                color: 'rgb(140, 26, 26)',//'#ED1B1B'
                            }
                        }
                    );

                    _graphic.push({
                        elements: [{
                            type: "image",
                            z: 3,
                            style: {
                                image: '../../_img/NG.png',
                                width: 50,
                                height: 50,

                            },
                            left: 'center',
                            top: "31%",
                            position: [100, 100]
                        },
                        {       //图形中间文字
                            type: "text",
                            left: "center",
                            top: "55%",
                            style: {
                                text: parseInt(_ng) + "/" + (parseInt(_ng) + parseInt(_ok)),
                                textAlign: "center",
                                fill: '#fff',
                                fontSize: 30,                            
                                fontFamily: 'Arial',
                                fontWeight: 'bolder'
                            }
                        }
                        ]
                    });
                }

                if (parseInt(_ok) != 0) {
                    isOK = true;
                    _legend.push("OK");
                    _data.push(
                        {
                            value: parseInt(_ok),
                            name: "OK",
                            label: {
                                show: true,
                                position: 'inside'
                            },
                            itemStyle: {
                                color: '#558B37'
                            }
                        }
                    );
                }

                if (parseInt(_ng) == 0 && parseInt(_ok) != 0) {
                    var _text = parseInt(_ng) + "/" + (parseInt(_ng) + parseInt(_ok));
                    if (_chartid == "PieChart4") {
                        _text = "0/0";
                    }
                    _graphic.push({
                        elements: [{
                            type: "image",
                            z: 3,
                            style: {
                                image: '../../_img/OK.png',
                                width: 50,
                                height: 50,

                            },
                            left: 'center',
                            top: "31%",
                            position: [100, 100]
                        },
                            {       //图形中间文字

                                title: _title,
                                type: "text",
                                left: "center",
                                top: "55%",
                                style: {
                                    text: _text,
                                    textAlign: "center",
                                    fill: '#fff',
                                    fontSize: 30,
                                    fontFamily: 'Arial',
                                    fontWeight: 'bolder'
                                }, onclick: function (params) {
                                    var i = params;
                                    //alert(params);
                                }
                        }
                        ]
                    });
                }//if (parseInt(_ng) == 0 && parseInt(_ok) != 0) {
                var _formatter = '{b}' + ":" + '{c}';
                if (_chartid == "PieChart4") {
                    _formatter = '{b}' + ": " + '0';
                }
                var option = {
                    title: {
                        show: true,
                        textStyle: {
                            fontWeight: 'bolder',
                            fontFamily: 'Arial',
                            fontSize: 18,
                            fontStyle: 'italic',
                            color: 'rgb(249,246,246)',//'#fff',
                            shadowColor: 'rgb(32,31,31)',//'#fff', //默认透明
                            shadowBlur: 10
                        },
                        text: _title,
                        left: 'center',
                        top: 'bottom',
                        padding: [
                            15,  // up
                            10, // right
                            10,  // down
                            10, // left
                        ]
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: '{a} <br/>{b}: {c}'
                        //formatter: '{a} <br/>{b}: {c} ({d}%)'
                    },

                    graphic: _graphic,
                    legend: [{
                        show: false,
                        orient: 'vertical',
                        top: 'left',
                        left: "left",
                        icon: 'circle',
                        itemGap: 5,
                        right: 60,
                        textStyle: {
                            color: '#fff',
                            fontWeight: 'normal',
                            fontFamily: 'Aril',
                            rich: {
                                a: {
                                    width: 100,
                                },
                                b: {
                                    width: 20,
                                    align: 'right'
                                },
                            },
                        },
                        data: ['OK', 'NG']
                    }],
                    series: [
                        {
                            name: _title,
                            type: 'pie',
                            radius: ['50%', '70%'],
                            emphasis: {
                                itemStyle: {
                                    shadowBlur: 10,
                                    shadowOffsetX: 0,
                                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                                }
                            },
                            //标签
                            label: {
                                normal: {
                                    show: true,
                                    position: 'inside', //'\n'
                                    formatter: _formatter,//模板变量有 {a}、{b}、{c}、{d}，分别表示系列名，数据名，数据值，百分比。{d}数据会根据value值计算百分比

                                    textStyle: {
                                        align: 'center',
                                        baseline: 'middle',
                                        fontFamily: '微软雅黑',
                                        fontSize: 12,
                                        fontWeight: 'bolder'
                                    }
                                },
                            },
                            data: _data
                        }

                    ]
                };



                myChart.hideLoading();  // 隐藏 loading 效果
                myChart.setOption(option);

                ////只有NG時，不要去設定默認選中NG部份
                if (isOK == true) {
                    ////設置默認選中高亮                   
                    function emphasis() {
                        var dataLen = option.series[0].data.length;
                        for (var i = 0; i < option.series[0].data.length; i++) {
                            //高亮當前圖形
                            if (option.series[0].data[i].name == "NG") {
                                myChart.dispatchAction({
                                    type: 'highlight',
                                    seriesIndex: 0,
                                    dataIndex: i,
                                });
                            }
                        }
                    }
                    function unemphasis() {
                        var dataLen = option.series[0].data.length;
                        // 取消之前高亮的圖形
                        myChart.dispatchAction({
                            type: 'downplay',
                            seriesIndex: 0,
                            dataIndex: 0
                        });
                    }

                    myChart.setOption(option);

                    window.addEventListener("resize", function () {
                        myChart.resize();
                    });

                    emphasis();
                    myChart.on('mouseover', function (a) {
                        if (a.dataIndex != 0) {
                            unemphasis();
                        }
                    })
                    myChart.on('mouseout', function () {
                        emphasis();
                    })

                }

                myChart.getZr().on("click", function (e) {

                    if (_dValue == "--" || (_chartid == "PieChart4" || _chartid == "PieChart5")) {

                    } else {
                        OnlineLayoutApp.fab = self.Fab;
                        OnlineLayoutApp.stage = self.Stage;
                        OnlineLayoutApp.func = self.Func;
                        if (_chartid == "PieChart")
                            OnlineLayoutApp.modelType = "anomaly_detection";
                        else if (_chartid == "PieChart2") {
                            OnlineLayoutApp.modelType = "health_assessment";
                        } else if (_chartid == "PieChart3") {
                            OnlineLayoutApp.modelType = "prognostic";
                        }
                        window.open("/Online/ToolList", "_blank");
                    }
                });

        

            }

        },

        DrawECharts: function (_chartid, _dValue, _name, _title) {
          
            var self = this;

            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            //Health Assessment
            var myChart = echarts.init(document.getElementById(_chartid));
            myChart.showLoading();  // 开启 loading 效果

            
       
            if (_dValue == "--") {
                var img = new Image();
                var canvas = document.createElement('canvas');
                var ctx = canvas.getContext('2d');

                //canvas.width = myChart.getWidth() * window.devicePixelRatio;
                //canvas.height = myChart.getHeight() * window.devicePixelRatio;

                canvas.width = myChart.getWidth() ;
                canvas.height = myChart.getHeight() ;
                
                var fullImage = new Image();
                img.onload = function () {
                    //ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                    ctx.drawImage(img, 0, 0, canvas.width + 2, canvas.height + 2);
                    fullImage.src = canvas.toDataURL();
                    setTimeout(function () {
                        myChart.resize();
                    }, 100)
                }
                img.src = '../../_img/NA1.png';
                var _series = [];
                _series.push({
                    name: 'MXCI', data: [10, 20, 30, 40, 50], type: 'scatter',
                    itemStyle: { color: 'rgba(255,100,0,0)' }
                });

                var msgOption = {
                    backgroundColor: {
                        type: "pattern",
                        repeat: "repeat",
                        image: fullImage,
                    },
                    title: {
                        show: true,
                        textStyle: {
                            fontWeight: 'bolder',
                            fontFamily: 'Arial',
                            fontSize: 18,
                            fontStyle: 'italic',
                            color: 'rgb(249,246,246)',//'#fff',
                            shadowColor: 'rgb(32,31,31)',//'#fff', //默认透明
                            shadowBlur: 10
                        },
                        text: 'Not Available',
                        //effect: 'whirling',
                        //effectOption: {
                        //    backgroundColor: "rgba(50,50,50,0)",//loading的背景
                        //},
                        left: 'center',
                        top: 'top',
                        padding: [
                            20,  // up
                            10, // right
                            5,  // down
                            10, // left
                        ]
                    },
                    xAxis: [
                        {
                            name: _title,
                            nameLocation: 'middle',
                            position: 'bottom',
                            nameTextStyle: {
                                //color: '#fff',
                                //fontSize: '24'
                                fontWeight: 'bolder',
                                fontFamily: 'Arial',
                                fontSize: 18,
                                fontStyle: 'italic',
                                color: 'rgb(249,246,246)',//'#fff',
                                shadowColor: 'rgb(32,31,31)',//'#fff', //默认透明
                                shadowBlur: 10
                            },
                            axisTick: {
                                show: false,
                                alignWithLabel: false
                            },
                            // 控制网格线是否显示
                            splitLine: {
                                show: false,
                            },
                            //  改变x轴颜色
                            axisLine: {
                                show: false,
                            },

                            axisLabel: {
                                show: false,

                            },

                        }
                    ],

                    yAxis: [
                        {
                            show: true,

                            // 控制网格线是否显示
                            axisLine: { show: false },
                            // 去除y轴上的刻度线
                            axisTick: { show: false },
                            splitLine: { show: false },



                            //  改变y轴字体颜色和大小
                            axisLabel: {
                                show: false,
                                lineStyle: {
                                    color: '',
                                    width: 2,//这里是为了突出显示加上的，可以去掉
                                }
                            },

                        }
                    ],
                    series: _series

                };
                myChart.hideLoading();  // 隐藏 loading 效果
                myChart.setOption(msgOption);
                
            } else {
                
                var option = {
                    //title: {
                    //    text: _dValue + '%',
                    //    subtext: '',
                    //    x: 'center',
                    //    y: 'top',
                    //    textAlign: 'left',
                    //    textStyle: { color: 'rgb(187,187,187)', fontSize: 36}
                    //},
                    grid: {
                        top:'15%',
                        left: '8%',
                        right: '0',
                        bottom: '1%',
                        containLabel: true
                    },

                    tooltip: {
                        formatter: '{a} <br/>{b} : {c}%'
                    },
                    //toolbox: {
                    //    feature: {
                    //        restore: {},
                    //        saveAsImage: {}
                    //    }
                    //},
                    series: [
                        {
                            name: _name,
                            type: 'gauge',
                            center: ["50%", "63%"], // 默认全局居中
                            radius: "65%",
                            detail: { formatter: '{value}%' },
                            data: [{
                                value: _dValue, label: { show: false }, labelLine: { show: false }
                                , name:_title,
                              
                            },
                                


                            ],//name: 'Anomaly Detection'
                            axisLine: { 
                                // 座标轴线
                                show: true,
                                lineStyle: {       // 属性lineStyle控制线条样式
                                    //color: [[0.2, '#ff4500'], [0.80, '#1e90ff'], [4, 'lime']],
                                    color: [[0.2, 'rgb(140, 26, 26)'], [0.60, 'rgb(134,139,55)'], [4, 'rgb(85,139,55)']],
                                   // width: 3,
                                    shadowColor: 'rgb(32,31,31)',//'#fff', //默认透明
                                    shadowBlur: 10
                                }
                            },
                            axisLabel: {
                                show: false,
                            },
                            axisTick: {
                                show: false,
                            },
                            splitLine: {
                                show: true,

                                
                                lineStyle: {
                                    color: 'rgb(32,31,31)',
                                    width: 3,
                                },

                            },
                            detail: {
                                show: true,
                                offsetCenter: [0, -120],       // x, y，單位px
                                formatter: '{value}%',
                                textStyle: {
                                    color: 'rgb(187,187,187)',
                                    fontSize: 36,
                                    fontFamily: 'Arial',
                                }
                            },
                            min: 0,
                            max: 100,
                            startAngle: 180,
                            endAngle: 0,
                            clockwish: true,
                            title: {
                                show: true,
                                offsetCenter: [0, '60%'],       // x, y，單位px
                                textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
                                    fontWeight: 'bolder',
                                    fontFamily: 'Arial',
                                    fontSize: 18,
                                    fontStyle: 'italic',
                                    color: 'rgb(249,246,246)',//'#fff',
                                    shadowColor: 'rgb(32,31,31)',//'#fff', //默认透明
                                    shadowBlur: 10
                                }
                            },

                        }
                    ]
                };

                myChart.hideLoading();  // 隐藏 loading 效果
                myChart.setOption(option);
                
                myChart.getZr().on("click", function (e) {

                    if (_dValue == "--") {

                    } else {
                        OnlineLayoutApp.fab = self.Fab;
                        OnlineLayoutApp.stage = self.Stage;
                        OnlineLayoutApp.func = self.Func;
                        if (_chartid == "PieChart")
                            OnlineLayoutApp.modelType = "anomaly_detection";
                        else if (_chartid == "PieChart2") {
                            OnlineLayoutApp.modelType = "health_assessment";
                        } else if (_chartid == "PieChart3") {
                            OnlineLayoutApp.modelType = "prognostic";
                        }
                        window.open("/Online/ToolList", "_blank");
                    }
                });
            }



        
        },

        AnomalyChart: function () {
            var self = this;
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            //Health Assessment
            var myChart = echarts.init(document.getElementById('PieChart'));
            myChart.showLoading();  // 开启 loading 效果

            var option = {
                tooltip: {
                    formatter: '{a} <br/>{b} : {c}%'
                },
                //toolbox: {
                //    feature: {
                //        restore: {},
                //        saveAsImage: {}
                //    }
                //},
                series: [
                    {
                        name: 'Anomaly Detection',
                        type: 'gauge',
                        center: ["50%", "56%"], // 默认全局居中
                        radius: "100%",
                        detail: { formatter: '{value}%' },
                        data: [{ value: self.dAnomaly, }],//name: 'Anomaly Detection'
                        axisLine: {            // 座标轴线
                            lineStyle: {       // 属性lineStyle控制线条样式
                                //color: [[0.2, '#ff4500'], [0.80, '#1e90ff'], [4, 'lime']],
                                color: [[0.2, '#F85256'], [0.60, '#FFBF00'], [4, '#2E9233']],
                                //width: 3,
                                shadowColor: '#fff', //默认透明
                                shadowBlur: 10
                            }
                        },
                        min: 0,
                        max: 100,
                        startAngle: 180,
                        endAngle: 0,
                        clockwish: true,
                        title: {
                            textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
                                fontWeight: 'bolder',
                                fontSize: 18,
                                fontStyle: 'italic',
                                color: '#fff',
                                shadowColor: '#fff', //默认透明
                                shadowBlur: 10
                            }
                        },

                    }
                ]
            };



            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option);

            myChart.getZr().on("click", function (e) {
                alert("link to toollist");
                //if (e.target) {

                //    //skip("ARWv_qLC5sdEvqxx.HI4j5I");
                //}
            });
        },

        HealthChart: function () {
            var self = this;
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            //Health Assessment
            var myChart = echarts.init(document.getElementById('PieChart2'));            
            myChart.showLoading();  // 开启 loading 效果

            var option = {
                tooltip: {
                    formatter: '{a} <br/>{b} : {c}%'
                },
                //toolbox: {
                //    feature: {
                //        restore: {},
                //        saveAsImage: {}
                //    }
                //},
                series: [
                    {
                        name: 'Health Assessment',
                        type: 'gauge',
                        center: ["50%", "56%"], // 默认全局居中
                        radius: "100%",
                        detail: { formatter: '{value}%' },
                        data: [{ value: self.dHealth, }],//name: 'Health Assessment'
                        axisLine: {            // 座标轴线
                            lineStyle: {       // 属性lineStyle控制线条样式
                                //color: [[0.2, '#ff4500'], [0.80, '#1e90ff'], [4, 'lime']],
                                color: [[0.2, '#F85256'], [0.60, '#FFBF00'], [4, '#2E9233']],
                                //width: 3,
                                shadowColor: '#fff', //默认透明
                                shadowBlur: 10
                            }
                        },
                        min: 0,
                        max: 100,
                        startAngle: 180,
                        endAngle: 0,
                        clockwish: true,
                        title: {
                            textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
                                fontWeight: 'bolder',
                                fontSize: 18,
                                fontStyle: 'italic',
                                color: '#fff',
                                shadowColor: '#fff', //默认透明
                                shadowBlur: 10
                            }
                        },

                    }
                ]
            };



            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option);

            myChart.getZr().on("click", function (e) {
                alert("link to toollist");
                //if (e.target) {

                //    //skip("ARWv_qLC5sdEvqxx.HI4j5I");
                //}
            });
        },

        PrognosticChart: function () {
            var self = this;
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            //Prognostic
            var myChart = echarts.init(document.getElementById('PieChart3'));
            myChart.showLoading();  // 开启 loading 效果

            var option = {
                //backgroundColor: '#f',
                tooltip: {
                    formatter: "{a} <br/>{b} : {c}%"
                },
                //toolbox: {
                //    feature: {
                //        restore: {},
                //        saveAsImage: {}
                //    }
                //},
                series: [
                    {
                        name: 'Prognostic',
                        center: ["50%", "56%"], // 默认全局居中
                        radius: "100%",
                        type: 'gauge',
                        startAngle: 180,
                        endAngle: 0,
                        min: 0,
                        max: 100,
                        clockwish: true,
                        detail: { formatter: '{value}%' },
                        axisLine: {            // 座标轴线
                            lineStyle: {       // 属性lineStyle控制线条样式
                                //color: [[0.2, '#ff4500'], [0.80, '#1e90ff'], [4, 'lime']],
                                color: [[0.2, '#F85256'], [0.60, '#FFBF00'], [4, '#2E9233']],
                                width: 3,
                                shadowColor: '#fff', //默认透明
                                shadowBlur: 10
                            }
                        },
                        axisLabel: {            // 座标轴小标记
                            distance: 8,
                            fontSize: 12,
                            formatter: function (v) {
                                return v.toFixed(0);
                            },
                        },
                        axisTick: {            // 座标轴小标记
                            length: 15,        // 属性length控制线长
                            lineStyle: {       // 属性lineStyle控制线条样式
                                color: 'auto',
                                shadowColor: '#fff', //默认透明
                                shadowBlur: 10
                            }
                        },
                        splitLine: {           // 分隔线
                            length: 25,         // 属性length控制线长
                            lineStyle: {       // 属性lineStyle（详见lineStyle）控制线条样式
                                width: 3,
                                color: '#fff',
                                shadowColor: '#fff', //默认透明
                                shadowBlur: 10
                            }
                        },
                        pointer: {           // 分隔线
                            shadowColor: '#fff', //默认透明
                            shadowBlur: 5
                        },
                        title: {
                            textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
                                fontWeight: 'bolder',
                                fontSize: 18,
                                fontStyle: 'italic',
                                color: '#fff',
                                shadowColor: '#fff', //默认透明
                                shadowBlur: 10
                            }
                        },
                        data: [{ value: parseFloat(self.sPrognostic), }]//name: 'Prognostic'
                    }
                ]
            };
            
            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option);
        },

        linkPage: function (model_type, dValue) {
            var self = this;
           
            if (dValue == "--") {
                return;
            } else {
                OnlineLayoutApp.fab = self.Fab;
                OnlineLayoutApp.stage = self.Stage;
                OnlineLayoutApp.func = self.Func;
                OnlineLayoutApp.modelType = model_type;
                window.open("/Online/ToolList", "_blank");
            }
        },

        changeMode: function () {
            OnlineLayoutApp.onlineHomeViewMode = 'list';
            window.location = "/online/onlinemodellist";
        }

    }
})