﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {
        fabs: [],
        fab: '',
        stages: [],
        stage: '',
        funcs: [],
        func: '',
        modelTypes: store.getters.getmodelTypes,
        modelType: '',
        chambers: [],
        chamber: '',
        startTime: moment(new Date()).add(-14, 'days').format('YYYY-MM-DD'),
        endTime: moment(new Date()).format('YYYY-MM-DD'),
        pickerOptions: {//控制elementUI不能選今天以後的日期
            disabledDate(time) {
                return time.getTime() > Date.now();
            },

        },
        Pagination: {
            current_page: 1,
            page_size: 5,
            total: 0
        },
        healthChart: {
            check_date: [],
            health_ok: [],
            health_ng: [],
            health_threshhold: []
        },
        pieChartData: [],
        filterPieChartData: {
            legends: [],
            chart_scale:[]
        },
        allToolTist: [],
        filterToolList: [],
        filterToolListByPage: [],
        alarmLevel: 'NG',
        anomalyThreshold:1,
        healthThreshold: 70,
        //healthThreshold: 70,
        projectId: '',
        modelId: '',
        projectList: [],
        projectName: '',
        pieChartInfo: {
            pieChartOption: {},
            pieChartItmeStyle: {
                normal: {
                    borderWidth: 4,
                    borderColor: '#ffffff',
                }
                , emphasis: {
                    borderWidth: 0,
                    shadowBlur: 10,
                    shadowOffsetX: 0,
                    shadowColor: 'rgba(0,0,0,0.5',
                }
            }
        },

       
    },
    watch: {
        modelType: function (value) {
            OnlineLayoutApp.modelType = value;
        }
    },
    mounted: function () {
        var self = this;
        self.init();
        //self.drawChart();
    },
    methods: {
        init: function () {

            store.commit('setShowLoading', true);

            var self = this;
            self.projectId = getUrlParameterByName('projectid', window.location.href.toLowerCase());
            if (self.projectId)
                window.localStorage.setItem('projectid', self.projectId);

            self.modelId = getUrlParameterByName('modelid', window.location.href.toLowerCase());
            if (self.modelId)
                window.localStorage.setItem('modelid', self.modelId);

            if (OnlineLayoutApp.onlineHomeViewMode == 'list') {
                self.projectId = window.localStorage.getItem('projectid');
                self.modelId = window.localStorage.getItem('modelid');
            }  
            
            
            self.getFabsPromise().then(function () {

                //預設fab
                if (OnlineLayoutApp.fab || OnlineLayoutApp.fab=="")
                    self.fab = OnlineLayoutApp.fab;
                else {
                    if (self.fabs) {
                        self.fab = self.fabs[0].fab;
                    }
                }
                if (self.fab) self.getStages();

                //預設stage
                if (OnlineLayoutApp.stage || OnlineLayoutApp.stage=="")
                    self.stage = OnlineLayoutApp.stage;
                else {
                    if (self.stages) {
                        self.stage = self.stages[0].stage_name;
                    }
                }
                if (self.stage) self.getFuncs();

                //預設Function
                if (OnlineLayoutApp.func || OnlineLayoutApp.func == "")
                    self.func = OnlineLayoutApp.func;
                else {
                    if (self.funcs) {
                        self.func = self.funcs[0];
                    }
                }

                //if (self.projectId != null && self.modelId != null && self.projectId != "" && self.modelId != "") {
                if (self.projectId && self.modelId ) {
                    
                    self.fab = "";
                    self.func = "";
                    self.stage = "";                    

                    self.getProjectPromise().then(function () {

                        store.commit('setShowLoading', false);

                    });

                }

                self.getHealthModel().then(function () {

                    //預設ModelType
                    if (OnlineLayoutApp.modelType) {

                        //如果原本設定的ModelType設定在
                        //if (self.pieChartData.indexOf(OnlineLayoutApp.modelType) == -1) {
                        //    OnlineLayoutApp.modelType = self.pieChartData[0].model_type;
                        //}
                        self.modelType = OnlineLayoutApp.modelType;

                    }                        
                    else {
                        if (self.pieChartData) {
                            if (self.pieChartData[0]) {
                                self.modelType = self.pieChartData[0].model_type;
                            }
                            else {
                                store.commit('setShowLoading', false);
                                alertify.alert("No data");
                                return;
                            }

                           
                        }
                    }
                    
                                       
                    if (self.modelType == 'health_assessment') {
                        Vue.nextTick()
                            .then(function () {
                                self.drawHealthChart();
                            });
                    }
                  
                    self.drawPieChart();

                    self.filterToolChamberList();

                    store.commit('setShowLoading', false);
                   
                });

            });
        },

        queryData: function () {
            store.commit('setShowLoading', true);

            var self = this;
            self.getHealthModel().then(function () {

                //預設ModelType
                if (OnlineLayoutApp.modelType)
                    self.modelType = OnlineLayoutApp.modelType;
                else {
                    if (self.pieChartData) {
                        self.modelType = self.pieChartData[0].model_type;
                    }
                }
               

                if (self.modelType == 'health_assessment') {
                    Vue.nextTick()
                        .then(function () {
                            self.drawHealthChart();
                        });
                }

               
               
                self.drawPieChart();

                self.filterToolChamberList();

                store.commit('setShowLoading', false);
               
            });

        },


        getHealthModel: function () {
            var self = this;

            return new Promise(function (resolve, reject) {
                var apiUrl = "/model_health";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    code: 200,
                    data: {
                        health_chart: {
                            check_date: ['2020-03-23', '2020-03-24', '2020-03-25', '2020-03-26', '2020-03-27', '2020-03-28', '2020-03-29', '2020-03-30', '2020-03-31', '2020-04-01', '2020-04-02', '2020-04-03', '2020-04-05', '2020-04-06', '2020-04-07'],
                            health_ok: [15, 23, 51, 32, 39, 50, 41, 25, 30, 47, 70, 77, 91, 35, 10],
                            health_ng: [118, 130, 125, 188, 181, 173, 181, 198, 189, 161, 74, 114, 124, 181, 68],
                            health_threshhold: [70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70,70]
                        },
                        model_pie: [
                            {
                                model_type: "anomaly_detection",
                                chart_scale: [
                                    {
                                        alarm_level: "OK",
                                        count: 60
                                    },
                                    {
                                        alarm_level: "NG",
                                        count: 40
                                    }
                                ]
                            },
                            {
                                model_type: "health_assessment",
                                chart_scale: [
                                    {
                                        alarm_level: "OK",
                                        count: 80
                                    },
                                    {
                                        alarm_level: "NG",
                                        count: 20
                                    }
                                ]
                            },
                            {
                                model_type: "prognostic",
                                chart_scale: [
                                    {
                                        alarm_level: "OK",
                                        count: 30
                                    },
                                    {
                                        alarm_level: "NG",
                                        count: 70
                                    }
                                ]
                            }
                        ],
                        tool_list: [{
                            tool_id: "AAIEX100",
                            chamber: "SB_WIND",
                            anomaly_index: 60,
                            health_index: 55,
                            fault_part: ""
                            },
                            {
                                tool_id: "AAIEX100",
                                chamber: "axi_x2",
                                anomaly_index: 80,
                                health_index: 65,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX200",
                                chamber: "axi_x1",
                                anomaly_index: 60,
                                health_index: 55,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX200",
                                chamber: "axi_x2",
                                anomaly_index: 80,
                                health_index: 65,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX300",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 75,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX300",
                                chamber: "axi_x2",
                                anomaly_index: 75,
                                health_index: 50,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX400",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX400",
                                chamber: "axi_x2",
                                anomaly_index: 90,
                                health_index: 30,
                                fault_part: "Motor"
                            },
                            {
                                tool_id: "ABIEX500",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX500",
                                chamber: "axi_x2",
                                anomaly_index: 70,
                                health_index: 80,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX600",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX600",
                                chamber: "axi_x2",                           
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX600",
                                chamber: "axi_x3",
                                health_index: 60,
                                fault_part: "Motor"
                            },
                            {
                                tool_id: "ABIEX600",
                                chamber: "axi_x4",
                                health_index: 60,
                                fault_part: "Motor"
                            },
                            {
                                tool_id: "ABIEX700",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 90,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX700",
                                chamber: "axi_x2",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX800",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX900",
                                chamber: "axi_x2",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX800",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX900",
                                chamber: "axi_x2",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX1000",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 70,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX1100",
                                chamber: "axi_x2",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX1200",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX1300",
                                chamber: "axi_x2",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX1400",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX1500",
                                chamber: "axi_x2",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX1600",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX1700",
                                chamber: "axi_x2",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX1800",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX1900",
                                chamber: "axi_x2",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX2000",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 60,
                                fault_part: ""
                            },
                            {
                                tool_id: "ABIEX2100",
                                chamber: "axi_x2",
                                anomaly_index: 70,
                                health_index: 60,
                               
                            },
                            {
                                tool_id: "ABIEX2200",
                                chamber: "axi_x1",
                                anomaly_index: 70,
                                health_index: 60,
                               
                            },
                            {
                                tool_id: "ABIEX2300",
                                chamber: "axi_x2",
                                anomaly_index: 70,
                                health_index: 60
                              
                            }
                        ]
                    },
                    description: "Get Model Tool_ID success",
                    status: "OK"
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }    
                
                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOnlineApiUrl,
                    url: apiUrl,
                    params: {
                        fab: self.fab,
                        stage: self.stage,
                        function: self.func,
                        model_type: self.modelType,
                        start_date: moment(self.startTime).local().format('YYYY-MM-DD'),
                        end_date: moment(self.endTime).local().format('YYYY-MM-DD'),
                        project_id: self.projectId,
                        model_id: self.modelId
                    }

                })
                .then(function (response) {
                    self.healthChart = response.data.data.health_chart;
                    self.pieChartData = response.data.data.model_pie;
                    self.allToolTist = response.data.data.tool_list;
                    resolve();   
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);                      

                    })

            })


        },

        getFabsPromise: function () {
            var self = this;


            return new Promise(function (resolve, reject) {


                var apiUrl = "/dropitem/online_filter";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        select_item:
                            [
                                {
                                    fab: "L5C",
                                    stage: [
                                        {
                                            stage_name: "ARRAY",
                                            function_list: ["ETCH", "INT", "PHOTO", "TF",]
                                        },
                                        {
                                            stage_name: "CELL",
                                            function_list: ["BEOL", "FAC", "ODF", "PI", "SLM"]
                                        },
                                        {
                                            stage_name: "CF",
                                            function_list: ["FAC", "ITO", "PHOTO", "TF"]
                                        }
                                    ]
                                },
                                {
                                    fab: "L6A",
                                    stage: [
                                        {
                                            stage_name: "ARRAY",
                                            function_list: ["ETCH", "FA", "FAC", "INT", "PHOTO", "TF"]
                                        },
                                        {
                                            stage_name: "CELL",
                                            function_list: ["BEOL", "CELL_N3", "CELL_TEST", "CUTTING", "FA", "FAC", "ODF", "PI"]
                                        },
                                        {
                                            stage_name: "CF",
                                            function_list: ["CF", "FA", "FAC", "ITO", "PHOTO"]
                                        }
                                    ]
                                }
                            ]
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }         

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOnlineApiUrl,
                    url: apiUrl

                })
                .then(function (response) {
                    self.fabs = response.data.data.select_item;

                    self.stage = "";
                    resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
              

        getStages: function () {

            var self = this;
            self.stage = "";
            self.stages = [];
            self.func = "";
            self.funcs = [];
            self.fabs.forEach(function (item, index) {

                if (item.fab == self.fab) {
                    self.stages = item.stage;                   
                }
            });
        },

        getFuncs: function () {

            var self = this;           
            self.func = "";
            self.funcs = [];
            self.stages.forEach(function (item, index) {

                if (item.stage_name == self.stage) {
                    self.funcs = item.function_list;
                }
            });
        },

        getProjectPromise: function () {
            var self = this;


            return new Promise(function (resolve, reject) {


                var apiUrl = "/project";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        total_count: 9527,
                        project_list: [
                            {
                                project_id: 1,
                                ai365_project_name: "test_phm",
                                model_type: "Anomaly Detection",
                                application: "Robot",
                                fab: "L5C",
                                stage: "Array",
                                func: "PHOTO",
                                tool_type: "Robot_LD",
                                offline_model_status: 100,
                                user_name: "Joyce",
                                itime: "2019-12-31 10:58:30",
                                model_id: 1
                            }
                        ]
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: self.projectId,
                    }

                })
                    .then(function (response) {
                        self.projectList = response.data.data.project_list; 
                        if (self.projectList.length > 0) {
                            self.projectName = self.projectList[0].fab + "-" + self.projectList[0].stage + "-" +
                                self.projectList[0].func + "-" + self.projectList[0].ai365_project_name + "-" +
                                self.projectList[0].model_type + "_" + self.projectList[0].project_id;

                        }
                        if (self.projectList.length == 0) {
                            alertify.error("No data");
                        }  


                         
                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },

        changeModelType: function () {
            var self = this;

            if (self.modelType == 'health_assessment') {
                Vue.nextTick()
                    .then(function () {
                        self.drawHealthChart();
                    });
            }      

            self.drawPieChart();  

            self.Pagination.current_page = 1;
            self.filterToolChamberList();
        },

        filterToolChamberList: function () {
            var self = this;

            var tmpToolList = [];

            var finalFilterToolList = [];

            switch (self.modelType) {

                case 'anomaly_detection':
                    {
                        tmpToolList = self.allToolTist.filter(function (el) {
                            return el.anomaly_index != undefined;
                        });             

                      
                        //根據HealthTreshold過濾
                        switch (self.alarmLevel) {
                            //case 'NG':
                            //    {
                            //        tmpToolList = tmpToolList.filter(function (el) {
                            //            return el.anomaly_index >= self.anomalyThreshold;
                            //        });
                            //        break;
                            //    }
                            //case 'OK':
                            //    {
                            //        tmpToolList = tmpToolList.filter(function (el) {
                            //            return el.anomaly_index < self.anomalyThreshold;
                            //        });
                            //        break;
                            //    }


                            //case 'OK':
                            //    {
                            //        tmpToolList = tmpToolList.filter(function (el) {
                            //            return el.anomaly_index >= self.anomalyThreshold;
                            //        });
                            //        break;
                            //    }
                            //case 'NG':
                            //    {
                            //        tmpToolList = tmpToolList.filter(function (el) {
                            //            return el.anomaly_index < self.anomalyThreshold;
                            //        });
                            //        break;
                            //    }


                            //20200514 Sam通知用anomaly_is_normal判斷OK.NG
                            case 'OK':
                                {
                                    tmpToolList = tmpToolList.filter(function (el) {
                                        return el.anomaly_is_normal == true;
                                    });
                                    break;
                                }
                            case 'NG':
                                {
                                    tmpToolList = tmpToolList.filter(function (el) {
                                        return el.anomaly_is_normal == false;
                                    });
                                    break;
                                }


                            default:
                        }   

                        var groupToolList = tmpToolList.groupBy('tool_id');


                        for (var key in groupToolList) {
                             //Anomaly Detection : 數值在0~1.5區間，越高越異常
                            var max = groupToolList[key].reduce(function (prev, current) {
                                return (prev.anomaly_index > current.anomaly_index) ? prev : current
                            });
                            var currentChambers = groupToolList[key].map(function (item) {
                                return item.chamber;
                            });

                            finalFilterToolList.push(
                                {
                                    tool_id: max.tool_id,
                                    chamber: max.chamber,
                                    anomaly_index: max.anomaly_index,
                                    health_index: max.health_index,
                                    fault_part: max.fault_part,
                                    chambers: currentChambers
                                }
                            );
                        }

                        break;
                    }

                case 'health_assessment':
                    {
                        tmpToolList = self.allToolTist.filter(function (el) {
                            return el.health_index != undefined;
                        }); 


                        //根據HealthTreshold過濾
                        switch (self.alarmLevel) {
                            //case 'NG':
                            //    {
                            //        tmpToolList = tmpToolList.filter(function (el) {
                            //            return el.health_index >= self.healthThreshold;
                            //        });
                            //        break;
                            //    }
                            //case 'OK':
                            //    {
                            //        tmpToolList = tmpToolList.filter(function (el) {
                            //            return el.health_index < self.healthThreshold;
                            //        });
                            //        break;
                            //    }

                            //case 'OK':
                            //    {
                            //        tmpToolList = tmpToolList.filter(function (el) {
                            //            return el.health_index >= self.healthThreshold;
                            //        });
                            //        break;
                            //    }
                            //case 'NG':
                            //    {
                            //        tmpToolList = tmpToolList.filter(function (el) {
                            //            return el.health_index < self.healthThreshold;
                            //        });
                            //        break;
                            //    }

                            //20200514 Sam通知用health_is_normal判斷OK.NG
                            case 'OK':
                                {
                                    tmpToolList = tmpToolList.filter(function (el) {
                                        return el.health_is_normal == true;
                                    });
                                    break;
                                }
                            case 'NG':
                                {
                                    tmpToolList = tmpToolList.filter(function (el) {
                                        return el.health_is_normal == false;
                                    });
                                    break;
                                }
                            default:
                                break;
                        }   

                        var groupToolList = tmpToolList.groupBy('tool_id');

                        
                        for (var key in groupToolList) {                           
                            //Health Assessment : 數值在0~1區間，越高越異常
                            var max = groupToolList[key].reduce(function (prev, current) {
                                return (prev.health_index > current.health_index) ? prev : current
                            });


                            var currentChambers = groupToolList[key].map(function (item) {
                                return item.chamber;
                            });

                            finalFilterToolList.push(
                                {
                                    tool_id: max.tool_id,
                                    chamber: max.chamber,
                                    anomaly_index: max.anomaly_index,
                                    health_index: max.health_index,
                                    fault_part: max.fault_part,
                                    chambers: currentChambers
                                }
                            );
                        }

                        break;
                    }
                case 'prognostic':
                    {
                        tmpToolList = self.allToolTist.filter(function (el) {
                            return el.fault_part != undefined;
                        }); 

                                                
                        switch (self.alarmLevel) {
                            //case 'OK':
                            //    {
                            //        tmpToolList = tmpToolList.filter(function (el) {
                            //            return el.fault_part == "";
                            //        });
                            //        break;
                            //    }
                            //case 'NG':
                            //    {
                            //        tmpToolList = tmpToolList.filter(function (el) {
                            //            return el.fault_part != "";
                            //        });
                            //        break;
                            //    }
                            //default:
                            //    break;

                            //20200514 Sam通知用health_is_normal判斷OK.NG
                            case 'OK':
                                {
                                    tmpToolList = tmpToolList.filter(function (el) {
                                        return el.prognostic_is_normal == true;
                                    });
                                    break;
                                }
                            case 'NG':
                                {
                                    tmpToolList = tmpToolList.filter(function (el) {
                                        return el.prognostic_is_normal == false;
                                    });
                                    break;
                                }
                            default:
                                break;
                        }  


                        var groupToolList = tmpToolList.groupBy('tool_id');


                        for (var key in groupToolList) {
                            //Prognostic : 非空字串，異常

                            var issueDatas= groupToolList[key].filter(function (el) {
                                return el.fault_part !="";
                            }); 


                            var currentChambers = groupToolList[key].map(function (item) {
                                return item.chamber;
                            });

                           
                            if (issueDatas && issueDatas.length > 0) {
                                finalFilterToolList.push({
                                    tool_id: issueDatas[0].tool_id,
                                    chamber: issueDatas[0].chamber,
                                    anomaly_index: issueDatas[0].anomaly_index,
                                    health_index: issueDatas[0].health_index,
                                    fault_part: issueDatas[0].fault_part,
                                    chambers: currentChambers
                                });                               
                            }
                            else {//沒異常就顯示OK的資料
                                finalFilterToolList.push({
                                    tool_id: groupToolList[key][0].tool_id,
                                    chamber: groupToolList[key][0].chamber,
                                    anomaly_index: groupToolList[key][0].anomaly_index,
                                    health_index: groupToolList[key][0].health_index,
                                    fault_part: "OK",
                                    chambers: currentChambers
                                });
                            }                           
                        }


                        break;
                    }
                default:
                    {
                        break;
                    }
            }   



            //分頁取資料
            self.filterToolList = finalFilterToolList;    

            //this.$set(self.Pagination, 'total', finalFilterToolList.length);
            self.Pagination.total = self.filterToolList.length;
            self.handleChangePage(self.Pagination.current_page);

        },
        
        filterHealth: function (alarmLevel) {
            var self = this;
            self.alarmLevel = alarmLevel;
            self.filterToolChamberList();  
        },
        

        drawHealthChart: function () {

            var self = this;
            var alarmHealthChart = echarts.init(document.getElementById('AlarmHealthChart'));
            alarmHealthChart.showLoading();  // 开启 loading 效果

            var _legend = ['OK', 'NG',"Threshhold"]
            var option = {
                baseOption: {
                    //backgroundColor: '#25404e',//背景色
                    legend: {
                        //type: 'scroll',
                        orient: 'vertical',
                        //x: 'right',
                        //y: 'top',
                        borderWidth: 2,
                        padding: 2,
                        itemGap: 5,
                        right: '1%',
                        top: '10%',


                        data: _legend,
                        selected: {


                        },
                        bottom: '50%',
                        itemHeight: 10,
                        textStyle: {
                            color: '#CDEDED',
                            fontSize: '12'
                        },

                        //selected: 1
                    }
                    , grid: {
                        x: '7%',
                        y: '7%',
                        width: '80%',
                        height: '65%',
                        show: false,
                        borderColor: 'red'
                    }
                    ,
                    xAxis: {
                        type: 'category',
                        nameLocation: 'middle',
                        nameGap: 125,
                        triggerEvent: true,
                        boundaryGap: true,
                        data: self.healthChart.check_date,
                        axisTick: {
                            show: false,
                            alignWithLabel: true
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变x轴颜色
                        axisLine: {
                            show: true,
                            onZero: false,
                            position: 'end',
                            lineStyle: {
                                color: '#008bad',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        //  改变x轴字体颜色和大小
                        axisLabel: {
                            show: true,
                            rotate: 90,
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },

                    },
                    yAxis: [
                        {
                            name: 'Mean Value',
                            fontSize: '14',
                            nameLocation: 'middle',
                            nameGap: 55,
                            //  隐藏y轴
                            axisLine: {
                                show: true,
                                lineStyle: {
                                    color: '#008bad',
                                    width: 2,//这里是为了突出显示加上的，可以去掉

                                }
                            },

                            // 去除y轴上的刻度线
                            axisTick: {
                                show: false
                            },
                            // 控制网格线是否显示
                            splitLine: {
                                show: false,
                                //  改变轴线颜色
                                lineStyle: {
                                    // 使用深浅的间隔色
                                    color: ['red']
                                }
                            },
                            //  改变y轴字体颜色和大小
                            axisLabel: {
                                textStyle: {
                                    color: '#ffffff',
                                    fontSize: '12'
                                },
                            },
                            type: 'value',
                            triggerEvent: true,
                            scale: true,
                        }
                    ],
                    dataZoom: [{
                        type: 'inside',
                        start: 0,
                        end: 100
                    }, {
                        start: 0,
                        end: 100,
                        handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                        handleSize: '80%',
                        handleStyle: {
                            color: '#fff',
                            shadowBlur: 3,
                            shadowColor: 'rgba(0, 0, 0, 0.6)',
                            shadowOffsetX: 2,
                            shadowOffsetY: 2
                        }
                    }],
                    series: [
                        {
                            name: 'Threshhold',
                            data: self.healthChart.health_threshhold,
                            type: 'line',
                            smooth: true,
                            itemStyle: { color: "#FF9326" }
                        },
                        {
                            name: 'NG',
                            type: 'line',
                            smooth: true,
                            data: self.healthChart.health_ng,
                            itemStyle: { color: "#558b37" }
                        },
                        {
                            name: 'OK',
                            type: 'line',
                            smooth: true,
                            data: self.healthChart.health_ok,
                            itemStyle: { color: "#ed1b1b" }
                        },
                    ]
                },

            };
                      

            alarmHealthChart.hideLoading();  // 隐藏 loading 效果
            alarmHealthChart.setOption(option);

        },     

        drawPieChart: function () {
            var self = this;

            var getCurrentPieChartData = self.pieChartData.filter(function (el) {
                return el.model_type.toLowerCase().indexOf(self.modelType.toLowerCase()) > -1;
            });

            if (getCurrentPieChartData && getCurrentPieChartData.length > 0) {
                self.filterPieChartData.chart_scale = getCurrentPieChartData[0].chart_scale;

                self.filterPieChartData.legends = self.filterPieChartData.chart_scale.map(function (el) {
                    return el.alarm_level;
                });
            }
            else {
                store.commit('setShowLoading', false);

                alertify.alert("No pie chart data");

                return;
            }

            var pieChart = echarts.init(document.getElementById('PieChart'));

            pieChart.showLoading();  // 开启 loading 效果


            //事件
            pieChart.on('click', function (params) {    
                //self.drawPieChart();
                self.filterHealth(params.name);   
               
            });


            var optionData = [];

            self.filterPieChartData.chart_scale.forEach(function (el) {

                if (el.count != 0) {
                    //var color = el.alarm_level != 'OK' ? '#FC97B1' : '#03C9C9';
                    var color = el.alarm_level != 'OK' ? '#ed1b1b' : '#558b37';

                    optionData.push(
                        {
                            value: el.count,
                            name: el.alarm_level,
                            label: {
                                show: true,
                                position: 'inside'
                            },
                            itemStyle: {
                                color: color
                            }
                        }
                    );
                }
                else {//20200514優化:當圓餅圖為0時，代表List應該也為0，所以當OK或NG為0時，自動切換到另一個Level
                    self.alarmLevel = el.alarm_level == 'OK' ? 'NG' : 'OK';
                }


                //if (el.alarm_level == self.alarmLevel) {
                //    optionData.push(
                //        {
                //            value: el.count,
                //            name: el.alarm_level,
                //            label: {
                //                show: true,
                //                position: 'inside'
                //            },
                //            itemStyle: {
                //                color: color,
                //                borderWidth: 4,
                //                borderColor: '#ffffff',
                //                shadowBlur: 10,
                //                shadowOffsetX: 0,
                //                shadowColor: 'rgba(0,0,0,0.5)',

                //            }
                //        }
                //    );
                //} else {
                //    optionData.push(
                //        {
                //            value: el.count,
                //            name: el.alarm_level,
                //            label: {
                //                show: true,
                //                position: 'inside'
                //            },
                //            itemStyle: {
                //                color: color
                //            }
                //        }
                //    );
                //}

           

                
            });


            self.pieChartInfo.pieChartOption = {               

                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b}: {c} ({d}%)'
                },

                legend: [{
                    orient: 'vertical',
                    top: 'left',
                    left: "left",
                    icon: 'circle',
                    itemGap: 5,
                    right: 60,
                    textStyle: {
                        color: '#fff',
                        fontWeight: 'normal',
                        fontFamily: 'Aril',
                        fontSize :14,
                        rich: {
                            a: {
                                width: 100,
                            },
                            b: {
                                width: 20,
                                align: 'right'
                            },
                        },
                    },
                    data: self.filterPieChartData.legends
                }],
                series: [
                    {
                        name: 'Tool Summary',
                        type: 'pie',
                        radius: ['50%', '70%'],
                        hoverAnimation: false,
                        //selectedMode: 'single',
                        //selectedOffset: 20,
                        //hoverOffset: 0,
                        //selectedMode: true,
                        stillShowZeroSum: false,
                        avoidLabelOverlap: false,
                        label: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            label: {
                                show: true,
                                fontSize: '30',
                                fontWeight: 'bold'
                            }
                        },
                        labelLine: {
                            show: true
                        },
                        itemStyle: {      
                            normal: {
                                borderWidth: 0,                               
                            }
                            , emphasis: {
                                borderWidth: 4,
                                borderColor: '#ffffff',
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0,0,0,0.5)',
                            }
                        },
                        data: optionData
                    }

                ]
            };
            pieChart.hideLoading();  // 隐藏 loading 效果
            pieChart.setOption(self.pieChartInfo.pieChartOption);

        },
          
        viewDetail: function (data) {
            var self = this;
            OnlineLayoutApp.toolId = data.tool_id;
            OnlineLayoutApp.modelType = self.modelType;
            OnlineLayoutApp.startTime = self.startTime;
            OnlineLayoutApp.endTime = self.endTime;
            OnlineLayoutApp.chamber = data.chamber;
            OnlineLayoutApp.chambers = data.chambers;
            if (self.projectId != null && self.modelId != null && self.projectId != "" && self.modelId != "")
                window.location = "/Online/ToolDetail?projectid=" + self.projectId + "&modelid=" + self.modelId;
            else
                window.location = "/Online/ToolDetail";


        },

        //換頁
        handleChangePage: function (val) {
            var self = this;
            self.Pagination.current_page = val;

            var startIndex = (self.Pagination.current_page - 1) * self.Pagination.page_size ;
            if (startIndex < 0) startIndex = 0;

            if (startIndex > self.Pagination.total) startIndex = 0;

            var endIndex = (self.Pagination.current_page * self.Pagination.page_size) ;
            if (endIndex >= self.filterToolList.length) endIndex = self.filterToolList.length ;
            self.filterToolListByPage = self.filterToolList.slice(startIndex, endIndex);
           
        },


        chooseDate: function () {
            var self = this;

            if (self.startTime > self.endTime) {
                alertify.error("日期選擇錯誤");

                self.endTime = self.startTime ;
                
            }

        },






        xxxgetFabs: function () {
            var self = this;


            var apiUrl = "/dropitem/online_filter";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: {
                    select_item:
                        [
                            {
                                fab: "L5C",
                                stage: [
                                    {
                                        stage_name: "ARRAY",
                                        function_list: ["ETCH", "INT", "PHOTO", "TF",]
                                    },
                                    {
                                        stage_name: "CELL",
                                        function_list: ["BEOL", "FAC", "ODF", "PI", "SLM"]
                                    },
                                    {
                                        stage_name: "CF",
                                        function_list: ["FAC", "ITO", "PHOTO", "TF"]
                                    }
                                ]
                            },
                            {
                                fab: "L6A",
                                stage: [
                                    {
                                        stage_name: "ARRAY",
                                        function_list: ["ETCH", "FA", "FAC", "INT", "PHOTO", "TF"]
                                    },
                                    {
                                        stage_name: "CELL",
                                        function_list: ["BEOL", "CELL_N3", "CELL_TEST", "CUTTING", "FA", "FAC", "ODF", "PI"]
                                    },
                                    {
                                        stage_name: "CF",
                                        function_list: ["CF", "FA", "FAC", "ITO", "PHOTO"]
                                    }
                                ]
                            }
                        ]
                }
            });

            //if (store.getters.getEnv == 'prd') {
            //    mock.restore();
            //}         

            var responseData = {};
            axios({
                method: 'get',
                baseURL: store.getters.getOnlineApiUrl,
                url: apiUrl

            })
                .then(function (response) {
                    self.fabs = response.data.data.select_item;

                    self.stage = "";


                    //store.commit('setShowLoading', false);
                })


        },



        xxxdrawChart: function () {
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            var pieChart = echarts.init(document.getElementById('PieChart'));
            var alarmHealthChart = echarts.init(document.getElementById('AlarmHealthChart'));
            //var myChart3 = echarts.init(document.getElementById('PieChart3'));
            //var myChart4 = echarts.init(document.getElementById('PieChart4'));
            //var myChart5 = echarts.init(document.getElementById('PieChart5'));
            //var myChart6 = echarts.init(document.getElementById('PieChart6'));
            pieChart.showLoading();  // 开启 loading 效果
            alarmHealthChart.showLoading();  // 开启 loading 效果
            //myChart3.showLoading();  // 开启 loading 效果
            //myChart4.showLoading();  // 开启 loading 效果
            //myChart5.showLoading();  // 开启 loading 效果
            //myChart6.showLoading();  // 开启 loading 效果




            //測試事件

            pieChart.on('click', function (params) {
                alert(params.name);
                //alert(params.componentType);
                //if (params.componentType === 'series') {
                //    alert("点击事件" + params.seriesType);

                //}
                //window.open('https://www.baidu.com/s?wd=');
            });




            var option1 = {
                //backgroundColor: '#25404e',//背景色
                //title: {
                //    text: 'No CSV Reason',
                //    subtext: '',
                //    x: 'center',
                //    y: 'top',
                //    textAlign: 'left',
                //    textStyle: {
                //        color: arColor[1],
                //        fontStyle: 'normal',
                //        fontWeight: 'lighter',
                //        fontFamily: 'san-serif',
                //        fontSize: 18
                //    }
                //},

                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b}: {c} ({d}%)'
                },

                legend: [{
                    orient: 'vertical',
                    top: 'left',
                    left: "left",
                    icon: 'circle',
                    itemGap: 5,
                    right: 60,
                    textStyle: {
                        color: '#fff',
                        fontWeight: 'normal',
                        fontFamily: 'Aril',
                        rich: {
                            a: {
                                width: 100,
                            },
                            b: {
                                width: 20,
                                align: 'right'
                            },
                        },
                    },
                    data: ['NG', 'OK']
                }],
                series: [
                    {
                        name: 'CSV File not created',
                        type: 'pie',
                        radius: ['50%', '70%'],


                        selectedMode: false,
                        stillShowZeroSum: false,
                        avoidLabelOverlap: false,
                        label: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            label: {
                                show: true,
                                fontSize: '30',
                                fontWeight: 'bold'
                            }
                        },
                        labelLine: {
                            show: true
                        },
                        itemStyle: {
                            normal: {
                                borderWidth: 4,
                                borderColor: '#ffffff',
                            }, emphasis: {
                                borderWidth: 0,
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0,0,0,0.5',
                            },
                        },
                        data: [
                            //{
                            //    value: 335, name: 'Alarm', label: {
                            //        show: true,
                            //        position: 'inside'
                            //    }, itemStyle: { color: arColor[0] }
                            //},
                            {
                                value: 310, name: 'NG', label: {
                                    show: true,
                                    position: 'inside'
                                }, itemStyle: { color: "#FC97B1" }
                            },
                            {
                                value: 234, name: 'OK', label: {
                                    show: true,
                                    position: 'inside'
                                }, itemStyle: { color: "#03C9C9" }
                            },

                        ]
                    }

                ]
            };
            pieChart.hideLoading();  // 隐藏 loading 效果
            pieChart.setOption(option1);

            var _legend = ['NG', 'OK']
            var option2 = {
                baseOption: {
                    //backgroundColor: '#25404e',//背景色
                    legend: {
                        //type: 'scroll',
                        orient: 'vertical',
                        //x: 'right',
                        //y: 'top',
                        borderWidth: 2,
                        padding: 2,
                        itemGap: 5,
                        right: '1%',
                        top: '10%',


                        data: _legend,
                        selected: {


                        },
                        bottom: '50%',
                        itemHeight: 10,
                        textStyle: {
                            color: '#CDEDED',
                            fontSize: '12'
                        },

                        //selected: 1
                    }
                    , grid: {
                        x: '7%',
                        y: '7%',
                        width: '80%',
                        height: '65%',
                        show: false,
                        borderColor: 'red'
                    }
                    ,
                    xAxis: {
                        type: 'category',
                        data: ['2020-03-23', '2020-03-24', '2020-03-25', '2020-03-26', '2020-03-27', '2020-03-28', '2020-03-29', '2020-03-30', '2020-03-31', '2020-04-01', '2020-04-02', '2020-04-03', '2020-04-05', '2020-04-06', '2020-04-07']
                        ,
                        axisTick: {
                            show: false,
                            alignWithLabel: true
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变x轴颜色
                        axisLine: {
                            show: true,
                            onZero: false,
                            position: 'end',
                            lineStyle: {
                                color: '#008bad',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        //  改变x轴字体颜色和大小
                        axisLabel: {
                            show: true,
                            rotate: 90,
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },

                    },
                    yAxis: [
                        {
                            name: 'Mean Value',
                            fontSize: '14',
                            nameLocation: 'middle',
                            nameGap: 55,
                            //  隐藏y轴
                            axisLine: {
                                show: true,
                                lineStyle: {
                                    color: '#008bad',
                                    width: 2,//这里是为了突出显示加上的，可以去掉

                                }
                            },

                            // 去除y轴上的刻度线
                            axisTick: {
                                show: false
                            },
                            // 控制网格线是否显示
                            splitLine: {
                                show: false,
                                //  改变轴线颜色
                                lineStyle: {
                                    // 使用深浅的间隔色
                                    color: ['red']
                                }
                            },
                            //  改变y轴字体颜色和大小
                            axisLabel: {
                                textStyle: {
                                    color: '#ffffff',
                                    fontSize: '12'
                                },
                            },
                            type: 'value',
                            triggerEvent: true,
                            scale: true,
                        }
                    ],
                    series: [
                        //    {
                        //    name: 'Alarm',
                        //    data: [133, 153, 176, 220, 220, 223, 222, 223, 219, 208, 144, 191, 215, 216, 78],
                        //    type: 'line',
                        //    smooth: true,
                        //    itemStyle: { color: arColor[0] }
                        //},
                        {
                            name: 'NG',
                            type: 'line',
                            smooth: true,
                            data: [118, 130, 125, 188, 181, 173, 181, 198, 189, 161, 74, 114, 124, 181, 68],
                            itemStyle: { color: "#FC97B1" }
                        },
                        {
                            name: 'OK',
                            type: 'line',
                            smooth: true,
                            data: [15, 23, 51, 32, 39, 50, 41, 25, 30, 47, 70, 77, 91, 35, 10],
                            itemStyle: { color: "#03C9C9" }
                        },
                    ]
                },

            };
            alarmHealthChart.hideLoading();  // 隐藏 loading 效果
            alarmHealthChart.setOption(option2);


        },
    }
})