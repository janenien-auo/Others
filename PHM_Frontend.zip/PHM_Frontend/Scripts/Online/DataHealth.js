﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {       
        dataHealthList: [],   
        keyWord:'',//目前此頁沒有Keyword功能
        filterDataHealthList: [],
        filterDataHealthListByPage: [],
        projectName: 'This is project name',
        modelType: '',
        projectId: '',
        modelId: '',
        Pagination: {
            current_page: 1,
            page_size: 10,
            total: 0
        },
        dataHealthStyles: [
            {
                dataHealth: 'no_data',
                css:'dataHealthRed',
            },
            {
                dataHealth: 'feature_abnormal',
                css: 'dataHealthYellow',
            },
            {
                dataHealth: 'ok',
                css: 'dataHealthGreen',
            }
        ]
    },   
    mounted: function () {
        var self = this;
        self.init();
       
    },
    methods: {
        init: function () {

            store.commit('setShowLoading', true);

            var self = this;
            self.projectId = getUrlParameterByName('projectid', window.location.href.toLowerCase());
            self.modelId = getUrlParameterByName('modelid', window.location.href.toLowerCase());
                                  
            store.commit("setCurrentProjectId", self.projectId);

            store.commit("setProjectInfo", null);
            self.projectInfo = store.getters.getCurrentProjectInfo;
            self.projectName = self.projectInfo.fab + "-" + self.projectInfo.stage + "-" + self.projectInfo.func + "-" + self.projectInfo.ai365_project_name + "-" + self.projectInfo.model_type + "-" + self.projectInfo.project_id;
            self.modelType= self.projectInfo.model_type;

            self.getDataHealthList().then(function () {
                self.filterModelList();
                store.commit('setShowLoading', false);
            });

          
        },    


        getDataHealthList: function () {
            var self = this;

            return new Promise(function (resolve, reject) {
                var apiUrl = "/model_health";
               
                              

                var data = {
                    project_id:self.projectId,
                    model_id:self.modelId

                };  


                getToolChamberDataHealth(data, store.getters.getIsApiTest)
                .then(function (response) {
                    self.dataHealthList = response.data.data;


                    resolve();
                }).catch(function (err) {
                    store.commit('setShowLoading', false);

                })
            })

        },

        //過濾Keyword資料
        filterModelList: function () {

            var self = this;

            if (!self.keyWord) {
                self.filterDataHealthList = self.dataHealthList;
                self.Pagination.total = self.filterDataHealthList.length;
                self.handleChangePage(1);
                return;
            }

            self.filterDataHealthList = [];

            var options = {
                threshold: 0.2,
                location: 0,
                distance: 100,
                // 要搜尋的欄位
                keys: self.searchKeys
            }

            var fuse = new Fuse(self.onlineModelList, options);


            var result = fuse.search(self.keyWord);

            result.forEach(function (d) {
                self.filterDataHealthList.push(d.item);
            })

            self.Pagination.total = self.filterDataHealthList.length;

            self.handleChangePage(1);


        },    

        //換頁
        handleChangePage: function (val) {
            var self = this;
            self.Pagination.current_page = val;

            var startIndex = (self.Pagination.current_page - 1) * self.Pagination.page_size;
            if (startIndex < 0) startIndex = 0;

            if (startIndex > self.Pagination.total) startIndex = 0;

            var endIndex = (self.Pagination.current_page * self.Pagination.page_size);
            if (endIndex >= self.filterDataHealthList.length) endIndex = self.filterDataHealthList.length;
            self.filterDataHealthListByPage = self.filterDataHealthList.slice(startIndex, endIndex);
        },  

        setDataHealthColor: function (dataHealth) {
            var self = this;

            var dataHealthStyle = self.dataHealthStyles.find(function (el) {
                return el.dataHealth.toLowerCase() == dataHealth.toLowerCase();
            });

            return dataHealthStyle.css;
        }

    }
})