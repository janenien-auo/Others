﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {       
        closeEstoneList: [],   
        projectName: 'This is project name',
        eventTypes: store.getters.getEventTypes,
        eventType: '',
        components: store.getters.getComponents,
        component:'',
        alarmCodes: [],
        alarmCode: '',
        solutions: store.getters.getSolutions,
        solution:'',
        actionTime: '',
        note: '',
        closeEventDetail: {}
    },   
    mounted: function () {
        var self = this;
        self.init();
       
    },
    methods: {
        init: function () {

            //store.commit('setShowLoading', true);

            var self = this;   


            store.commit('setDefaultProjectId');
            store.commit('setProjectInfo');
            self.projectInfo = store.getters.getCurrentProjectInfo;
            self.projectName = self.projectInfo.fab + "-" + self.projectInfo.stage + "-" + self.projectInfo.func + "-" + self.projectInfo.ai365_project_name + "-" + self.projectInfo.model_type + "-" + self.projectInfo.project_id;


            var closeEventDetailStr  =  window.localStorage.getItem('closeeventdetail');

            if (closeEventDetailStr) {
                self.closeEventDetail = JSON.parse(closeEventDetailStr);


                //self.projectName = self.closeEventDetail.

            }          
        },    

        clickSave: function () {
            var self = this;          


            this.$validator.validateAll().then(function (result) {
                if (result) {
                    self.closeEstone();
                }
                else {
                    alertify.error('欄位資料填寫錯誤');
                }
            })
        },


        closeEstone: function () {
            var self = this;


            var data = {
                project_id: self.projectInfo.project_id,
                model_id: self.projectInfo.model_id,
                tool_id: self.closeEventDetail.tool_id,
                chamber: self.closeEventDetail.chamber,
                event_type: self.eventType,
                component: self.component,
                alarm_code: '',
                solution: self.solution,
                action_time: moment(self.actionTime).format('YYYY-MM-DD hh:mm'),
                note: self.note,
                source: "event",
                event_id_list: self.closeEventDetail.event_id_list
            };


            postMaintainRecord(data, false)
                .then(function (response) {
                                                        

                    alertify.alert('儲存成功!', function () { window.location = "/online/RecordHistory"; });
                    
                }).catch(function (err) {
                    store.commit('setShowLoading', false);
                })

        }

       

    }
})