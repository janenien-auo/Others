﻿//var log = {
//    logError: function (error) {
//        var msg = "";
//        if (error.isAxiosError) {
//            msg = "[RequestUrl:" + error.request.responseURL + "][ResponseStatus:" + error.response.status + "][Message:" + error.message + "]";
//        }
//        else {
//            msg = "[" + error.toString() + "][" + error.stack + "]";
//        }
//        $.ajax({
//            type: 'POST',
//            url: "/api/Log/Error",
//            data: {
//                '': msg
//            }
//        });
//    }
//};

//module.exports = log 


function logError(error) {
  
    var msg = "";
    if (error.isAxiosError) {
        msg = "[RequestUrl:" + error.request.responseURL + "][ResponseStatus:" + error.response.status + "][Message:" + error.message + "]";
    }
    else {
        msg = "[" + error.toString() + "][" + error.stack + "]";
    }
    $.ajax({
        type: 'POST',
        url: "/api/Log/Error",
        data: {
            '': msg
        }
    });
}