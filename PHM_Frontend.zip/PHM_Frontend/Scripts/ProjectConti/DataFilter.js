﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {
        closeEstoneList: [],
        projectName: 'This is project name',
        tool_chamber_list: [],
        imputation_setting_list: [],
        datafilter_list: [],
        datalist: [],
        showDataCheckPreview: false,
        showDataCheckPreviewBtn: true,
        ideldefines: store.getters.getAllIdelDefines,
        filterdefines: store.getters.getAllFilterDefines,
        tools: [],
        chambers: [], 
        parameters: [],
        seltool: '',
        selchamber: '',
        selparameter: '',
        datalist_filter: [],
      
    },
    mounted: function () {
        var self = this;
        self.init();

    },
    methods: {
        init: function () {

            //store.commit('setShowLoading', true);

            var self = this;


            store.commit('setDefaultProjectId');
            store.commit('setProjectInfo');
            self.projectInfo = store.getters.getCurrentProjectInfo;
            self.projectName = self.projectInfo.fab + "-" + self.projectInfo.stage + "-" + self.projectInfo.func + "-" + self.projectInfo.ai365_project_name + "-" + self.projectInfo.model_type + "-" + self.projectInfo.project_id;
            self.getImputationSettingPromise().then(function () {
                self.getDataFilterPromise().then(function () {
                    self.getToolChamberListPromise().then(function () {

                    });
                });

            });

            store.commit('setShowLoading', false);
        },
        getToolChamberListPromise: function () {
            var self = this;


            return new Promise(function (resolve, reject) {


                var apiUrl = "/project_tool_chamber_list";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        tool_chamber_list: [
                            {
                                tool_id: "AAIEX100",
                                chamber: "C100",
                                real_chamber: [
                                    "COATER",
                                    "LC_DRY"
                                ]
                            },
                            {
                                tool_id: "AAIEX200",
                                chamber: "C200",
                                real_chamber: [
                                    "COATER",
                                    "LC_DRY"
                                ]
                            },
                            {
                                tool_id: "AAIEX300",
                                chamber: "C300",
                                real_chamber: [
                                    "COATER",
                                    "LC_DRY"
                                ]
                            },
                        ],
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {

                                self.tool_chamber_list = response.data.data.tool_chamber_list;
       
                                var iCnt = 0;
                                self.tools = [];
                                $.each(response.data.data.tool_chamber_list, function (index, objTool) {
                                    var arChamber = [], arParameter = [];
                                    var _chamber = '';
                                    self.tools.push(objTool.tool_id);
                                    var result = self.imputation_setting_list.map(function (item, idx, ary) {
                                        if (item.tool_id == objTool.tool_id) {
                                            arChamber.push(item.chamber);
                                            arParameter.push(item.parameter);
                                        }
 
                                        return item;
                                    }).filter(function (d, index) {
                                        return d != undefined;
                                    });

                                    var resultChamber = arChamber.filter(function (element, index, arr) {
                                        return arr.indexOf(element) === index;
                                    });
                                    var resultParameter = arParameter.filter(function (element, index, arr) {
                                        return arr.indexOf(element) === index;
                                    });




                                    //判斷是否有設定過
                                    var result_setting = [];
                                    $.each(resultChamber, function (idx, obj) {
                                        var _setting = self.datafilter_list.map(function (item, idx, ary) {
                                            if (item.tool_id == objTool.tool_id && item.chamber == obj) {
                                                result_setting.push(item);
                                                return item;
                                            }
                                        }).filter(function (d, index) {
                                            return d != undefined;
                                            });
                                    });

                                    
                                    if (result_setting != null && result_setting.length > 0) {
                                        var _data_filter = [];
                                        if (result_setting[0].data_filter != null) {
                                            
                                            $.each(result_setting[0].data_filter, function (idx1, obj1) {
                                                var _filter_upper_percentage_threshold = "";
                                                if (obj1.filter_upper_percentage_threshold != undefined && obj1.filter_upper_percentage_threshold.toString() != "")
                                                    _filter_upper_percentage_threshold = obj1.filter_upper_percentage_threshold.toString();

                                                var _std = "";
                                                if (obj1.std != undefined && obj1.std.toString() != "")
                                                    _std = obj1.std.toString();
                                                var _value = "", _value_compare_symbol = "=";
                                                if (obj1.parameter_value_filter != undefined && obj1.parameter_value_filter[0].value.toString() != "") {
                                                    _value = obj1.parameter_value_filter[0].value.toString();
                                                }

                                                var _filter = {
                                                    "parameter": obj1.parameter, "filter_upper_percentage_threshold": _filter_upper_percentage_threshold,
                                                    "parameter_value_filter": [{
                                                        "value": _value, "value_compare_symbol": _value_compare_symbol
                                                    }],
                                                    "std": _std
                                                };
                                                _data_filter.push(_filter);

                                            });
  
                                        }//if (result_setting[0].data_filter != null) {
                                        if (result_setting[0].idle_define != null) {

                                            //result_setting[0].idle_define.forEach(function (d) {

                                            //    d['checked'] = true;

                                            //});

                                            $.each(self.ideldefines, function (idx1, obj1) {
                                                var result_idel = result_setting[0].idle_define.map(function (item, idx, ary) {
                                                    if (item.value_compare_symbol == obj1) {

                                                        return item;
                                                    }
                                                }).filter(function (d, index) {
                                                    return d != undefined;
                                                });

                                                if (result_idel.length == 0) {
                                                    //result_setting[0].idle_define.push({
                                                    //    "value": '', "value_compare_symbol": "" + obj1 + "", "checked": false
                                                    //});
                                                    
                                                    result_setting[0].idle_define.push({
                                                        "value": '', "value_compare_symbol": "" + obj1 + ""
                                                    });
                                                }//if (result_idel.length == 0) {
                                            });

                                            var item = {
                                                "item": ++iCnt, "tool_id": objTool.tool_id, "chamber": result_setting[0].chamber,
                                                "available_chamber": resultChamber, "main_parameter": result_setting[0].main_parameter, "available_parameter": resultParameter,
                                                "idle_define": result_setting[0].idle_define, "data_filter": _data_filter
                                            };
                                            self.datalist.push(item);

                                        } else {
                                            //無設定資料，給預設值
                                            var _idle_define = [];
                                            var _value = null;
                                            $.each(self.ideldefines, function (idx1, obj1) {
                                                //_idle_define.push({
                                                //    "value": '', "value_compare_symbol": "" + obj1 + "", "checked": false
                                                //});
                                                
                                                _idle_define.push({
                                                    "value": '', "value_compare_symbol": "" + obj1 + ""
                                                });
                                            });

                                            var item = {
                                                "item": ++iCnt, "tool_id": objTool.tool_id, "chamber": '',
                                                "available_chamber": resultChamber, "main_parameter": '', "available_parameter": resultParameter,
                                                "idle_define": _idle_define, "data_filter": _data_filter
                                            };
                                            self.datalist.push(item);
                                        }//if (result_setting[0].idle_define != null) {

                                    } else {
                                        //無設定資料，給預設值
                                        var _idle_define = [];
                                       
                                        $.each(self.ideldefines, function (idx1, obj1) {
                                            //_idle_define.push({
                                            //    "value": '', "value_compare_symbol": "" + obj1 + "", "checked": false
                                            //});
                                            _idle_define.push({
                                                "value": '', "value_compare_symbol": "" + obj1 + ""
                                            });
                                        });

                                        var item = {
                                            "item": ++iCnt, "tool_id": objTool.tool_id, "chamber": '',
                                            "available_chamber": resultChamber, "main_parameter": '', "available_parameter": resultParameter,
                                            "idle_define": _idle_define, "data_filter": []
                                        };
                                        self.datalist.push(item);
                                    }//if (result_setting != null && result_setting.length > 0) {


                                    
                                });
                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        getImputationSettingPromise: function () {
            var self = this;
            self.datalist = [];

            return new Promise(function (resolve, reject) {


                var apiUrl = "/continuous/imputation_setting";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        tool_chamber_list: [
                            {
                                tool_id: "AAIEX100",
                                chamber: "COATER",
                                parameter: "P1",
                                sampling_rate: ''
                            },
                            {
                                tool_id: "AAIEX100",
                                chamber: "DRY",
                                parameter: "P1",
                                sampling_rate: 6
                            },
                            {
                                tool_id: "AAIEX200",
                                chamber: "COATER",
                                parameter: "P2",
                                sampling_rate: 10
                            },
                            {
                                tool_id: "AAIEX200",
                                chamber: "DRY",
                                parameter: "P2",
                                sampling_rate: 1
                            }
                        ]
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {


                                self.imputation_setting_list = response.data.data.tool_chamber_list;




                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },   
        getDataFilterPromise: function () {
            var self = this;
            self.datalist = [];

            return new Promise(function (resolve, reject) {


                var apiUrl = "/continuous/pre_raw_data_filter";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        tool_chamber_list: [
                            {
                                chamber: "COATER",
                                data_filter: [
                                    {
                                        parameter: "ESD_VOLTAGE",
                                        filter_upper_percentage_threshold: 90,
                                        parameter_value_filter: [
                                            {
                                                value: 20,
                                                value_compare_symbol: "<"
                                            },
                                        ],
                                        std: 3
                                    }
                               ],
                               idle_define: [
                                    {
                                        value: 20,
                                        value_compare_symbol: "<"
                                    },
                                    {
                                        value: 0,
                                        value_compare_symbol: ">"
                                    }
                                ],
                                main_parameter: "ESD_VOLTAGE",
                                tool_id: "AAIEX100"
                            },
                            {
                                chamber: "COATER",
                                idle_define: [
                                    {
                                        value: 20,
                                        value_compare_symbol: "<"
                                    }
                                ],
                                main_parameter: "ESD_VOLTAGE",
                                tool_id: "AAIEX200"
                            }
                        ]
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {





                                self.datafilter_list = response.data.data.tool_chamber_list;





                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        }, 
        getDataCheckPreview: function (tool_id, chamber, parameter) {
            var self = this;


            var apiUrl = "/continuous/pre_raw_data_preview";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data:
                {

                    datetime: ["2020-08-01 12:34:56.333", "2020-08-01 12:34:56.666", "2020-08-01 12:34:57"],
                    value: [1, 2, 3]
                }


            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;


            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    model_id: store.getters.getCurrentModelId,
                    tool_id: tool_id,
                    chamber: chamber,
                    parameter: parameter,
                }

            })
                .then(function (response) {
                    if (response.data.status == "OK") {

                        self.ChartDatas = response.data.data;
                        self.DrawDataCheckChart();
                    }
                })


        },
        viewDataCheckPreview: function (tool_id, chamber, parameter) {
            var self = this;
            self.tool_id = tool_id;
            self.chamber = chamber;
            self.parameter = parameter;

            self.showDataCheckPreview = true;
            self.getDataCheckPreview(tool_id, chamber, parameter)


            //self.getDataCheckPreview();
        },
        DrawDataCheckChart: function () {
            //var arColor = ['#00B0F0', '#00EACD', '#43A047', '#92D050', '#D05052', '#FF7800', '#FFFF00', '#A349A4', '#F06292', '#7E57C2', '#02B9C4', '#5292B3', '#DAF7A6', '#49ff33', '#b9e7ff', '#83B9C7', '#2ACDC9', '#FFD000', '#7CFEF0', '#d7f96e'];
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            var self = this;

            var _series = [], _legend = [], _xAxis = [];
            _xAxis = [];
            _legend.push("Continuous Data Chart PreView");
            _series.push({ name: "RawData", data: self.ChartDatas.value, type: 'line', symbol: '', smooth: true, itemStyle: { color: arColor[0] } });

            var iTotalPoint = self.ChartDatas.datetime.length;
            var myChart = echarts.init(document.getElementById("DataCheckChart"), 'default');
            myChart.clear();

            /*  去除加载缓冲图 */
            myChart.showLoading({
                text: 'Loading...',
                textStyle: { fontSize: 30, color: '#444' },
                effectOption: { backgroundColor: 'rgba(0, 0, 0, 0)' }
            });

            var option = {
                backgroundColor: '#545655',//背景色
                tooltip: {
                    trigger: 'axis',
                    textStyle: {
                        fontSize: 11
                    }


                },

                legend: {
                    //type: 'scroll',
                    orient: 'vertical',
                    //x: 'right',
                    //y: 'top',
                    show: false,
                    borderWidth: 2,
                    padding: 2,
                    itemGap: 5,
                    right: '1%',
                    top: '10%',

                    color: '#02B9C4',
                    data: _legend,
                    selected: {
                        'RawData': true

                    },
                    bottom: '50%',
                    textStyle: {
                        color: '#CDEDED',
                        fontSize: '10'
                    },

                    //selected: 1
                }, grid: {
                    x: '7%',
                    y: '7%',
                    width: '85%',
                    height: '60%',
                    show: false,
                    borderColor: 'red'
                },
                toolbox: {
                    show: true,
                    feature: {
                        mark: { show: true },
                        dataZoom: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#ec7063'
                                }
                            }
                        },
                        dataView: {
                            show: false, readOnly: false, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#e59866'
                                }
                            }
                        },
                        restore: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#8e44ad'
                                }
                            }
                        },
                        saveAsImage: {
                            show: true, type: 'png', excludeComponents: ['toolbox'], pixelRatio: 2, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#2ecc71',
                                    shadowColor: 'rgba(0, 0, 0, 0.5)',
                                    shadowBlur: 10
                                }
                            }
                        }
                    }
                },
                xAxis: [
                    {
                        type: 'category',
                        triggerEvent: true,
                        boundaryGap: true,
                        data: self.ChartDatas.datetime,



                        axisTick: {
                            show: false,
                            alignWithLabel: true
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变x轴颜色
                        axisLine: {
                            show: true,
                            onZero: false,
                            position: 'end',
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        //  改变x轴字体颜色和大小
                        axisLabel: {
                            show: true,
                            rotate: 90,
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                    }
                ],

                yAxis: [
                    {
                        //  隐藏y轴
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },

                        // 去除y轴上的刻度线
                        axisTick: {
                            show: false
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变y轴字体颜色和大小
                        axisLabel: {
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                        type: 'value',
                        triggerEvent: true
                    }
                ],

                dataZoom: [{
                    type: 'inside',
                    start: 0,
                    end: 100
                }, {
                    start: 0,
                    end: 100,
                    handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                    handleSize: '80%',
                    handleStyle: {
                        color: '#fff',
                        shadowBlur: 3,
                        shadowColor: 'rgba(0, 0, 0, 0.6)',
                        shadowOffsetX: 2,
                        shadowOffsetY: 2
                    }
                }],
                series: _series
            };


            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option, true);
        },
        changeValue: function (event, item) {
            var _toolid = item.tool_id;
          
            var self = this;

            $.each(self.datalist, function (index, obj) {
                if (obj.tool_id == _toolid && event == obj.chamber) {
                    var arParameter = [], arChamber = [];
                    var result = self.imputation_setting_list.map(function (item, idx, ary) {
                        if (item.tool_id == _toolid) {
                            arChamber.push(item.chamber);
                        }
                        if (item.tool_id == _toolid && item.chamber == event) {
                            arParameter.push(item.parameter);                            
                        }
                        return item;
                    }).filter(function (d, index) {
                        return d != undefined;
                    });
                    var resultChamber = arChamber.filter(function (element, index, arr) {
                        return arr.indexOf(element) === index;
                    });
                    var resultParameter = arParameter.filter(function (element, index, arr) {
                        return arr.indexOf(element) === index;
                    });
                    var _item = { "item": obj.item, "tool_id": obj.tool_id, "chamber": obj.chamber, "available_chamber": resultChamber, "main_parameter": '', "available_parameter": resultParameter };

                    self.datalist[index].item = obj.item;
                    self.datalist[index].tool_id = obj.tool_id;
                    self.datalist[index].chamber = obj.chamber;
                    self.datalist[index].available_chamber = resultChamber;
                    self.datalist[index].main_parameter = '';
                    self.datalist[index].available_parameter = resultParameter;

                }//if (obj.tool_id == event.tool_id && obj.chamber == event.chamber) {

            });
            
        },
        getChambers: function (event) {
            var self = this;
            self.seltool = event.target.value;
            self.chambers = [];
            self.selchamber = '';
            self.parameters = [];
            self.selparameter = '';
            var arChamber = [];
            var result = self.imputation_setting_list.map(function (item, idx, ary) {
                if (item.tool_id == event.target.value) {
                    arChamber.push(item.chamber);
                    return item;
                }
            }).filter(function (d, index) {
                return d != undefined;
                });
            var resultChamber = arChamber.filter(function (element, index, arr) {
                return arr.indexOf(element) === index;
            });

            self.chambers = resultChamber;

        },
        getParameters: function (event) {
            var self = this;
            self.selchamber = event.target.value;
            self.parameters = [];
            self.selparameter = '';
            var arParameter = [];
            var result = self.imputation_setting_list.map(function (item, idx, ary) {
                if (item.tool_id == self.seltool && item.chamber == event.target.value) {
                    arParameter.push(item.parameter);
                    return item;
                }
            }).filter(function (d, index) {
                return d != undefined;
                });

            var resultParameter = arParameter.filter(function (element, index, arr) {
                return arr.indexOf(element) === index;
            });

            self.parameters = resultParameter;
        },
        AddNew: function () {
            var self = this;
            if (self.seltool == '' || self.seltool == null) {
                alertify.error("Please Select ToolID !!");
                return;
            }

            if (self.selchamber == '' || self.selchamber == null) {
                alertify.error("Please Select Chamber !!");
                return;
            }

            if (self.selparameter == '' || self.selparameter == null) {
                alertify.error("Please Select Parameter !!");
                return;
            }
            var _datalist_tmp = [];
            //datalist_filter
            var isSame = false;
            var arSame = [];
            $.each(self.datalist, function (index, obj) {
                if (obj.tool_id == self.seltool && obj.chamber == self.selchamber && obj.main_parameter == self.selparameter) {
                    if (obj.data_filter.length > 0) {
                        $.each(obj.data_filter, function (idx, obj_filter) {
                            if (obj_filter.parameter == self.selparameter) {
                                isSame = true;
                                arSame.push(self.seltool + "," + self.selchamber + "," + self.selparameter + "已存在，請重新確認!!");
                                return;
                            } 
                        });
                    }//if (obj.data_filter.length > 0) {
                }//if (obj.tool_id == self.seltool && obj.chamber == self.selchamber) {
            });

            if (isSame == true) {
                alertify.error(arSame.join());
                return;
            } else {
                var result = self.datalist.map(function (item, idx, ary) {
                    if (item.tool_id == self.seltool && item.chamber == self.selchamber) {
                        return item;
                    }
                }).filter(function (d, index) {
                    return d != undefined;
                    });

                if (result != null && result.length > 0) {
                    $.each(self.datalist, function (index, obj) {
                        if (obj.tool_id == self.seltool && obj.chamber == self.selchamber) {


                            var result2 = obj.data_filter.map(function (item, idx, ary) {
                                if (item.parameter == self.selparameter) {

                                    return item;
                                }
                            }).filter(function (d, index) {
                                return d != undefined;
                                });

                            if (result2 != null && result2.length == 0) {
                                var _filter = {
                                    "parameter": self.selparameter, "filter_upper_percentage_threshold": '',
                                    "parameter_value_filter": [{
                                        "value": '', "value_compare_symbol": "="
                                    }],
                                    "std": ''
                                };
                                self.datalist[index].data_filter.push(_filter);
                            }

                        }//if (obj.tool_id == self.seltool && obj.chamber == self.selchamber) {
                    });
                } else {
                    var iCnt = self.datalist.length;
                    var item = {
                        "item": ++iCnt, "tool_id": self.seltool, "chamber": self.selchamber,
                        "available_chamber": [], "available_parameter": [],
                        "data_filter": []
                    };

                    self.datalist.push(item);

                    var _filter = {
                        "parameter": self.selparameter, "filter_upper_percentage_threshold": '',
                        "parameter_value_filter": [{
                            "value": '', "value_compare_symbol": "="
                        }],
                        "std": ''
                    };
                    self.datalist[self.datalist.length - 1].data_filter.push(_filter);
                }

           }
            
        },
        checkBlur: function (event, data, val) {
            //var self = this;
            //var _datalist_tmp = [];
            //$.each(self.datalist, function (index, objList) {
            //    if (objList.tool_id == data.tool_id && objList.chamber == data.chamber && objList.main_parameter == data.main_parameter) {
            //        $.each(objList.idle_define, function (idx, obj) {
            //            if (obj.value_compare_symbol == val.value_compare_symbol) {
            //                if (self.datalist[index].idle_define[idx].value != "")
            //                    self.datalist[index].idle_define[idx].checked = true;
            //                else
            //                    self.datalist[index].idle_define[idx].checked = false;                            
            //            }//if (obj.value_compare_symbol == val.value_compare_symbol) {
            //        });
            //    }//if (obj.tool_id == data.tool_id && obj.chamber == data.chamber) {
            //});
        },
        RemoveItem: function (data, val) {
            var self = this;
            var _datalist_tmp = [];
            if (confirm("Are you sure to remove this item?")) {
                $.each(self.datalist, function (index, obj) {
                    if (obj.tool_id == data.tool_id && obj.chamber == data.chamber) {

                        var result2 = obj.data_filter.map(function (item, idx, ary) {
                            if (item.parameter != val.parameter) {

                                return item;
                            }
                        }).filter(function (d, index) {
                            return d != undefined;
                            });


                        self.datalist[index].data_filter = result2;
 
                    }
                });

                
            }
        },
        backClick: function () {
            alertify.confirm("回上一步驟",
                function (e) {
                    if (e) {
                        ////OK
                        ////window.location.href = "/Project/FeatureEngineering";
                        CreateProjectLayoutContiApp.backStatus();
                    } else {
                        //Cancel                      
                    }
                });
        },
        nextClick: function () {

            var self = this;

            alertify.confirm("儲存編輯內容，並前往下一步驟?",
                function (e) {
                    if (e) {
                        //OK

                        self.vaildDataAndSave(function () {

                        });

                    } else {
                        //Cancel                      
                    }
                });


        },
        vaildDataAndSave: function () {
            var self = this;
            $.each(self.datalist, function (index, objTool) {
                if (objTool.chamber == "") {
                    alertify.error(objTool.tool_id + " Please Select Chamber !!");
                    return false;
                }//if (objTool.chamber == "") {

                if (objTool.main_parameter == "") {
                    alertify.error(objTool.tool_id + " Please Select Parameter !!");
                    return false;
                }//if (objTool.chamber == "") {             

                //idel define至少3擇一
                var isNull = false;
                var iCount = 0;
                $.each(objTool.idle_define, function (idx, obj) {
                    if (obj.value.toString() == "") {
                        isNull = true;
                        ++iCount;
                    }
                });

                if (isNull == true && iCount == 3) {
                    alertify.error(objTool.tool_id + "/" + objTool.chamber + "/" + objTool.main_parameter + " Please Setting Idel Define !!");
                    return false;
                }

                isNull = false;
               
                $.each(objTool.data_filter, function (idx, obj) {
                    iCount = 0;
                    if (obj.std != undefined && obj.std.toString() == "") {
                        ++iCount;
                       
                    }
                    if (obj.filter_upper_percentage_threshold != undefined && obj.filter_upper_percentage_threshold.toString() == "") {
                        ++iCount;
                      
                    }
                    if (obj.parameter_value_filter != undefined && obj.parameter_value_filter[0].value.toString() == "") {
                        ++iCount;
                       
                    }
                    if (iCount == 3)
                        isNull = true;
                });

                if (isNull == true && iCount == 3) {
                    alertify.error(objTool.tool_id + "/" + objTool.chamber + "/" + objTool.main_parameter + " Please Setting Data Filter !!");
                    return false;
                }

            });

            self.save(function () {
                self.updateStatus(function () {

                });
                
            });

            return true;
        },
        //更新狀態
        updateStatus: function (fu) {
            var self = this;



            //呼叫更新狀態API
            var apiUrl = "/model_training";
            axios({
                method: 'put',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    offline_model_status: 1301
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        CreateProjectLayoutContiApp.nextStatus();
                    }
                    else
                        alertify.alert("操作失敗，請重新操作，謝謝!");
                })

        },
        //呼叫API儲存資料
        save: function (fn) {
            var self = this;
            $.each(self.datalist, function (index, obj) {
                if (obj.idle_define != null) {
                    var _idle_define = [];
                    $.each(obj.idle_define, function (idx1, obj1) {

                        if (obj1.value.toString() != "") {



                            var item = {
                                "value": parseFloat(obj1.value),
                                "value_compare_symbol": obj1.value_compare_symbol
                            };
                            _idle_define.push(item);
                        }
                    });
                    self.datalist[index].idle_define = _idle_define;
                }//if (obj.idle_define != null) {
                if (obj.data_filter != null) {
                    var _data_filter = [];

                    var arrTmp = [];
                    $.each(obj.data_filter, function (idx1, obj1) {

                        

                        if (obj1.std.toString() != "" && obj1.filter_upper_percentage_threshold.toString() != "" && obj1.parameter_value_filter[0].value.toString() != "") {
                            var item = {
                                "parameter": obj1.parameter,
                                "std": parseFloat(obj1.std),
                                "filter_upper_percentage_threshold": parseFloat(obj1.filter_upper_percentage_threshold),
                                "parameter_value_filter": [
                                    {
                                        "value": parseFloat(obj1.parameter_value_filter[0].value),
                                        "value_compare_symbol": obj1.parameter_value_filter[0].value_compare_symbol
                                    }
                                ]
                            };
                            arrTmp.unshift(item);
                        }
                        else if (obj1.std.toString() != "" && obj1.filter_upper_percentage_threshold.toString() != "" && obj1.parameter_value_filter[0].value.toString() == "") {
                            var item = {
                                "parameter": obj1.parameter,
                                "std": parseFloat(obj1.std),
                                "filter_upper_percentage_threshold": parseFloat(obj1.filter_upper_percentage_threshold)
                            };
                            arrTmp.unshift(item);
                        } else if (obj1.std.toString() != "" && obj1.filter_upper_percentage_threshold.toString() == "" && obj1.parameter_value_filter[0].value.toString() == "") {
                            var item = {
                                "parameter": obj1.parameter,
                                "std": parseFloat(obj1.std),
                            };
                            arrTmp.unshift(item);
                        }
                        else if (obj1.std.toString() == "" && obj1.filter_upper_percentage_threshold.toString() == "" && obj1.parameter_value_filter[0].value.toString() != "") {
                            var item = {
                                "parameter": obj1.parameter,
                                "parameter_value_filter": [
                                    {
                                        "value": parseFloat(obj1.parameter_value_filter[0].value),
                                        "value_compare_symbol": obj1.parameter_value_filter[0].value_compare_symbol
                                    }
                                ]
                            };
                            arrTmp.unshift(item);
                        } else if (obj1.std.toString() != "" && obj1.filter_upper_percentage_threshold.toString() == "" && obj1.parameter_value_filter[0].value.toString() != "") {
                            var item = {
                                "parameter": obj1.parameter,
                                "std": parseFloat(obj1.std),
                                "parameter_value_filter": [
                                    {
                                        "value": parseFloat(obj1.parameter_value_filter[0].value),
                                        "value_compare_symbol": obj1.parameter_value_filter[0].value_compare_symbol
                                    }
                                ]
                            };
                            arrTmp.unshift(item);
                        } else if (obj1.std.toString() == "" && obj1.filter_upper_percentage_threshold.toString() != "" && obj1.parameter_value_filter[0].value.toString() != "") {
                            var item = {
                                "parameter": obj1.parameter,
                                "filter_upper_percentage_threshold": parseFloat(obj1.filter_upper_percentage_threshold),
                                "parameter_value_filter": [
                                    {
                                        "value": parseFloat(obj1.parameter_value_filter[0].value),
                                        "value_compare_symbol": obj1.parameter_value_filter[0].value_compare_symbol
                                    }
                                ]
                            };
                            arrTmp.unshift(item);
                        } else if (obj1.std.toString() == "" && obj1.filter_upper_percentage_threshold.toString() != "" && obj1.parameter_value_filter[0].value.toString() == "") {
                            var item = {
                                "parameter": obj1.parameter,
                                "filter_upper_percentage_threshold": parseFloat(obj1.filter_upper_percentage_threshold),
                            };
                            arrTmp.unshift(item);
                        } 




                        
                    
                        

                    });
                    self.datalist[index].data_filter = arrTmp;
                }//if (obj.data_filter != null) {
            });
           
            var apiUrl = "/continuous/pre_raw_data_filter";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                status: "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            


            axios({
                method: 'post',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    model_id: store.getters.getCurrentModelId,
                    tool_chamber_list: self.datalist,
                }

            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        alertify.success("Save Success");
                        if (fn) {
                            setTimeout(fn, 500);
                        }
                    }
                    else {
                        alertify.success("Save fail");
                    }
                })

        },




    }
})