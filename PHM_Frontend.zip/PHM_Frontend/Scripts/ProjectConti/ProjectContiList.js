﻿

var app = new Vue({
    el: '#app',
    store: store,
    data: {
        StartTime: '',
        applications: [],
        application: "",
        fabs: [],
        fab: "",
        stages: [],
        stage: "",
        functions: [],
        func: "",
        projectList: [],
        keyWord: "",
        selected: [],
        allSelected: false,
        Pagination: {
            current_page: 1,
            page_size: 10,
            total: 0
        },
        data_source:"continuous",


    },
    mounted: function () {
        var self = this;
        self.getProjectList();
        self.getApplications();
        self.getFabs();
        store.commit('setShowLoading', false);
    },
    methods: {


        //Get Applications
        getApplications: function () {
            var self = this;
            self.applications = store.getters.getApplications;
        },

        //Get Fabs
        getFabs: function () {

            //var apiUrl = "/DropItem";
            var apiUrl = "/api/Basicinfor/GetFabs";

            //用來模擬API的資料，實際上線不會執行這段           
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: [
                    {
                        Key: "L5C",
                        Value: 1
                    },
                    {
                        Key: "L7A",
                        Value: 2
                    }
                ]
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'get',
                url: apiUrl,
                params: {
                    //key:"Fab"
                    SITEID: "TC"
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK")
                        self.fabs = response.data.data;
                })
        },

        //選擇Fab後所觸發的事件
        selectFab: function () {
            var self = this;
            self.getStages();
        },

        //Get Modules
        getStages: function () {

            //var apiUrl = "/DropItem";
            var apiUrl = "/api/Basicinfor/GetModules";

            var dataType = this.data_source;
          

            //用來模擬API的資料，實際上線不會執行這段          
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: [
                    {
                        Key: "CF",
                        Value: 1
                    },
                    {
                        Key: "Array",
                        Value: 2
                    }
                ]
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'get',
                url: apiUrl,
                params: {
                    //key: "process_type"
                    FabSite: self.fab,
                    DataType: dataType
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK")
                        self.stages = response.data.data;
                })
        },

        //選擇Stage後所觸發的事件
        selectStage: function () {
            var self = this;
            self.getFunctions();
        },

        //Get Functions
        getFunctions: function () {

            //var apiUrl = "/DropItem";
            var apiUrl = "/api/Basicinfor/GetFunctions";

            var dataType = this.data_source;

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: [
                    {
                        Key: "Robot",
                        Value: 1
                    },
                    {
                        Key: "Pump",
                        Value: 2
                    }
                ]
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'get',
                url: apiUrl,
                params: {
                    FabSite: self.fab,
                    ProcessType: self.stage,
                    DataType: dataType
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK")
                        self.functions = response.data.data;
                })
        },

        //選擇Function後所觸發的事件
        selectFunction: function () {
            var self = this;

            //Mark by Jane:改成統一由Search按鈕搜尋
            //self.getProjectList();
        },

        //Get ProjectList
        getProjectList: function (page) {

            var apiUrl = "/project";

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: {
                    total_count: 20,
                    project_list: [
                        {
                            project_id: 1,
                            ai365_project_name: "test_phm",
                            model_type: "Anomaly Detection",
                            application: "Robot",
                            fab: "L5C",
                            stage: "Array",
                            func: "PHOTO",
                            tool_type: "Robot_LD",
                            offline_model_status: 100,
                            user_name: "Joyce",
                            itime: "2019-12-31 10:58:30",
                            model_id: 1
                        },
                        {
                            project_id: 2,
                            ai365_project_name: "test_phm",
                            model_type: "Anomaly Detection",
                            application: "Robot",
                            fab: "L5C",
                            stage: "Array",
                            func: "PHOTO",
                            tool_type: "Robot_LD",
                            offline_model_status: 200,
                            user_name: "Joyce",
                            itime: "2019-12-31 10:58:30",
                            model_id: 2
                        },
                        {
                            project_id: 3,
                            ai365_project_name: "test_phm",
                            model_type: "Anomaly Detection",
                            application: "Robot",
                            fab: "L5C",
                            stage: "Array",
                            func: "PHOTO",
                            tool_type: "Robot_LD",
                            offline_model_status: 300,
                            user_name: "Joyce",
                            itime: "2019-12-31 10:58:30",
                            model_id: 3
                        },
                        {
                            project_id: 4,
                            ai365_project_name: "test_phm",
                            model_type: "Anomaly Detection",
                            application: "Robot",
                            fab: "L5C",
                            stage: "Array",
                            func: "PHOTO",
                            tool_type: "Robot_LD",
                            offline_model_status: 400,
                            user_name: "Joyce",
                            itime: "2019-12-31 10:58:30",
                            model_id: 3
                        },
                        {
                            project_id: 4,
                            ai365_project_name: "test_phm",
                            model_type: "Anomaly Detection",
                            application: "Robot",
                            fab: "L5C",
                            stage: "Array",
                            func: "PHOTO",
                            tool_type: "Robot_LD",
                            offline_model_status: 410,
                            user_name: "Joyce",
                            itime: "2019-12-31 10:58:30",
                            model_id: 4
                        },
                        {
                            project_id: 5,
                            ai365_project_name: "test_phm",
                            model_type: "Anomaly Detection",
                            application: "Robot",
                            fab: "L5C",
                            stage: "Array",
                            func: "PHOTO",
                            tool_type: "Robot_LD",
                            offline_model_status: 500,
                            user_name: "Joyce",
                            itime: "2019-12-31 10:58:30",
                            model_id: 5
                        },
                        {
                            project_id: 5,
                            ai365_project_name: "test_phm",
                            model_type: "Anomaly Detection",
                            application: "Robot",
                            fab: "L5C",
                            stage: "Array",
                            func: "PHOTO",
                            tool_type: "Robot_LD",
                            offline_model_status: 510,
                            user_name: "Joyce",
                            itime: "2019-12-31 10:58:30",
                            model_id: 6
                        },
                        {
                            project_id: 6,
                            ai365_project_name: "test_phm",
                            model_type: "Anomaly Detection",
                            application: "Robot",
                            fab: "L5C",
                            stage: "Array",
                            func: "PHOTO",
                            tool_type: "Robot_LD",
                            offline_model_status: 600,
                            user_name: "Joyce",
                            itime: "2019-12-31 10:58:30",
                            model_id: 7
                        },
                        {
                            project_id: 7,
                            ai365_project_name: "test_phm",
                            model_type: "Anomaly Detection",
                            application: "Robot",
                            fab: "L5C",
                            stage: "Array",
                            func: "PHOTO",
                            tool_type: "Robot_LD",
                            offline_model_status: 700,
                            user_name: "Joyce",
                            itime: "2019-12-31 10:58:30",
                            model_id: 8
                        },
                        {
                            project_id: 7,
                            ai365_project_name: "test_phm",
                            model_type: "Anomaly Detection",
                            application: "Robot",
                            fab: "L5C",
                            stage: "Array",
                            func: "PHOTO",
                            tool_type: "Robot_LD",
                            offline_model_status: 800,
                            user_name: "Joyce",
                            itime: "2019-12-31 10:58:30",
                            model_id: 9
                        },
                        {
                            project_id: 7,
                            ai365_project_name: "test_phm",
                            model_type: "Anomaly Detection",
                            application: "Robot",
                            fab: "L5C",
                            stage: "Array",
                            func: "PHOTO",
                            tool_type: "Robot_LD",
                            offline_model_status: 900,
                            user_name: "Joyce",
                            itime: "2019-12-31 10:58:30",
                            model_id: 10
                        },
                        {
                            project_id: 7,
                            ai365_project_name: "test_phm",
                            model_type: "Anomaly Detection",
                            application: "Robot",
                            fab: "L5C",
                            stage: "Array",
                            func: "PHOTO",
                            tool_type: "Robot_LD",
                            offline_model_status: 1000,
                            user_name: "Joyce",
                            itime: "2019-12-31 10:58:30",
                            model_id: 11
                        },
                        {
                            project_id: 7,
                            ai365_project_name: "test_phm",
                            model_type: "Anomaly Detection",
                            application: "Robot",
                            fab: "L5C",
                            stage: "Array",
                            func: "PHOTO",
                            tool_type: "Robot_LD",
                            offline_model_status: 1100,
                            user_name: "Joyce",
                            itime: "2019-12-31 10:58:30",
                            model_id: 12
                        }
                    ]
                }
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }
            var self = this;

            //避免User在其他頁點選查詢造成沒有資料，統一導向第一頁
            if (page)
                self.Pagination.current_page = page;




            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    page_no: self.Pagination.current_page,
                    page_size: self.Pagination.page_size,
                    keyword: self.keyWord,
                    func: self.func,
                    fab: self.fab,
                    application: self.application,
                    stage: self.stage,
                    data_source: 'continuous'
                }
            })
                .then(function (response) {


                    if (response.data.status == "OK") {
                        self.Pagination.total = response.data.data.total_count;
                        self.projectList = response.data.data.project_list;

                        if (self.projectList.length == 0) {
                            alertify.error("No data");
                        }


                        for (var i = 0; i < self.projectList.length; i++) {
                            var offline_model_status = "";
                            var statusInfos = [];
                            if (self.projectList[i].data_source == "continuous") {
                                if (self.projectList[i].offline_model_status == 100)
                                    self.projectList[i].offline_model_status = 1000;
                                if (self.projectList[i].offline_model_status >= 600 && self.projectList[i].offline_model_status  < 1000)
                                    statusInfos = store.getters.getStatusInfos;
                                else
                                    statusInfos = store.getters.getStatusInfosConti;
                            }
                            else
                                statusInfos = store.getters.getStatusInfos;
                            for (var j = 0; j < statusInfos.length; j++) {
                                if (statusInfos[j].offline_model_status == self.projectList[i].offline_model_status) {
                                    offline_model_status = statusInfos[j].statusName;
                                    break;
                                }
                            }

                            if (self.projectList[i].project_status) {
                                self.projectList[i].project_status = offline_model_status;
                            }
                            else {
                                self.projectList[i]["project_status"] = offline_model_status;
                            }
                        }

                    }
                })
        },

        //Edit Project
        viewProject: function (row) {
            if (row.offline_model_status >= 600 && row.offline_model_status < 1000)
                window.location.href = "/Project/RedriectUrl" + "?projectid=" + row.project_id + "&modelid=" + row.model_id;
            else
                window.location.href = "/ProjectConti/RedriectContiUrl" + "?projectid=" + row.project_id + "&modelid=" + row.model_id;
        },

        //mark by amanda 2020-09-07 15:09
        ////Delete Project
        //deleteProject: function (row) {

        //    var apiUrl = "/project";
        //    var self = this;

        //    if (row.project_id)
        //        self.selected = [row.project_id];

        //    alertify.confirm("Are you want to delete project?",
        //        function (e) {
        //            if (e) {
        //                //OK   

        //                //用來模擬API的資料，實際上線不會執行這段                        
        //                let mock = new AxiosMockAdapter(axios);
        //                mock.onDelete(apiUrl).reply(200, {
        //                    status: "success",
        //                    data: {}
        //                });

        //                if (store.getters.getEnv == 'prd') {
        //                    mock.restore();
        //                }


        //                axios({
        //                    method: 'delete',
        //                    baseURL: store.getters.getOfflineApiUrl,
        //                    url: apiUrl,
        //                    data: {
        //                        project_id: self.selected
        //                    }
        //                })
        //                    .then(function (response) {
        //                        if (response.data.status == "OK") {
        //                            alertify.success("Delete Success");
        //                            self.getProjectList();
        //                        }
        //                        else {
        //                            alertify.alert("Delete Fail");
        //                        }
        //                    })



        //            } else {
        //                //Cancel    
        //                return;
        //            }
        //        });


        //},

        //選擇全部的按鈕
        selectAll: function () {
            var self = this;

            self.selected = [];

            if (!self.allSelected) {
                for (p in self.projectList) {
                    self.selected.push(self.projectList[p].project_id);
                }
            }


        },

        //換頁
        handleChangePage: function (val) {
            var self = this;
            self.Pagination.current_page = val;
            self.getProjectList();
        },

        //mark by amanda 2020-09-07 15:09
        ////新增NewProject的按鈕
        //createNew: function () {
        //    store.commit('clearCurrentProjectInfo', function () {
        //        window.location.href = "/Project/ProjectInfo";
        //    });
        //}
    }


})