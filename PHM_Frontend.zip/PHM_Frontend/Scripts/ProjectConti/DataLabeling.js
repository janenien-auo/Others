﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {
        closeEstoneList: [],
        projectName: 'This is project name',
        featureEngneeringDatas: {
            feature_config: [],
            all_statisticals: []
        },
        datalist: [],
        showMenu: false,
        showDataCheckPreview: false,
        showDataCheckPreviewBtn: true,
        tool_chamber_list: [],
        imputation_setting_list: [],
        statisticals: [],
        brushSelectedIdx: '',
        feature_label_list: [],
        tool_label_info_list: [],
        reset_toolid: '',
        update_toolid: '',
        projectInfo: [],
    },
    mounted: function () {
        var self = this;
        self.init();

    },
    methods: {
        init: function () {

            //store.commit('setShowLoading', true);
 

            var self = this;


            store.commit('setDefaultProjectId');
            store.commit('setProjectInfo');
            self.projectInfo = store.getters.getCurrentProjectInfo;
 
            self.projectName = self.projectInfo.fab + "-" + self.projectInfo.stage + "-" + self.projectInfo.func + "-" + self.projectInfo.ai365_project_name + "-" + self.projectInfo.model_type + "-" + self.projectInfo.project_id;
            self.getLabelingInfoPromise().then(function () {
                self.getFeatureEngineeringPromise().then(function () {
                    self.getImputationSettingPromise().then(function () {
                        self.getToolChamberListPromise().then(function () {

                        });
                    });
                });
            });

            //var closeEventDetailStr = window.localStorage.getItem('closeeventdetail');

            //if (closeEventDetailStr) {
            //    self.closeEventDetail = JSON.parse(closeEventDetailStr);


            //    //self.projectName = self.closeEventDetail.

            //}

            store.commit('setShowLoading', false);
        },
        getLabelingInfoPromise: function () {
            var self = this;
           

            return new Promise(function (resolve, reject) {


                var apiUrl = "/continuous/labeling_info";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {

                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }
                
                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: 'http://tcapcphmd01:8001',//store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {

                                responseData = response.data.data;

                                self.tool_label_info_list = response.data.data;




                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        getFeatureEngineeringPromise: function () {
            var self = this;
            self.datalist = [];

            return new Promise(function (resolve, reject) {


                var apiUrl = "/continuous/feature_engineering";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
  
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {

                                responseData = response.data.data;

                                self.featureEngneeringDatas.feature_config = responseData.feature_config;

                                self.featureEngneeringDatas.feature_config.forEach(function (el) {
                                    if (el.spectrum.length > 0) {
                                        self.statisticals = el.spectrum[0].statistical
                                        //if (el.spectrum[0].statistical.length > 0) {
                                            
                                        //    el.spectrum[0].statistical.forEach(function (el2) {
                                        //        statisticals.push(el2)
                                        //    });
                                        //} 
                                    }//if (el.spectrum.length > 0) {
                                });


                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        getFeaturePreviewPromise: function (tool_id, chamber, parameter, statistic) {
            var self = this;


            return new Promise(function (resolve, reject) {


                var apiUrl = "/continuous/feature_preview";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        virtual_tool_chamber_data_id: [
                            321,
                            123,
                            456
                        ],
                        datetime: [
                            "2020-08-01 12:34:56.333",
                            "2020-08-01 12:34:56.666",
                            "2020-08-01 12:34:57.555"
                        ],
                        value: [
                            1,
                            2,
                            3
                        ],
                        label: [
                            "OK",
                            "OK",
                            "OK"
                        ],
                        machine_part: [
                            "",
                            "",
                            ""
                        ]
                    }
                });
                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        model_id: store.getters.getCurrentModelId,
                        tool_id: tool_id,
                        chamber: chamber,
                        parameter: parameter,
                        statistic: statistic
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {
                                self.ChartDatas = response.data.data;

                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        getToolChamberListPromise: function () {
            var self = this;


            return new Promise(function (resolve, reject) {


                var apiUrl = "/project_tool_chamber_list";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        tool_chamber_list: [
                            {
                                tool_id: "AAIEX100",
                                chamber: "C100",
                                real_chamber: [
                                    "COATER",
                                    "LC_DRY"
                                ]
                            },
                            {
                                tool_id: "AAIEX200",
                                chamber: "C200",
                                real_chamber: [
                                    "COATER",
                                    "LC_DRY"
                                ]
                            },
                            {
                                tool_id: "AAIEX300",
                                chamber: "C300",
                                real_chamber: [
                                    "COATER",
                                    "LC_DRY"
                                ]
                            },
                        ],
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {



                                self.tool_chamber_list = response.data.data.tool_chamber_list;

                                var iCnt = 0;
                                
                                $.each(response.data.data.tool_chamber_list, function (index, objTool) {
                                    var isSetting = 0;
                                    var arChamber = [], arParameter = [];
                                    var _chamber = '';
                                    
                                    var result = self.imputation_setting_list.map(function (item, idx, ary) {
                                        if (item.tool_id == objTool.tool_id) {
                                            arChamber.push(item.chamber);
                                            arParameter.push(item.parameter);
                                            return item;
                                        }
                                    }).filter(function (d, index) {
                                        return d != undefined;
                                    });
                                    var resultChamber = arChamber.filter(function (element, index, arr) {
                                        return arr.indexOf(element) === index;
                                    });
                                    var resultParameter = arParameter.filter(function (element, index, arr) {
                                        return arr.indexOf(element) === index;
                                    });




                                    //判斷是否有設定過
                                    var _parameter = '', _statistic = '';
                                    $.each(self.tool_label_info_list, function (idx, obj) {
                                        if (obj.tool_id == objTool.tool_id) {
                                            isSetting = 1;
                                            _chamber = obj.chamber;
                                            _parameter = obj.parameter;
                                            _statistic = obj.statistic;
                                        }
                                    });
                                

                                    var item = {
                                        "item": ++iCnt, "tool_id": objTool.tool_id, "chamber": _chamber,
                                        "available_chamber": resultChamber, "main_parameter": _parameter, "available_parameter": resultParameter,
                                        "statistic": _statistic, "available_statistic": self.statisticals,
                                        "is_setting": isSetting
                                        
                                    };
                                    self.datalist.push(item);



                                });
                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        getImputationSettingPromise: function () {
            var self = this;
            self.datalist = [];

            return new Promise(function (resolve, reject) {


                var apiUrl = "/continuous/imputation_setting";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        tool_chamber_list: [
                            {
                                tool_id: "AAIEX100",
                                chamber: "COATER",
                                parameter: "P1",
                                sampling_rate: ''
                            },
                            {
                                tool_id: "AAIEX100",
                                chamber: "DRY",
                                parameter: "P1",
                                sampling_rate: 6
                            },
                            {
                                tool_id: "AAIEX200",
                                chamber: "COATER",
                                parameter: "P2",
                                sampling_rate: 10
                            },
                            {
                                tool_id: "AAIEX200",
                                chamber: "DRY",
                                parameter: "P2",
                                sampling_rate: 1
                            }
                        ]
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {

                                var iCnt = 0;
                                self.imputation_setting_list = response.data.data.tool_chamber_list;

                                self.imputation_setting_list.forEach(function (d) {

                                    d['item'] = ++iCnt;

                                });



                                //$.each(response.data.data.tool_chamber_list, function (index, objTool) {
                                //    var item = { "item": ++iCnt, "tool": objTool.tool_id, "chamber": objTool.chamber, "parameter": objTool.parameter, "sampling_rate": objTool.sampling_rate };

                                //    self.datalist.push(item);
                                //});


                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        viewDataCheckPreview: function (tool_id, chamber, parameter, statistic) {

            

            var self = this;
            self.tool_id = tool_id;
            self.chamber = chamber;
            self.parameter = parameter;
            self.statistic = statistic;


            self.showDataCheckPreview = true;

            self.getDataCheckPreview(tool_id, chamber, parameter, statistic);  

        },
        getDataCheckPreview: function (tool_id, chamber, parameter, statistic) {
            var self = this;


            var apiUrl = "/continuous/feature_preview";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: {
                    virtual_tool_chamber_data_id: [
                        321,
                        123,
                        456
                    ],
                    datetime: [
                        "2020-08-01 12:34:56.333",
                        "2020-08-01 12:34:56.666",
                        "2020-08-01 12:34:57.555"
                    ],
                    value: [
                        1,
                        2,
                        3
                    ],
                    label: [
                        "OK",
                        "OK",
                        "OK"
                    ],
                    machine_part: [
                        "",
                        "",
                        ""
                    ]
                }


            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;


            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    model_id: store.getters.getCurrentModelId,
                    tool_id: tool_id,
                    chamber: chamber,
                    parameter: parameter,
                    statistic: statistic
                }

            })
                .then(function (response) {
                    if (response.data.status == "OK") {

                        self.ChartDatas = response.data.data;
                        self.DrawDataCheckChart(tool_id, chamber, parameter, statistic);
                    }
                })


        },
        changeValue: function (event, item) {
            var _toolid = item.tool_id;

            var self = this;

            $.each(self.datalist, function (index, obj) {
                if (obj.tool_id == _toolid && event == obj.chamber) {
                    var arParameter = [], arChamber = [];
                    var result = self.imputation_setting_list.map(function (item, idx, ary) {
                        if (item.tool_id == _toolid) {
                            arChamber.push(item.chamber);
                        }
                        if (item.tool_id == _toolid && item.chamber == event) {
                            arParameter.push(item.parameter);
                        }
                        return item;
                    }).filter(function (d, index) {
                        return d != undefined;
                    });
                    var resultChamber = arChamber.filter(function (element, index, arr) {
                        return arr.indexOf(element) === index;
                    });
                    var resultParameter = arParameter.filter(function (element, index, arr) {
                        return arr.indexOf(element) === index;
                    });
                    var _item = { "item": obj.item, "tool_id": obj.tool_id, "chamber": obj.chamber, "available_chamber": resultChamber, "main_parameter": '', "available_parameter": resultParameter };

                    self.datalist[index].item = obj.item;
                    self.datalist[index].tool_id = obj.tool_id;
                    self.datalist[index].chamber = obj.chamber;
                    self.datalist[index].available_chamber = resultChamber;
                    self.datalist[index].main_parameter = '';
                    self.datalist[index].available_parameter = resultParameter;

                }//if (obj.tool_id == event.tool_id && obj.chamber == event.chamber) {

            });

        },
        changeStatistic: function (event, item) {
            var _toolid = item.tool_id;

            var self = this;

            self.tool_id = item.tool_id;;
            self.chamber = item.chamber;
            self.parameter = item.main_parameter;
            self.statistic = item.statistic;


            $.each(self.datalist, function (index, obj) {
                if (obj.tool_id == _toolid) {
                    self.datalist[index].statistic = event;
                }//if (obj.tool_id == event.tool_id && obj.chamber == event.chamber) {

            });

        },
        DrawDataCheckChart: function (tool_id, chamber, parameter, statistic) {
            //var arColor = ['#00B0F0', '#00EACD', '#43A047', '#92D050', '#D05052', '#FF7800', '#FFFF00', '#A349A4', '#F06292', '#7E57C2', '#02B9C4', '#5292B3', '#DAF7A6', '#49ff33', '#b9e7ff', '#83B9C7', '#2ACDC9', '#FFD000', '#7CFEF0', '#d7f96e'];
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            var self = this;
            var _data = [{
                x: 1,
                y: 2,
                name: "Point2",
                color: "#00FF00"
            }, {
                x: 1,
                y: 4,
                name: "Point1",
                color: "#FF00FF"
            }];
            var _series = [], _legend = [], _xAxis = [];
            _xAxis = [];
            _legend.push("Continuous Data Chart PreView");
            //_series.push({ name: "RawData", data: self.ChartDatas.value, type: 'line',  smooth: true, itemStyle: { color: arColor[0] } });
            _series.push({
                name: 'RawData', data: self.ChartDatas.value, type: 'scatter',
                itemStyle: {
                    normal: {
                        color: function (params) {
                            // build a color map as your need.
                            //var colorList = [
                            //    '#C1232B', '#B5C334', '#FCCE10', '#E87C25', '#27727B',
                            //    '#FE8463', '#9BCA63', '#FAD860', '#F3A43B', '#60C0DD',
                            //    '#D7504B', '#C6E579', '#F4E001', '#F0805A', '#26C0C0'
                            //];
                            if (self.ChartDatas.label[params.dataIndex] == "OK")
                                return arColor[0];
                            else
                                return '#F85256';
                            //return colorList[params.dataIndex]
                        }
                    }
                }
                //itemStyle: { color: arColor[0] }
            });




            var iTotalPoint = self.ChartDatas.datetime.length;
            var myChart = echarts.init(document.getElementById("DataCheckChart"), 'default');
            myChart.clear();

            /*  去除加载缓冲图 */
            myChart.showLoading({
                text: 'Loading...',
                textStyle: { fontSize: 30, color: '#444' },
                effectOption: { backgroundColor: 'rgba(0, 0, 0, 0)' }
            });

            var option = {
                backgroundColor: '#545655',//背景色
                tooltip: {
                    trigger: 'axis',
                    textStyle: {
                        fontSize: 11
                    },
                    formatter: function (params) {
                        var iRow = params[0].dataIndex;

                        var result = "";
                        params.forEach(function (item) {
                            result += '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + item.color + '"></span>';
                            result += "label : " + '<span style="color:#ccffff;font-family: arial;">' + self.ChartDatas.label[iRow] + "</span><br>";
                        });
                        result += "datetime: " + '<span style="color:#ccffff;font-family: arial;">' + params[0].name + "</span><br>";
                        result += "value : " + '<span style="color:#ccffff;font-family: arial;">' + self.ChartDatas.value[iRow] + "</span><br>";
                        result += "virtual_tool_chamber_data_id : " + '<span style="color:#ccffff;font-family: arial;">' + self.ChartDatas.virtual_tool_chamber_data_id[iRow] + "</span><br>";
                        result += "machine_part : " + '<span style="color:#ccffff;font-family: arial;">' + self.ChartDatas.machine_part[iRow] + "</span><br>";


                        return result;
                    }


                },

                legend: {
                    //type: 'scroll',
                    orient: 'vertical',
                    //x: 'right',
                    //y: 'top',
                    show: false,
                    borderWidth: 2,
                    padding: 2,
                    itemGap: 5,
                    right: '1%',
                    top: '10%',

                    color: '#02B9C4',
                    data: _legend,
                    selected: {
                        'RawData': true

                    },
                    bottom: '50%',
                    textStyle: {
                        color: '#CDEDED',
                        fontSize: '10'
                    },

                    //selected: 1
                },
                grid: {
                    x: '7%',
                    y: '7%',
                    width: '85%',
                    height: '64%',
                    show: false,
                    borderColor: 'red'
                },
                toolbox: {
                    show: true,
                    feature: {
                        mark: { show: true },
                        dataZoom: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#ec7063'
                                }
                            }
                        },
                        dataView: {
                            show: false, readOnly: false, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#e59866'
                                }
                            }
                        },
                        restore: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#8e44ad'
                                }
                            }
                        },
                        saveAsImage: {
                            show: true, type: 'png', excludeComponents: ['toolbox'], pixelRatio: 2, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#2ecc71',
                                    shadowColor: 'rgba(0, 0, 0, 0.5)',
                                    shadowBlur: 10
                                }
                            }
                        }
                    }
                },
                xAxis: [
                    {
                        type: 'category',
                        triggerEvent: true,
                        boundaryGap: true,
                        data: self.ChartDatas.datetime,



                        axisTick: {
                            show: false,
                            alignWithLabel: true
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变x轴颜色
                        axisLine: {
                            show: true,
                            onZero: false,
                            position: 'end',
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        //  改变x轴字体颜色和大小
                        axisLabel: {
                            show: true,
                            rotate: 90,
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                    }
                ],

                yAxis: [
                    {
                        //  隐藏y轴
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },

                        // 去除y轴上的刻度线
                        axisTick: {
                            show: false
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变y轴字体颜色和大小
                        axisLabel: {
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                        type: 'value',
                        triggerEvent: true
                    }
                ],

                dataZoom: [{
                    type: 'inside',
                    start: 0,
                    end: 100
                }, {
                    start: 0,
                    end: 100,
                    handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                    handleSize: '80%',
                    handleStyle: {
                        color: '#fff',
                        shadowBlur: 3,
                        shadowColor: 'rgba(0, 0, 0, 0.6)',
                        shadowOffsetX: 2,
                        shadowOffsetY: 2
                    }
                }],
                series: _series
            };


            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option, true);
            myChart.setOption({
                brush: {

                    toolbox: ['rect', 'lineX', 'clear'],//['rect', 'polygon', 'lineX', 'lineY', 'keep', 'clear'],           
                    xAxisIndex: 'all',
                    brushLink: 'all',
                    outOfBrush: {
                        colorAlpha: 0.1,
                        opacity: 0.2,
                        color: '#A9A9A9',
                    },
                    brushStyle: {
                        borderWidth: 1,
                        color: 'rgba(120,140,180,0.3)',
                        borderColor: 'rgba(0,0,0,.65)'
                    }

                },


            });




 

            //myChart.off("brushSelected");
            myChart.on('brushSelected', renderBrushed);
            function renderBrushed(params) {
                var brushed = [];
                var brushComponent = params.batch[0];

                for (var sIdx = 0; sIdx < brushComponent.selected.length; sIdx++) {
                    if (brushComponent.selected[sIdx].seriesName == "RawData") {
                    var rawIndices = brushComponent.selected[sIdx].dataIndex;

                    brushed.push('[Series ' + sIdx + '] ' + rawIndices.join(','));

                        self.brushSelectedIdx = rawIndices;//rawIndices.join(',');
                    }//if (brushComponent.selected[sIdx].seriesName == "Predict Y") {
                }


            }

            myChart.getZr().on('mousedown', function (e) {
                //點擊空白處
                if (!e.target) { return; }
                if (e.event.button == 2) {

                    //e中有当前节点信息
                    showMenu(e, [
                        {
                            "name": "NG",
                            "fn": function () {
                                self.feature_label_list = [];
                                self.update_toolid = tool_id;
                                $.each(self.brushSelectedIdx, function (index, obj) {
                                    var item = {
                                        "virtual_tool_chamber_data_id": self.ChartDatas.virtual_tool_chamber_data_id[obj],                                       
                                        "label": "NG",
                                        "machine_part": self.ChartDatas.machine_part[obj],
                                        "statistic": statistic,
                                        "index": parseInt(obj),
                                        "tool_id": tool_id
                                    };
                                    self.feature_label_list.push(item);

                                });
                                self.saveDataLabeling(function () {
                                    self.getDataCheckPreview(tool_id, chamber, parameter, statistic);
                                });
                                console.log(e);
                            }
                        }
                        , {
                            "name": "OK",
                            "fn": function () {
                                self.update_toolid = tool_id;
                                self.feature_label_list = [];
                                $.each(self.brushSelectedIdx, function (index, obj) {
                                    var item = {
                                        "virtual_tool_chamber_data_id": self.ChartDatas.virtual_tool_chamber_data_id[obj],                                       
                                        "label": "OK",
                                        "machine_part": self.ChartDatas.machine_part[obj],
                                        "statistic": statistic,
                                        "index": parseInt(obj),
                                        "tool_id": tool_id
                                    };
                                    self.feature_label_list.push(item);

                                });
                                self.saveDataLabeling(function () {
                                    self.getDataCheckPreview(tool_id, chamber, parameter, statistic);
                                });
                                console.log(e);
                            }
                        }
                    ]);


                }//if (e.event.button == 2) {
            });

    
            var style_ul = "position:absolute,z-index:9999;padding:0px;margin:0px;border: 1px solid #376075;background-color: #4988A8;position: absolute;left: 0px;top: 0px;z-index: 2;display: none;";
            var style_li = "list-style:none;padding: 5px; cursor: pointer; padding: 5px 20px;margin:0px;";
            var style_li_hover = style_li + "background-color: #00A0E9; color: #fff;";

            //右键Menu容器
            var menubox = $("<div class= 'z' style = '" + style_ul + "' > <div style='text-align:center;background:#ccc'></div> <ul style='margin:0px;padding:0px;'></ul></div > ")
                .appendTo($(document.getElementById("DataCheckPreview")));
       
            //移除瀏覽器右键Menu
            myChart.getDom().oncontextmenu = menubox[0].oncontextmenu = function () {
                return false;
            }





            //點擊其他位置隐藏Menu
            $(document).click(function () {
               
                menubox.hide()
            });




            //顯示Menu
            var showMenu = function (e, menus) {
 

                //e.name
                $("div", menubox).text(" [ Data Labeling ] ");
                var menulistbox = $("ul", menubox).empty();
                $(menus).each(function (i, item) {
                    var li = $("<li style='" + style_li + "'>" + item.name + "</li>")
                        .mouseenter(function () {
                            $(this).attr("style", style_li_hover);
                        })
                        .mouseleave(function () {
                            $(this).attr("style", style_li);
                        })
                        .click(function () {
                            item["fn"].call(this);
                            menubox.hide();
                        });
                    menulistbox.append(li);
                });

                menubox.css({
                    "left": e.offsetX+30,
                    "top": e.offsetY+100
                }).show();
            }


        },
        backClick: function () {
            alertify.confirm("回上一步驟",
                function (e) {
                    if (e) {
                        ////OK
                        ////window.location.href = "/Project/FeatureEngineering";
                        CreateProjectLayoutContiApp.backStatus();
                    } else {
                        //Cancel                      
                    }
                });
        },
        nextClick: function () {

            var self = this;
            //判斷是否有標記NG
            var _isDataLabeling = 0;
            var result = self.datalist.map(function (item, idx, ary) {
                if (item.is_setting == 1)
                    _isDataLabeling = 1;

            });
            
            if (self.projectInfo.data_source == 'continuous' && self.projectInfo.model_type == 'health_assessment' && _isDataLabeling == 0) {
                alertify.alert("未標註NG，請重新確認!!");
            } else {


                alertify.confirm("儲存編輯內容，並前往下一步驟?",
                    function (e) {
                        if (e) {
                            ////OK
                            //self.updateStatus(function () {
                            CreateProjectLayoutContiApp.nextStatus();
                            //});

                        } else {
                            //Cancel                      
                        }
                    });
            }

        },
        //儲存按鈕觸發事件
        saveClick: function () {
            var self = this;

            alertify.confirm("儲存編輯中的內容?",
                function (e) {
                    if (e) {
                        //OK
                        self.vaildDataAndSave();
                    } else {
                        //Cancel                      
                    }
                });
        },
        vaildDataAndSave: function () {
            var self = this;



            this.$validator.validateAll().then(function (result) {
                if (result) {
                    self.save(function () {
                        CreateProjectLayoutContiApp.nextStatus();
                    });
                }
                else {
                    alertify.error('欄位資料填寫錯誤');
                }
            })
        },
        //呼叫API儲存資料
        saveDataLabeling: function (fn) {
            var self = this;

            var apiUrl = "/continuous/data_labeling";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                status: "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'post',
                baseURL: 'http://tcapcphmd01:8000',//store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    model_id: store.getters.getCurrentModelId,
                    feature_label_list: self.feature_label_list,
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                      
                        $.each(self.feature_label_list, function (idx, obj) {
                            
                            self.ChartDatas.label[parseInt(obj.index)] = obj.label;
                           
                        });
                        var _is_setting = 0;
                        //判斷是否有標記NG
                        var result = self.ChartDatas.label.map(function (item, idx, ary) {
                            if (item == "NG")
                                _is_setting = 1;
                            
                        });
                       
                        $.each(self.datalist, function (idx, obj) {
                            
                            if (obj.tool_id == self.update_toolid)
                                self.datalist[idx].is_setting = _is_setting;    
                        });

                        alertify.success("Save Success");
                        if (fn) {
                            setTimeout(fn, 500);
                        }
                    }
                    else {
                        alertify.success("Save fail");
                    }
                })

        },

        resetClick: function (tool_id) {
            var self = this;
            self.reset_toolid = tool_id;
            alertify.confirm("刪除標記的內容?",
                function (e) {
                    if (e) {
                        //OK
                        self.saveResetLabelingInfo(function () {

                        });
                    } else {
                        //Cancel                      
                    }
                });
        },
        saveResetLabelingInfo: function (fn) {
            var self = this;
            
            var apiUrl = "/continuous/reset_labeling_info";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                status: "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }


            axios({
                method: 'post',
                baseURL: 'http://tcapcphmd01:8001',//store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    model_id: store.getters.getCurrentModelId,
                    tool_id: self.reset_toolid,
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {

                        $.each(self.datalist, function (idx, obj) {

                            if (obj.tool_id == self.reset_toolid) {
                                self.datalist[idx].chamber = '';
                                self.datalist[idx].main_parameter = '';
                                self.datalist[idx].statistic = '';
                                self.datalist[idx].is_setting = 0;
                            }
                        });

                        alertify.success("Save Success");
                        if (fn) {
                            setTimeout(fn, 500);
                        }
                    }
                    else {
                        alertify.success("Save fail");
                    }
                })

        },
        //更新狀態
        updateStatus: function (fu) {
            var self = this;



            //呼叫更新狀態API
            var apiUrl = "/model_training";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPut(apiUrl).reply(200, { "code": 200, "data": {}, "description": "Successful response", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            axios({
                method: 'put',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    offline_model_status: 600
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        CreateProjectLayoutContiApp.nextStatus();
                    }
                    else
                        alertify.alert("操作失敗，請重新操作，謝謝!");
                })

        },



    }
})