﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {
        closeEstoneList: [],
        projectName: 'This is project name',
        datalist: [],
        statisticalInfos: [],
        featureEngneeringDatas: {
            feature_config: [],
            all_statisticals: []
        },
        chkStatisticalAll: false,
        statistical_default: store.getters.getStatisticalDefault_conti,
        feature_configs: [],
    },
    mounted: function () {
        var self = this;
        self.init();

    },
    methods: {
        init: function () {

            //store.commit('setShowLoading', true);

            var self = this;


            store.commit('setDefaultProjectId');
            store.commit('setProjectInfo');
            self.projectInfo = store.getters.getCurrentProjectInfo;
            self.projectName = self.projectInfo.fab + "-" + self.projectInfo.stage + "-" + self.projectInfo.func + "-" + self.projectInfo.ai365_project_name + "-" + self.projectInfo.model_type + "-" + self.projectInfo.project_id;
            self.getStatisticalInfos();
            self.getImputationSettingPromise().then(function () {
                self.getFeatureEngneering();
            });

            store.commit('setShowLoading', false);
        },
        //取得可選的Statistical List
        getStatisticalInfos: function () {
            var self = this;
            self.statisticalInfos = store.getters.getStatisticalInfos_Conti;
        },
        getImputationSettingPromise: function () {
            var self = this;
            self.datalist = [];

            return new Promise(function (resolve, reject) {


                var apiUrl = "/continuous/imputation_setting";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        tool_chamber_list: [
                            {
                                tool_id: "AAIEX100",
                                chamber: "COATER",
                                parameter: "P1",
                                sampling_rate: ''
                            },
                            {
                                tool_id: "AAIEX100",
                                chamber: "DRY",
                                parameter: "P1",
                                sampling_rate: 6
                            },
                            {
                                tool_id: "AAIEX200",
                                chamber: "COATER",
                                parameter: "P2",
                                sampling_rate: 10
                            },
                            {
                                tool_id: "AAIEX200",
                                chamber: "DRY",
                                parameter: "P2",
                                sampling_rate: 1
                            },
                            {
                                tool_id: "AAIEX300",
                                chamber: "DRY",
                                parameter: "P2",
                                sampling_rate: 1
                            },
                            {
                                tool_id: "AAIEX400",
                                chamber: "DRY",
                                parameter: "P2",
                                sampling_rate: 1
                            }
                        ]
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {


                                self.datalist = response.data.data.tool_chamber_list;



                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        //取得FeatureEngneering資訊
        getFeatureEngneering: function () {

            var self = this;


            var apiUrl = "/continuous/feature_engineering";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: {
                    feature_config: [
                        //{
                        //    spectrum: [
                        //        {
                        //            statistical: [
                        //                //"Mean",
                        //                //"Std",
                        //                //"Max"
                        //            ]
                        //        }
                        //    ]
                        //}
                    ]
                }
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;

            var responseData = {};
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                }
            })
                .then(function (response) {
                    responseData = response.data.data;

                    self.featureEngneeringDatas.feature_config = responseData.feature_config;

                    self.featureEngneeringDatas.all_statisticals = self.statisticalInfos;


                    var iTotalCount = self.featureEngneeringDatas.all_statisticals.length;
                    self.featureEngneeringDatas.all_statisticals.forEach(function (d1) {

                        var ibool = false;
                        if (self.featureEngneeringDatas.feature_config.length == 0) {
                            //未設預選的項目
                            self.statistical_default.forEach(function (val) {
                                if (d1.abbreviation == val)
                                    ibool = true;
                            });
                        } else {
                            //用來確認是第一次進來還是之前設定過
                            self.featureEngneeringDatas.feature_config.forEach(function (el) {
                                if (el.spectrum.length > 0) {
                                    if (el.spectrum[0].statistical.length > 0) {

                                        el.spectrum[0].statistical.forEach(function (el2) {
                                            if (d1.abbreviation == el2) {
                                                ibool = true;
                                            }
                                        });
                                    } else {
                                        //未設預選的項目
                                        self.statistical_default.forEach(function (val) {
                                            if (d1.abbreviation == val)
                                                ibool = true;
                                        });
                                    }//if (el.spectrum[0].statistical.length > 0) {
                                }//if (el.spectrum.length > 0) {
                            });
                        }//if (self.featureEngneeringDatas.feature_config.length == 0) {
                        d1['checked'] = ibool;
                    });

                    var arAmanda = [];
                    self.featureEngneeringDatas.checked.filter(function (a) {
                        if (a.checked) {
                            arAmanda.push(a.abbreviation);
                        }
                    });

                    if (arAmanda.length > 0 && arAmanda.length == iTotalCount)
                        self.chkStatisticalAll = true;

                    store.commit('setShowLoading', false);
                })

        },
        //當User點選All button觸發的事件
        selectAll: function (isAll) {

            var self = this;
            //var pIdx = self.featureEngneeringDatas.feature_config.findIndex(function (item) {
            //    return item.parameter == parameter;
            //});
            var pIdx = 0;

            self.featureEngneeringDatas.all_statisticals.forEach(function (d1) {
                d1['checked'] = $(isAll.target)[0].checked;
            });



            //this.$set(this.featureEngneeringDatas.feature_config[pIdx].all, 'allchecked', $(isAll.target)[0].checked);
            //this.$set(this.featureEngneeringDatas.feature_config[pIdx].all, 'statisticals', currentParameter.all.statisticals);
            self.setAllStyle($(isAll.target)[0].checked);

        },
        //控制點選All Button所要顯示的樣式
        setAllStyle: function (checked) {
            var self = this;
            self.featureEngneeringDatas.all_statisticals.forEach(function (val) {


                var allEl = $('.' + val.abbreviation + '-statisticalBox');

                allEl.each(function (index) {
                    allEl[index].childNodes.forEach(function (element) {
                        if (element.tagName == "SPAN" || element.tagName == "LABEL") {
                            if (checked)
                                element.style.opacity = 0.1;
                            else
                                element.style.opacity = 1;
                        }
                    });


                });
            });
        },
        backClick: function () {
            alertify.confirm("回上一步驟",
                function (e) {
                    if (e) {
                        ////OK
                        ////window.location.href = "/Project/FeatureEngineering";
                        CreateProjectLayoutContiApp.backStatus();
                    } else {
                        //Cancel                      
                    }
                });
        },
        nextClick: function () {

            var self = this;

            alertify.confirm("儲存編輯內容，並前往下一步驟?",
                function (e) {
                    if (e) {
                        //OK
                        self.vaildDataAndSave(function () {
                            //CreateProjectLayoutApp.nextStatus();
                        });

                    } else {
                        //Cancel                      
                    }
                });


        },
        vaildDataAndSave: function () {
            var self = this;

            var arSelFeature = [];
            self.featureEngneeringDatas.all_statisticals.filter(function (a) {
                if (a.checked) {
                    arSelFeature.push(a.abbreviation);
                }
            });

            self.feature_configs = [];

            var item = { "spectrum": [{ "statistical": arSelFeature }] };
            self.feature_configs.push(item);

            if (arSelFeature != null && arSelFeature.length > 0) {
                self.save(function () {
                    self.updateStatus(function () {
                    });

                });
            } else {
                alertify.error('Please Select Statistical Method !!');
            }

            //this.$validator.validateAll().then(function (result) {
            //    if (result) {
            //        self.save(function () {
            //            //CreateProjectLayoutApp.redriectPage(true, null)
            //        });
            //    }
            //    else {
            //        alertify.error('欄位資料填寫錯誤');
            //    }
            //})
        },
        //更新狀態
        updateStatus: function (fu) {
            var self = this;



            //呼叫更新狀態API
            var apiUrl = "/model_training";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPut(apiUrl).reply(200, { "code": 200, "data": {}, "description": "Successful response", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            axios({
                method: 'put',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    offline_model_status: 1401
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        CreateProjectLayoutContiApp.nextStatus();
                    }
                    else
                        alertify.alert("操作失敗，請重新操作，謝謝!");
                })

        },
        //呼叫API儲存資料
        save: function (fn) {
            var self = this;

            var apiUrl = "/continuous/feature_engineering";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                status: "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'post',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    model_id: store.getters.getCurrentModelId,
                    feature_config: self.feature_configs,
                }

            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        alertify.success("Save Success");
                        if (fn) {
                            setTimeout(fn, 500);
                        }
                    }
                    else {
                        alertify.success("Save fail");
                    }
                })

        },




    }
})