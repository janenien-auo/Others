﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {
        projectName: 'This is project name',
        isNull: false,
        chamber_list_available: [],
        chamber_list_acquisition: [],
        datalist: [],
        startTime: moment(new Date()).format('YYYY-MM-DD hh:mm:ss'),
        endTime: moment(new Date()).format('YYYY-MM-DD hh:mm:ss'),
        pickerOptions: {//控制elementUI不能選今天以後的日期
            disabledDate(time) {
                return time.getTime() > Date.now();
            },
        },  
        chamber_list:[],
    },
    mounted: function () {
        var self = this;
        self.init();

    },
    methods: {
        init: function () {

            //store.commit('setShowLoading', true);

            var self = this;


            store.commit('setDefaultProjectId');
            store.commit('setProjectInfo');
            self.projectInfo = store.getters.getCurrentProjectInfo;
            self.projectName = self.projectInfo.fab + "-" + self.projectInfo.stage + "-" + self.projectInfo.func + "-" + self.projectInfo.ai365_project_name + "-" + self.projectInfo.model_type + "-" + self.projectInfo.project_id;
            self.getAvailableParameterPromise().then(function () {
                self.getAcquisitionParameterPromise().then(function () {
                    self.getToolChamberListPromise().then(function () {



                        

                    });
                });
            });






            store.commit('setShowLoading', false);
        },
        getToolChamberListPromise: function () {
            var self = this;


            return new Promise(function (resolve, reject) {


                var apiUrl = "/project_tool_chamber_list";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        tool_chamber_list: [
                            {
                                tool_id: "AAIEX100",
                                chamber: "C100",
                                real_chamber: [
                                    "COATER",
                                    "LC_DRY"
                                ]
                            },
                            {
                                tool_id: "AAIEX200",
                                chamber: "C200",
                                real_chamber: [
                                    "COATER",
                                    "LC_DRY"
                                ]
                            },
                            {
                                tool_id: "AAIEX300",
                                chamber: "C300",
                                real_chamber: [
                                    "COATER",
                                    "LC_DRY"
                                ]
                            },
                        ],
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {

                                var iCnt = 0;
                                var arTmp = [], arTC = [];
                                $.each(response.data.data.tool_chamber_list, function (index, objTool) {
                                    $.each(objTool.real_chamber_list, function (idx, val) {
                                        arTmp.push(val);
                                    });
                                    arTC.push(objTool.tool_id + "/" + objTool.chamber);
                                });

                                var result = arTmp.filter(function (element, index, arr) {
                                    return arr.indexOf(element) === index;
                                });

                                var resultTC = arTC.filter(function (element, index, arr) {
                                    return arr.indexOf(element) === index;
                                });


                                $.each(result, function (index, value) {
                                    var chamber = value;
                                    var arParamAvailable = [];
                                    var result_available = self.chamber_list_available.map(function (val, idx, ary){
                                        if (val.chamber == chamber) {
                                            arParamAvailable = val.parameter_list;
                                            return val;
                                        }
                                    });

                                    var arParamAcquisition = [];
                                    var result_acquisition = self.chamber_list_acquisition.map(function (val, idx, ary) {
                                        if (val.chamber == chamber) {
                                            arParamAcquisition = val.parameter_list;
                                            return val;
                                        }
                                    });

 




                                    var item = {
                                        "item": ++iCnt, "tool": resultTC.join().replace(",","\n"), "chamber": chamber, "parameter_list": arParamAcquisition, "available_parameter": arParamAvailable
                                    };

                                    self.datalist.push(item);

                                });

                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        getAvailableParameterPromise: function () {
            var self = this;


            return new Promise(function (resolve, reject) {


                var apiUrl = "/continuous/available_parameter";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        parameter_list: [
                            "ESD_VOLTAGE",
                            "PARTICLE_05U_1MIN_AVG",
                            "PARTICLE_05U_1MIN_SUM",
                            "PARTICLE_05U_HIGHEST",
                            "PARTICLE_1U_1MIN_AVG",
                            "PARTICLE_1U_1MIN_SUM",
                            "PARTICLE_1U_HIGHEST",
                            "RESIST_N2",
                        ]
                    }
                });
                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {
                                self.chamber_list_available = response.data.data.chamber_list;
                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        getAcquisitionParameterPromise: function () {
            var self = this;


            return new Promise(function (resolve, reject) {


                var apiUrl = "/continuous/acquisition_parameter";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        parameter_list: [
                            "ESD_VOLTAGE",
                            "RESIST_N2",
                        ],
                        acquisition_period: {
                            start_datetime: "2020-09-01 12:34:56",
                            end_datetime: "2020-09-03 12:34:56"
                        }
                    }
                });
                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {
                                self.chamber_list_acquisition = response.data.data.chamber_list;
                                //self.acquisitionPeriods = response.data.data.acquisition_period;
                                if (response.data.data.acquisition_period.end_datetime != null)
                                    self.endTime = response.data.data.acquisition_period.end_datetime;
                                if (response.data.data.acquisition_period.start_datetime != null)
                                    self.startTime = response.data.data.acquisition_period.start_datetime;
                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },

        chooseDate: function () {
            var self = this;

            if (self.startTime > self.endTime) {
                alertify.error("日期選擇錯誤");

                self.endTime = self.startTime;

            }

        },
        backClick: function () {
            alertify.confirm("回上一步驟",
                function (e) {
                    if (e) {
                        ////OK
                        ////window.location.href = "/Project/FeatureEngineering";
                        CreateProjectLayoutApp.backStatus();
                    } else {
                        //Cancel                      
                    }
                });
        },
        changeValue: function (event, item) {
            

        },
        //資料驗證
        vaildDataAndSave: function (fn) {
            var self = this;
            self.isNull = false;
            self.datalist.forEach(function (val, idx) {
                if (val.parameter_list.length == 0) {
                    self.isNull = true;
                }
            });

            if (self.isNull == true) {
                alertify.error('Please Select Parameter !!');
            }

            if (self.isNull == false) {
                
                self.SaveParamData(function () {
                    CreateProjectLayoutContiApp.nextStatus();
                });
               
            }
        },
        //儲存按鈕觸發事件
        saveClick: function () {
            var self = this;

            alertify.confirm("儲存編輯中的內容?",
                function (e) {
                    if (e) {
                        //OK
                        self.vaildDataAndSave();
                    } else {
                        //Cancel                      
                    }
                });
        },

        nextClick: function () {

            var self = this;
            alertify.confirm("前往下一步驟",
                function (e) {
                    if (e) {
                        ////OK
                        ////window.location.href = "/Project/FeatureSelection";
                        self.vaildDataAndSave(function () {  });

                        //CreateProjectLayoutApp.nextStatus();

                    } else {
                        //Cancel                      
                    }
                });


        },
        //Next : Save parameter_list & acquisition_period
        SaveParamData: function (fn) {

            var self = this;

            var apiUrl = "/continuous/acquisition_parameter";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {

                status: "OK",
            });


            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }



            axios({
                method: 'post',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                headers: { 'Content-Type': 'application/json' },
                data: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    chamber_list: self.datalist,
                    acquisition_period: {
                        start_datetime: self.startTime,
                        end_datetime: self.endTime
                    },
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        alertify.success("Save Success");
                        if (fn) {
                            setTimeout(fn, 500);
                        }

                    } else {
                        alertify.success("Save fail");
                        //self.nextClick();
                    }
                })
        },
        
        getToolChamberList: function () {

            var self = this;


            var apiUrl = "/project_tool_chamber_list";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: {
                    tool_chamber_list: [
                        {
                            tool_id: "AAIEX100",
                            chamber: "C100",
                            real_chamber: [
                                "COATER",
                                "LC_DRY"
                            ]
                        },
                        {
                            tool_id: "AAIEX200",
                            chamber: "C200",
                            real_chamber: [
                                "COATER",
                                "LC_DRY"
                            ]
                        },
                        {
                            tool_id: "AAIEX300",
                            chamber: "C300",
                            real_chamber: [
                                "COATER",
                                "CLEANER_AK"
                            ]
                        },
                    ],
                }
            });

            if (store.getters.getEnv == 'prd2') {
                mock.restore();
            }

            var self = this;

            var responseData = {};
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                }
            })
                .then(function (response) {

                    responseData = response.data.data;
                    if (response.data.status == "OK") {
                        var iCnt = 0;
                        $.each(response.data.data.tool_chamber_list, function (index, objTool) {
                            var item = { "item": ++iCnt, "tool": objTool.tool_id, "chamber": objTool.chamber, "real_chamber": objTool.real_chamber.join(), "item_count": response.data.data.tool_chamber_list.length };
                            self.datalist.push(item);
                        });
                        if (self.datalist.length >= 1)
                            self.subjectType = "multiple";
                    } else
                        alertify.error("get data fail. error message = " + response.data.data.message);
                })

        },    
        DistinctArray: function (arTmp) {
            var result = [];
            var map = new Map();

            arTmp.forEach(function (item, index, array) {

                if (!map.has(item)) {
                    map.set(item, true);    // set any value to Map
                    result.push({
                        real_chamber: item,
                    });
                }
            });
            return result;
        },



    }
})