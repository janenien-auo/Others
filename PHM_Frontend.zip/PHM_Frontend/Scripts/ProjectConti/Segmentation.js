﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {
        closeEstoneList: [],
        projectName: 'This is project name',
        datalist: [],
        segmentations: store.getters.getSegmentations,
        segmentation: 'regular', //mode
        regulartimes: store.getters.getRegulartimes, 
        regular_hour: 4,
        rollings: [],
        rolling_hour:null,
    },
    mounted: function () {
        var self = this;
        self.init();

    },
    methods: {
        init: function () {

            //store.commit('setShowLoading', true);

            var self = this;


            store.commit('setDefaultProjectId');
            store.commit('setProjectInfo');
            self.projectInfo = store.getters.getCurrentProjectInfo;
            self.projectName = self.projectInfo.fab + "-" + self.projectInfo.stage + "-" + self.projectInfo.func + "-" + self.projectInfo.ai365_project_name + "-" + self.projectInfo.model_type + "-" + self.projectInfo.project_id;
            self.getSegmentationSettingPromise().then(function () {
                self.getRollings();
            });

            store.commit('setShowLoading', false);
        },
        getRollings: function () {

            var self = this;
            if (self.segmentation == "rolling") {
                self.rollings = [];
                var iRolling = self.regular_hour - 1;
                for (var i = 1; i <= iRolling; i++) {
                    self.rollings.push(parseInt(i));
                }
            } else {
                self.rolling_hour = null;
            }

        }, 
        getSegmentationSettingPromise: function () {
            var self = this;
            self.datalist = [];

            return new Promise(function (resolve, reject) {


                var apiUrl = "/continuous/segmentation_setting";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        mode: "rolling",
                        regular_hour: 4,
                        rolling_hour: 2
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {
                                if (response.data.data.mode != null)
                                    self.segmentation = response.data.data.mode;
                                if (response.data.data.regular_hour != null)
                                    self.regular_hour = response.data.data.regular_hour;
                                if (response.data.data.rolling_hour != null)
                                    self.rolling_hour = response.data.data.rolling_hour;

                                
                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        backClick: function () {
            alertify.confirm("回上一步驟",
                function (e) {
                    if (e) {
                        ////OK
                        ////window.location.href = "/Project/FeatureEngineering";
                        CreateProjectLayoutContiApp.backStatus();
                    } else {
                        //Cancel                      
                    }
                });
        },
        nextClick: function () {

            var self = this;

            alertify.confirm("儲存編輯內容，並前往下一步驟?",
                function (e) {
                    if (e) {
                        //OK
                        self.vaildDataAndSave(function () {
                            
                        });

                    } else {
                        //Cancel                      
                    }
                });


        },
        vaildDataAndSave: function () {
            var self = this;
            this.$validator.validateAll().then(function (result) {
                if (result) {
                    self.save(function () {
                        self.updateStatus(function () {
                            
                        });
                        
                    });
                }
                else {
                    alertify.error('欄位資料填寫錯誤');
                }
            })
        },
        //更新狀態
        updateStatus: function (fu) {
            var self = this;
     


            //呼叫更新狀態API
            var apiUrl = "/model_training";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPut(apiUrl).reply(200, { "code": 200, "data": {}, "description": "Successful response", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }


            axios({
                method: 'put',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    offline_model_status: 1201
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        CreateProjectLayoutContiApp.nextStatus();
                    }
                    else
                        alertify.alert("操作失敗，請重新操作，謝謝!");
                })

        },

        //呼叫API儲存資料
        save: function (fn) {
            var self = this;

            var apiUrl = "/continuous/segmentation_setting";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                status: "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'post',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    model_id: store.getters.getCurrentModelId,
                    mode: self.segmentation.toLowerCase(),
                    regular_hour: self.regular_hour,
                    rolling_hour: self.rolling_hour
                }

            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        alertify.success("Save Success");
                        if (fn) {
                            setTimeout(fn, 500);
                        }
                    }
                    else {
                        alertify.success("Save fail");
                    }
                })

        },
        //clickSave: function () {
        //    var self = this;


        //    this.$validator.validateAll().then(function (result) {
        //        if (result) {
        //            self.closeEstone();
        //        }
        //        else {
        //            alertify.error('欄位資料填寫錯誤');
        //        }
        //    })
        //},


        //closeEstone: function () {
        //    var self = this;


        //    var data = {
        //        project_id: self.projectInfo.project_id,
        //        model_id: self.projectInfo.model_id,
        //        tool_id: self.closeEventDetail.tool_id,
        //        chamber: self.closeEventDetail.chamber,
        //        event_type: self.eventType,
        //        component: self.component,
        //        alarm_code: '',
        //        solution: self.solution,
        //        action_time: moment(self.actionTime).format('YYYY-MM-DD hh:mm'),
        //        note: self.note,
        //        source: "event",
        //        event_id_list: self.closeEventDetail.event_id_list
        //    };


        //    postMaintainRecord(data, false)
        //        .then(function (response) {


        //            alertify.alert('儲存成功!', function () { window.location = "/online/RecordHistory"; });

        //        }).catch(function (err) {
        //            store.commit('setShowLoading', false);
        //        })

        //}



    }
})