﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {
        closeEstoneList: [],
        projectName: 'This is project name',
        chamber_list_acquisition: [],
        imputation_setting_list: [],
        datalist: [],
        samplings: store.getters.getSamplings,
        sampling: '',
        showDataCheckPreview: false,
        showDataCheckPreviewBtn: true,
        keyWord: "",
        searchKeys: ["tool_id", "chamber", "parameter","sampling_rate"],
        filterToolChamberList: [],
        filterToolChamberListByPage: [],
        Pagination: {
            current_page: 1,
            page_size: 10,
            total: 0
        },
        ChartDatas: [],
        tool_id: '',
        chamber: '',
        parameter: '',
        startTime: moment(new Date()).add(-1, 'days').format('YYYY-MM-DD hh:mm:ss'),
        endTime: moment(new Date()).format('YYYY-MM-DD hh:mm:ss'),
    },
    mounted: function () {
        var self = this;
        self.init();
 
    },
    methods: {
        init: function () {

            //store.commit('setShowLoading', true);

            var self = this;
            

            store.commit('setDefaultProjectId');
            store.commit('setProjectInfo');
            self.projectInfo = store.getters.getCurrentProjectInfo;
            self.projectName = self.projectInfo.fab + "-" + self.projectInfo.stage + "-" + self.projectInfo.func + "-" + self.projectInfo.ai365_project_name + "-" + self.projectInfo.model_type + "-" + self.projectInfo.project_id;
            self.getAcquisitionParameterPromise().then(function () {
                self.getImputationSettingPromise().then(function () {
                    self.getToolChamberListPromise().then(function () {

                    });
                });
            });

            //var closeEventDetailStr = window.localStorage.getItem('closeeventdetail');

            //if (closeEventDetailStr) {
            //    self.closeEventDetail = JSON.parse(closeEventDetailStr);


            //    //self.projectName = self.closeEventDetail.

            //}

            store.commit('setShowLoading', false);
        },


        getImputationSettingPromise: function () {
            var self = this;
            self.datalist = [];

            return new Promise(function (resolve, reject) {


                var apiUrl = "/continuous/imputation_setting";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        tool_chamber_list: [
                            {
                                tool_id: "AAIEX100",
                                chamber: "COATER",
                                parameter: "P1",
                                sampling_rate: ''
                            },
                            {
                                tool_id: "AAIEX100",
                                chamber: "DRY",
                                parameter: "P1",
                                sampling_rate: 6
                            },
                            {
                                tool_id: "AAIEX200",
                                chamber: "COATER",
                                parameter: "P2",
                                sampling_rate: 10
                            },
                            {
                                tool_id: "AAIEX200",
                                chamber: "DRY",
                                parameter: "P2",
                                sampling_rate: 1
                            }
                        ]
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {

                                var iCnt = 0;
                                self.imputation_setting_list = response.data.data.tool_chamber_list;

                                self.imputation_setting_list.forEach(function (d) {

                                    d['item'] = ++iCnt;

                                });

                                

                                //$.each(response.data.data.tool_chamber_list, function (index, objTool) {
                                //    var item = { "item": ++iCnt, "tool": objTool.tool_id, "chamber": objTool.chamber, "parameter": objTool.parameter, "sampling_rate": objTool.sampling_rate };

                                //    self.datalist.push(item);
                                //});


                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        getAcquisitionParameterPromise: function () {
            var self = this;


            return new Promise(function (resolve, reject) {


                var apiUrl = "/continuous/acquisition_parameter";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        parameter_list: [
                            "ESD_VOLTAGE",
                            "RESIST_N2",
                        ],
                        acquisition_period: {
                            start_datetime: "2020-09-01 12:34:56",
                            end_datetime: "2020-09-03 12:34:56"
                        }
                    }
                });
                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {
                                self.chamber_list_acquisition = response.data.data.chamber_list;

                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        getToolChamberListPromise: function () {
            var self = this;


            return new Promise(function (resolve, reject) {


                var apiUrl = "/project_tool_chamber_list";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    data: {
                        tool_chamber_list: [
                            {
                                tool_id: "AAIEX100",
                                chamber: "C100",
                                real_chamber: [
                                    "COATER",
                                    "LC_DRY"
                                ]
                            },
                            {
                                tool_id: "AAIEX200",
                                chamber: "C200",
                                real_chamber: [
                                    "COATER",
                                    "LC_DRY"
                                ]
                            },
                            {
                                tool_id: "AAIEX300",
                                chamber: "C300",
                                real_chamber: [
                                    "COATER",
                                    "LC_DRY"
                                ]
                            },
                        ],
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {

                                var iCnt = 0;
                               


                                $.each(response.data.data.tool_chamber_list, function (index, objTool) {
                                    $.each(self.chamber_list_acquisition, function (idx, val) {                                    
                                        $.each(val.parameter_list, function (idx2, val2) {
                                            var sampling_rate;
                                            var result = self.imputation_setting_list.map(function (item, idx, ary) {
                                                if (item.chamber == val.chamber && item.parameter == val2 && item.tool_id == objTool.tool_id) {
                                                    sampling_rate = item.sampling_rate;
                                                    return item;
                                                }
                                            });

                                            var items = {
                                                "item": ++iCnt, "tool_id": objTool.tool_id, "chamber": val.chamber, "parameter": val2, "sampling_rate": sampling_rate
                                            };

                                            self.datalist.push(items);
                                        });
                                    });
                                });

                                self.filterToolChamber();
   

                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },
        //過濾Keyword資料
        filterToolChamber: function () {
            
            var self = this;

            if (!self.keyWord) {
                self.filterToolChamberList = self.datalist;
                self.Pagination.total = self.filterToolChamberList.length;
                self.handleChangePage(1);
                return;
            }

            self.filterToolChamberList = [];

            var keywords = self.keyWord.split(' ');

            self.$search(keywords, self.datalist, self.searchKeys, null, 0.1).then(
                function (response) {
                    response.forEach(function (d) {
                        self.filterToolChamberList.push(d.item);
                    })

                    self.Pagination.total = self.filterToolChamberList.length;

                    self.handleChangePage(1);


                }
            );
        },     
        //換頁
        handleChangePage: function (val) {
            var self = this;
            self.Pagination.current_page = val;

            var startIndex = (self.Pagination.current_page - 1) * self.Pagination.page_size;
            if (startIndex < 0) startIndex = 0;

            if (startIndex > self.Pagination.total) startIndex = 0;

            var endIndex = (self.Pagination.current_page * self.Pagination.page_size);
            if (endIndex >= self.filterToolChamberList.length) endIndex = self.filterToolChamberList.length;
            self.filterToolChamberListByPage = self.filterToolChamberList.slice(startIndex, endIndex);
        },
        viewDataCheckPreview: function (tool_id, chamber, parameter) {
            var self = this;
            self.tool_id = tool_id;
            self.chamber = chamber;
            self.parameter = parameter;
                
            self.showDataCheckPreview = true;
            self.getDataCheckPreview(tool_id, chamber, parameter)
            

            //self.getDataCheckPreview();
        },
        getDataCheckPreview: function (tool_id, chamber, parameter) {
            var self = this;


            var apiUrl = "/continuous/continuous_preview";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data:
                {

                    datetime: ["2020-08-01 12:34:56.333", "2020-08-01 12:34:56.666", "2020-08-01 12:34:57"],
                    value: [1, 2, 3]
                }


            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;


            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    model_id: store.getters.getCurrentModelId,
                    tool_id: tool_id,
                    chamber: chamber,
                    parameter: parameter,
                    start_datetime: self.startTime,
                    end_datetime: self.endTime,
                }

            })
                .then(function (response) {
                    if (response.data.status == "OK") {

                        self.ChartDatas = response.data.data;
                        self.DrawDataCheckChart();
                    }
                })


        },
        DrawDataCheckChart: function () {
            //var arColor = ['#00B0F0', '#00EACD', '#43A047', '#92D050', '#D05052', '#FF7800', '#FFFF00', '#A349A4', '#F06292', '#7E57C2', '#02B9C4', '#5292B3', '#DAF7A6', '#49ff33', '#b9e7ff', '#83B9C7', '#2ACDC9', '#FFD000', '#7CFEF0', '#d7f96e'];
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            var self = this;

            var _series = [], _legend = [], _xAxis = [];
            _xAxis = [];
            _legend.push("Continuous Data Chart PreView");
            _series.push({ name: "RawData", data: self.ChartDatas.value, type: 'line', symbol: '', smooth: true, itemStyle: { color: arColor[0] } });

            var iTotalPoint = self.ChartDatas.datetime.length;
            var myChart = echarts.init(document.getElementById("DataCheckChart"), 'default');
            myChart.clear();

            /*  去除加载缓冲图 */
            myChart.showLoading({
                text: 'Loading...',
                textStyle: { fontSize: 30, color: '#444' },
                effectOption: { backgroundColor: 'rgba(0, 0, 0, 0)' }
            });

            var option = {
                backgroundColor: '#545655',//背景色
                tooltip: {
                    trigger: 'axis',
                    textStyle: {
                        fontSize: 11
                    }


                },

                legend: {
                    //type: 'scroll',
                    orient: 'vertical',
                    //x: 'right',
                    //y: 'top',
                    show: false,
                    borderWidth: 2,
                    padding: 2,
                    itemGap: 5,
                    right: '1%',
                    top: '10%',
                    
                    color: '#02B9C4',
                    data: _legend,
                    selected: {
                        'RawData': true

                    },
                    bottom: '50%',
                    textStyle: {
                        color: '#CDEDED',
                        fontSize: '10'
                    },

                    //selected: 1
                }, grid: {
                    x: '7%',
                    y: '7%',
                    width: '85%',
                    height: '60%',
                    show: false,
                    borderColor: 'red'
                },
                toolbox: {
                    show: true,
                    feature: {
                        mark: { show: true },
                        dataZoom: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#ec7063'
                                }
                            }
                        },
                        dataView: {
                            show: false, readOnly: false, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#e59866'
                                }
                            }
                        },
                        restore: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#8e44ad'
                                }
                            }
                        },
                        saveAsImage: {
                            show: true, type: 'png', excludeComponents: ['toolbox'], pixelRatio: 2, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#2ecc71',
                                    shadowColor: 'rgba(0, 0, 0, 0.5)',
                                    shadowBlur: 10
                                }
                            }
                        }
                    }
                },
                xAxis: [
                    {
                        type: 'category',
                        triggerEvent: true,
                        boundaryGap: true,
                        data: self.ChartDatas.datetime,



                        axisTick: {
                            show: false,
                            alignWithLabel: true
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变x轴颜色
                        axisLine: {
                            show: true,
                            onZero: false,
                            position: 'end',
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        //  改变x轴字体颜色和大小
                        axisLabel: {
                            show: true,
                            rotate: 90,
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                    }
                ],

                yAxis: [
                    {
                        //  隐藏y轴
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },

                        // 去除y轴上的刻度线
                        axisTick: {
                            show: false
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变y轴字体颜色和大小
                        axisLabel: {
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                        type: 'value',
                        triggerEvent: true
                    }
                ],

                dataZoom: [{
                    type: 'inside',
                    start: 0,
                    end: 100
                }, {
                    start: 0,
                    end: 100,
                    handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                    handleSize: '80%',
                    handleStyle: {
                        color: '#fff',
                        shadowBlur: 3,
                        shadowColor: 'rgba(0, 0, 0, 0.6)',
                        shadowOffsetX: 2,
                        shadowOffsetY: 2
                    }
                }],
                series: _series
            };


            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option, true);
        },
        backClick: function () {
            alertify.confirm("回上一步驟",
                function (e) {
                    if (e) {
                        ////OK
                        ////window.location.href = "/Project/FeatureEngineering";
                        CreateProjectLayoutContiApp.backStatus();
                    } else {
                        //Cancel                      
                    }
                });
        },
        nextClick: function () {

            var self = this;

            alertify.confirm("儲存編輯內容，並前往下一步驟?",
                function (e) {
                    if (e) {
                        //OK
                        self.vaildDataAndSave(function () {
                            //CreateProjectLayoutApp.nextStatus();
                        });

                    } else {
                        //Cancel                      
                    }
                });


        },
        //儲存按鈕觸發事件
        saveClick: function () {
            var self = this;

            alertify.confirm("儲存編輯中的內容?",
                function (e) {
                    if (e) {
                        //OK
                        self.vaildDataAndSave();
                    } else {
                        //Cancel                      
                    }
                });
        },
        vaildDataAndSave: function () {
            var self = this;
            this.$validator.validateAll().then(function (result) {
                if (result) {
                    self.save(function () {
                        CreateProjectLayoutContiApp.nextStatus();
                    });
                }
                else {
                    alertify.error('欄位資料填寫錯誤');
                }
            })
        },
        //呼叫API儲存資料
        save: function (fn) {
            var self = this;

            var apiUrl = "/continuous/imputation_setting";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                status: "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'post',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    model_id: store.getters.getCurrentModelId,
                    tool_chamber_list: self.datalist,
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        alertify.success("Save Success");
                        if (fn) {
                            setTimeout(fn, 500);
                        }
                    }
                    else {
                        alertify.success("Save fail");
                    }
                })

        },


        //clickSave: function () {
        //    var self = this;


        //    this.$validator.validateAll().then(function (result) {
        //        if (result) {
        //            self.closeEstone();
        //        }
        //        else {
        //            alertify.error('欄位資料填寫錯誤');
        //        }
        //    })
        //},


        //closeEstone: function () {
        //    var self = this;


        //    var data = {
        //        project_id: self.projectInfo.project_id,
        //        model_id: self.projectInfo.model_id,
        //        tool_id: self.closeEventDetail.tool_id,
        //        chamber: self.closeEventDetail.chamber,
        //        event_type: self.eventType,
        //        component: self.component,
        //        alarm_code: '',
        //        solution: self.solution,
        //        action_time: moment(self.actionTime).format('YYYY-MM-DD hh:mm'),
        //        note: self.note,
        //        source: "event",
        //        event_id_list: self.closeEventDetail.event_id_list
        //    };


        //    postMaintainRecord(data, false)
        //        .then(function (response) {


        //            alertify.alert('儲存成功!', function () { window.location = "/online/RecordHistory"; });

        //        }).catch(function (err) {
        //            store.commit('setShowLoading', false);
        //        })

        //}



    }
})