﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {
        filterSetting: {
            tool_id: '',
            virtual_chamber:'',
            chamber: '',
            recipe: '',
            step:'',
            parameter: '',
            data_filter: {
                start_end: {
                    check: false,
                    value: 15
                },
                x_diff: {
                    check: false,
                    value: 12
                },
                data_length_diff: {
                    check: false,
                    value: 2
                }
            }           
        },
        currentAppliction: store.getters.getCurrentProjectInfo.application,        
        //currentAppliction: 'Robot',       
        available_chamber: [],
        available_recipe: [],
        available_step: [],
        available_parameter: [],
        getParameterSelectResponse: {},
        filterSettingList: [],
        isVaild: true //Application如果為 Robot，就一定要設定一筆Step為ALL的Filter，而且這個Filter是三個條件都要選
    },
    mounted: function () {
        var self = this;
        self.init();

    },
    methods: {
        init: function () {
            var self = this;

            self.getDataFilter();
            self.getParameterSelect();  

            store.commit('setShowLoading', false);
        },

        getParameterSelect: function () {
            var self = this;

            var apiUrl = "/raw_data/acquisition_parameter";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                "data": {
                    "acquisition_period": {
                        "start_datetime": "2020-11-10 04:07:18",
                        "end_datetime": "2020-11-17 04:07:18"
                    },
                    "tool_list": [
                        {
                            "tool_id": "T1",
                            "chamber_list": [
                                {
                                    "chamber": "C1",
                                    "recipe_list": [
                                        {
                                            "recipe": "R1",
                                            "step_list": [
                                                "ALL",
                                                "S1",
                                                "S2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P3"
                                            ]
                                        },
                                        {
                                            "recipe": "R2",
                                            "step_list": [
                                                "S1",
                                                "S2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P3"
                                            ]
                                        }
                                    ]
                                },
                                {
                                    "chamber": "C2",
                                    "recipe_list": [
                                        {
                                            "recipe": "R1",
                                            "step_list": [
                                                "ALL",
                                                "0"
                                            ],
                                            "parameter_list": [
                                                "P3",
                                                "P4"
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "virtual_chamber": "VC1"
                        },
                        {
                            "tool_id": "T2",
                            "chamber_list": [
                                {
                                    "chamber": "C1",
                                    "recipe_list": [
                                        {
                                            "recipe": "R2",
                                            "step_list": [
                                                "0",
                                                "1"
                                            ],
                                            "parameter_list": [
                                                "P2",
                                                "P3"
                                            ]
                                        },
                                        {
                                            "recipe": "R4",
                                            "step_list": [
                                                "0",
                                                "1"
                                            ],
                                            "parameter_list": [
                                                "P2",
                                                "P3"
                                            ]
                                        }
                                    ]
                                },
                                {
                                    "chamber": "C2",
                                    "recipe_list": [
                                        {
                                            "recipe": "R5",
                                            "step_list": [
                                                "ALL",
                                                "0"
                                            ],
                                            "parameter_list": [
                                                "P3",
                                                "P4"
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "virtual_chamber": "VC2"
                        }
                    ]
                }
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;

            var responseData = {};

            return new Promise(function (resolve, reject) {

                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        model_id: store.getters.getCurrentModelId,
                        start_datetime: self.startTime,
                        end_datetime: self.endTime,
                    }
                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            self.getParameterSelectResponse = response.data.data;                            
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);
                    })

            })
        },

        getDataFilter: function () {

            var self = this;



            var apiUrl = "/raw_data/data_filter";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "data": {
                    "filter_list": [
                        {
                            "tool_id": "T1",
                            "chamber": "C1",
                            "virtual_chamber": "VC1",
                            "recipe": "R1",
                            "step": "S1",
                            "parameter": "P1",
                            "data_filter": {
                                "start_end": 15,
                                "x_diff": 12,
                                "data_length_diff": 2
                            }
                        }
                    ]
                },
                "code": 200,
                "description": "",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }



            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId
                }
             })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.filterSettingList = response.data.data.filter_list;
                    } else
                        alertify.error(response.data.data.message);
                });
        },

        changeTool: function () {

            var self = this;

            $.each(self.getParameterSelectResponse.tool_list, function (idxTool, objTool) {
                if (objTool.tool_id == self.filterSetting.tool_id) {
                    self.available_chamber = objTool.chamber_list;
                    self.filterSetting.virtual_chamber = objTool.virtual_chamber
                }
            });       

            self.filterSetting.chamber = '';
            self.filterSetting.recipe = '';
            self.filterSetting.step = '';
            self.filterSetting.parameter = '';

        },

        changeChamber: function () {

            var self = this;

            $.each(self.getParameterSelectResponse.tool_list, function (idxTool, objTool) {
                $.each(objTool.chamber_list, function (idxChamber, objChamber) {
                    if (objTool.tool_id == self.filterSetting.tool_id && objChamber.chamber == self.filterSetting.chamber) {
                        self.available_recipe = objChamber.recipe_list;
                    }
                });
            });  
          
            self.filterSetting.recipe = '';
            self.filterSetting.step = '';
            self.filterSetting.parameter = '';

        },

        changeRecipe: function () {

            var self = this;
            $.each(self.getParameterSelectResponse.tool_list, function (idxTool, objTool) {
                $.each(objTool.chamber_list, function (idxChamber, objChamber) {
                    $.each(objChamber.recipe_list, function (idxRecipe, objRecipe) {

                        if (objTool.tool_id == self.filterSetting.tool_id
                            && objChamber.chamber == self.filterSetting.chamber
                            && objRecipe.recipe == self.filterSetting.recipe) {
                            self.available_step = objRecipe.step_list;
                            self.available_parameter = objRecipe.parameter_list;
                        }
                    });
                });
            });   
           
            self.filterSetting.step = '';
            self.filterSetting.parameter = '';
        },
       

        addTempFilter: function () {
            var self = this;

            var isDuplicate = false;

           

            if (!self.filterSetting.data_filter.start_end.check && !self.filterSetting.data_filter.x_diff.check && !self.filterSetting.data_filter.data_length_diff.check) {
                alertify.alert("Please choose filter define");
                return;
            }

            //檢查重複
            if (self.filterSettingList.length>0) {
                $.each(self.filterSettingList, function (idxFilter, objFilter) {
                    if (objFilter.tool_id == self.filterSetting.tool_id
                        && objFilter.chamber == self.filterSetting.chamber
                        && objFilter.virtual_chamber == self.filterSetting.virtual_chamber
                        && objFilter.recipe == self.filterSetting.recipe
                        && objFilter.step == self.filterSetting.step
                        && objFilter.parameter == self.filterSetting.parameter
                    ) {
                        isDuplicate = true;
                    }
                })
            }

            if (isDuplicate) {
                alertify.alert("The filter define is duplicate,please remove the same filter define first.");
                return;
            }

            var dataFilter = {};

            if (self.filterSetting.data_filter.start_end.check) {

                if (dataFilter.start_end)
                    dataFilter.start_end = self.filterSetting.data_filter.start_end.value;
                else
                    dataFilter["start_end"] = self.filterSetting.data_filter.start_end.value;
            }

            if (self.filterSetting.data_filter.x_diff.check) {

                if (dataFilter.x_diff)
                    dataFilter.x_diff = self.filterSetting.data_filter.x_diff.value;
                else
                    dataFilter["x_diff"] = self.filterSetting.data_filter.x_diff.value;
            }

            if (self.filterSetting.data_filter.data_length_diff.check) {

                if (dataFilter.data_length_diff)
                    dataFilter.data_length_diff = self.filterSetting.data_filter.data_length_diff.value;
                else
                    dataFilter["data_length_diff"] = self.filterSetting.data_filter.data_length_diff.value;
            }            

            self.filterSettingList.push({
                tool_id: self.filterSetting.tool_id,
                virtual_chamber: self.filterSetting.virtual_chamber,
                chamber: self.filterSetting.chamber,
                recipe: self.filterSetting.recipe,
                step: self.filterSetting.step,
                parameter: self.filterSetting.parameter,
                data_filter: dataFilter
            });                       
          
        },

        removeItem: function (d) {
            var self = this;


            self.filterSettingList = self.filterSettingList.filter(function (el) {    
                return el.tool_id != d.tool_id
                    || el.chamber != d.chamber
                    || el.recipe != d.recipe
                    || el.step != d.step
                    || el.parameter != d.parameter;
            });          

        },

        saveDataFilter: function (fn) {
            var self = this;

            //驗證資料
            self.vaildData();
            if (!self.isVaild) return;

            var apiUrl = "/raw_data/data_filter";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                "data": {},
                "code": 200,
                "description": "",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            axios({
                method: 'post',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    model_id: store.getters.getCurrentModelId,
                    filter_list: self.filterSettingList
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        if (fn)
                            fn()

                    } else
                        alertify.error(response.data.data.message);

                });

        },

        backClick: function () {
            var self = this;                    
            
            alertify.confirm("Are you sure back to previous step?",
                function (e) {
                    if (e) {
                        //OK
                        window.location ="/ProjectRawData/ParameterSelectRawData"
                        
                    } else {
                        //Cancel                      
                    }
                });
        },


        vaildData: function () {
            var self = this;           

            //Application如果為 Robot，就一定要設定一筆Step為ALL的Filter，而且這個Filter是三個條件都要選
            if (self.currentAppliction == 'Robot') {
                self.isVaild = false;
                if (self.filterSettingList.length > 0) {
                    $.each(self.filterSettingList, function (idx, obj) {
                        if (obj.step.toLowerCase() == 'all') {
                            if (obj.data_filter.start_end && obj.data_filter.x_diff && obj.data_filter.data_length_diff) {
                                self.isVaild = true;
                            }
                        }
                    });
                }

                if (!self.isVaild) {
                    alertify.alert("The filter need to set one of Step is ALL,and need to set all filter define.");
                }
            }
        },

        saveClick: function () {
            var self = this;

            var callback = function () {
                alertify.success("Save Sussess");
            }


            alertify.confirm("儲存編輯中的內容?",
                function (e) {
                    if (e) {
                        //OK
                        self.saveDataFilter(callback);
                    } else {
                        //Cancel                      
                    }
                });


        },

        nextClick: function () {
            var self = this;

            var callback = function () {
                alertify.success("Save Sussess");
                CreateProjectLayoutRawDataApp.nextStatus();
                //Redirct Data Filter

            }


            alertify.confirm("儲存編輯內容，並前往下一步驟?",
                function (e) {
                    if (e) {
                        //OK
                        self.saveDataFilter(callback);

                    } else {
                        //Cancel                      
                    }
                });   


        }

    }
})