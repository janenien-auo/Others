﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {

    },
    mounted: function () {
        var self = this;
        store.commit('setShowLoading', true);
        self.getProjectInfo();
    },
    methods: {
        getProjectInfo: function () {
            var self = this;
            store.commit("setProjectInfo", self.redriectPage);
        },
        redriectPage: function () {
            CreateProjectLayoutRawDataApp.redriectPage(true, null);
          
        }
    }
})