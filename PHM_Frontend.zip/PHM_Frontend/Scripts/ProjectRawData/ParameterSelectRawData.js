﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {
        startTime: moment(new Date()).add(-7, 'days').format('YYYY-MM-DD hh:mm:ss'),
        endTime: moment(new Date()).format('YYYY-MM-DD hh:mm:ss'),
        getParameterSelectResponse: {},
        recipeCountList: [],
        parameterlist:[],
        toolList: [],
        virtualChamberList: [],
        chamberList: [],
        availableRecipes: [],
        selectedRecipes: [],
        availableSteps: [],
        selectedSteps: [],
        availableParameters: [],
        selectedParameters: [],
        pickerOptions: {//控制elementUI不能選今天以後的日期
            disabledDate(time) {
                return time.getTime() > Date.now();
            },
        },
        showRecipeCount: false,
        getAvailableParameterResponse: {},
        project_tool_chamber_list: [],
        currentAppliction: store.getters.getCurrentProjectInfo.application,
        currentChamberMerge: store.getters.getCurrentProjectInfo.chamber_merge,
        //currentAppliction: 'Pump',
        //currentChamberMerge: false,
        realChamberAmount: 0,
        recipeTotalAmount: 0,
        chamberIntersectionList: [],
        parameterSelectPostRequest: {},
        vaildResult: true,
        algorithm_type: "default",
        algorithms: [],
        chooseAlgorithm:null,
        algorithm_versions: [],
        chooseVersion: null,
        checkAllRecipe: false,
        isShowCustomAlgorithm: store.getters.getIsShowCustomAlgorithm

    },
    //watch: {
    //    checkAllRecipe: function () {
    //        console.log(this.checkAllRecipe);
    //    }
    //},
    mounted: function () {
        var self = this;
        store.commit('setShowLoading', true);
        self.init();
    },
    methods: {
        init: function () {
            var self = this;
           

            self.getParameterSelect().then(
                function () {

                    self.getProjectToolChamberList().then(
                        function () {
                            //self.getRecipeRunCount();
                            //self.getAvailableParameter();   
                            self.prepareParameterlist();

                            store.commit('setShowLoading', false);
                        }
                    )
                }                
            );

            //自訂演算法-取演算法和版本
            self.getProjectAlgorithm();
            self.getAlgorithmList();          

        },
        
        getProjectToolChamberList: function () {
            var self = this;

            var apiUrl = "/project_tool_chamber_list";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                "data": {
                    "tool_chamber_list": [
                        {
                            "tool_id": "T1",
                            "chamber": "VC1",
                            "real_chamber_list": [
                                "C1",
                                "C2"
                            ]
                        },
                        {
                            "tool_id": "T2",
                            "chamber": "VC2",
                            "real_chamber_list": [
                                "C1",
                                "C3"
                            ]
                        }
                    ]
                },
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;


            var responseData = {};

            return new Promise(function (resolve, reject) {

                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId
                    }
                })
                    .then(function (response) {

                        if (response.data.status == "OK") {
                            self.project_tool_chamber_list = response.data.data.tool_chamber_list;
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);


                        resolve();
                    })
            });
        },

        getAvailableParameter: function () {
            var self = this;

            var apiUrl = "/raw_data/available_parameter";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                "data": {
                    "chamber_list": [
                        {
                            "chamber": "C1",
                            "recipe_list": [
                                {
                                    "recipe": "R1",
                                    "run_count": 100,
                                    "step_list": [
                                        "ALL",
                                        "0",
                                        "1"
                                    ],
                                    "parameter_list": [
                                        "R1_P1",
                                        "R1_P2",
                                        "R1_P3"
                                    ]
                                },
                                {
                                    "recipe": "R2",
                                    "run_count": 200,
                                    "step_list": [
                                        "ALL",
                                        "0",
                                        "1"
                                    ],
                                    "parameter_list": [
                                        "R2_P1",
                                        "R2_P2",
                                        "R2_P3"
                                    ]
                                }
                            ]
                        }
                    ]
                },
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;

            var responseData = {};

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    model_id: store.getters.getCurrentModelId,
                    start_datetime: self.startTime,
                    end_datetime: self.endTime,
                }
            })
                .then(function (response) {


                    if (response.data.status == "OK") {
                        self.getAvailableParameterResponse = response.data.data;
                    } else
                        alertify.error("get data fail. error message = " + response.data.data.message);


                })
        },

        getRecipeRunCount: function () {

            var self = this;

            var apiUrl = "/raw_data/available_parameter";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                "data": {
                    "tool_list": [
                        {
                            "tool_id": "T1",
                            "chamber_list": [
                                {
                                    "chamber": "C1",
                                    "recipe_list": [
                                        {
                                            "recipe": "R1",
                                            "run_count": 100,
                                            "step_list": [
                                                "ALL",
                                                "0",
                                                "1",
                                                "2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P2",
                                                "P3",
                                                "P4"
                                            ]
                                        },
                                        {
                                            "recipe": "R2",
                                            "run_count": 200,
                                            "step_list": [
                                                "ALL",
                                                "0",
                                                "1"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P2",
                                                "P3"
                                            ]
                                        },
                                        {
                                            "recipe": "R3",
                                            "run_count": 300,
                                            "step_list": [
                                                "ALL",
                                                "0",
                                                "1"
                                            ],
                                            "parameter_list": [
                                                "P2",
                                                "P3",
                                                "P4"
                                            ]
                                        },
                                        {
                                            "recipe": "R4",
                                            "run_count": 400,
                                            "step_list": [
                                                "0",
                                                "1",
                                                "2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P2",
                                                "P3"
                                            ]
                                        }
                                    ]
                                },
                                {
                                    "chamber": "C2",
                                    "recipe_list": [
                                        {
                                            "recipe": "R1",
                                            "run_count": 100,
                                            "step_list": [
                                                "ALL",
                                                "0",
                                                "1",
                                                "2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P2",
                                                "P3",
                                                "P4"
                                            ]
                                        },
                                        {
                                            "recipe": "R2",
                                            "run_count": 200,
                                            "step_list": [
                                                "ALL",
                                                "0",
                                                "1",
                                                "2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P2",
                                                "P3",
                                                "P4"
                                            ]
                                        },
                                        {
                                            "recipe": "R4",
                                            "run_count": 400,
                                            "step_list": [
                                                "ALL",
                                                "0",
                                                "1",
                                                "2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P2",
                                                "P3",
                                                "P4"
                                            ]
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "tool_id": "T2",
                            "chamber_list": [
                                {
                                    "chamber": "C1",
                                    "recipe_list": [
                                        {
                                            "recipe": "R1",
                                            "run_count": 100,
                                            "step_list": [
                                                "ALL",
                                                "0",
                                                "1",
                                                "2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P2",
                                                "P3",
                                                "P4"
                                            ]
                                        },
                                        {
                                            "recipe": "R2",
                                            "run_count": 200,
                                            "step_list": [
                                                "ALL",
                                                "0",
                                                "1",
                                                "2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P2",
                                                "P3",
                                                "P4"
                                            ]
                                        },
                                        {
                                            "recipe": "R4",
                                            "run_count": 400,
                                            "step_list": [
                                                "ALL",
                                                "0",
                                                "1",
                                                "2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P2",
                                                "P3",
                                                "P4"
                                            ]
                                        }
                                    ]
                                },
                                {
                                    "chamber": "C2",
                                    "recipe_list": [
                                        {
                                            "recipe": "R1",
                                            "run_count": 100,
                                            "step_list": [
                                                "ALL",
                                                "0",
                                                "1",
                                                "2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P2",
                                                "P3",
                                                "P4"
                                            ]
                                        },
                                        {
                                            "recipe": "R2",
                                            "run_count": 200,
                                            "step_list": [
                                                "ALL",
                                                "0",
                                                "1",
                                                "2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P2",
                                                "P3",
                                                "P4"
                                            ]
                                        },
                                        {
                                            "recipe": "R5",
                                            "run_count": 400,
                                            "step_list": [
                                                "ALL",
                                                "0",
                                                "1",
                                                "2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P2",
                                                "P3",
                                                "P4"
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                },
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;

            var responseData = {};

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    model_id: store.getters.getCurrentModelId,
                    start_datetime: self.startTime,
                    end_datetime: self.endTime,
                }
            })
                .then(function (response) {


                    responseData = response.data.data;
                    if (response.data.status == "OK") {

                        self.recipeCountList = responseData.tool_list;                      

                        self.prepareParameterlist();



                    } else {
                        alertify.error("get data fail. error message = " + response.data.data.message);
                    }

                    //顯示Recipe Count列表
                    self.showRecipeCount = true;


                    store.commit('setShowLoading', false);
                })

        },

        getParameterSelect: function () {

            var self = this;

            return new Promise(function (resolve, reject) {

                var apiUrl = "/raw_data/acquisition_parameter";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    status: "OK",
                    "data": {
                        "acquisition_period": {
                            "start_datetime": "2020-11-10 04:07:18",
                            "end_datetime": "2020-11-17 04:07:18"
                        },
                        "tool_list": [
                            {
                                "tool_id": "T1",
                                "chamber_list": [
                                    {
                                        "chamber": "C1",
                                        "recipe_list": [
                                            {
                                                "recipe": "R1",
                                                "step_list": [
                                                    "0",
                                                    "1"
                                                ],
                                                "parameter_list": [
                                                    "P2",
                                                    "P3"
                                                ]
                                            },
                                            {
                                                "recipe": "R2",
                                                "step_list": [
                                                    "0",
                                                    "1"
                                                ],
                                                "parameter_list": [
                                                    "P2",
                                                    "P3"
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "chamber": "C2",
                                        "recipe_list": [
                                            {
                                                "recipe": "R1",
                                                "step_list": [
                                                    "ALL",
                                                    "0"
                                                ],
                                                "parameter_list": [
                                                    "P3",
                                                    "P4"
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "virtual_chamber": "VC1"
                            },
                            {
                                "tool_id": "T2",
                                "chamber_list": [
                                    {
                                        "chamber": "C1",
                                        "recipe_list": [
                                            {
                                                "recipe": "R2",
                                                "step_list": [
                                                    "0",
                                                    "1"
                                                ],
                                                "parameter_list": [
                                                    "P2",
                                                    "P3"
                                                ]
                                            },
                                            {
                                                "recipe": "R4",
                                                "step_list": [
                                                    "0",
                                                    "1"
                                                ],
                                                "parameter_list": [
                                                    "P2",
                                                    "P3"
                                                ]
                                            }
                                        ]
                                    },
                                    {
                                        "chamber": "C2",
                                        "recipe_list": [
                                            {
                                                "recipe": "R5",
                                                "step_list": [
                                                    "ALL",
                                                    "0"
                                                ],
                                                "parameter_list": [
                                                    "P3",
                                                    "P4"
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "virtual_chamber": "VC2"
                            }
                        ]
                    }
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};

                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        model_id: store.getters.getCurrentModelId
                    }
                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            self.getParameterSelectResponse = response.data.data;
                            if (self.getParameterSelectResponse && self.getParameterSelectResponse.tool_list.length > 0) {
                                self.startTime = self.getParameterSelectResponse.acquisition_period.start_datetime;
                                self.endTime = self.getParameterSelectResponse.acquisition_period.end_datetime;
                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);

                        resolve();
                    })

            });
        },

        //準備Parameter選單
        prepareParameterlist: function () {
            var self = this;

            if (self.recipeCountList.length > 0) {
                self.chamberIntersectionList = self.recipeCountList[0].chamber_list;
                self.parameterlist = self.recipeCountList;

                console.log("******1*******")
                console.log("******self.chamberIntersectionList*******")
                console.log(self.chamberIntersectionList);

                console.log("******self.parameterlist*******")
                console.log(self.parameterlist);

            } else if (self.getParameterSelectResponse.tool_list.length > 0) {
                self.chamberIntersectionList = self.getParameterSelectResponse.tool_list[0].chamber_list;
                self.parameterlist = self.getParameterSelectResponse.tool_list;


                console.log("******2*******")
                console.log("******self.chamberIntersectionList*******")
                console.log(self.chamberIntersectionList);

                console.log("******self.parameterlist*******")
                console.log(self.parameterlist);

            }


            /*** 非Robot.CHAMBER非融合模式 ***/
            if (self.currentAppliction != 'Robot' && !self.currentChamberMerge) {

                var stepIntersectionList = [];              
                

                $.each(self.parameterlist, function (index, objtool) {

                    //取得虛擬Chamber
                    var find_tool_chamber_Obj = self.project_tool_chamber_list.find(function (item) {
                        return item.tool_id == objtool.tool_id;
                    })

                    if (self.parameterlist[index].virtualChamber)
                        self.parameterlist[index].virtualChamber = find_tool_chamber_Obj.chamber;
                    else
                        self.parameterlist[index]["virtualChamber"] = find_tool_chamber_Obj.chamber;


                    //用於合併儲存格計算合併的欄位數
                    var recipeAmount = 0;

                    if (!self.toolList.includes(objtool.tool_id)) {
                        self.toolList.push(objtool.tool_id)
                        self.virtualChamberList.push(objtool.virtualChamber)
                    }

                    self.realChamberAmount = self.realChamberAmount + objtool.chamber_list.length;

                    //取得Chamber清單
                    $.each(objtool.chamber_list, function (idx, objchamber) {

                        if (!self.chamberList.includes(objchamber.chamber)) {
                            self.chamberList.push(objchamber.chamber)
                        }

                        self.recipeTotalAmount += objchamber.recipe_list.length;

                        //For RecipeCount表格判斷合併儲存格
                        recipeAmount += objchamber.recipe_list.length;
                        if (self.parameterlist[index].recipeAmount)
                            self.parameterlist[index].recipeAmount = recipeAmount;
                        else
                            self.parameterlist[index]["recipeAmount"] = recipeAmount;

                    });
                })


                $.each(self.chamberIntersectionList, function (idxMainChamber, objMainChamber) {


                    //準備availableSteps
                    var preMergeStep = [];
                    var finalMergeStep = [];
                    self.availableSteps = [];

                    if (objMainChamber.availableSteps)
                        objMainChamber.availableSteps = [];
                    else
                        objMainChamber["availableSteps"] = [];


                    //準備availableParameters
                    var preMergeParameter = [];
                    var finalMergeParameter = [];
                    self.availableParameters = [];

                    if (objMainChamber.availableParameters)
                        objMainChamber.availableParameters = [];
                    else
                        objMainChamber["availableParameters"] = [];


                    //準備MainChamber的ToolList
                    if (objMainChamber.toolList)
                        objMainChamber.toolList = [];
                    else
                        objMainChamber["toolList"] = [];


                    objMainChamber.toolList = self.parameterlist;

                    $.each(objMainChamber.toolList, function (idxTool, objTool) {

                        var selectStep = [];
                        var selectParameter = [];

                        $.each(objTool.chamber_list, function (idxChamber, objChamber) {

                            var recipeSelect = [];

                            //搜尋User的前次設定
                            if (self.getParameterSelectResponse && self.getParameterSelectResponse.tool_list.length > 0) {
                                $.each(self.getParameterSelectResponse.tool_list, function (idxTool_PS, objTool_PS) {
                                    $.each(objTool_PS.chamber_list, function (idxChamber_PS, objChamber_PS) {

                                        if (objTool_PS.tool_id == objTool.tool_id
                                            && objChamber_PS.chamber == objMainChamber.chamber
                                            && objChamber.chamber == objMainChamber.chamber) {

                                            recipeSelect = objChamber_PS.recipe_list.map(function (obj) {
                                                return obj.recipe;
                                            });

                                            if (objChamber.selectedRecipes)
                                                objChamber.selectedRecipes = recipeSelect;
                                            else
                                                objChamber["selectedRecipes"] = recipeSelect;

                                            //20210323-給Select All Recipe使用
                                            if (objChamber.selectedAllRecipes)
                                                objChamber.selectedAllRecipes = false;
                                            else
                                                objChamber["selectedAllRecipes"] = false;


                                            selectStep = objChamber_PS.recipe_list[0].step_list;
                                            selectParameter = objChamber_PS.recipe_list[0].parameter_list;
                                        }
                                    });
                                });
                            } else {
                                //給雙向綁定用的物件
                                if (objTool.selectedRecipes)
                                    objChamber.selectedRecipes = recipeSelect;
                                else
                                    objChamber["selectedRecipes"] = recipeSelect;

                                //20210323-給Select All Recipe使用
                                if (objChamber.selectedAllRecipes)
                                    objChamber.selectedAllRecipes = false;
                                else
                                    objChamber["selectedAllRecipes"] = false;
                            }


                            if (objChamber.chamber == objMainChamber.chamber) {

                                $.each(objChamber.recipe_list, function (index, objRecipe) {

                                    //取得availableSteps
                                    if (idxTool == 0 && index == 0) {
                                        finalMergeStep = objRecipe.step_list;
                                    }

                                    preMergeStep = [];
                                    $.each(finalMergeStep, function (idxS, objS) {
                                        preMergeStep.push(objS);
                                    });

                                    finalMergeStep = [];
                                    $.each(objRecipe.step_list, function (i, obj) {
                                        if (preMergeStep.includes(obj) && !finalMergeStep.includes(obj)) {
                                            finalMergeStep.push(obj)
                                        }
                                    })

                                    objMainChamber.availableSteps = finalMergeStep;

                                    //取得availableParameter
                                    if (idxTool == 0 && index == 0) {
                                        finalMergeParameter = objRecipe.parameter_list;
                                    }
                                    preMergeParameter = [];
                                    $.each(finalMergeParameter, function (idxS, objS) {
                                        preMergeParameter.push(objS);
                                    });

                                    finalMergeParameter = [];

                                    $.each(objRecipe.parameter_list, function (i, obj) {
                                        if (preMergeParameter.includes(obj) && !finalMergeParameter.includes(obj)) {
                                            finalMergeParameter.push(obj);
                                        }
                                    })

                                    objMainChamber.availableParameters = finalMergeParameter;
                                });
                            }
                        });

                        //給雙向綁定用的物件
                        if (objMainChamber.selectedSteps)
                            objMainChamber.selectedSteps = selectStep;
                        else
                            objMainChamber["selectedSteps"] = selectStep;


                        //給雙向綁定用的物件
                        if (objMainChamber.selectedParameters)
                            objMainChamber.selectedParameters = selectParameter;
                        else
                            objMainChamber["selectedParameters"] = selectParameter;
                    })
                })




            }
            else {

                self.realChamberAmount = 0;
                self.recipeTotalAmount = 0;

                //準備availableSteps
                var preMergeStep = [];
                var finalMergeStep = [];
                self.availableSteps = [];


                //準備availableParameters
                var preMergeParameter = [];
                var finalMergeParameter = [];
                self.availableParameters = [];

                self.availableRecipes = [];

                //取得tool清單
                $.each(self.parameterlist, function (index, objtool) {

                    //取得虛擬Chamber
                    var find_tool_chamber_Obj = self.project_tool_chamber_list.find(function (item) {
                        return item.tool_id == objtool.tool_id;
                    })

                    if (self.parameterlist[index].virtualChamber)
                        self.parameterlist[index].virtualChamber = find_tool_chamber_Obj.chamber;
                    else
                        self.parameterlist[index]["virtualChamber"] = find_tool_chamber_Obj.chamber;


                    //用於合併儲存格計算合併的欄位數
                    var recipeAmount = 0;

                    if (!self.toolList.includes(objtool.tool_id)) {
                        self.toolList.push(objtool.tool_id)
                        self.virtualChamberList.push(objtool.virtualChamber)
                    }

                    self.realChamberAmount = self.realChamberAmount + objtool.chamber_list.length;

                    //取得Chamber清單
                    $.each(objtool.chamber_list, function (idx, objchamber) {

                        if (!self.chamberList.includes(objchamber.chamber)) {
                            self.chamberList.push(objchamber.chamber)
                        }

                        /***ROBOT模式***/
                        if (self.currentAppliction == 'Robot') {
                            //取得Recipe清單
                            $.each(objchamber.recipe_list, function (i, objrecipe) {

                                if (!self.availableRecipes.includes(objrecipe.recipe)) {
                                    self.availableRecipes.push(objrecipe.recipe)
                                }

                            });

                            if (self.getParameterSelectResponse && self.getParameterSelectResponse.tool_list[0] && self.getParameterSelectResponse.tool_list[0].chamber_list[0]) {
                                self.selectedRecipes = self.getParameterSelectResponse.tool_list[0].chamber_list[0].recipe_list.map(function (obj) {
                                    return obj.recipe;
                                });

                                self.selectedSteps = self.getParameterSelectResponse.tool_list[0].chamber_list[0].recipe_list[0].step_list;
                                self.selectedParameters = self.getParameterSelectResponse.tool_list[0].chamber_list[0].recipe_list[0].parameter_list;
                            }


                        }
                        /***非ROBOT.CHAMBER融合模式***/
                        else if (self.currentAppliction != 'Robot' && self.currentChamberMerge) {



                            //搜尋User的前次設定(Step.Parameter)
                            if (self.getParameterSelectResponse && self.getParameterSelectResponse.tool_list && self.getParameterSelectResponse.tool_list.length > 0) {
                                self.selectedSteps = self.getParameterSelectResponse.tool_list[0].chamber_list[0].recipe_list[0].step_list;
                                self.selectedParameters = self.getParameterSelectResponse.tool_list[0].chamber_list[0].recipe_list[0].parameter_list;
                                //self.selectedSteps = self.recipeCountList[0].chamber_list[0].recipe_list[0].step_list;
                                //self.selectedParameters = self.recipeCountList[0].chamber_list[0].recipe_list[0].parameter_list;



                                $.each(self.getParameterSelectResponse.tool_list, function (idxTool_PS, objTool_PS) {
                                    $.each(objTool_PS.chamber_list, function (idxChamber_PS, objChamber_PS) {

                                        if (objTool_PS.tool_id == objtool.tool_id && objChamber_PS.chamber == objchamber.chamber) {
                                            var recipeSelect = objChamber_PS.recipe_list.map(function (obj) {
                                                return obj.recipe;
                                            });

                                            if (objchamber.selectedRecipes)
                                                objchamber.selectedRecipes = recipeSelect;
                                            else
                                                objchamber["selectedRecipes"] = recipeSelect;

                                            //20210323-給Select All Recipe使用
                                            if (objchamber.selectedAllRecipes)
                                                objchamber.selectedAllRecipes = false;
                                            else
                                                objchamber["selectedAllRecipes"] = false;
                                        }
                                    });
                                });
                            } else {

                                if (objchamber.selectedRecipes)
                                    objchamber.selectedRecipes = [];
                                else
                                    objchamber["selectedRecipes"] = [];

                                //20210323-給Select All Recipe使用
                                if (objchamber.selectedAllRecipes)
                                    objchamber.selectedAllRecipes = false;
                                else
                                    objchamber["selectedAllRecipes"] = false;

                            }



                            $.each(objchamber.recipe_list, function (ix, objRecipe) {

                                //取得availableSteps
                                if (index == 0 && idx == 0 && ix == 0) {
                                    finalMergeStep = objRecipe.step_list;
                                }

                                preMergeStep = [];
                                $.each(finalMergeStep, function (idxS, objS) {
                                    preMergeStep.push(objS);
                                });

                                finalMergeStep = [];
                                $.each(objRecipe.step_list, function (i, obj) {
                                    if (preMergeStep.includes(obj) && !finalMergeStep.includes(obj)) {
                                        finalMergeStep.push(obj)
                                    }
                                })

                                self.availableSteps = finalMergeStep;

                                //取得availableParameter
                                if (index == 0 && idx == 0 && ix == 0) {
                                    finalMergeParameter = objRecipe.parameter_list;
                                }
                                preMergeParameter = [];
                                $.each(finalMergeParameter, function (idxS, objS) {
                                    preMergeParameter.push(objS);
                                });

                                finalMergeParameter = [];

                                $.each(objRecipe.parameter_list, function (i, obj) {
                                    if (preMergeParameter.includes(obj) && !finalMergeParameter.includes(obj)) {
                                        finalMergeParameter.push(obj);
                                    }
                                })

                                self.availableParameters = finalMergeParameter;
                            })
                        }

                        self.recipeTotalAmount += objchamber.recipe_list.length;

                        //For RecipeCount表格判斷合併儲存格
                        recipeAmount += objchamber.recipe_list.length;
                        if (self.parameterlist[index].recipeAmount)
                            self.parameterlist[index].recipeAmount = recipeAmount;
                        else
                            self.parameterlist[index]["recipeAmount"] = recipeAmount;

                    });

                });

            }

            if (self.currentAppliction == 'Robot') {
                self.changeRecipe();
            }

        },

        changeShowRecipe: function () {
            this.showRecipeCount = !this.showRecipeCount;
        },

        chooseDate: function () {
            var self = this;
            store.commit('setShowLoading', true);
          
           self.getRecipeRunCount();
          
          
        },

        changeRecipe: function () {
            var self = this;
         
         

            if (self.selectedRecipes.length == 0) {
                self.availableSteps = [];
                self.availableParameters = [];
                return;
            }     

            if (self.currentAppliction == 'Robot') {
                $.each(self.parameterlist, function (idxTool, objTool) {

                    $.each(objTool.chamber_list, function (index, objChamber) {

                        var findIndex = objChamber.recipe_list.findIndex(function (d) { return d.recipe == self.selectedRecipes[0] });

                        console.log(findIndex);

                        if (findIndex >= 0) {

                            console.log(objChamber.recipe_list[findIndex].step_list);
                            self.availableSteps = objChamber.recipe_list[findIndex].step_list;

                            console.log(objChamber.recipe_list[findIndex].parameter_list);
                            self.availableParameters = objChamber.recipe_list[findIndex].parameter_list;
                        }
                    });
                });
            } else {
                //清空，給user重新選
                self.selectedSteps = [];
                self.selectedParameters = [];
            }




           

        },

        //解決Vue動態綁定失效的問題
        changeRecipeDataBinding: function (index, idx, val) {
            var self = this;
            self.$set(self.parameterlist, index, self.parameterlist[index]);
        },

        //解決Vue動態綁定失效的問題
        changeStepDataBinding: function (index, val, availableSteps) {
            var self = this;

            self.$set(self.chamberIntersectionList, index, self.chamberIntersectionList[index]);

            //if (self.currentAppliction != 'Robot' && self.currentChamberMerge == false) {
            //    if (val.indexOf('ALL') > -1) {
            //        self.chamberIntersectionList[index].selectedSteps = availableSteps;
            //    }
            //    self.$set(self.chamberIntersectionList, index, self.chamberIntersectionList[index]);
            //}
            //else  {
            //    if (val.indexOf('ALL') > -1) {
            //        self.selectedSteps = availableSteps;
            //    }
            //}
        },

        //解決Vue動態綁定失效的問題
        changeParameterDataBinding: function (index, val) {
            var self = this;
            self.$set(self.chamberIntersectionList, index, self.chamberIntersectionList[index]);
        },

        //非Robot.Chamber非融合的parameterSelectPostRequest
        parameterSelectPostRequest_NotRobot_NotChamberMerge: function () {
            var self = this;
            self.parameterSelectPostRequest = {};

            var tmpParameterSelectPostRequest = self.parameterlist;           
            

            var tempToolList = [];
            $.each(tmpParameterSelectPostRequest, function (idxTool, objTool) {

                var tempChamberList = [];
                $.each(objTool.chamber_list, function (idxChamber, objChamber) { 

                    var selectRecipes = [];

                    //判斷該recipe有沒有被選
                    $.each(self.chamberIntersectionList, function (idxMainChamber, objMainChamber) {
                        $.each(objMainChamber.toolList, function (idxMainTool, objMainTool) {
                            $.each(objMainTool.chamber_list, function (indexChamber, objectChamber) {
                                if (objMainChamber.chamber == objChamber.chamber && objMainTool.tool_id == objTool.tool_id && objectChamber.chamber == objChamber.chamber) {
                                    selectRecipes = objectChamber.selectedRecipes;
                                }
                            });
                        });
                    });
                    console.log(selectRecipes);


                    var tempRecipeList = [];
                    $.each(selectRecipes, function (idxRecipe, recipe) {                        

                        var tempStepList = [];
                        var tempParameterList = [];
                        $.each(self.chamberIntersectionList, function (idxMainChamber, objMainChamber) {
                            if (objMainChamber.chamber == objChamber.chamber) {
                                tempStepList = objMainChamber.selectedSteps;
                                tempParameterList = objMainChamber.selectedParameters;
                            } 
                        })  

                        var tempRecipe = {
                            recipe: recipe,
                            step_list: tempStepList,
                            parameter_list: tempParameterList
                        };

                        tempRecipeList.push(tempRecipe);
                    });       

                    var tempChamber = {
                        chamber: objChamber.chamber,
                        recipe_list: tempRecipeList                      
                    }
                    tempChamberList.push(tempChamber);
                    
                });

                var temptool = {
                    tool_id: objTool.tool_id,
                    chamber_list: tempChamberList,
                    virtual_chamber: objTool.virtualChamber
                };

                tempToolList.push(temptool);  
               
            });


            self.parameterSelectPostRequest = {
                model_id: store.getters.getCurrentModelId,
                acquisition_period: {
                    start_datetime: self.startTime,
                    end_datetime: self.endTime
                },
                tool_list: tempToolList
            }
            
            console.log(JSON.stringify(self.parameterSelectPostRequest));
        },

        parameterSelectPostRequest_NotRobot_ChamberMerge: function () {
            var self = this;
            self.parameterSelectPostRequest = {};  


            if (self.selectedSteps.length == 0) {
                self.vaildResult = false;
                alertify.alert("Please select steps");
                return;
            }

            if (self.selectedParameters.length == 0) {
                self.vaildResult = false;
                alertify.alert("Please select parameters");
                return;
            }


            var tempToolList = [];
            $.each(self.parameterlist, function (idxTool, objTool) {

                var tempChamberList = [];

                $.each(objTool.chamber_list, function (idxChamber, objChamber) {


                    if (objChamber.selectedRecipes.length == 0) {
                        self.vaildResult = false;
                        alertify.alert("Please select recipe [Tool:" + objTool.tool_id + "][Chamber:" + objChamber.chamber + "]");
                        return;
                    }                    

                    var tempRecipeList = [];

                    $.each(objChamber.selectedRecipes, function (idxRecipe, recipe) {

                        var tempRecipe = {
                            recipe: recipe,
                            step_list: self.selectedSteps,
                            parameter_list: self.selectedParameters
                        };

                        tempRecipeList.push(tempRecipe);

                    });

                    var tempChamber = {
                        chamber: objChamber.chamber,
                        recipe_list: tempRecipeList
                    }
                    tempChamberList.push(tempChamber);

                });

                var temptool = {
                    tool_id: objTool.tool_id,
                    chamber_list: tempChamberList,
                    virtual_chamber: objTool.virtualChamber
                };

                tempToolList.push(temptool);
            });
        

            self.parameterSelectPostRequest = {
                model_id: store.getters.getCurrentModelId,
                acquisition_period: {
                    start_datetime: self.startTime,
                    end_datetime: self.endTime
                },
                tool_list: tempToolList
            }

            console.log(JSON.stringify(self.parameterSelectPostRequest));        
        },

        parameterSelectPostRequest_Robot: function () {
            var self = this;
            self.parameterSelectPostRequest = {};


            if (self.selectedRecipes.length == 0) {
                self.vaildResult = false;
                alertify.alert("Please select recipe");
                return;
            }

            if (self.selectedSteps.length == 0) {
                self.vaildResult = false;
                alertify.alert("Please select steps");
                return;
            }

            if (self.selectedParameters.length == 0) {
                self.vaildResult = false;
                alertify.alert("Please select parameters");
                return;
            }

            self.vaildResult = true;
                                             

            var tempToolList = [];
            $.each(self.parameterlist, function (idxTool, objTool) {

                var tempChamberList = [];

                $.each(objTool.chamber_list, function (idxChamber, objChamber) {


                    var tempRecipeList = [];

                    $.each(self.selectedRecipes, function (idxRecipe, recipe) {

                        var tempRecipe = {
                            recipe: recipe,
                            step_list: self.selectedSteps,
                            parameter_list: self.selectedParameters
                        };

                        tempRecipeList.push(tempRecipe);

                    });

                    var tempChamber = {
                        chamber: objChamber.chamber,
                        recipe_list: tempRecipeList
                    }
                    tempChamberList.push(tempChamber);

                });

                var temptool = {
                    tool_id: objTool.tool_id,
                    chamber_list: tempChamberList,
                    virtual_chamber: objTool.virtualChamber
                };

                tempToolList.push(temptool);
            });


            self.parameterSelectPostRequest = {
                model_id: store.getters.getCurrentModelId,
                acquisition_period: {
                    start_datetime: self.startTime,
                    end_datetime: self.endTime
                },
                tool_list: tempToolList
            }

            console.log(JSON.stringify(self.parameterSelectPostRequest));
        },

        //實際呼叫API進行儲存
        saveParameterSelect: function (fn) {
            var self = this;

            /***ROBOT模式***/
            if (self.currentAppliction == 'Robot') {
                self.parameterSelectPostRequest_Robot();
            }
            /***非ROBOT.CHAMBER融合模式***/
            else if (self.currentAppliction != 'Robot' && self.currentChamberMerge) {
                self.parameterSelectPostRequest_NotRobot_ChamberMerge();
            }
            /***非ROBOT.CHAMBER非融合模式***/
            else if (self.currentAppliction != 'Robot' && !self.currentChamberMerge) {
                self.parameterSelectPostRequest_NotRobot_NotChamberMerge();
            }

            if (!self.vaildResult) {
                return;
            }


            var apiUrl = "/raw_data/acquisition_parameter";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                "data": {},
                "code": 200,
                "description": "",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }



                axios({
                    method: 'post',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    data: self.parameterSelectPostRequest
                })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        if (fn)
                            fn()

                    } else
                        alertify.error(response.data.data.message);

                });
        }, 

        //按下儲存鈕
        saveClick: function () {
            var self = this;

            var callback = function () {

                //20210312-新增儲存Algorithm資訊
                if (self.algorithm_type == "default") {
                    alertify.success("Save Sussess");
                }
                else {
                    self.postProjectAlgorithm().then(function () {

                        alertify.success("Save Sussess");
                    });
                }
            }

            alertify.confirm("儲存編輯中的內容?",
                function (e) {
                    if (e) {
                        //OK
                        self.saveParameterSelect(callback);
                    } else {
                        //Cancel                      
                    }
                });
        },

        //按下下一步
        nextClick: function () {

            var self = this;

            var callback = function () {

                //20210325-新增儲存Algorithm資訊
                if (self.algorithm_type == "default") {
                    alertify.success("Save Sussess");
                    CreateProjectLayoutRawDataApp.nextStatus(); //Redirct Data Filter
                    

                }
                else {
                    self.postProjectAlgorithm().then(function () {
                        self.updateStatus(2601).then(function () {
                            alertify.success("Save Sussess");
                            window.location.href = "/Project/ModelResult" + "?projectid=" + store.getters.getCurrentProjectId + "&modelid=" + store.getters.getCurrentModelId;
                        });                       
                        //CreateProjectLayoutRawDataApp.nextStatus(); //Redirct Data Filter
                    });
                }
            }


            alertify.confirm("儲存編輯內容，並前往下一步驟?",
                function (e) {
                    if (e) {
                        //OK
                        self.saveParameterSelect(callback);    

                    } else {
                        //Cancel                      
                    }
                });   

        },

        //取出該Project設定的Algorithm
        getProjectAlgorithm: function () {

            var self = this;   
            var apiUrl = "/project/algorithm";

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "data": {
                    "algorithm_id": 1,
                    "algorithm_package_id": 5
                },
                "code": 200,
                "description": "",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }  

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    model_id: store.getters.getCurrentModelId
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK" && response.data.algorithm_id) {
                        self.chooseAlgorithm = response.data.algorithm_id;
                        self.chooseVersion = response.data.chooseVersion;
                    }                    
                })
        },

        //儲存演算法資訊
        postProjectAlgorithm: function () {

            var self = this;

            return new Promise(function (resolve, reject) {


                if (self.chooseAlgorithm == null || self.chooseVersion == null) {
                    alertify.alert("Please select Algorithm and Version");
                    reject();
                }

                var apiUrl = "/project/algorithm";

                //用來模擬API的資料，實際上線不會執行這段            
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    "data": {
                    },
                    "code": 200,
                    "description": "",
                    "status": "OK"
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                axios({
                    method: 'post',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    data: {
                        model_id: store.getters.getCurrentModelId,
                        algorithm_type: self.algorithm_type,
                        algorithm_id: self.chooseAlgorithm,
                        version: self.chooseVersion
                    }
                })
                    .then(function (response) {
                        resolve();
                    })     
            });
        },

        //取Algorithm List
        getAlgorithmList: function () {

            var self = this;

            var apiUrl = "/algorithm/info_list";

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "data": {
                    "algorithm_list": [
                        {
                            "algorithm_id": 1,
                            "algorithm_name": "N1",
                            "author": "A1",
                            "algorithm_type": "AT1",
                            "model_type": "MT1",
                            "introduction_doc_name": "IDN",
                            "status": "S",
                            "description": "D",
                            "itime": "I",
                            "utime": "U"
                        },
                        {
                            "algorithm_id": 2,
                            "algorithm_name": "N1",
                            "author": "A1",
                            "algorithm_type": "AT1",
                            "model_type": "MT1",
                            "introduction_doc_name": "IDN",
                            "status": "S",
                            "description": "D",
                            "itime": "I",
                            "utime": "U"
                        }
                    ]
                },
                "code": 200,
                "description": "",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }   

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    page_no: 1,
                    page_size: 100
                }
            })
                .then(function (response) {

                    if (response.data.status == "OK") {    

                        //必須要符合的algorithm_type和model_type
                        var algorithm_list = response.data.data.algorithm_list.filter(function (item) {
                            //因目前頁面是raw data建立資料的步驟，所以這邊固定取raw_data_pipeline的資料
                            return item.algorithm_type == 'raw_data_pipeline' && item.model_type == store.getters.getCurrentModelType;
                        });
                        self.algorithms = algorithm_list;                      
                    }                   
                })     

        },

        //取Algorithm Version
        getAlgorithmVerisonList: function () {

            var self = this;

            var apiUrl = "/algorithm/package_list";

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "code": 200,
                "data": {
                    "total_count": 25,
                    "version_list": [
                        {
                            "itime": "2021-03-04 10:02:31",
                            "package_description": "ffff",
                            "status": "accept",
                            "system_message": "",
                            "version": 72
                        },
                        {
                            "itime": "2021-03-03 16:53:20",
                            "package_description": "",
                            "status": "accept",
                            "system_message": "",
                            "version": 71
                        }
                    ]
                },
                "description": "Successful response",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }           

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    algorithm_id: self.chooseAlgorithm,
                    page_no: 1,
                    page_size: 100
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {         
                        //必須要符合的可使用的狀態
                        var algorithm_versions = response.data.data.version_list.filter(function (item) {
                            //因目前頁面是raw data建立資料的步驟，所以這邊固定取raw_data_pipeline的資料
                            return item.status != 'reject' ;
                        });                        

                        self.algorithm_versions = algorithm_versions;                       
                    }
                })
        },

        //觸發Algorithm Change事件
        changeAlgorithm: function () {
            this.getAlgorithmVerisonList();
        },

        //Root點All Recipe Checkbox
        rootSelectAllRecipe: function () {
            if (!this.checkAllRecipe) {
                this.selectedRecipes = this.availableRecipes;
            }
            else {
                this.selectedRecipes = [];
            }

           
            this.changeRecipe();
        },

        chamberMergeSelectAllRecipe: function (checked,index,idx,recipes) {
            var self = this;
            if (!checked) {
                self.parameterlist[index].chamber_list[idx].selectedRecipes = recipes;
                //self.$set(self.parameterlist[index].chamber_list[idx], "selectedRecipes", recipes);             
            } else {
                self.parameterlist[index].chamber_list[idx].selectedRecipes = [];
            }

            self.parameterlist[index].chamber_list[idx].selectedAllRecipes = !checked;
            self.$set(self.parameterlist, index, self.parameterlist[index]);
        },

        chamberNonMergeSelectAllRecipe: function (checked,index, idx, recipes) {
            var self = this;

            if (!checked) {
                self.parameterlist[index].chamber_list[idx].selectedRecipes = recipes;              
                //self.$set(self.parameterlist[index].chamber_list[idx], "selectedRecipes", recipes);             
            } else {
                self.parameterlist[index].chamber_list[idx].selectedRecipes = [];
            }

            self.parameterlist[index].chamber_list[idx].selectedAllRecipes = !checked;
            self.$set(self.parameterlist, index, self.parameterlist[index]);

           
        },

        //更新Project Status
        updateStatus: function (status) {
           
            return new Promise(function (resolve, reject) {

            //呼叫更新狀態API
            var apiUrl = "/model_training";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPut(apiUrl).reply(200, {
                "data": {},
                "code": 200,
                "description": "",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }


            axios({
                method: 'put',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    offline_model_status: status
                }
            })
                .then(function (response) {
                    resolve();
                })
            });
        }
    }
})