﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {
        showStatisticalSetting: false,
        showNextBtn: false,  

        spectrumMethodInfos: [],
        frequencyTransformParms: [],
        checkedNames: [],
        confirmList: [],
        floatVal: 1,
        statisticalInfos: [],
        spectrumStatisticals: [],
        spectrumStatisticalsPostData: [],
        //n_cluster: 0,
        n_clusters: [],
        offline_model_status: 0,       
        cluster: "",
        clusters: [],
        datalist: [],
        clusterdata: [],
        showEditor: true,
        showLabeling: false,
        showDataLabelingChart: false,
        ToolIDs: [],
        ToolID: "",
        Chambers: [],
        Chamber: "",
        AllParameters: [],
        Parameters: [],
        Parameter: "",
        Spectrum: "",
        Spectrums: [],
        StartTimes: [],
        StartTime: "",
        ChartDatas: [],
        isShow: "1",
        Statistical: "",
        Statisticals: [],
        featureEngneeringDatas: {
            feature_config: [],
            stepGroup:[]
        },
        vaildDataResult: false,
        featureEngneeringPostDatas: {
            feature_config: []
        },
        isNeedSetDefault: true,
        currentAppliction: 'Pumb',
        currentChamberMerge: true,
        getParameterSelectResponse: {},
        getFeatureEngneeringResponse: {},
        postFeatureEngneeringRequest: {},
        statistical_default: store.getters.getStatisticalDefault_conti,//Conti和RawData一樣
    },
    watch: {
        showStatisticalSetting: function (value) {
            this.showNextBtn = value;
        }
    },
    mounted: function () {
        //store.commit('setShowLoading', true);   
        var self = this;
        self.init();
    },
    methods: {
        init: function () {
            var self = this;
            self.getParameterSelect().then(function () {
                self.getSpectrumMethodInfos();//取得Store設定的Spectrum選項
                self.getStatisticalInfos();//取得Store設定的Statistical選項
                self.getFeatureEngneering();
            });           
        },
        //取得可選的spectrum List
        getSpectrumMethodInfos: function () {
            var self = this;
            self.spectrumMethodInfos = store.getters.getSpectrumMethodInfos_rawdata;
        },

        //取得可選的Statistical List
        getStatisticalInfos: function () {
            var self = this;
            self.statisticalInfos = store.getters.getStatisticalInfos;
        },

        getParameterSelect: function () {
            var self = this;

            var apiUrl = "/raw_data/acquisition_parameter";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                "data": {
                    "acquisition_period": {
                        "start_datetime": "2020-11-10 04:07:18",
                        "end_datetime": "2020-11-17 04:07:18"
                    },
                    "tool_list": [
                        {
                            "tool_id": "T1",
                            "chamber_list": [
                                {
                                    "chamber": "C1",
                                    "recipe_list": [
                                        {
                                            "recipe": "R1",
                                            "step_list": [
                                                "ALL",
                                                "S1",
                                                "S2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P3"
                                            ]
                                        },
                                        {
                                            "recipe": "R2",
                                            "step_list": [
                                                "S1",
                                                "S2"
                                            ],
                                            "parameter_list": [
                                                "P1",
                                                "P3"
                                            ]
                                        }
                                    ]
                                },
                                {
                                    "chamber": "C2",
                                    "recipe_list": [
                                        {
                                            "recipe": "R1",
                                            "step_list": [
                                                "ALL",
                                                "0"
                                            ],
                                            "parameter_list": [
                                                "P3",
                                                "P4"
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "virtual_chamber": "VC1"
                        },
                        {
                            "tool_id": "T2",
                            "chamber_list": [
                                {
                                    "chamber": "C1",
                                    "recipe_list": [
                                        {
                                            "recipe": "R2",
                                            "step_list": [
                                                "0",
                                                "1"
                                            ],
                                            "parameter_list": [
                                                "P2",
                                                "P3"
                                            ]
                                        },
                                        {
                                            "recipe": "R4",
                                            "step_list": [
                                                "0",
                                                "1"
                                            ],
                                            "parameter_list": [
                                                "P2",
                                                "P3"
                                            ]
                                        }
                                    ]
                                },
                                {
                                    "chamber": "C2",
                                    "recipe_list": [
                                        {
                                            "recipe": "R5",
                                            "step_list": [
                                                "ALL",
                                                "0"
                                            ],
                                            "parameter_list": [
                                                "P3",
                                                "P4"
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "virtual_chamber": "VC2"
                        }
                    ]
                }
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;

            var responseData = {};

            return new Promise(function (resolve, reject) {

                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        model_id: store.getters.getCurrentModelId
                    }
                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            self.getParameterSelectResponse = response.data.data;
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);

                        resolve();
                    })

            })
        },

        //取得FeatureEngneering資訊
        getFeatureEngneering: function () {

            var self = this;


            var apiUrl = "/raw_data/feature_engineering";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: {
                    "model_id": 230,
                    "feature_config": []
                }
                //data: {
                //    "model_id": 230,
                //    "feature_config": [
                //        {
                //            "chamber": "C1",
                //            "parameter_list": [
                //                {
                //                    "parameter": "P1",
                //                    "spectrum": [
                //                        {
                //                            "step": "ALL",
                //                            "item": "WP",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        },
                //                        {
                //                            "step": "ALL",
                //                            "item": "Time Domain",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        },
                //                        {
                //                            "step": "ALL",
                //                            "item": "Time Domain Diff",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        },
                //                        {
                //                            "step": "0",
                //                            "item": "Time Domain",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        },
                //                        {
                //                            "step": "0",
                //                            "item": "Time Domain Diff",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        }
                //                    ]
                //                },
                //                {
                //                    "parameter": "P2",
                //                    "spectrum": [
                //                        {
                //                            "step": "ALL",
                //                            "item": "WP",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        },
                //                        {
                //                            "step": "ALL",
                //                            "item": "Time Domain",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        },
                //                        {
                //                            "step": "ALL",
                //                            "item": "Time Domain Diff",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        },
                //                        {
                //                            "step": "0",
                //                            "item": "Time Domain",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        },
                //                        {
                //                            "step": "0",
                //                            "item": "Time Domain Diff",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        }
                //                    ]
                //                }
                //            ]
                //        },
                //        {
                //            "chamber": "C2",
                //            "parameter_list": [
                //                {
                //                    "parameter": "P1",
                //                    "spectrum": [
                //                        {
                //                            "step": "ALL",
                //                            "item": "WP",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        },
                //                        {
                //                            "step": "ALL",
                //                            "item": "Time Domain",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        },
                //                        {
                //                            "step": "ALL",
                //                            "item": "Time Domain Diff",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        },
                //                        {
                //                            "step": "0",
                //                            "item": "Time Domain",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        },
                //                        {
                //                            "step": "0",
                //                            "item": "Time Domain Diff",

                //                            "statistical": [
                //                                "mean",
                //                                "std"
                //                            ]
                //                        }
                //                    ]
                //                }
                //            ]
                //        }
                //    ]
                //}
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;

          
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {                   
                    model_id: store.getters.getCurrentModelId,
                }
            })
                .then(function (response) {
                    self.getFeatureEngneeringResponse = response.data.data;
                
                    self.featureEngneeringDatas.feature_config = [];

                    //組合要雙向綁定的資料  
                    //self.preBindingData(responseData);


                    self.groupStep();
                    self.preBindingData_NotRobot_NotChamberMerge("");                   

                    

                    setTimeout(
                        function () {
                            self.selectDefaultStyle();
                        }
                        , 100);

                    store.commit('setShowLoading', false);
                })

        },

        //顯示StatisticalSetting區塊
        statisticalSetting: function () {
            var self = this;
            self.showStatisticalSetting = true;
        },

        //取得Spectrum可選的Statistical
        getSpectrumStatisticals: function () {

            var self = this;
            var apiUrl = "/spectrum_statistical/get_list";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                code: 200,
                data: {
                    parameter: [
                        {
                            key: "CT",
                            spectrum: [
                                {
                                    item: "fft",
                                    spectrum_collection_info_id: 1,
                                    statistical: [
                                        "Var",
                                        "Std"
                                    ]
                                }
                            ]
                        }
                    ]
                },
                description: "Get Spectrum list success"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.spectrumStatisticals = response.data.data.parameter;
                        for (var i = 0; i < self.spectrumStatisticals.length; i++) {
                            for (var j = 0; j < self.spectrumStatisticals[i].spectrum.length; j++) {

                                //if (self.spectrumStatisticals[i].spectrum[j].bin) {
                                //    self.spectrumStatisticals[i].spectrum[j].bin = 1;
                                //}
                                //else {
                                //    self.spectrumStatisticals[i].spectrum[j]["bin"] = 1;
                                //}

                                var _statisticalInfos = [];
                                for (var k = 0; k < store.getters.getStatisticalInfos.length; k++) {

                                    var getData = self.spectrumStatisticals[i].spectrum[j].statistical.find(function (d) {
                                        return d == store.getters.getStatisticalInfos[k].abbreviation;
                                    });

                                    var ischeck = false;

                                    if (getData) {
                                        ischeck = getData.length > 0 ? true : false;
                                    }

                                    _statisticalInfos.push(
                                        {
                                            abbreviation: store.getters.getStatisticalInfos[k].abbreviation,
                                            isCheck: ischeck
                                        }
                                    );

                                }

                                self.spectrumStatisticals[i].spectrum[j].statistical = _statisticalInfos;

                            }

                            //新頁面會用到

                            if (self.spectrumStatisticals[i].showAdvance) {
                                self.spectrumStatisticals[i].showAdvance = false;
                            }
                            else {
                                self.spectrumStatisticals[i]["showAdvance"] = false;
                            }
                        }

                    }

                })

        },

        selectDefaultStyle: function () {
            var self = this;
            //設定預設樣式
            self.featureEngneeringDatas.feature_config.forEach(function (c) {
                c.parameter_list.forEach(function (p) {
                    self.setAllStyle(p.all.allchecked, c.chamber,  p.parameter, "ALL");

                    p.spectrum.forEach(function (s) {
                        $.each(s.item, function (idx,obj) {
                            self.setAllStyle(s.allchecked, c.chamber, p.parameter, obj.name);
                        })                   
                    });
                });
            });

        },

        //當User點選All button觸發的事件
        selectAll: function (e, isAll,chamber , parameter, step) {

            var self = this;
            //var pIdx = self.featureEngneeringDatas.feature_config.findIndex(function (item) {
            //    return item.parameter == parameter;
            //});

            $.each(self.featureEngneeringDatas.feature_config, function (idxChamber, objChamber) {
                $.each(objChamber.parameter_list, function (idxParameter, objParameter) {

                    if (objChamber.chamber == chamber && objParameter.parameter == parameter) {                        

                        if (isAll) {
                            objParameter.all.statisticals.forEach(function (item) {
                                item.checked = $(e.target)[0].checked;
                            });

                            this.$set(this.featureEngneeringDatas.feature_config[idxChamber].parameter_list[idxParameter].all, 'allchecked', $(e.target)[0].checked);
                            this.$set(this.featureEngneeringDatas.feature_config[idxChamber].parameter_list[idxParameter].all, 'statisticals', objParameter.all.statisticals);
                        }
                        else {
                            $.each(objParameter.spectrum, function (idxSpectrum, objSpectrum) {

                                if (objSpectrum.step == step) {

                                    objSpectrum.statisticals.forEach(function (item) {
                                        item.checked = $(e.target)[0].checked;
                                    });

                                    this.$set(this.featureEngneeringDatas.feature_config[idxChamber].parameter_list[idxParameter].spectrum[idxSpectrum], 'allchecked', $(e.target)[0].checked);
                                    this.$set(this.featureEngneeringDatas.feature_config[idxChamber].parameter_list[idxParameter].spectrum[idxSpectrum], 'statisticals', objSpectrum.statisticals);

                                }

                            });   
                        }
                        self.setAllStyle($(isAll.target)[0].checked, chamber, parameter, spectrum);                       
                    }
                })
            }) 
        },

        //控制點選All Button所要顯示的樣式
        setAllStyle: function (checked, chamber, parameter, spectrum) {



            var allEl = $('.' + chamber +'-'+ parameter + '-' + spectrum + '-statisticalBox');

            allEl.each(function (index) {
                allEl[index].childNodes.forEach(function (element) {
                    if (element.tagName == "SPAN" || element.tagName == "LABEL") {
                        if (checked)
                            element.style.opacity = 0.1;
                        else
                            element.style.opacity = 1;
                    }
                });
            });
        },   
      
        getFeatureExtractionStatisticals: function (event) {

            var self = this;

            self.Statistical = "";
            self.Statisticals = [];
            var arrTmp = [];
            var arSpectrum = self.Parameters.filter(function (item, index) {

                if (item.parameter == self.Parameter) {
                    //alert(item.spectrum.length)
                    //return item.spectrum
                    for (var i = 0; i < item.spectrum.length; i++) {
                        if (item.spectrum[i].item == self.Spectrum) {
                            self.Statisticals = item.spectrum[i].statistical;
                        }
                    }
                    return;


                }
            })




        },    

        //顯示進階設定
        showAdvance: function (chamber,parameter) {
            var self = this;           

            $.each(self.featureEngneeringDatas.feature_config, function (idxChamber, objChamber) {
                $.each(objChamber.parameter_list, function (idxParameter, objParameter) {

                    if (objChamber.chamber == chamber && objParameter.parameter == parameter) {
                        objParameter.showAdvance = !objParameter.showAdvance;

                        this.$set(this.featureEngneeringDatas.feature_config[idxChamber].parameter_list, 'showAdvance', this.featureEngneeringDatas.feature_config[idxChamber].parameter_list[idxParameter]);
                    }              

                })
            })


            
        },   

        //回到前一頁
        backClick: function () {
            alertify.confirm("捨棄編輯中的內容，並回上一步驟",
                function (e) {
                    if (e) {
                        //OK

                        //window.location.href = "/Project/DataProcess";
                        CreateProjectLayoutApp.backStatus();
                    } else {
                        //Cancel                      
                        return;
                    }
                });
        },

        //儲存按鈕觸發事件
        saveClick: function () {
            var self = this;

            alertify.confirm("儲存編輯中的內容?",
                function (e) {
                    if (e) {
                        //OK
                        self.save();
                    } else {
                        //Cancel                      
                    }
                });
        },

        //Next按鈕觸發事件
        nextClick: function () {
            var self = this;

            alertify.confirm("儲存編輯內容，並前往下一步驟?",
                function (e) {
                    if (e) {
                        //OK
                        self.save(function () { CreateProjectLayoutRawDataApp.nextStatus(); });

                    } else {
                        //Cancel                      
                    }
                });
        },       

        //呼叫API儲存資料
        save: function (fn) {
            var self = this;
            self.conventerFeatureEngineeringPostData();


            //TODO:待確認怎麼驗證
            //if (!self.vaildDataResult) {
            //    return;
            //}

            var apiUrl = "/raw_data/feature_engineering";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                status: "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'post',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: self.postFeatureEngneeringRequest
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        alertify.success("Save Success");
                        if (fn) {
                            setTimeout(fn, 500);
                        }
                    }
                    else {
                        alertify.success("Save fail");
                    }
                })
        },

        //將後端回傳的格式依據Step做Group
        groupStep: function () {
            var self = this;

            //用來確認是第一次進來還是之前設定過
            self.getFeatureEngneeringResponse.feature_config.forEach(function (el) {
                if (el.parameter_list.length > 0 && el.parameter_list[0].spectrum.length > 0) {
                    self.isNeedSetDefault = false;
                }
            });
           
            var chamber_list = [];
            if (self.isNeedSetDefault) {

                //非Robot非融合:每個機台的Chamber都一樣，依據Chamber設定Parameter
                if (self.currentAppliction != "Robot" && !self.currentChamberMerge) {
                    $.each(self.getParameterSelectResponse.tool_list[0].chamber_list, function (idxChamber, objChamber) {
                        var parameter_list = [];
                        $.each(objChamber.recipe_list[0].parameter_list, function (idxParameter, objParameter) {
                            var spectrumItems = [];
                            $.each(objChamber.recipe_list[0].step_list, function (idx, step) {
                                spectrumItems.push({
                                    step: step,
                                    item: [],
                                    statistical: []
                                });
                            });

                            parameter_list.push({
                                parameter: objParameter,
                                spectrum: spectrumItems
                            });
                        });

                        chamber_list.push({
                            chamber: objChamber.chamber,
                            parameter_list: parameter_list
                        });
                    });
                }
                else {//Robot和Chamber融合:所有Chamber都是同一組Parameter                    
                    $.each(self.getParameterSelectResponse.tool_list[0].chamber_list, function (idxChamber, objChamber) {

                        //設定第一筆就好
                        if (idxChamber == 0) {
                            var parameter_list = [];
                            $.each(objChamber.recipe_list[0].parameter_list, function (idxParameter, objParameter) {

                                
                                    var preStatistical = [];
                                    var spectrumNames = [];
                                    var spectrumItems = [];
                                    $.each(objChamber.recipe_list[0].step_list, function (idx, step) {
                                        spectrumItems.push({
                                            step: step,
                                            item: spectrumNames,
                                            statistical: preStatistical
                                        });
                                    });


                                    parameter_list.push({
                                        parameter: objParameter,
                                        spectrum: spectrumItems
                                    });
                               
                            });

                            chamber_list.push({
                                chamber: self.currentAppliction == "Robot" ? objChamber.chamber :"ALL_CHAMBER",
                                parameter_list: parameter_list
                            });
                        }  
                    });
                }
            }
            else {
               
                $.each(self.getFeatureEngneeringResponse.feature_config, function (idxChamber, objChamber) {
                    var parameter_list = [];
                    $.each(objChamber.parameter_list, function (idxParameter, objParameter) {

                        var preStep = "";
                        var preStatistical = [];

                        var spectrumNames = [];
                        var spectrumItems = [];
                        $.each(objParameter.spectrum, function (idxSpectrum, objSpectrum) {
                            if (idxSpectrum == 0) {
                                preStep = objSpectrum.step;
                            }

                            if (preStep != objSpectrum.step) {
                                spectrumItems.push({
                                    step: preStep,
                                    item: spectrumNames,
                                    statistical: preStatistical
                                });


                                preStep = objSpectrum.step;                              
                                spectrumNames = [];
                                preStatistical = [];
                            }

                            if (objSpectrum.step == preStep) {
                                spectrumNames.push({
                                    name: objSpectrum.item
                                });
                                preStatistical = objSpectrum.statistical;//Statistical是By Step設定
                            }

                            if (idxSpectrum == objParameter.spectrum.length - 1) {
                                spectrumItems.push({
                                    step: objSpectrum.step,
                                    item: spectrumNames,
                                    statistical: preStatistical
                                });
                            }
                        });

                        parameter_list.push({
                            parameter: objParameter.parameter,
                            spectrum: spectrumItems
                        });
                        spectrumItems = [];
                    });

                    chamber_list.push({
                        chamber: objChamber.chamber,
                        parameter_list: parameter_list
                    });

                });
            }         

            self.featureEngneeringDatas.stepGroup = chamber_list;
        },     
      
        //
        preBindingData_NotRobot_NotChamberMerge: function ( source) {
            var self = this;

            self.featureEngneeringDatas.feature_config = [];  


            $.each(self.featureEngneeringDatas.stepGroup, function (idxChamber, objChamber) {

                var parameter_list = [];
                $.each(objChamber.parameter_list, function (idxParameter, objParameter) {

                   
                    var spectrumList = [];
                   
                    var showAdvance = false;
                    var allShowAdvance = false;   
                    var allcheck = true;
                    var allStatisticals = [];                

                    $.each(objParameter.spectrum, function (idxSpectrum, objSpectrum) {
                        var spectrumlDetails = [];
                        var statisticals = [];;

                        for (var j = 0; j < self.spectrumMethodInfos.length; j++) {

                           
                            allcheck = false;

                            var getSpectrumIdx = -1

                            if (source == "clickspectrum") {
                                getSpectrumIdx = objSpectrum.item.findIndex(function (d) {
                                    return d.name.toLowerCase() == self.spectrumMethodInfos[j].patameter.toLowerCase() && d.checked == true
                                });
                            }
                            else {
                                getSpectrumIdx = objSpectrum.item.findIndex(function (d) {
                                    return d.name.toLowerCase() == self.spectrumMethodInfos[j].patameter.toLowerCase()
                                });
                            }

                            //暫時移除，因為statistical跟item同階層
                            //if (getSpectrumIdx > -1
                            //    && objSpectrum.item[getSpectrumIdx]
                            //    && objParameter.spectrum[getSpectrumIdx].statistical.length != 0
                            //    && objParameter.spectrum[getSpectrumIdx].statistical.length != self.statisticalInfos.length) {
                            //    showAdvance = true;
                            //}

                            //if ((objParameter.spectrum.length == 0 && self.isNeedSetDefault)
                            //    || (getSpectrumIdx > -1 && (objParameter.spectrum[getSpectrumIdx].statistical && objParameter.spectrum[getSpectrumIdx].statistical.length == 0))
                            //    || (getSpectrumIdx > -1 && (objParameter.spectrum[getSpectrumIdx].statistical && objParameter.spectrum[getSpectrumIdx].statistical.length == self.statisticalInfos.length))) {
                            //    allcheck = true;
                            //}

                            //預設不要全選，改為"Std", "Rms", "Kurtosis", "Var", "Max_Min","Skewness"
                            //if ((getSpectrumIdx > -1 && (objParameter.spectrum[getSpectrumIdx].statistical && objParameter.spectrum[getSpectrumIdx].statistical.length == self.statisticalInfos.length))) {
                            //    allcheck = true;
                            //}

                           


                            //spectrumlDetails.push({
                            //    item: self.spectrumMethodInfos[j].patameter,
                            //    checked: getSpectrumIdx > -1 ||  self.isNeedSetDefault || allcheck ? true : false,
                            //    statisticals: statisticals,
                            //    allchecked: allcheck
                            //});

                            //小波包WP只會在Step ALL
                            if (self.spectrumMethodInfos[j].patameter.indexOf("WP")>-1 && objSpectrum.step != "ALL") {
                                continue;
                            }

                            spectrumlDetails.push({
                                name: self.spectrumMethodInfos[j].patameter,
                                checked: getSpectrumIdx > -1 || self.isNeedSetDefault  ? true : false
                            });

                        }
                      
                        var checkCount = 0;//用來確認選取的數量給Allcheck判斷用
                        for (var k = 0; k < self.statisticalInfos.length; k++) {
                            var getStatisticalIdx = -1;                                                                     

                            var currentStatisticalIsCheck = false;                        

                            
                            if (!objSpectrum.statistical || objSpectrum.statistical.length == 0) {
                                //如果之前都沒有設定過，就預設勾選store.getters.getStatisticalDefault_conti清單的選項
                                var isDefaultCheck = false;
                                self.statistical_default.forEach(function (val) {
                                    if (self.statisticalInfos[k].abbreviation == val)
                                        isDefaultCheck = true;
                                });
                                currentStatisticalIsCheck = isDefaultCheck;
                            } else { //如果之前有選過就依據之前選過的內容設定
                            

                                //該statistical是否有被選取
                                getStatisticalIdx = objSpectrum.statistical.findIndex(function (d) {
                                    return d.toLowerCase() == self.statisticalInfos[k].abbreviation.toLowerCase();
                                });
                               

                                if (source == "clickspectrum") {
                                    getStatisticalIdx = objSpectrum.statistical.findIndex(function (d) {
                                        return d.toLowerCase() == self.statisticalInfos[k].abbreviation.toLowerCase();
                                    });
                                }

                                if (getStatisticalIdx > -1) {
                                    currentStatisticalIsCheck = true;
                                    checkCount++;
                                }
                                else currentStatisticalIsCheck = false;
                            }

                          
                            //if (objParameter.spectrum[getSpectrumIdx]
                            //    && objParameter.spectrum[getSpectrumIdx].statistical) {

                            //    var _currentStatisticalIsCheck = false;
                            //    objParameter.spectrum[getSpectrumIdx].statistical.forEach(function (val) {
                            //        if (self.statisticalInfos[k].abbreviation.toLowerCase() == val.toLowerCase())
                            //            _currentStatisticalIsCheck = true;

                            //    });
                            //    currentStatisticalIsCheck = _currentStatisticalIsCheck;//data.feature_config[i].spectrum[getSpectrumIdx].statistical[k].checked;
                            //}
                            
                            statisticals.push(
                                {
                                    abbreviation: self.statisticalInfos[k].abbreviation,
                                    checked: currentStatisticalIsCheck
                                }
                            );

                            //用來給SimpleSetting懶人版設定使用
                            if (idxSpectrum == 0) {
                                allStatisticals.push(
                                    {
                                        abbreviation: self.statisticalInfos[k].abbreviation,
                                        checked: currentStatisticalIsCheck
                                    }
                                );
                            }                        
                        }

                        spectrumList.push({
                            step: objSpectrum.step,
                            item: spectrumlDetails,
                            statisticals: statisticals,
                            allchecked: checkCount == self.statisticalInfos.length ? true : false
                        });

                        //給懶人版SimpleSetting使用
                        if (checkCount != self.statisticalInfos.length) {
                            allcheck=false
                        }                       
                    })  

                    var resultData = {};

                    //因為Statistical設定有分SimpleSetting模式和AdvanceSetting模式
                    //if (objParameter.spectrum.length == 0 && !self.isNeedSetDefault) {                   
                    //    resultData = {
                    //        parameter: objParameter.parameter,
                    //        spectrum: spectrumList,                         
                    //        showAdvance: false,
                    //        isShow: false,
                    //        all: {}
                    //    };
                    //}
                    //else {
                    //    resultData = {
                    //        parameter: objParameter.parameter,
                    //        spectrum: spectrumList,                          
                    //        showAdvance: showAdvance,
                    //        isShow: true,
                    //        all: {
                    //            statisticals: allStatisticals,
                    //            allchecked: allcheck
                    //        }
                    //    };
                    //}
                    resultData = {
                        parameter: objParameter.parameter,
                        spectrum: spectrumList,
                        showAdvance: false,
                        isShow: true,
                        all: {
                            statisticals: allStatisticals,
                            allchecked: allcheck
                        }
                    };

                    parameter_list.push(resultData);
                });

                self.featureEngneeringDatas.feature_config.push({
                    chamber: objChamber.chamber,
                    parameter_list: parameter_list,
                });
                self.$set(self.featureEngneeringDatas.feature_config, idxChamber, self.featureEngneeringDatas.feature_config[idxChamber]);
            });
        },

        selectSpectrum: function (chamber, parameter, spectrum) {
            var self = this;

            //var copyData = $.extend(true, {}, self.featureEngneeringDatas);
            //self.preBindingData(copyData,'clickspectrum');

            $.each(self.featureEngneeringDatas.feature_config, function (idxChamber, objChamber) {

                var parameter_list = [];
                $.each(objChamber.parameter_list, function (idxParameter, objParameter) {

                    if (objChamber.chamber == chamber && objParameter.parameter == parameter) {

                        //Click Spectrum指綁定第一筆，所以以第一筆的資訊重新設定給其他Step的Spectrum
                        var selectSpectrums = objParameter.spectrum[0].item;
                        
                        $.each(objParameter.spectrum, function (idxSpectrum, objSpectrum) {

                            //因為第一筆是要設定的資訊
                            if (idxSpectrum != 0) {
                                $.each(objSpectrum.item, function (idx, obj) {
                                    if (obj.name == spectrum) {
                                        var findSpectrumItem = selectSpectrums.findIndex(function (d) {
                                            return d.name.toLowerCase() == obj.name.toLowerCase();
                                        });

                                        if (findSpectrumItem > -1) {
                                            obj.checked = !selectSpectrums[findSpectrumItem].checked;

                                            self.$set(self.featureEngneeringDatas.feature_config[idxChamber].parameter_list[idxParameter].spectrum[idxSpectrum].item
                                                , idx
                                                , self.featureEngneeringDatas.feature_config[idxChamber].parameter_list[idxParameter].spectrum[idxSpectrum].item[idx]);
                                        }
                                    }                                    
                                });

                                self.$set(self.featureEngneeringDatas.feature_config[idxChamber].parameter_list[idxParameter].spectrum
                                    , idxSpectrum
                                    , self.featureEngneeringDatas.feature_config[idxChamber].parameter_list[idxParameter].spectrum[idxSpectrum]);
                            }   

                        });

                        self.$set(self.featureEngneeringDatas.feature_config[idxChamber].parameter_list
                            , idxParameter
                            , self.featureEngneeringDatas.feature_config[idxChamber].parameter_list[idxParameter]);

                    }
                });

                self.$set(self.featureEngneeringDatas.feature_config
                    , idxChamber
                    , self.featureEngneeringDatas.feature_config[idxChamber]);

            });  
         
        },

        conventerFeatureEngineeringPostData: function () {
            var self = this;

            var chamber_list = [];
            $.each(self.featureEngneeringDatas.feature_config, function (idxChamber, objChamber) {

                var parameter_list = [];
                $.each(objChamber.parameter_list, function (idxParameter, objParameter) {


                    var allStatisticals = objParameter.all.statisticals.filter(function (obj) {
                        return obj.checked == true;
                    }).map(function (obj) {
                        return obj.abbreviation;
                    });

                    var spectrumList = [];

                    $.each(objParameter.spectrum, function (idxSpectrum, objSpectrum) {


                        var statisticals = objSpectrum.statisticals.filter(function (obj) {
                            return obj.checked == true;
                        }).map(function (obj) {
                            return obj.abbreviation;
                            });

                        $.each(objSpectrum.item, function (idx, obj) {
                            if (obj.checked) {                                

                                if (obj.name.indexOf("WP") > -1) {
                                    var isSelectRms = false;
                                    if (objParameter.showAdvance) {
                                        isSelectRms = statisticals.includes("Rms") ? true : false;
                                    }
                                    else {
                                        isSelectRms = allStatisticals.includes("Rms") ? true : false;
                                    }
                                    
                                    if (isSelectRms) {
                                        spectrumList.push(
                                            {
                                                step: objSpectrum.step,
                                                item: obj.name,
                                                statistical: ["Rms"]
                                            }
                                        )
                                    }
                                }
                                else {
                                    spectrumList.push(
                                        {
                                            step: objSpectrum.step,
                                            item: obj.name,
                                            statistical: objParameter.showAdvance ? statisticals : allStatisticals
                                        }
                                    )
                                }                               
                            }
                        }); 
                    });

                    parameter_list.push({
                        parameter: objParameter.parameter,
                        spectrum: spectrumList
                    });
                });

                chamber_list.push({
                    chamber: objChamber.chamber,
                    parameter_list: parameter_list
                });
            });

            self.postFeatureEngneeringRequest = {
                model_id: store.getters.getCurrentModelId,
                feature_config: chamber_list
            };

        },


    }
})