﻿

var app = new Vue({
    el: '#app',
    store: store,
    data: {    
        algorithmList: [],       
        Pagination: {
            current_page: 1,
            page_size:10,
            total:0
        }
    },
    mounted: function () {
        var self = this;     
        store.commit('setShowLoading', true);    
        self.getAlgorithmList();    
    },  
    methods: {    
        //Get ProjectList
        getAlgorithmList: function (page) {

            var apiUrl = "/algorithm/info_list";  

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "data": {
                    "algorithm_list": [
                        {
                            "algorithm_id": 1,
                            "algorithm_name": "N1",
                            "author": "A1",
                            "algorithm_type": "AT1",
                            "model_type": "MT1",
                            "introduction_doc_name": "IDN",
                            "status": "S",
                            "description": "D",
                            "itime": "I",
                            "utime": "U"
                        },
                        {
                            "algorithm_id": 2,
                            "algorithm_name": "N1",
                            "author": "A1",
                            "algorithm_type": "AT1",
                            "model_type": "MT1",
                            "introduction_doc_name": "IDN",
                            "status": "S",
                            "description": "D",
                            "itime": "I",
                            "utime": "U"
                        }
                    ]
                },
                "code": 200,
                "description": "",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }                    
            var self = this;   

            //避免User在其他頁點選查詢造成沒有資料，統一導向第一頁
            if (page)
                self.Pagination.current_page = page;
            
           
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,                
                params: {       
                    page_no: self.Pagination.current_page,
                    page_size: self.Pagination.page_size             
                }
            })          
                .then(function (response) {
                  
                    if (response.data.status == "OK") {
                        self.Pagination.total = response.data.data.total_count;
                        self.algorithmList = response.data.data.algorithm_list;

                        if (self.algorithmList.length == 0) {
                            alertify.error("No data");
                        }
                    }    

                    store.commit('setShowLoading', false);
                })               
        },

        //Edit Project
        editAlgorithm: function (row) {  
            window.location.href = "/CustomAlgorithm/CreateAlgorithm?algorithmid=" + row.algorithm_id;        
        },

        //View Version
        viewVersion: function (row) {
            window.location.href = "/CustomAlgorithm/VersionList?algorithmid=" + row.algorithm_id;
        },

        //Delete Project
        deleteAlgorithm: function (row) {           

            var apiUrl = "/algorithm/info";
            var self = this;
                        

            if (row.author != store.getters.getUserInfo.UserId) {
                alertify.alert("Sorry,you do not have permission to delete.");
                return;
            }

            var msg = "Are you want to delete algorithm id " + row.algorithm_id +"?"

            alertify.confirm(msg,
                function (e) {
                    if (e) {
                        //OK   


                        store.commit('setShowLoading', true);

                        //用來模擬API的資料，實際上線不會執行這段                        
                        let mock = new AxiosMockAdapter(axios);
                        mock.onDelete(apiUrl).reply(200, {
                            status: "success",
                            data: {}
                        });

                        if (store.getters.getEnv == 'prd') {
                            mock.restore();
                        }

                     
                        axios({
                            method: 'delete',
                            baseURL: store.getters.getOfflineApiUrl,
                            url: apiUrl,
                            data: {
                                algorithm_id: row.algorithm_id                              
                            }
                        })
                            .then(function (response) {    
                             store.commit('setShowLoading', false);

                            if (response.data.status == "OK") {
                                alertify.success("Delete Success");
                                self.getAlgorithmList();
                            }
                            else {
                                alertify.alert("Delete Fail");
                            }

                           
                        })                      

                    } else {
                        //Cancel    
                        return;
                    }
                });             
        },      
      

        //換頁
        handleChangePage: function (val) {
            var self = this;
            self.Pagination.current_page = val;
            self.getAlgorithmList();          
        },

        //新增NewProject的按鈕
        createNew: function () {
            window.location.href = "/CustomAlgorithm/CreateAlgorithm";                 
        }
    }


})