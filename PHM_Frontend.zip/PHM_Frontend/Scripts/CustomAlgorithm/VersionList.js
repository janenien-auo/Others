﻿

var app = new Vue({
    el: '#app',
    store: store,
    data: {    
        algorithmid: null,   
        algorithmInfo: {},
        versionList: [],
        Pagination: {
            current_page: 1,
            page_size: 10,
            total: 0
        },
        uploadFiles:[]
    },
    mounted: function () {
        var self = this;    

        self.algorithmid = getUrlParameterByName("algorithmid", window.location.href.toLocaleLowerCase());
        self.getAlgorithmInfo();
        self.getVersionList();        
        store.commit('setShowLoading', false);

        setInterval(self.getVersionList, 60000);
        
    },  
    methods: {    

        //Get Algorithm Info
        getAlgorithmInfo: function () {

            var self = this;

            var apiUrl = "/algorithm/info_list";

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "data": {
                    "algorithm_list": [
                        {
                            "algorithm_id": 1,
                            "algorithm_name": "N1",
                            "author": "A1",
                            "algorithm_type": "AT1",
                            "model_type": "MT1",
                            "introduction_doc_name": "IDN",
                            "status": "S",
                            "description": "D",
                            "itime": "I",
                            "utime": "U"
                        }
                    ]
                },
                "code": 200,
                "description": "",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    algorithm_id: self.algorithmid
                }
            })
                .then(function (response) {


                    if (response.data.status == "OK") {
                        if (response.data.data.algorithm_list.length == 0) {
                            alertify.error("No data");
                        }
                        else {
                            self.algorithmInfo = response.data.data.algorithm_list[0];
                        }

                        store.commit('setShowLoading', false);
                    }

                })
        },

        //Get ProjectList
        getVersionList: function (page) {

            var apiUrl = "/algorithm/package_list";

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "code": 200,
                "data": {
                    "total_count": 25,
                    "version_list": [
                        {
                            "itime": "2021-03-04 10:02:31",
                            "package_description": "ffff",
                            "status": "accept",
                            "system_message": "",
                            "version": 72
                        },
                        {
                            "itime": "2021-03-03 16:53:20",
                            "package_description": "",
                            "status": "accept",
                            "system_message": "",
                            "version": 71
                        }
                    ]
                },
                "description": "Successful response",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }
            var self = this;

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    algorithm_id: self.algorithmid,
                    page_no: self.Pagination.current_page,
                    page_size: self.Pagination.page_size
                }
            })
                .then(function (response) {

                    if (response.data.status == "OK") {
                        self.Pagination.total = response.data.data.total_count;
                        self.versionList = response.data.data.version_list;

                        if (self.versionList.length == 0) {
                            alertify.error("No data");
                        } 
                    }                  
                })
        },

        //Edit Version
        editVersion: function (row) {  
            window.location.href = "/CustomAlgorithm/editAlgorithm?version=" + row.algorithm_id;        
        },     

        //Delete Version
        deleteVersion: function (row) {           

            var apiUrl = "/algorithm/package";
            var self = this;   

            if (row.status == "verifying" || row.status == "used") {
                alertify.alert("Sorry, the status " + row.status +" cannot delete.");
                return;
            }


            if (self.algorithmInfo.author_deptid != store.getters.getUserInfo.UserDeptID) {
                alertify.alert("Sorry,you do not have permission to delete.");
                return;
            }

            var msg = "Are you want to delete algorithm id " + self.algorithmInfo.algorithm_id + ", version " + row.version+"?"

            alertify.confirm(msg,
                function (e) {
                    if (e) {
                        //OK   

                        store.commit('setShowLoading', true);

                        //用來模擬API的資料，實際上線不會執行這段                        
                        let mock = new AxiosMockAdapter(axios);
                        mock.onDelete(apiUrl).reply(200, {
                            status: "success",
                            data: {}
                        });

                        if (store.getters.getEnv == 'prd') {
                            mock.restore();
                        }

                     
                        axios({
                            method: 'delete',
                            baseURL: store.getters.getOfflineApiUrl,
                            url: apiUrl,
                            params: {
                                algorithm_id: self.algorithmInfo.algorithm_id,
                                version: row.version
                            }
                        })
                            .then(function (response) {
                                store.commit('setShowLoading', false);
                                if (response.data.status == "OK") {
                                    alertify.success("Delete Success");
                                    self.getVersionList();
                                }
                                else {
                                    alertify.alert("Delete Fail");
                                }

                            })                      

                    } else {
                        //Cancel    
                        return;
                    }
                });             
        },  
        
        //換頁
        handleChangePage: function (val) {
            var self = this;
            self.Pagination.current_page = val;
            self.getVersionList();
        },

        //新增NewProject的按鈕
        createNew: function () {
            var self = this;
            window.location.href = "/CustomAlgorithm/CreateVersion?algorithmid=" + self.algorithmid;                 
        },

        //選取檔案
        onFileChange: function (e) {
            var self = this;

            var files = e.target.files || e.dataTransfer.files;
            if (!files.length)
                return;

            self.newFileName = files[0].name;
            self.uploadFiles = files;           

        },  

        uploadVersion: function () {

            var self = this;

           

            return new Promise(function (resolve, reject) {
                var apiUrl = "/algorithm/package";

                //用來模擬API的資料，實際上線不會執行這段            
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    "data": {
                    },
                    "code": 200,
                    "description": "",
                    "status": "OK"
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var formData = new FormData();

                formData.append("algorithm_id", self.algorithmid);
                formData.append("introduction_doc_file", self.uploadFiles[0]);

                axios({
                    method: 'post',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    data: formData
                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            alertify.alert("Update successfuly!");
                            self.newFileName = null;
                            self.init();
                            store.commit('setShowLoading', false);

                        }
                    })

            });

        }
    }


})