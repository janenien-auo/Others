﻿

var app = new Vue({
    el: '#app',
    store: store,
    data: {
        algorithmid: null,
        algorithmInfo: {},
        versionid: null,
        package_description: null,
        newFileName:null,        
        uploadFiles: null
    },
    mounted: function () {
        var self = this;  

        store.commit('setShowLoading', true);
        self.init();     

        
    },  
    methods: {
        init: function () {     

            var self = this;   

            if (!self.algorithmid) {
                //確認Url有帶algorithmid:algorithmid有值代表修改，沒值代表新增
                self.algorithmid = getUrlParameterByName("algorithmid", window.location.href.toLocaleLowerCase());
                self.versionid = getUrlParameterByName("versionid", window.location.href.toLocaleLowerCase());
            }
           

            if (self.algorithmid) {  
                self.getAlgorithmInfo();
            }
            else {
                store.commit('setShowLoading', false);
            }
        },        

        //Get Algorithm Info
        getAlgorithmInfo: function () {

            var self = this;        

            var apiUrl = "/algorithm/info_list";  

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "code": 200,
                "data": {                   
                    "version_list": [
                        {
                            "itime": "2021-03-04 10:02:31",
                            "package_description": "ffff",
                            "status": "accept",
                            "system_message": "",
                            "version": 72
                        }
                    ]
                },
                "description": "Successful response",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }  

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,                
                params: {       
                    algorithm_id: self.algorithmid    
                }
            })          
                .then(function (response) {                  
                    if (response.data.status == "OK") {
                        if (response.data.data.algorithm_list.length == 0) {
                            alertify.error("No data");
                        }
                        else {
                            self.algorithmInfo = response.data.data.algorithm_list[0];
                        }                        
                    }
                    store.commit('setShowLoading', false);
                  
                })               
        },

        //選取檔案
        onFileChange: function (e) {
            var self = this;

            var files = e.target.files || e.dataTransfer.files;
            if (!files.length)
                return;

            self.newFileName = files[0].name; 
            self.uploadFiles = files;
           
        },  
      
        //按下新增或修改
        create: function () {
          
            var self = this;
            store.commit('setShowLoading', true);


            self.updateFile();                    
        },
       

        //新增或修改Algorithm desc pdf
        updateFile: function () {
            var self = this;       


           

            return new Promise(function (resolve, reject) {


                if (self.uploadFiles == null) {
                    store.commit('setShowLoading', false);
                    alertify.alert("Please Choose Upload File");
                    resolve();
                };


                var apiUrl = "/algorithm/package";

                //用來模擬API的資料，實際上線不會執行這段            
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    "data": {
                    },
                    "code": 200,
                    "description": "",
                    "status": "OK"
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var formData = new FormData();

                formData.append("algorithm_id", self.algorithmid);
                formData.append("author_deptid", store.getters.getUserInfo.UserDeptID);   
                formData.append("package_description", self.package_description);                    
                formData.append("algorithm_package", self.uploadFiles[0], self.newFileName);


                axios({
                    method: 'post',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,     
                    contentType: false,
                    data: formData                                  
                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            alertify.alert("Update successfuly!");
                            //self.newFileName = null;
                            //self.init();
                            store.commit('setShowLoading', false);

                            window.location.href = "/CustomAlgorithm/VersionList?algorithmid=" + self.algorithmid;   

                        }
                    })
                    .catch(function (error) {
                        store.commit('setShowLoading', false);
                        console.log(error);
                    })

            });
        },

        deleteFile: function () {
            var self = this;

            var apiUrl = "/algorithm/introduction_doc";

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "data": {
                },
                "code": 200,
                "description": "",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var formData = new FormData();

            formData.append("algorithm_id", self.algorithmid);    
          

            axios({
                method: 'delete',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: formData
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        alertify.alert("Delete successfuly!");
                        self.init();
                        store.commit('setShowLoading', false);

                    }
                })

        }
               
       

    }


})