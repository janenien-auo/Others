﻿

var app = new Vue({
    el: '#app',
    store: store,
    data: {
        algorithmid: null,      
        algorithmInfo: {},
        newFileName:null,
        oldFileUrl: "",
        uploadFiles: null
    },
    mounted: function () {
        var self = this;  

        store.commit('setShowLoading', true);
        self.init();     

        
    },  
    methods: {
        init: function () {     

            var self = this;   

            if (!self.algorithmid) {
                //確認Url有帶algorithmid:algorithmid有值代表修改，沒值代表新增
                self.algorithmid = getUrlParameterByName("algorithmid", window.location.href.toLocaleLowerCase());
            }
           

            if (self.algorithmid) {
                self.oldFileUrl = store.getters.getOfflineApiUrl + "/algorithm/introduction_doc?algorithm_id=" + self.algorithmid;
                self.getAlgorithmInfo();
            }
            else {
                store.commit('setShowLoading', false);
            }
        },        

        //Get Algorithm Info
        getAlgorithmInfo: function () {

            var self = this;        

            var apiUrl = "/algorithm/info_list";  

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "data": {
                    "algorithm_list": [
                        {
                            "algorithm_id": 1,
                            "algorithm_name": "N1",
                            "author": "A1",
                            "algorithm_type": "AT1",
                            "model_type": "MT1",
                            "introduction_doc_name": "IDN",
                            "status": "S",
                            "description": "D",
                            "itime": "I",
                            "utime": "U"
                        }
                    ]
                },
                "code": 200,
                "description": "",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }  

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,                
                params: {       
                    algorithm_id: self.algorithmid    
                }
            })          
                .then(function (response) {

                  
                    if (response.data.status == "OK") {
                        if (response.data.data.algorithm_list.length == 0) {
                            alertify.error("No data");
                        }
                        else {
                            self.algorithmInfo = response.data.data.algorithm_list[0];
                        } 

                        store.commit('setShowLoading', false);
                    }
                  
                })               
        },

        //選取檔案
        onFileChange: function (e) {
            var self = this;

            var files = e.target.files || e.dataTransfer.files;
            if (!files.length)
                return;

            self.newFileName = files[0].name; 
            self.uploadFiles = files;
           
        },  
      
        //按下新增或修改
        create: function () {
          
            var self = this;
            store.commit('setShowLoading', true);


            self.updateAlgorithm().then(
                //success
                function () {
                    if (self.uploadFiles) {
                        self.updateFile().then(
                            function () {
                                alertify.alert("Update successfuly!");
                                self.init();
                                store.commit('setShowLoading', false);
                            }
                        );
                    }
                    else {
                        alertify.alert("Update successfuly!");                        
                        self.init();
                        store.commit('setShowLoading', false);
                    } 
                },
                //fail
                function () {
                    alertify.error("Update fail")
                });                    
        },

        //新增或修改Algorithm
        updateAlgorithm: function () {
            var self = this;

            self.algorithmInfo["author"] = UserInfoApp.userInfo.UserId;
            self.algorithmInfo["author_deptid"] = UserInfoApp.userInfo.UserDeptID;

            return new Promise(function (resolve, reject) {
                var apiUrl = "/algorithm/info";

                //用來模擬API的資料，實際上線不會執行這段            
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    "data": {
                        "algorithm_id": 123
                    },
                    "code": 200,
                    "description": "",
                    "status": "OK"
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                axios({
                    method: 'post',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    data: self.algorithmInfo
                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                                                
                            self.algorithmid = response.data.data.algorithm_id;                            
                        }

                        resolve();
                    })       

            });

        },

        //新增或修改Algorithm desc pdf
        updateFile: function () {
            var self = this;         


            return new Promise(function (resolve, reject) {
                var apiUrl = "/algorithm/introduction_doc";

                //用來模擬API的資料，實際上線不會執行這段            
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, {
                    "data": {
                    },
                    "code": 200,
                    "description": "",
                    "status": "OK"
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var formData = new FormData();

                formData.append("algorithm_id", self.algorithmid);
                formData.append("introduction_doc_file", self.uploadFiles[0]);

                axios({
                    method: 'post',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    data: formData                   
                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            self.newFileName = null;

                        }

                        resolve();
                    })

            });
        },

        deleteFile: function () {
            var self = this;

            var msg = "Are you want to delete " + self.algorithmInfo.introduction_doc_name + "?"

            alertify.confirm(msg,
                function (e) {
                    if (e) {
                        //OK   

                        var apiUrl = "/algorithm/introduction_doc";

                        //用來模擬API的資料，實際上線不會執行這段            
                        let mock = new AxiosMockAdapter(axios);
                        mock.onGet(apiUrl).reply(200, {
                            "data": {
                            },
                            "code": 200,
                            "description": "",
                            "status": "OK"
                        });

                        if (store.getters.getEnv == 'prd') {
                            mock.restore();
                        }

                        var formData = new FormData();

                        formData.append("algorithm_id", self.algorithmid);

                        axios({
                            method: 'delete',
                            baseURL: store.getters.getOfflineApiUrl,
                            url: apiUrl,
                            data: formData
                        })
                            .then(function (response) {
                                if (response.data.status == "OK") {
                                    alertify.alert("Delete successfuly!");
                                    self.init();
                                    store.commit('setShowLoading', false);

                                }
                            })


                    } else {
                        //Cancel    
                        return;
                    }
                });
        }

        //取得Algorithm desc pdf
        //xxxgetFile: function () {
        //    var self = this;

        //    var apiUrl = "/algorithm/introduction_doc";

        //    //用來模擬API的資料，實際上線不會執行這段            
        //    let mock = new AxiosMockAdapter(axios);
        //    mock.onGet(apiUrl).reply(200, {
        //        "data": {
        //        },
        //        "code": 200,
        //        "description": "",
        //        "status": "OK"
        //    });

        //    if (store.getters.getEnv == 'prd') {
        //        mock.restore();
        //    }

        //    axios({
        //        method: 'get',
        //        baseURL: store.getters.getOfflineApiUrl,
        //        url: apiUrl,
        //        params: {
        //            algorithm_id: self.algorithmid
        //        }
        //        ,
        //        responseType: 'blob'//取得檔案
        //    })
        //        .then(function (response) {             
        //            var headerval = response.headers['Content-Disposition'];
        //            //var filename = headerval.split(';')[1].split('=')[1].replace('"', '').replace('"', '');


        //            var blob = new Blob([response.data], { type: 'application/pdf' });                 
        //            self.downloadUrl = window.URL.createObjectURL(blob);                 
                

        //            document.getElementById('downfile').onclick = function (event) {                     
        //                this.target = '_blank';
                       
        //                //this.download = filename;

        //            }


        //        })
        //},
       

    }


})