﻿var app = new Vue({
    el: '#app', //el為要綁定的div的id(已設定完成)  
    data: {       
        //該頁會使用道的變數請統一放在這裡
        showConfirm: false,
        spectrumMethodInfos: [],
        frequencyTransformParms: [],
        checkedNames: [],
        confirmList: [],
        floatVal:1
    },
    mounted: function () {      
        var self = this;      
        self.getSpectrumMethodInfos();
        self.getFrequencyTransformParms();
        LayoutApp.showLoading = false;
    },
    methods: {
        getSpectrumMethodInfos: function () {
            var self = this;
            self.spectrumMethodInfos = LayoutApp.spectrumMethodInfos;            
        },
        getFrequencyTransformParms: function () {
            var self = this;


            var apiUrl = "/frequency_transform";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: {
                    parameter: [
                        "SPEED",
                        "CT",
                        "P3",
                        "P4"
                    ]
                }
            });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'get',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                params: {
                    project_id: LayoutApp.currentProjectId,
                    model_id: LayoutApp.currentModelId,
                }})
                .then(function (response) {
                    if (response.data.status == "OK")
                        self.frequencyTransformParms = response.data.data;
                })               

           
        },       
        confirm: function () {
            var self = this;     
            var spectrumCheckboxs = $('.spectrumCheckbox:checked');

            if (spectrumCheckboxs.length == 0) {
                alertify.error('You did not select any spectrums');
                return;
            }

            self.confirmList = [];
          

            var params = [];
            var preParam = "";
            for (var i = 0; i < spectrumCheckboxs.length; i++) {
               
                var temp = spectrumCheckboxs[i].id.split('-');

                //為了要比對每個param都至少選一個method
                if (i == 0) {                     
                    params.push(temp[0]);
                }
                else {
                    if (preParam != temp[0]) {
                        params.push(temp[0]);
                    }
                }

                var level = 1;
                if ($(spectrumCheckboxs[i]).attr('fullname').indexOf('Wavelet') > -1) level = null;

                self.confirmList.push({
                    param: temp[0],
                    method: temp[1],
                    method_param: {
                        samplerate: 4000,
                        level: 7 //20200204總立告知不讓User填寫，先統一帶7
                    }
                });   
                preParam = temp[0];
            }

            if (params.length != self.frequencyTransformParms.length) {
                self.confirmList = [];
                alertify.error('Each parameter need to select at least one method.');
            }
            else {
                self.showConfirm = true;
            }

        },
        reselectClick: function () {
            var self = this;
            alertify.confirm("Are you want to reselect spectrums?",
                function (e) {
                    if (e) {
                        //OK
                        self.confirmList = [];
                        self.showConfirm = false;
                       
                        var spectrumCheckboxs = $('.spectrumCheckbox:checked');
                        for (var i = 0; i < spectrumCheckboxs.length; i++) {
                            spectrumCheckboxs[i].checked = false;
                        }

                        
                    } else {
                        //Cancel                      
                    }
                });          

        },

        backClick: function () {
            var self = this;
            alertify.confirm("捨棄編輯中的內容，並回上一步驟?",
                function (e) {
                    if (e) {
                        //OK
                        window.location.href = "/Project/CheckData";
                    } else {
                        //Cancel                      
                    }
                });
        },
        saveClick: function () {
            var self = this;

            alertify.confirm("儲存編輯中的內容?",
                function (e) {
                    if (e) {
                        //OK
                        self.vaildDataAndSave();
                    } else {
                        //Cancel                      
                    }
                });  
        },
        nextClick: function () {
            var self = this;

            alertify.confirm("儲存編輯內容，並前往下一步驟?",
                function (e) {
                    if (e) {
                        //OK


                        self.vaildDataAndSave(function () { window.location.href = "/Project/FrequencyTransformPreview";});
                                         
                    } else {
                        //Cancel                      
                    }
                });          
        },

        vaildDataAndSave: function (fn) {
            var self = this;
            this.$validator.validateAll().then(function (result) {
                if (result) {
                    self.save(fn);
                }
                else {
                    alertify.error('欄位資料填寫錯誤');
                }
            })
        },

        save: function (fn) {
            var self = this;

            if (self.confirmList.length == 0) {
                alertify.error('You did not set samplingrate');
                return;
            }

            var apiUrl = "/frequency_transform";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                status: "OK"
            });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'post',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                data: {
                    project_id: LayoutApp.currentProjectId,
                    model_id: LayoutApp.currentModelId,
                    data:  self.confirmList
                }})
                .then(function (response) {
                    if (response.data.status == "OK") {
                        alertify.success("Save Success");       
                        if (fn) {
                            setTimeout(fn, 500);
                        }
                    }
                    else {
                        alertify.success("Save fail");                      
                    }
                })              

        }
        
    }
})