﻿var app = new Vue({
    el: '#app', //el為要綁定的div的id(已設定完成)  
    data: {
        statisticalInfos: [],
        spectrumStatisticals: [],
        spectrumStatisticalsPostData: []        
        
    },
    mounted: function () {       
        var self = this;
        self.getStatisticalInfos();
        self.getSpectrumStatisticals();     
        LayoutApp.showLoading = false;
    },
    methods: {       
        getStatisticalInfos: function () {
            var self = this;
            self.statisticalInfos = LayoutApp.statisticalInfos;           
        },

        getSpectrumStatisticals: function () {

            var self = this;
            var apiUrl = "/spectrum_statistical/get_list";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                code: 200,
                data: {
                    parameter: [
                        {
                            key: "CT",
                            spectrum: [
                                {
                                    item: "fft",
                                    spectrum_collection_info_id:1,
                                    statistical: [
                                        "Var",
                                        "Std"
                                    ]
                                }
                            ]
                        }
                    ]
                },
                description: "Get Spectrum list success"
            });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }
          
            axios({
                method: 'get',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                params: {
                    project_id: LayoutApp.currentProjectId,
                    model_id: LayoutApp.currentModelId,
                }
                })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.spectrumStatisticals = response.data.data.parameter;
                        for (var i = 0; i < self.spectrumStatisticals.length; i++) {   
                            for (var j = 0; j < self.spectrumStatisticals[i].spectrum.length; j++) {

                                if (self.spectrumStatisticals[i].spectrum[j].bin) {
                                    self.spectrumStatisticals[i].spectrum[j].bin = 1;
                                }
                                else {
                                    self.spectrumStatisticals[i].spectrum[j]["bin"] = 1;
                                }

                                var _statisticalInfos = [];
                                for (var k = 0; k < LayoutApp.statisticalInfos.length; k++) {

                                    var getData = self.spectrumStatisticals[i].spectrum[j].statistical.find(function (d) {
                                        return d == LayoutApp.statisticalInfos[k].abbreviation;
                                    });

                                    var ischeck = false;

                                    if (getData) {
                                        ischeck = getData.length > 0 ? true : false;
                                    }

                                    _statisticalInfos.push(
                                        {
                                            abbreviation:LayoutApp.statisticalInfos[k].abbreviation,
                                            isCheck:ischeck
                                        }
                                    );

                                }

                                self.spectrumStatisticals[i].spectrum[j].statistical = _statisticalInfos;
                            }
                        }

                    }
                      
                })             

        },

        openAllClick: function () {
            var self = this;
            var statisticalboxs = $('.statisticalbox');
            for (var i = 0; i < statisticalboxs.length; i++) {
                statisticalboxs[i].checked = true;               
                if (!statisticalboxs[i].className.includes('statisticalboxItem')) {
                      self.selectAll(statisticalboxs[i].id);
                }     
            }
        },

        cancelAllClick: function () {
            var self = this;
            var statisticalboxs = $('.statisticalbox');
            for (var i = 0; i < statisticalboxs.length; i++) {
                statisticalboxs[i].checked = false;
                if (!statisticalboxs[i].className.includes('statisticalboxItem')) {
                    self.selectAll(statisticalboxs[i].id);
                }           
            }           
        },

        selectAll: function (id) {
            var statisticalboxs = $('.' + id);
            var isCheckedAll = $('#' + id)[0].checked;
            for (var i = 0; i < statisticalboxs.length; i++) {
                statisticalboxs[i].checked = isCheckedAll;
                statisticalboxs[i].disabled = isCheckedAll;
            }

            if (isCheckedAll) {
                $('.' + id + '_td')[0].style.opacity = 0.1;                
            }
            else {
                $('.' + id + '_td')[0].style.opacity = 1;             
            }
        },


        backClick: function () {
            var self = this;
            alertify.confirm("捨棄編輯中的內容，並回上一步驟?",
                function (e) {
                    if (e) {
                        //OK
                        window.location.href = "/Project/FrequencyTransformPreview";
                    } else {
                        //Cancel                      
                    }
                });
        },

        saveClick: function () {
            var self = this;

            alertify.confirm("儲存編輯中的內容?",
                function (e) {
                    if (e) {
                        //OK
                        self.vaildDataAndSave();
                    } else {
                        //Cancel                      
                    }
                });             
        },

        nextClick: function () {
            var self = this;

            alertify.confirm("儲存編輯內容，並前往下一步驟?",
                function (e) {
                    if (e) {
                        //OK
                        self.vaildDataAndSave(function () { window.location.href = "/Project/FeatureExtractionPreview"; });
                    } else {
                        //Cancel                      
                    }
                });    

        },

        vaildDataAndSave: function (fn) {
            var self = this;
            this.$validator.validateAll().then(function (result) {
                if (result) {
                    self.save(fn);
                }
                else {
                    alertify.error('欄位資料填寫錯誤');
                }
            })
        },       

        save: function (fn) {

            var self = this;


            var statisticalboxs = $('.statisticalboxItem:checked');


            if (statisticalboxs.length == 0) {
                alertify.error('You did not select any statistical');
                return;
            }

            self.spectrumStatisticalsPostData = [];
            var preId, _parameter, _spectrum, _statistical, _spectrum_collection_info_id, _bin;
            var statisticals = [];
            for (var i = 0; i < statisticalboxs.length; i++) {

                var ids = $(statisticalboxs[i])[0].id.split('-');
                _spectrum_collection_info_id = ids[3];

                if (i == 0) preId = ids[3];
                else {
                    if (preId != parseInt(_spectrum_collection_info_id)) {
                        self.spectrumStatisticalsPostData.push(
                            {
                                spectrum_collection_info_id: parseInt(preId),
                                parameter: _parameter,
                                spectrum: _spectrum,
                                statistical: statisticals,
                                bin: parseInt(_bin)
                            }
                        );
                        statisticals = [];
                    }
                } 

                 _parameter = ids[0];
                 _spectrum = ids[1];
                 _statistical = ids[2];                
                _bin = $('#' + $(statisticalboxs[i]).attr('binName'))[0].value;       
                statisticals.push(_statistical);

                if (statisticalboxs.length - 1 == i) {
                    self.spectrumStatisticalsPostData.push(
                        {
                            spectrum_collection_info_id: parseInt(_spectrum_collection_info_id),
                            parameter: _parameter,
                            spectrum: _spectrum,
                            statistical: statisticals,
                            bin: parseInt(_bin)
                        }
                    );
                }
               
               
                preId = _spectrum_collection_info_id;
            }


            var apiUrl = "/spectrum_statistical";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                status: "OK"
            });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'post',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                data: {
                    project_id: parseInt(LayoutApp.currentProjectId),
                    model_id: parseInt(LayoutApp.currentModelId),
                    data: self.spectrumStatisticalsPostData
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        alertify.success("Save Success");
                        if (fn) {
                            setTimeout(fn, 500);
                        }
                    }
                    else {
                        alertify.success("Save fail");
                    }
                })              
        }
    }
})