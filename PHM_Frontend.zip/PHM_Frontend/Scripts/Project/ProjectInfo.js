﻿/*
˙Loading:如果URL有帶ProjectId則呼叫API-Flask-/project/detail [Get] 取得資料顯示到以下欄位
˙【Project Name】:自動檢查格式(格式:英數字，先不限制幾個字元)
˙【Model Type】:改為DropDownlist,資料來源直接參考畫面
˙【Application】:參考FlaskAPI文件(頁籤-UI項目列表與參數範圍)
˙【Fab】:API-DotNet-GetFabs(根據Applicatio連動)
˙【Module】:API-DotNet-Modules(根據Fab連動)
˙【Function】:API-DotNet-GetFunctions(根據Module連動)
˙【Tool Type】:資料來源:Opendata
˙【Tool】:可多選，API-DotNet-GetTools，含Continuous + APC資料
˙【Chember】:API-DotNet-GetChembers(根據Tool連動)
˙【Confirm】:顯示Tool Chamber Confirm List，展開下方清單
˙【Tool Chamber Confirm List-Delete】:只是刪除暫存於前端的資訊，不用調用API
˙【Back】:提示視窗確認User是否要放棄編輯回到前一步
˙【Save】:提醒視窗(提醒文字由芳榕提供)後調用API-Flask-/project   [Post]
˙【Next】:提醒視窗(提醒文字由芳榕提供)後調用API-Flask-/project   [Post]，並轉導到02_Upload Files
 */
var app = new Vue({
    el: '#app', //el為要綁定的div的id(已設定完成)  
    store: store,
    data: {
        //該頁會使用道的變數請統一放在這裡
        projectname: "",
        modeltype: "",
        applications: store.getters.getApplications,
        application: "",
        fabs: [],
        fab: "",
        stages: [],
        stage: "",
        functions: [],
        func: "", // function 是關鍵字會錯
        tooltypes: [],
        tooltype: "",
        tools: [],
        selectedtool: [],
        chambers: [],
        selectedchamber: [],
        datalist: [],
        showToolChamber: false, // 是否要顯示 tool - chamber list 的區塊
        model_id: 0, // 要 query 設定值分二次, 第一次 : /project 回傳中會有 model_id -> 要帶給第二次呼叫 /dropitem/tool_chamber 時用
        all_datasources: store.getters.getAllDataSources,
        data_source: 'user_upload',
        all_chambers: [],
        selectedtool_conti: [],
        isNull: false,
        isSame: false,
        btnClick: '',
        chamber_merge:false
    },
    mounted: function () {
        var self = this;
        self.Init();
        store.commit('setShowLoading', false);
    },
    watch: { //Watch使用場景:驗證資料

    },
    methods: {
        Init: function () {
            self = this;          

           
            if (store.getters.getCurrentProjectId != "") {
                self.getData_Comm();
            }
            else {
                // 選單的事件綁定
                $("select").change(function () {
                    if (this.value == undefined || this.value == "")
                        return;

                    switch (this.name) {
                        case "selFab":
                            self.getStages();
                            break;
                        case "selStage":
                            self.getFunctions();
                            break;
                        case "selFunction":
                            self.getToolTypes();
                            break;
                        case "selToolType":
                            self.getTools();
                            break;
                        case "selTool":
                            self.getChambers();
                            break;
                    }
                });

                self.getFabs();                
            }
        },

        Confirm: function () {
            self = this;
            console.log(self.modeltype.length);
            var sErr = '';
            //if ($('#txtProjectName').val().length == 0) {
            if (self.projectname.length == 0) {
                sErr += "[Project Name] is required \n</br>";
            }
            //if ($('input[name=rdoModelType]:checked').length == 0) {
            if (self.modeltype.length == 0) {
                sErr += "[Model Type] is required \n</br>";
            }
            $("select").each(function () {
                if (this.value == "")
                    sErr += "[" + this.name.substring(3) + "] is required \n</br>";
            })
            if (sErr.length > 0) {
                alertify.alert(sErr);
                return;
            }
            else {
                var iCnt = 0;
                //$("select[name='selTool'] option:selected").each(function () {
                $.each(self.selectedtool, function (index, value) {
                    var tool = value;
                    self.selectedtool_conti = value;
                    self.getChambersPromise().then(function () {
                        
                        //$("select[name='selChamber'] option:selected").each(function () {
                        $.each(self.selectedchamber, function (index, value) {
                            var chamber = value;
                            var item = { "item": ++iCnt, "tool": tool, "chamber": chamber, "real_chamber": [], "all_chamber": self.all_chambers };
                            self.datalist.push(item);
                        })
                    });
                })
                //console.log(self.datalist);
                self.showToolChamber = true;

                //$(".fas.fa-save").show();
            }
        },
        RemoveItem: function (row) {
          
            //if (confirm("Are you sure to remove this item?")) {
            //    self.datalist = self.datalist.filter(function (elem) {
            //        return elem != row
            //    });//resul
            //}

            alertify.confirm("Are you sure to remove this item?",
                function (e) {
                    if (e) {
                        self.datalist = self.datalist.filter(function (elem) {
                            return elem != row
                        });//resul
                    } else {
                        //Cancel                      
                        return;
                    }
                });
        }, 
        //Get Applications
        getApplications: function () {
            var apiUrl = "/dropitem";

            //用來模擬API的資料，實際上線不會執行這段
            var axiosApplication = axios.create();
            let mock = new AxiosMockAdapter(axiosApplication);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: [{
                    Key: "Robot_Test",
                    Value: 1
                },
                {
                    Key: "Pump",
                    Value: 2
                }
                ]
            });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            self.selectedtool = [];
            self.selectedchamber = [];

            var self = this;
            axiosApplication({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    "key": "Application"
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.applications = response.data.data;
                        //console.log(self.applications);
                    }
                    else
                        alertify.error("response status is not 'OK')");
                })
        },

        //Get Fabs
        getFabs: function () {
            store.commit('setShowLoading', true);

            var apiUrl = "/api/Basicinfor/GetFabs";

            ////用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "status": "OK", "data": [{ "fab": "C4A" }, { "fab": "C5D" }, { "fab": "C5E" }, { "fab": "C6C" }, { "fab": "L3C" }, { "fab": "L3D" }, { "fab": "L4A" }, { "fab": "L4B" }, { "fab": "L5A" }, { "fab": "L5B" }, { "fab": "L5C" }, { "fab": "L5D" }, { "fab": "L6A" }, { "fab": "L6B" }, { "fab": "L6K" }, { "fab": "L7A" }, { "fab": "L7B" }, { "fab": "L8A" }, { "fab": "L8B" }, { "fab": "M01" }, { "fab": "M02" }, { "fab": "M11" }], "message": null });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }          

            var self = this;
            self.stages = []; self.stage = "";
            axios({
                method: 'get',
                baseURL: '',
                url: apiUrl,
                params: {
                    SITEID: "TC"
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.fabs = response.data.data;
                        console.log(self.fabs);
                    }

                    store.commit('setShowLoading', false);
                })

        },

        //Get Stages
        getStages: function () {
            var self = this;
            
            var apiUrl = "/api/Basicinfor/GetModules";
            var dataType = "APC,CONTINUOUS";
            if (self.data_source == "continuous" || self.data_source == "raw_data") {
                //dataType = "CONTINUOUS";
                dataType = self.data_source;
            }
              
            ////用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "status": "OK", "data": [{ "stage": "ARRAY" }, { "stage": "CELL" }, { "stage": "CF" }], "message": null });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            store.commit('setShowLoading', true);
            
            self.stages = []; self.stage = "";
            self.functions = []; self.func = "";
            self.tooltypes = []; self.tooltype = "";
            self.tools = []; self.tool = "";
            self.chamber = []; self.chamber = "";
            axios({
                method: 'get',
                url: apiUrl,
                params: {
                    FabSite: self.fab,
                    DataType: dataType
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK")
                        self.stages = response.data.data;

                    store.commit('setShowLoading', false);
                })

        },

        //Get Functions
        getFunctions: function () {
            var self = this;
            var apiUrl = "/api/Basicinfor/GetFunctions";

            var dataType = "APC,CONTINUOUS";
            if (self.data_source == "continuous" || self.data_source == "raw_data") {
                //dataType = "CONTINUOUS";
                dataType = self.data_source;
            }
            ////用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "status": "OK", "data": [{ "func": "INT" }, { "func": "TF" }, { "func": "PHOTO" }, { "func": "FA" }, { "func": "ETCH" }, { "func": "MVA" }, { "func": "HR" }, { "func": "FAC" }], "message": null });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            store.commit('setShowLoading', true);
            
            self.functions = []; self.func = "";
            self.tooltypes = []; self.tooltype = "";
            self.tools = []; self.tool = "";
            self.chamber = []; self.chamber = "";
            axios({
                method: 'get',
                url: apiUrl,
                params: {
                    FabSite: self.fab,
                    ProcessType: self.stage,
                    dataType: dataType
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.functions = response.data.data;
                    }

                    store.commit('setShowLoading', false);
                })

        },

        //Get ToolTypes
        getToolTypes: function () {
            var self = this;

            var dataType = "APC,CONTINUOUS";
            var apiUrl = "/api/Basicinfor/GetToolTypes";
            if (self.data_source == "continuous" || self.data_source == "raw_data") {
                //dataType = "CONTINUOUS";
                dataType = self.data_source;
            }


            ////用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "status": "OK", "data": [{ "tool_type": "TRACK" }, { "tool_type": "ROBOT_INDEX" }, { "tool_type": "ROBOT_DB" }, { "tool_type": "ROBOT_COATER" }, { "tool_type": "ROBOT_DRY" }, { "tool_type": "ROBOT_SB" }, { "tool_type": "ROBOT_IF" }, { "tool_type": "ROBOT_HB" }, { "tool_type": "EXPOSE EDGE" }, { "tool_type": "SCANNER" }, { "tool_type": "Robot_Index" }, { "tool_type": "MTP" }], "message": null });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            store.commit('setShowLoading', true);
            
            self.tooltypes = []; self.tooltype = "";
            self.tools = []; self.tool = "";
            self.chamber = []; self.chamber = "";
            axios({
                method: 'get',
                url: apiUrl,
                params: {
                    FabSite: self.fab,
                    ProcessType: self.stage,
                    ModuleName: self.func,
                    DataType: dataType
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK")
                        self.tooltypes = response.data.data;

                    store.commit('setShowLoading', false);
                })

        },

        //Get Tools
        getTools: function () {
            var self = this;
            var dataType = "APC,CONTINUOUS";
            var apiUrl = "/api/Basicinfor/GetTools";
            if (self.data_source == "continuous" || self.data_source == "raw_data") {
                //dataType = "CONTINUOUS";
                dataType = self.data_source;
            }
            ////用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "status": "OK", "data": [{ "tool": "AAIEX100" }, { "tool": "AAIEX110" }, { "tool": "AAIEX200" }, { "tool": "AAIEX210" }, { "tool": "AAIEX300" }, { "tool": "AAIEX310" }, { "tool": "AAIEX400" }, { "tool": "AAIEX410" }, { "tool": "AAIEX500" }, { "tool": "AAIEX510" }, { "tool": "AAIEX600" }, { "tool": "AAIEX610" }, { "tool": "AAIEX700" }, { "tool": "AAIEX710" }, { "tool": "AAIEX800" }, { "tool": "AAIEX810" }, { "tool": "AAIEX900" }, { "tool": "AAIEX910" }, { "tool": "AAIEXA00" }, { "tool": "AAIEXA10" }, { "tool": "AAIEXB00" }, { "tool": "AAIEXB10" }, { "tool": "AAIEXC00" }, { "tool": "AAIEXC10" }, { "tool": "AAIEXD00" }, { "tool": "AAIEXD10" }, { "tool": "AAIEXF00" }, { "tool": "AAIEXF10" }, { "tool": "AAIEXG00" }, { "tool": "AAIEXG10" }, { "tool": "AAIEXH00" }, { "tool": "AAIEXH10" }, { "tool": "AAIEXJ00" }, { "tool": "AAIEXJ10" }, { "tool": "AAIEXK00" }, { "tool": "AAIEXK10" }, { "tool": "AAIEXL00" }, { "tool": "AAIEXL10" }, { "tool": "AAIEXM00" }, { "tool": "AAIEXM10" }, { "tool": "AAIEXN00" }, { "tool": "AAIEXN10" }, { "tool": "AAIEXP00" }, { "tool": "AAIEXP10" }, { "tool": "AAIEXQ00" }, { "tool": "AAIEXQ10" }, { "tool": "AAIEXR00" }, { "tool": "AAIEXR10" }, { "tool": "AAIEXS00" }, { "tool": "AAIEXS10" }, { "tool": "AAIEXT00" }, { "tool": "AAIEXT10" }], "message": null });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            
            self.tools = []; self.tool = "";
            self.chambers = []; self.chamber = "";
            axios({
                method: 'get',
                url: apiUrl,
                params: {
                    FabSite: self.fab,
                    ProcessType: self.stage,
                    ModuleName: self.func,
                    ToolType: self.tooltype,
                    DataType: dataType
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK")
                        self.tools = response.data.data;
                })


        },

        //Get Chambers
        getChambers: function () {
            var self = this;
            var dataType ="RD,CONTINUOUS"
            var apiUrl = "/api/Basicinfor/GetChambers";
            if (self.data_source == "continuous" || self.data_source == "raw_data") {
                //dataType = "CONTINUOUS";
                dataType = self.data_source;
            }

            store.commit('setShowLoading', true);

            ////用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "status": "OK", "data": [{ "chamber": "COATER" }, { "chamber": "KPC_1" }, { "chamber": "KPC_2" }, { "chamber": "KPC_AACVD210" }, { "chamber": "KPC_AACVD410" }, { "chamber": "KPC_AACVD510" }, { "chamber": "KPC_AACVD910" }, { "chamber": "KPC_AACVDC10" }, { "chamber": "KPC_AACVDF10" }, { "chamber": "KPC_AAIEX110" }, { "chamber": "KPC_AAIEX210" }, { "chamber": "KPC_AAIEX310" }, { "chamber": "KPC_AAIEX410" }, { "chamber": "KPC_AAIEX810" }, { "chamber": "KPC_AAIEX910" }, { "chamber": "KPC_AAIEXA10" }, { "chamber": "KPC_AAIEXB10" }, { "chamber": "KPC_AAIEXC10" }, { "chamber": "KPC_AAIEXD10" }, { "chamber": "KPC_AAIEXF10" }, { "chamber": "KPC_AAIEXG10" }, { "chamber": "KPC_AAIEXH10" }, { "chamber": "KPC_AAIEXJ10" }, { "chamber": "KPC_AAIEXK10" }, { "chamber": "KPC_AAIEXL10" }, { "chamber": "KPC_AAIEXM10" }, { "chamber": "KPC_AAIEXN10" }, { "chamber": "KPC_AAIEXP10" }, { "chamber": "KPC_AAIEXQ10" }, { "chamber": "KPC_AAIEXR10" }, { "chamber": "KPC_AAIEXS10" }, { "chamber": "KPC_AAIEXT10" }, { "chamber": "KPC_AASPT110" }, { "chamber": "KPC_AASPT210" }, { "chamber": "KPC_AASPT410" }, { "chamber": "KPC_AASPT610" }, { "chamber": "KPC_AASPT710" }, { "chamber": "KPC_AASPT910" }, { "chamber": "KPC_AASPTG10" }, { "chamber": "KPC_AASTA100" }, { "chamber": "KPC_AASTA200" }, { "chamber": "KPC_AASTA300" }, { "chamber": "KPC_AASTO200" }, { "chamber": "KPC_AASTO300" }, { "chamber": "KPC_AASTO400" }, { "chamber": "KPC_AASTO500" }, { "chamber": "KPC_AASTO600" }, { "chamber": "KPC_AASTO700" }, { "chamber": "KPC_AASTO800" }, { "chamber": "KPC_AAWMA200" }, { "chamber": "KPC_AAWMA300" }, { "chamber": "KPC_AAWMA400" }, { "chamber": "KPC_AAWMA500" }, { "chamber": "KPC_AAWMA600" }, { "chamber": "KPC_AAWTO100" }, { "chamber": "KPC_AAWTO200" }, { "chamber": "KPC_AAWTO300" }, { "chamber": "LC_DRY" }, { "chamber": "X" }, { "chamber": "CLEANER_AK" }, { "chamber": "CLN_HIPUMP" }, { "chamber": "COATER_PT" }, { "chamber": "COATER_WIND" }, { "chamber": "DRY_WIND" }, { "chamber": "HB1_CURRENT" }, { "chamber": "HB2_CURRENT" }, { "chamber": "HB3_CURRENT" }, { "chamber": "HB4_CURRENT" }, { "chamber": "PLC_POLLING_IO" }, { "chamber": "SB_WIND" }, { "chamber": "SB1_CURRENT" }, { "chamber": "SB2_CURRENT" }, { "chamber": "SB3_CURRENT" }, { "chamber": "TRANSFER_MOTOR" }, { "chamber": "VCD_PUMPA_CT" }, { "chamber": "VCD_PUMPB_CT" }], "message": null });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }


            self.chambers = []; self.chamber = "";
            axios({
                method: 'get',
                url: apiUrl,
                params: {
                    FabSite: self.fab,
                    ProcessType: self.stage,
                    ModuleName: self.func,
                    ToolType: self.tooltype,
                    ToolID: self.selectedtool.toString(),
                    dataType: dataType
                }
            })
                .then(function (response) {

                    if (response.data.status == "OK") {
                        if (response.data.data == null) {
                            alertify.error("查無資料!!");
                        } else {
                            self.chambers = response.data.data;
                        }
                    }                      

                    store.commit('setShowLoading', true);
                })


        },

        getChambersPromise: function () {
            var self = this;
            self.datalist = [];

            var dataType = "APC,CONTINUOUS";          
            if (self.data_source == "continuous" || self.data_source == "raw_data") {
                //dataType = "CONTINUOUS";
                dataType = self.data_source;
            }      

            return new Promise(function (resolve, reject) {


                var apiUrl = "/api/Basicinfor/GetChambers";


                ////用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, { "status": "OK", "data": [{ "chamber": "COATER" }, { "chamber": "KPC_1" }, { "chamber": "KPC_2" }, { "chamber": "KPC_AACVD210" }, { "chamber": "KPC_AACVD410" }, { "chamber": "KPC_AACVD510" }, { "chamber": "KPC_AACVD910" }, { "chamber": "KPC_AACVDC10" }, { "chamber": "KPC_AACVDF10" }, { "chamber": "KPC_AAIEX110" }, { "chamber": "KPC_AAIEX210" }, { "chamber": "KPC_AAIEX310" }, { "chamber": "KPC_AAIEX410" }, { "chamber": "KPC_AAIEX810" }, { "chamber": "KPC_AAIEX910" }, { "chamber": "KPC_AAIEXA10" }, { "chamber": "KPC_AAIEXB10" }, { "chamber": "KPC_AAIEXC10" }, { "chamber": "KPC_AAIEXD10" }, { "chamber": "KPC_AAIEXF10" }, { "chamber": "KPC_AAIEXG10" }, { "chamber": "KPC_AAIEXH10" }, { "chamber": "KPC_AAIEXJ10" }, { "chamber": "KPC_AAIEXK10" }, { "chamber": "KPC_AAIEXL10" }, { "chamber": "KPC_AAIEXM10" }, { "chamber": "KPC_AAIEXN10" }, { "chamber": "KPC_AAIEXP10" }, { "chamber": "KPC_AAIEXQ10" }, { "chamber": "KPC_AAIEXR10" }, { "chamber": "KPC_AAIEXS10" }, { "chamber": "KPC_AAIEXT10" }, { "chamber": "KPC_AASPT110" }, { "chamber": "KPC_AASPT210" }, { "chamber": "KPC_AASPT410" }, { "chamber": "KPC_AASPT610" }, { "chamber": "KPC_AASPT710" }, { "chamber": "KPC_AASPT910" }, { "chamber": "KPC_AASPTG10" }, { "chamber": "KPC_AASTA100" }, { "chamber": "KPC_AASTA200" }, { "chamber": "KPC_AASTA300" }, { "chamber": "KPC_AASTO200" }, { "chamber": "KPC_AASTO300" }, { "chamber": "KPC_AASTO400" }, { "chamber": "KPC_AASTO500" }, { "chamber": "KPC_AASTO600" }, { "chamber": "KPC_AASTO700" }, { "chamber": "KPC_AASTO800" }, { "chamber": "KPC_AAWMA200" }, { "chamber": "KPC_AAWMA300" }, { "chamber": "KPC_AAWMA400" }, { "chamber": "KPC_AAWMA500" }, { "chamber": "KPC_AAWMA600" }, { "chamber": "KPC_AAWTO100" }, { "chamber": "KPC_AAWTO200" }, { "chamber": "KPC_AAWTO300" }, { "chamber": "LC_DRY" }, { "chamber": "X" }, { "chamber": "CLEANER_AK" }, { "chamber": "CLN_HIPUMP" }, { "chamber": "COATER_PT" }, { "chamber": "COATER_WIND" }, { "chamber": "DRY_WIND" }, { "chamber": "HB1_CURRENT" }, { "chamber": "HB2_CURRENT" }, { "chamber": "HB3_CURRENT" }, { "chamber": "HB4_CURRENT" }, { "chamber": "PLC_POLLING_IO" }, { "chamber": "SB_WIND" }, { "chamber": "SB1_CURRENT" }, { "chamber": "SB2_CURRENT" }, { "chamber": "SB3_CURRENT" }, { "chamber": "TRANSFER_MOTOR" }, { "chamber": "VCD_PUMPA_CT" }, { "chamber": "VCD_PUMPB_CT" }], "message": null });

                if (LayoutApp.env == 'prd') {
                    mock.restore();
                }


                var responseData = {};
                axios({
                    method: 'get',
                    url: apiUrl,
                    params: {
                        FabSite: self.fab,
                        ProcessType: self.stage,
                        ModuleName: self.func,
                        ToolType: self.tooltype,
                        ToolID: self.selectedtool_conti.toString(),
                        DataType: dataType
                    }
                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            self.all_chambers = response.data.data;
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },

        // get Data
        getData_Comm: function () {

            var apiUrl = "/project";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "code": 200, "data": { "project_list": [{ "ai365_project_name": "Jaz_test", "application": "MOTOR", "chamber_merge": false, "data_source": "user_upload", "data_type": "Feature", "fab": "L4B", "func": "PI", "itime": "2021-05-06 14:25:04", "model_id": 3731, "model_type": "anomaly_detection", "offline_model_status": 802, "project_id": 3732, "stage": "CELL", "status": "create", "tool_type": "PI_COATER", "user_deptid": "ML4BK2", "user_empno": "Y1604005" }], "total_count": 1 }, "description": "Get Project list success", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    "project_id": store.getters.getCurrentProjectId
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        var itemdata = response.data.data.project_list[0];
                        self.projectname = itemdata.ai365_project_name;
                        self.modeltype = itemdata.model_type;
                        self.application = itemdata.application;
                        self.fabs = [itemdata];
                        self.fab = itemdata.fab;
                        self.stages = [itemdata];
                        self.stage = itemdata.stage;
                        self.functions = [itemdata];
                        self.func = itemdata.func; // function 是關鍵字會錯
                        self.tooltypes = [itemdata];
                        self.tooltype = itemdata.tool_type;
                        self.model_id = itemdata.model_id;
                        self.data_source = itemdata.data_source;
                        if (self.data_source == "user_upload") {
                            // 取得 tool_chamber 的設定值
                            self.getData_ToolChamber(self.model_id);
                        } else if (self.data_source == "continuous" || self.data_source == "raw_data") {
                            self.getToolChamberListPromise().then(function () {

                            });
                        }
                    }
                    else
                        alertify.error("get data fail. error message = " + response.data.data.message);
                })

        },
        getData_ToolChamber: function (model_id) {

            var apiUrl = "/dropitem/tool_chamber";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "code": 200, "data": [{ "Chamber": ["COATER"], "Key": "AAIEX100", "Value": 1 }], "description": "Get DropdownList", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    "model_id": model_id
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        var iCnt = 0;
                        var tools = [];
                        var chambers = [];
                        $.each(response.data.data, function (index, objTool) {
                            $.each(objTool.Chamber, function (index, value) {
                                var chamber = value;
                                var item = { "item": ++iCnt, "tool": objTool.Key, "chamber": chamber };
                                self.datalist.push(item);

                                var exists = false;
                                $.each(tools, function (key, val) {
                                    if (val.tool == objTool.Key) { exists = true; }
                                });
                                if (exists == false)
                                    tools.push({ tool: objTool.Key });

                                exists = false;
                                $.each(chambers, function (key, val) {
                                    if (val.chamber == chamber) { exists = true; }
                                });
                                if (exists == false)
                                    chambers.push({ chamber: chamber });
                            })
                        })
                        self.tools = tools.sort(function (a, b) {
                            return a.tool.localeCompare(b.tool);
                        });
                        self.chambers = chambers.sort(function (a, b) {
                            return a.chamber.localeCompare(b.chamber);
                        });
                        self.showToolChamber = true;
                    }
                    else
                        alertify.error("get data fail. error message = " + response.data.data.message);
                })

        },

        getToolChamberListPromise: function () {
            var self = this;


            return new Promise(function (resolve, reject) {


                var apiUrl = "/project_tool_chamber_list";
                
                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, { "code": 200, "data": [{ "Chamber": ["COATER"], "Key": "AAIEX100", "Value": 1 }], "description": "Get DropdownList", "status": "OK" });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                var responseData = {};
                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                    }

                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            if (response.data.data == null) {
                                alertify.error("查無資料!!");
                            } else {
                                var iCnt = 0;
                                var tools = [];
                                var chambers = [];
                                $.each(response.data.data.tool_chamber_list, function (index, objTool) {
                                    self.selectedtool_conti = objTool.tool_id;
                                    self.getChambersPromise().then(function () {

                                        var item = {
                                            "item": ++iCnt, "tool": objTool.tool_id, "chamber": objTool.chamber
                                            , "real_chamber_list": objTool.real_chamber_list
                                            , "all_chamber": self.all_chambers
                                            , "item_count": response.data.data.tool_chamber_list.length
                                        };

                                        self.datalist.push(item);

                                        var exists = false;
                                        $.each(tools, function (key, val) {
                                            if (val.tool == objTool.tool_id) { exists = true; }
                                        });
                                        if (exists == false)
                                            tools.push({ tool: objTool.tool_id });

                                        exists = false;
                                        $.each(chambers, function (key, val) {
                                            if (val.chamber == objTool.chamber) { exists = true; }
                                        });
                                        if (exists == false)
                                            chambers.push({ chamber: objTool.chamber });

                                    });
                                });

                                self.tools = tools.sort(function (a, b) {
                                    return a.tool.localeCompare(b.tool);
                                });
                                self.chambers = chambers.sort(function (a, b) {
                                    return a.chamber.localeCompare(b.chamber);
                                });

                                self.showToolChamber = true;

                            }
                        } else
                            alertify.error("get data fail. error message = " + response.data.data.message);



                        resolve();
                    }).catch(function (err) {
                        store.commit('setShowLoading', false);

                    })

            });


        },

        vaildDataAndSave: function (btnClick) {
            var self = this;
            self.isNull = false;
            self.isSame = false;
            if (self.data_source == "continuous" || (self.data_source == "raw_data" && self.chamber_merge==false)) {

                self.datalist.forEach(function (val, idx) {
                    if (val.real_chamber_list.length == 0) {
                        self.isNull = true;
                    }
                });

                if (self.isNull == true) {
                    alertify.error('Please Select Real Chamber !!');
  
                }

                var _chamber = [];
                self.datalist.forEach(function (val, idx) {
                    var arRC = val.real_chamber_list.sort(function (a, b) {
                        return a.localeCompare(b);
                    });
                    _chamber.push(arRC.join());
                });

                var _start = "", _end = "";

                _chamber.forEach(function (val, idx) {
                    if (idx > 0) {
                        _end = val;
                    }
                    
                    if (_start != _end)
                        self.isSame = true;

                    _start = val;
                });

                if (self.isSame == true) {
                    alertify.error('Real Chamber必須一樣 !!');
                }


            }


            if (self.isSame == false && self.isNull == false) {
                self.saveData(function () {
                    if (self.btnClick == "Next") {
                        if (self.data_source == "continuous") {
                            window.location.href = "/ProjectConti/ParameterSelect";
                        }
                        else if (self.data_source == "raw_data") {
                            window.location.href = "/ProjectRawData/ParameterSelectRawData";
                        } else {
                            window.location.href = "/Project/UploadFiles";
                        }
                    }//if (self.btnClick == "Next") {
                });
            }

        },

        //儲存按鈕觸發事件
        saveClick: function () {
            var self = this;
            self.btnClick = "Save";
            alertify.confirm("儲存編輯中的內容?",
                function (e) {
                    if (e) {
                        //OK
                        self.vaildDataAndSave(function () {

                        });
                    } else {
                        //Cancel                      
                    }
                });
        },
        // save Data
        saveData: function (fn) {
           
            var apiUrl = "/project";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, { "code": 200, "data": { "model_id": 3735, "project_id": 3736 }, "description": "Create Project success", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            if (store.getters.getEnv != 'prd') {
                self.projectname = "AA";
                self.modeltype = "Health Assessment";
                self.application = "1";
                self.fab = "L5C";
                self.stage = "ARRAY";
                self.func = "INT";
                self.tooltype = "OVEN";
                self.datalist = [{
                    "item": 1,
                    "tool": "ABANI100",
                    "chamber": "KPC_ABANI100"
                },
                {
                    "item": 2,
                    "tool": "ABANI100",
                    "chamber": "KPC_B"
                }];
            }
            axios({
                method: 'post',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                headers: {
                    accept: "application/json",
                    "content-type": "application/json;charset=UTF-8"
                },
                data: {
                    project_id: store.getters.getCurrentProjectId == "" ? null : store.getters.getCurrentProjectId,
                    project_name: self.projectname,
                    model_type: self.modeltype,
                    application: self.application,
                    fab: self.fab,
                    stage: self.stage,
                    //process_type: self.stage,
                    //function: self.func,
                    func: self.func,
                    section: "",//self.section,
                    tool_type: self.tooltype,
                    tool_chamber_list: self.datalist,
                    user_empno: UserInfoApp.userInfo.UserId,
                    user_depid: UserInfoApp.userInfo.UserDeptID,
                    user_email: UserInfoApp.userInfo.UserEmail,
                    data_source: self.data_source,
                    chamber_merge: self.chamber_merge
                }
                //,
                //proxy: {
                //    host: "10.97.4.1",
                //    port: 8080
                //}
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        store.commit('setCurrentProjectId', response.data.data.project_id);
                        store.commit('setCurrentModelId', response.data.data.model_id);
                        alertify.success("save data sucessful. project_id = " + response.data.data.project_id
                            + ", model_id = " + response.data.data.model_id);
                        //$(".fas.fa-save").hide();
                        //$(".fas.fa-chevron-right").show();
                        $(".fas.fa-save").unbind("click").prop("disabled", true);

                        if (fn)
                            fn();
                    }
                    else
                        alertify.error("save data fail. error message = " + response.data.data);
                })

        },

        goNext: function () {
            var self = this;
            self.btnClick = "Next";
            alertify.confirm("Are you sure want to leave this page and go to the next step??",
                function (e) {
                    if (e) {
                        //OK


                        self.vaildDataAndSave(function () {

                        })


                        
                        //self.saveData(function () {
                        //    window.location.href = "/Project/UploadFiles";
                        //});

                    } else {
                        //Cancel                      
                    }
                });
        },

        changeDataSource: function () {
            this.selectedtool = [];
            this.selectedchamber = [];
        },

        changeApplication: function () {
            this.selectedtool = [];
            this.selectedchamber = [];
        }
    }
})