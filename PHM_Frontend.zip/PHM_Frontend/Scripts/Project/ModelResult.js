﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {
        modeltype: "",//app.currentModelType,//"",//有三種，分別會顯示不同區塊anomaly_detection : Anomaly Detection 、  health_assessment: Health Assessment 、prognostic : Prognostic 
        ToolIDs: [],
        ToolID: "",
        Chambers: [],
        Chamber: "",
        ChartDatas: [],
        method: "",
        method2: "",
        HAChartDatas: [],
        currentHAChartDatas: [],
        PModelDatas: [],
        //currentPSelect:"",
        currentPData: {},
        currentHAData: {},
        currentPData2: {},
        AutoShowChart: true,
        isFromRadio: false,
        currentProjectId: store.getters.getCurrentProjectId,
        edgeSettingFileUrl: '',
        isShowEdgeSettingDownload: false,
        showModelingAlgorithm:false,
        method: "",
        method_para: 0,      
        modeling_method: "",
        n_neighbors: 0, 

        //判斷分數
        scoreLevel: null,
        badScore: 50,
        goodScore:80
    },
    mounted: function () {
        var self = this;     
        //if (!store.getters.getCurrentModelType) {
        //    //Jane Notes:這樣寫有重複執行GetProJectInfo的問題，待優化:須了解Vue Store的生命周期去控制LayoutApp和當頁App的執行順序
        //    LayoutApp.getProjectInfo(self.init);          
        //}
        //else {          
            self.init();          
        //}

        self.checkEdgeDownloadUrl();
        store.commit('setShowLoading', false);         
    },
    methods: { 
        init: function () {
            var self = this;          

            self.modeltype = store.getters.getCurrentModelType;
            

            self.getTools().then(
                function () {
                    if (self.modeltype == "health_assessment") {
                        self.getHAChartDatas();
                    } else if (self.modeltype == "prognostic") {
                        self.getPChartDatas();
                    } else {
                        self.isFromRadio = true;
                    }
                }
            );  

            self.get_method();
        },

        checkEdgeDownloadUrl: function () {
            var self = this;
            self.edgeSettingFileUrl = 'http://tcapcphmd01:8000/download_edge_feature_engineering_info?project_id=' + self.currentProjectId;


            $.ajax({
                type: 'get',
                url: self.edgeSettingFileUrl,                
                async: false,   
                success: function (xmlobj) {
                    self.isShowEdgeSettingDownload = true;
                },
                error: function (result) {
                    self.isShowEdgeSettingDownload = false;  
                }
            });


        },       

        getTools: function () {

            var self = this;

            return new Promise(function (resolve, reject) {

                var apiUrl = "/dropitem/tool_chamber";
                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onGet(apiUrl).reply(200, { "code": 200, "data": [{ "Chamber": ["COATER"], "Key": "ACIEX110", "Value": 1 }], "description": "Get DropdownList", "status": "OK" });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }


                axios({
                    method: 'get',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    params: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId
                    }
                })
                    .then(function (response) {
                        if (response.data.status == "OK") {
                            self.ToolIDs = response.data.data;


                            // 2020-03-03 09:29 Amanda
                            if (self.AutoShowChart && self.ToolIDs.length > 0) {
                                self.ToolID = self.ToolIDs[0].Key;
                                console.log(self.ToolID);
                                self.getChambers();
                            }

                        } else {
                            alertify.success("get data fail. error message = " + response.data.data.message);
                        }
                        resolve();

                    })
            });
        },
        getChambers: function (event) {

            var self = this;
            self.Chamber = "";
            self.Chambers = [];
           
            //alert(Object.keys(self.ToolIDs).length);
            var arChamber = self.ToolIDs.filter(function (item, index) {
                //alert(item.Key)
                if (item.Key == self.ToolID)
                    return item.Chamber;
            })

            self.Chambers = arChamber[0].Chamber;

            // 2020-03-03 09:29 Amanda
            if (self.AutoShowChart && self.Chambers.length > 0) {
                self.Chamber = self.Chambers[0];
                console.log(self.Chamber);
                console.log(self.method); 

                if (self.modeltype == "anomaly_detection") {
                    self.isFromRadio = true;
                } 

                if (self.isFromRadio == true)
                    self.DrawChart();
            }



        },        
        getADChartDatas: function () {
            var self = this;

            if (self.ToolID == "") {
                alertify.error("Please Select Tool !!");
                return;
            }
            if (self.Chamber == "") {
                alertify.error("Please Select Chamber !!");
                return;
            }
            var apiUrl = "/modeling";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "code": 200, "data": [{ "method": "LOF", "method_result": { "anomaly_lower_threshold": 20, "anomaly_upper_threshold": 100, "anomaly_warning_threshold": 50, "data": [{ "anomaly_score_list": [96.163389, 95.332245, 96.223124, 94.623465, 91.493198, 94.620086, 96.745819, 94.500107, 96.021301, 94.304037, 96.123397, 94.68538, 92.608252, 95.201699, 95.022949, 95.000142, 93.590616, 96.165581, 91.624688, 91.767341, 91.498679, 96.327167, 92.192899, 95.563058, 88.830249, 96.570949, 92.56283, 93.731064, 91.299565, 94.225083, 90.781333, 95.711378, 86.970904, 94.158515, 94.556868, 94.705951, 94.420544, 95.714928, 92.150681, 95.233561, 93.76701, 92.55352, 95.302466, 88.023257, 96.728168, 91.666875, 95.775431, 90.96196, 96.093692, 90.348854, 92.691443, 95.824838, 91.661534, 95.30067, 50.158585, 87.517726, 94.602896, 95.265817, 96.938815, 93.550299, 88.068637, 82.139315, 92.627351, 90.747892, 94.831618], "anomaly_score_outlier_list": [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false], "chamber": "COATER", "mxci_outlier": [false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false], "mxci_score": [-0.997911, -1.027364, -1.006492, -1.05916, -1.004692, -1.020608, -0.995983, -1.000176, -0.993455, -1.041359, -1.311746, -1.01513, -0.994956, -0.994223, -0.996353, -1.032678, -1.03065, -0.997637, -1.009479, -0.996808, -1.012201, -0.999298, -1.037052, -0.998142, -1.014049, -1.014046, -0.993008, -1.000673, -1.000198, -0.996614, -1.002399, -1.013644, -0.999561, -0.991374, -0.995012, -1.023584, -1.003444, -1.008614, -0.993101, -1.054723, -0.995729, -1.049851, -0.998699, -1.010247, -0.989299, -1.006288, -1.012315, -1.013126, -0.999876, -0.993831, -1.018848, -0.995161, -1.003941, -1.000624, -0.994464, -1.011198, -0.99309, -1.004751, -0.989288, -1.016267, -1.003141, -0.994233, -1.008651, -0.997005, -0.99811], "mxci_threshold": [-1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746, -1.311746], "start_time_list": ["2020-02-18 11:14:13", "2020-02-18 11:14:15", "2020-02-18 11:14:16", "2020-02-18 11:14:16", "2020-02-18 11:14:17", "2020-02-18 11:14:17", "2020-02-18 11:14:19", "2020-02-18 11:14:19", "2020-02-18 11:14:19", "2020-02-18 11:14:19", "2020-02-18 11:14:19", "2020-02-18 11:14:21", "2020-02-18 11:14:21", "2020-02-18 11:14:22", "2020-02-18 11:14:22", "2020-02-18 11:14:23", "2020-02-18 11:14:23", "2020-02-18 11:14:25", "2020-02-18 11:14:25", "2020-02-18 11:14:26", "2020-02-18 11:14:27", "2020-02-18 11:14:27", "2020-02-18 11:14:29", "2020-02-18 11:14:29", "2020-02-18 11:14:29", "2020-02-18 11:14:29", "2020-02-18 11:14:31", "2020-02-18 11:14:31", "2020-02-18 11:14:33", "2020-02-18 11:14:33", "2020-02-18 11:14:37", "2020-02-18 11:14:38", "2020-02-18 11:14:38", "2020-02-18 11:14:38", "2020-02-18 11:14:38", "2020-02-18 11:14:38", "2020-02-18 11:14:40", "2020-02-18 11:14:40", "2020-02-18 11:14:40", "2020-02-18 11:14:40", "2020-02-18 11:14:42", "2020-02-18 11:14:43", "2020-02-18 11:14:43", "2020-02-18 11:14:45", "2020-02-18 11:14:45", "2020-02-18 11:14:45", "2020-02-18 11:14:45", "2020-02-18 11:14:46", "2020-02-18 11:14:46", "2020-02-18 11:14:46", "2020-02-18 11:14:46", "2020-02-18 11:14:46", "2020-02-18 11:14:51", "2020-02-18 11:14:51", "2020-02-18 11:14:51", "2020-02-18 11:14:53", "2020-02-18 11:14:53", "2020-02-18 11:14:53", "2020-02-18 11:14:53", "2020-02-18 11:14:53", "2020-02-18 11:14:55", "2020-02-18 11:14:55", "2020-02-18 11:14:55", "2020-02-18 11:14:55", "2020-02-18 11:14:55"], "test_use_list": [false, false, false, false, false, true, false, false, false, false, false, true, true, true, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, true, false, true, false, false, false, false, true, true, false, true, false, false, false, false, true, true, false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false], "tool": "AAIEX100" }] } }], "description": "Successful response", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;


            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId
                }

            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                       
                        self.ChartDatas = response.data.data;
                        self.checkToolChamberHasChartData();

                        self.getAllToolChamberScore();

                        Vue.nextTick()
                            .then(function () {
                                self.ClearECharts();
                                self.DrawLOFChart();
                            });
                       
                        //self.DrawMXCIChart();
                    } else {
                        alertify.success("get data fail. error message = " + response.data.data.message);
                    }                    
                })  
        },
        //backClick: function () {
        //    var self = this;
        //    alertify.confirm("Are you sure want to leave the [Feature Transform Preview] page and go back to the previous step??",
        //        function (e) {
        //            if (e) {
        //                //OK
        //                window.location.href = "/Project/ModelResult";
        //            } else {
        //                //Cancel                      
        //            }
        //        });
        //},
        DrawLOFChart: function () {
            //var arColor = ['#69FFF5F', '#00EACD', '#43A047', '#92D050', '#D05052', '#FF7800', '#FFFF00', '#A349A4', '#F06292', '#7E57C2', '#02B9C4', '#5292B3', '#DAF7A6', '#49ff33', '#b9e7ff', '#83B9C7', '#2ACDC9', '#FFD000', '#7CFEF0', '#d7f96e'];
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];

            var self = this;
            var _series = [], _legend = [], _xAxis = [], _upper = [], _lower = [];
            var _NGData = [];
            var _Testing = [];
            var _MXCI = [];
            //_legend.push("LOF");            
            _legend.push(self.ChartDatas[0].method); 
            _legend.push("NG");
            _legend.push("Testing");
            _legend.push("Upper");
            _legend.push("Lower");




            for (var i = 0; i < self.ChartDatas.length; i++) {

                for (var j = 0; j < self.ChartDatas[i].method_result.data.length; j++) {


                   



                    if (self.ToolID == self.ChartDatas[i].method_result.data[j].tool && self.Chamber == self.ChartDatas[i].method_result.data[j].chamber) {
                        _xAxis = self.ChartDatas[i].method_result.data[j].start_time_list;
                        for (var k = 0; k < self.ChartDatas[i].method_result.data[j].anomaly_score_outlier_list.length; k++) {
                            _upper.push(self.ChartDatas[i].method_result.anomaly_upper_threshold);
                            _lower.push(self.ChartDatas[i].method_result.anomaly_lower_threshold);

                            if (self.ChartDatas[i].method_result.data[j].anomaly_score_outlier_list[k] == true) {
                                _NGData.push(self.ChartDatas[i].method_result.data[j].anomaly_score_list[k]);
                            } else {
                                _NGData.push(null);
                            }

                            if (self.ChartDatas[i].method_result.data[j].test_use_list[k] == true)
                                _Testing.push(self.ChartDatas[i].method_result.data[j].anomaly_score_list[k]);
                            else
                                _Testing.push(null);

                        }
                        _series.push({
                            //name: 'LOF',
                            name: self.ChartDatas[0].method,
                            data: self.ChartDatas[i].method_result.data[j].anomaly_score_list,
                            type: 'scatter',
                            itemStyle: {
                                color: '#99ff99'//arColor[_series.length]
                            },

                        });

                        
                      
                        _series.push({
                            name: 'Upper',
                            data: _upper,
                            type: 'line',
                            symbol: 'none',
                            smooth: true,
                            itemStyle: {   
                                color: '#FF9326',
                            }
                        });

                        _series.push({
                            name: 'Lower',
                            data: _lower,
                            type: 'line',
                            symbol: 'none',
                            smooth: false,
                            itemStyle: {
                                color: '#FF9326',
                            }
                        });              



                        _series.push({ name: 'NG', data: _NGData, type: 'scatter', itemStyle: { color: '#f05050'  } });//'#F85256'
                        _series.push({ name: 'Testing', data: _Testing, type: 'scatter', symbol: 'triangle', smooth: true, itemStyle: { color: '#66ccff' } });//arColor[_series.length]

                        _MXCI.push({ name: 'MXCI', data: self.ChartDatas[i].method_result.data[j].mxci_score, type: 'scatter', itemStyle: { color: arColor[_MXCI.length] } });
                        _MXCI.push({ name: 'MXCI_Threshold', data: self.ChartDatas[i].method_result.data[j].mxci_threshold, type: 'line', symbol: 'none', smooth: true, itemStyle: { color: '#FF9326' } });
                        _NGData = [];
                        for (var k = 0; k < self.ChartDatas[i].method_result.data[j].mxci_outlier.length; k++) {
                            if (self.ChartDatas[i].method_result.data[j].mxci_outlier[k] == true) {
                                _NGData.push(self.ChartDatas[i].method_result.data[j].mxci_score[k]);
                            } else {
                                _NGData.push(null);
                            }
                        }

                        _MXCI.push({ name: 'NG', data: _NGData, type: 'scatter', itemStyle: { color: '#F85256' } });

                        //2020-04-15 Add by Jane : 新增計算LOF的Mean
                        self.scoreLevel = self.ChartDatas[i].method_result.data[j].scoreLevel

                        //self.judg_Score(self.ChartDatas[i].method_result.data[j].anomaly_score_list);


                    }//if (self.ToolID == self.ChartDatas[i].method_result.data[j].tool && self.Chamber == self.ChartDatas[i].method_result.data[j].chamber) {
                }//for (var j = 0; j < self.ChartDatas[i].method_result.data.length) {
            }//for (var i = 0; i < self.ChartDatas.length; i++) {

            if (_series.length > 0 || _MXCI.length > 0) {
                self.DrawECharts("EChart1", "", _series, _legend, _xAxis, "", "");

                _legend = [];
                _legend.push("MXCI");
                _legend.push("MXCI_Threshold");
                _legend.push("NG");
                self.DrawECharts("EChart2", "", _MXCI, _legend, _xAxis, "", "")
            } else {
                alertify.success("Not Data Found !!");
            }
        },
        getHAChartDatas: function () {
            var self = this;


            var apiUrl = "/modeling";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "code": 200,
                "data": [
                    {
                        "method": "LogisticRegression",
                        "method_result": {
                            "confusion_label": [
                                "NG",
                                "OK"
                            ],
                            "confusion_matrix": [
                                [
                                    0,
                                    8
                                ],
                                [
                                    6,
                                    2
                                ]
                            ],
                            "data": [
                                {
                                    "chamber": "IEX300_VCD2_\u4e0b\u6e38\u5074_\u87ba\u687f\u5206\u7fa4TEST",
                                    "health_score_list": [
                                        51.294324,
                                        49.370215,
                                        55.109773,
                                        50.223933,
                                        51.392087,
                                        46.532714,
                                        76.729579,
                                        55.130884,
                                        44.421943,
                                        51.713525,
                                        54.07184,
                                        60.559052,
                                        45.832635,
                                        95.032455,
                                        44.592626,
                                        51.039484,
                                        48.602055,
                                        41.505774,
                                        43.944849,
                                        47.432603,
                                        55.448797,
                                        45.645707,
                                        40.470805,
                                        55.870094,
                                        44.355782,
                                        59.073342,
                                        51.201531,
                                        42.849785,
                                        50.376558,
                                        50.873606,
                                        54.208911,
                                        56.869881,
                                        58.562586,
                                        46.184564,
                                        55.728111,
                                        44.403237,
                                        53.341662,
                                        45.675797,
                                        57.682028,
                                        45.082645,
                                        58.178602,
                                        44.493144,
                                        59.112661,
                                        41.691296,
                                        51.144893,
                                        62.962104,
                                        41.772549,
                                        48.755077,
                                        45.793601,
                                        50.073779,
                                        56.033566,
                                        56.748968,
                                        56.864624,
                                        50.37036,
                                        48.73554,
                                        40.837873,
                                        48.786257,
                                        55.907145,
                                        42.039734,
                                        52.505537,
                                        48.745759,
                                        46.815735,
                                        43.764719,
                                        54.950026,
                                        76.378836,
                                        44.267364,
                                        43.907064,
                                        46.681195,
                                        54.467023,
                                        58.825957,
                                        54.364164,
                                        52.336948,
                                        47.67907,
                                        57.067176,
                                        44.857042,
                                        51.048245,
                                        52.094033,
                                        52.866734,
                                        50.594104,
                                        51.547253,
                                        43.285241,
                                        50.261095,
                                        45.692567,
                                        44.496771
                                    ],
                                    "label_list": [
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0
                                    ],
                                    "label_list_value": [
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG"
                                    ],
                                    "mxci_outlier": [
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false
                                    ],
                                    "mxci_score": [
                                        -0.995759,
                                        -0.994086,
                                        -1.170483,
                                        -1.000157,
                                        -1.114642,
                                        -0.960577,
                                        -3.615435,
                                        -1.329766,
                                        -1.025345,
                                        -1.18989,
                                        -0.982927,
                                        -1.948876,
                                        -0.95381,
                                        -6.398448,
                                        -0.987711,
                                        -0.985923,
                                        -1.036056,
                                        -0.980723,
                                        -0.974206,
                                        -0.970379,
                                        -0.998832,
                                        -0.98743,
                                        -1.010239,
                                        -1.002648,
                                        -1.110276,
                                        -1.008332,
                                        -1.068823,
                                        -0.989765,
                                        -0.986588,
                                        -0.994647,
                                        -1.150514,
                                        -1.007025,
                                        -1.008833,
                                        -0.950674,
                                        -1.00273,
                                        -0.987222,
                                        -1.03911,
                                        -0.998396,
                                        -1.862227,
                                        -1.002559,
                                        -1.835598,
                                        -1.049184,
                                        -1.337156,
                                        -0.991126,
                                        -0.985923,
                                        -1.142857,
                                        -0.996229,
                                        -0.985717,
                                        -0.995952,
                                        -0.994782,
                                        -0.997408,
                                        -0.985278,
                                        -1.002635,
                                        -1.002498,
                                        -0.973089,
                                        -1.044969,
                                        -1.000759,
                                        -0.999514,
                                        -0.999155,
                                        -1.101485,
                                        -1.086582,
                                        -0.985687,
                                        -0.9991,
                                        -1.143425,
                                        -2.585144,
                                        -0.994013,
                                        -1.100695,
                                        -1.107989,
                                        -0.989381,
                                        -1.004488,
                                        -0.981001,
                                        -1.08187,
                                        -0.98545,
                                        -1.310429,
                                        -1.028159,
                                        -0.988203,
                                        -0.992349,
                                        -0.982674,
                                        -1.062965,
                                        -0.986996,
                                        -0.971096,
                                        -1.056908,
                                        -0.993594,
                                        -0.984632
                                    ],
                                    "mxci_threshold": [
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448
                                    ],
                                    "prediction_list": [
                                        1,
                                        0,
                                        1,
                                        1,
                                        1,
                                        0,
                                        1,
                                        1,
                                        0,
                                        1,
                                        1,
                                        1,
                                        0,
                                        1,
                                        0,
                                        1,
                                        0,
                                        0,
                                        0,
                                        0,
                                        1,
                                        0,
                                        0,
                                        1,
                                        0,
                                        1,
                                        1,
                                        0,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        0,
                                        1,
                                        0,
                                        1,
                                        0,
                                        1,
                                        0,
                                        1,
                                        0,
                                        1,
                                        0,
                                        1,
                                        1,
                                        0,
                                        0,
                                        0,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        0,
                                        0,
                                        0,
                                        1,
                                        0,
                                        1,
                                        0,
                                        0,
                                        0,
                                        1,
                                        1,
                                        0,
                                        0,
                                        0,
                                        1,
                                        1,
                                        1,
                                        1,
                                        0,
                                        1,
                                        0,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        0,
                                        1,
                                        0,
                                        0
                                    ],
                                    "prediction_list_value": [
                                        "OK",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "NG"
                                    ],
                                    "start_time_list": [
                                        "2021-04-15 03:14:49",
                                        "2021-04-15 05:08:43",
                                        "2021-04-15 06:04:43",
                                        "2021-04-15 06:18:43",
                                        "2021-04-15 06:46:43",
                                        "2021-04-15 07:00:44",
                                        "2021-04-15 07:28:44",
                                        "2021-04-15 19:04:41",
                                        "2021-04-15 19:46:40",
                                        "2021-04-15 21:38:38",
                                        "2021-04-16 00:12:38",
                                        "2021-04-16 00:26:38",
                                        "2021-04-16 03:42:35",
                                        "2021-04-16 05:08:41",
                                        "2021-04-16 05:36:40",
                                        "2021-04-16 06:04:39",
                                        "2021-04-16 06:46:38",
                                        "2021-04-16 07:42:36",
                                        "2021-04-16 10:02:34",
                                        "2021-04-16 12:50:32",
                                        "2021-04-16 13:04:32",
                                        "2021-04-16 15:24:33",
                                        "2021-04-16 16:34:32",
                                        "2021-04-16 18:08:43",
                                        "2021-04-16 20:28:42",
                                        "2021-04-16 21:24:40",
                                        "2021-04-16 23:30:41",
                                        "2021-04-17 03:00:38",
                                        "2021-04-17 04:10:36",
                                        "2021-04-17 06:04:41",
                                        "2021-04-17 07:28:38",
                                        "2021-04-17 07:42:37",
                                        "2021-04-17 07:56:37",
                                        "2021-04-17 08:24:36",
                                        "2021-04-17 08:38:36",
                                        "2021-04-17 08:52:36",
                                        "2021-04-17 17:54:42",
                                        "2021-04-17 18:50:41",
                                        "2021-04-17 19:04:40",
                                        "2021-04-17 19:46:38",
                                        "2021-04-17 20:42:36",
                                        "2021-04-17 22:48:38",
                                        "2021-04-17 23:30:37",
                                        "2021-04-18 00:54:36",
                                        "2021-04-18 01:36:36",
                                        "2021-04-18 02:04:36",
                                        "2021-04-18 03:56:38",
                                        "2021-04-18 04:40:44",
                                        "2021-04-18 05:22:43",
                                        "2021-04-18 05:50:42",
                                        "2021-04-18 07:00:40",
                                        "2021-04-18 07:42:39",
                                        "2021-04-18 08:38:37",
                                        "2021-04-18 09:20:37",
                                        "2021-04-18 10:30:35",
                                        "2021-04-18 12:22:35",
                                        "2021-04-18 14:14:33",
                                        "2021-04-18 14:28:32",
                                        "2021-04-18 15:24:32",
                                        "2021-04-18 17:26:42",
                                        "2021-04-18 21:38:40",
                                        "2021-04-19 00:54:39",
                                        "2021-04-19 01:50:53",
                                        "2021-04-19 02:04:53",
                                        "2021-04-19 03:14:51",
                                        "2021-04-19 06:32:43",
                                        "2021-04-19 07:56:43",
                                        "2021-04-19 10:02:41",
                                        "2021-04-19 20:42:41",
                                        "2021-04-19 23:16:41",
                                        "2021-04-20 00:12:42",
                                        "2021-04-20 03:56:41",
                                        "2021-04-20 09:20:46",
                                        "2021-04-20 09:34:46",
                                        "2021-04-20 10:02:46",
                                        "2021-04-20 10:16:45",
                                        "2021-04-20 12:36:43",
                                        "2021-04-20 13:32:43",
                                        "2021-04-20 14:56:42",
                                        "2021-04-20 15:10:42",
                                        "2021-04-20 17:12:43",
                                        "2021-04-20 19:32:42",
                                        "2021-04-20 20:56:42",
                                        "2021-04-21 02:04:41"
                                    ],
                                    "test_use_list": [
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        true,
                                        true,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        true,
                                        true,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        true,
                                        false,
                                        true,
                                        false,
                                        false
                                    ],
                                    "tool": "AFIEX300DPR"
                                }
                            ],
                            "f1_score": 0.59375
                        }
                    },
                    {
                        "method": "LOF",
                        "method_result": {
                            "confusion_label": [
                                "NG",
                                "OK"
                            ],
                            "confusion_matrix": [
                                [
                                    3,
                                    5
                                ],
                                [
                                    5,
                                    3
                                ]
                            ],
                            "data": [
                                {
                                    "chamber": "IEX300_VCD2_\u4e0b\u6e38\u5074_\u87ba\u687f\u5206\u7fa4TEST",
                                    "health_score_list": [
                                        100.0,
                                        99.124837,
                                        99.464175,
                                        98.924306,
                                        98.980423,
                                        96.004185,
                                        63.5689,
                                        91.694523,
                                        99.55963,
                                        86.663785,
                                        86.101078,
                                        99.533518,
                                        98.980423,
                                        90.691096,
                                        99.114296,
                                        100.0,
                                        89.258459,
                                        90.884931,
                                        98.60982,
                                        95.131239,
                                        99.551858,
                                        98.980423,
                                        90.157681,
                                        99.551858,
                                        91.546983,
                                        98.89774,
                                        98.980423,
                                        99.114296,
                                        100.0,
                                        99.124837,
                                        99.464175,
                                        95.203942,
                                        97.284765,
                                        98.980423,
                                        99.551858,
                                        99.114296,
                                        99.464175,
                                        99.55963,
                                        99.533518,
                                        97.825885,
                                        99.533518,
                                        99.55963,
                                        95.492893,
                                        95.353194,
                                        100.0,
                                        81.973778,
                                        96.255527,
                                        97.085015,
                                        98.355099,
                                        99.124837,
                                        86.268325,
                                        88.508003,
                                        92.940993,
                                        91.7965,
                                        97.996854,
                                        90.629294,
                                        86.405746,
                                        76.752073,
                                        97.08044,
                                        96.340763,
                                        97.029558,
                                        98.980423,
                                        97.133912,
                                        99.464175,
                                        0.0,
                                        98.879838,
                                        96.758282,
                                        93.154712,
                                        89.870361,
                                        73.538085,
                                        89.291974,
                                        97.488158,
                                        94.446793,
                                        97.003967,
                                        99.55963,
                                        96.544113,
                                        93.978519,
                                        96.528569,
                                        98.980423,
                                        100.0,
                                        93.72058,
                                        98.277972,
                                        98.257681,
                                        99.114296
                                    ],
                                    "label_list": [
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0
                                    ],
                                    "label_list_value": [
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG"
                                    ],
                                    "mxci_outlier": [
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false
                                    ],
                                    "mxci_score": [
                                        -0.995759,
                                        -0.994086,
                                        -1.170483,
                                        -1.000157,
                                        -1.114642,
                                        -0.960577,
                                        -3.615435,
                                        -1.329766,
                                        -1.025345,
                                        -1.18989,
                                        -0.982927,
                                        -1.948876,
                                        -0.95381,
                                        -6.398448,
                                        -0.987711,
                                        -0.985923,
                                        -1.036056,
                                        -0.980723,
                                        -0.974206,
                                        -0.970379,
                                        -0.998832,
                                        -0.98743,
                                        -1.010239,
                                        -1.002648,
                                        -1.110276,
                                        -1.008332,
                                        -1.068823,
                                        -0.989765,
                                        -0.986588,
                                        -0.994647,
                                        -1.150514,
                                        -1.007025,
                                        -1.008833,
                                        -0.950674,
                                        -1.00273,
                                        -0.987222,
                                        -1.03911,
                                        -0.998396,
                                        -1.862227,
                                        -1.002559,
                                        -1.835598,
                                        -1.049184,
                                        -1.337156,
                                        -0.991126,
                                        -0.985923,
                                        -1.142857,
                                        -0.996229,
                                        -0.985717,
                                        -0.995952,
                                        -0.994782,
                                        -0.997408,
                                        -0.985278,
                                        -1.002635,
                                        -1.002498,
                                        -0.973089,
                                        -1.044969,
                                        -1.000759,
                                        -0.999514,
                                        -0.999155,
                                        -1.101485,
                                        -1.086582,
                                        -0.985687,
                                        -0.9991,
                                        -1.143425,
                                        -2.585144,
                                        -0.994013,
                                        -1.100695,
                                        -1.107989,
                                        -0.989381,
                                        -1.004488,
                                        -0.981001,
                                        -1.08187,
                                        -0.98545,
                                        -1.310429,
                                        -1.028159,
                                        -0.988203,
                                        -0.992349,
                                        -0.982674,
                                        -1.062965,
                                        -0.986996,
                                        -0.971096,
                                        -1.056908,
                                        -0.993594,
                                        -0.984632
                                    ],
                                    "mxci_threshold": [
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448
                                    ],
                                    "prediction_list": [
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        0,
                                        0,
                                        1,
                                        0,
                                        0,
                                        1,
                                        1,
                                        0,
                                        1,
                                        1,
                                        0,
                                        0,
                                        1,
                                        1,
                                        1,
                                        1,
                                        0,
                                        1,
                                        0,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        0,
                                        1,
                                        1,
                                        1,
                                        1,
                                        0,
                                        0,
                                        0,
                                        0,
                                        1,
                                        0,
                                        0,
                                        0,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        0,
                                        1,
                                        1,
                                        0,
                                        0,
                                        0,
                                        0,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1
                                    ],
                                    "prediction_list_value": [
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK"
                                    ],
                                    "start_time_list": [
                                        "2021-04-15 03:14:49",
                                        "2021-04-15 05:08:43",
                                        "2021-04-15 06:04:43",
                                        "2021-04-15 06:18:43",
                                        "2021-04-15 06:46:43",
                                        "2021-04-15 07:00:44",
                                        "2021-04-15 07:28:44",
                                        "2021-04-15 19:04:41",
                                        "2021-04-15 19:46:40",
                                        "2021-04-15 21:38:38",
                                        "2021-04-16 00:12:38",
                                        "2021-04-16 00:26:38",
                                        "2021-04-16 03:42:35",
                                        "2021-04-16 05:08:41",
                                        "2021-04-16 05:36:40",
                                        "2021-04-16 06:04:39",
                                        "2021-04-16 06:46:38",
                                        "2021-04-16 07:42:36",
                                        "2021-04-16 10:02:34",
                                        "2021-04-16 12:50:32",
                                        "2021-04-16 13:04:32",
                                        "2021-04-16 15:24:33",
                                        "2021-04-16 16:34:32",
                                        "2021-04-16 18:08:43",
                                        "2021-04-16 20:28:42",
                                        "2021-04-16 21:24:40",
                                        "2021-04-16 23:30:41",
                                        "2021-04-17 03:00:38",
                                        "2021-04-17 04:10:36",
                                        "2021-04-17 06:04:41",
                                        "2021-04-17 07:28:38",
                                        "2021-04-17 07:42:37",
                                        "2021-04-17 07:56:37",
                                        "2021-04-17 08:24:36",
                                        "2021-04-17 08:38:36",
                                        "2021-04-17 08:52:36",
                                        "2021-04-17 17:54:42",
                                        "2021-04-17 18:50:41",
                                        "2021-04-17 19:04:40",
                                        "2021-04-17 19:46:38",
                                        "2021-04-17 20:42:36",
                                        "2021-04-17 22:48:38",
                                        "2021-04-17 23:30:37",
                                        "2021-04-18 00:54:36",
                                        "2021-04-18 01:36:36",
                                        "2021-04-18 02:04:36",
                                        "2021-04-18 03:56:38",
                                        "2021-04-18 04:40:44",
                                        "2021-04-18 05:22:43",
                                        "2021-04-18 05:50:42",
                                        "2021-04-18 07:00:40",
                                        "2021-04-18 07:42:39",
                                        "2021-04-18 08:38:37",
                                        "2021-04-18 09:20:37",
                                        "2021-04-18 10:30:35",
                                        "2021-04-18 12:22:35",
                                        "2021-04-18 14:14:33",
                                        "2021-04-18 14:28:32",
                                        "2021-04-18 15:24:32",
                                        "2021-04-18 17:26:42",
                                        "2021-04-18 21:38:40",
                                        "2021-04-19 00:54:39",
                                        "2021-04-19 01:50:53",
                                        "2021-04-19 02:04:53",
                                        "2021-04-19 03:14:51",
                                        "2021-04-19 06:32:43",
                                        "2021-04-19 07:56:43",
                                        "2021-04-19 10:02:41",
                                        "2021-04-19 20:42:41",
                                        "2021-04-19 23:16:41",
                                        "2021-04-20 00:12:42",
                                        "2021-04-20 03:56:41",
                                        "2021-04-20 09:20:46",
                                        "2021-04-20 09:34:46",
                                        "2021-04-20 10:02:46",
                                        "2021-04-20 10:16:45",
                                        "2021-04-20 12:36:43",
                                        "2021-04-20 13:32:43",
                                        "2021-04-20 14:56:42",
                                        "2021-04-20 15:10:42",
                                        "2021-04-20 17:12:43",
                                        "2021-04-20 19:32:42",
                                        "2021-04-20 20:56:42",
                                        "2021-04-21 02:04:41"
                                    ],
                                    "test_use_list": [
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        true,
                                        true,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        true,
                                        true,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        true,
                                        false,
                                        true,
                                        false,
                                        false
                                    ],
                                    "tool": "AFIEX300DPR"
                                }
                            ],
                            "f1_score": 0.425532
                        }
                    },
                    {
                        "method": "GNB",
                        "method_result": {
                            "confusion_label": [
                                "NG",
                                "OK"
                            ],
                            "confusion_matrix": [
                                [
                                    8,
                                    0
                                ],
                                [
                                    8,
                                    0
                                ]
                            ],
                            "data": [
                                {
                                    "chamber": "IEX300_VCD2_\u4e0b\u6e38\u5074_\u87ba\u687f\u5206\u7fa4TEST",
                                    "health_score_list": [
                                        38.247403,
                                        36.163669,
                                        35.661015,
                                        30.721236,
                                        29.082335,
                                        26.609853,
                                        99.999997,
                                        51.866673,
                                        30.486499,
                                        37.693286,
                                        33.026781,
                                        92.267307,
                                        25.923462,
                                        100.0,
                                        24.967937,
                                        37.337472,
                                        27.069082,
                                        32.534426,
                                        29.983626,
                                        26.523606,
                                        32.644802,
                                        25.623996,
                                        37.021114,
                                        32.734865,
                                        33.913307,
                                        38.869508,
                                        29.475291,
                                        26.494926,
                                        38.295755,
                                        32.75281,
                                        33.080468,
                                        33.714908,
                                        36.503452,
                                        26.230484,
                                        32.619619,
                                        24.941333,
                                        30.577888,
                                        28.224186,
                                        82.117436,
                                        24.470976,
                                        83.981532,
                                        31.071026,
                                        59.078521,
                                        28.527491,
                                        37.195124,
                                        59.916144,
                                        27.620125,
                                        26.883124,
                                        24.828754,
                                        34.318814,
                                        33.092213,
                                        35.736493,
                                        33.575965,
                                        30.107064,
                                        27.129354,
                                        28.372373,
                                        28.008393,
                                        32.807648,
                                        26.762961,
                                        37.530444,
                                        28.847747,
                                        25.642524,
                                        26.824443,
                                        34.662502,
                                        99.965413,
                                        24.512572,
                                        33.939896,
                                        33.189518,
                                        32.120773,
                                        41.930368,
                                        32.908434,
                                        34.941002,
                                        26.154609,
                                        52.32115,
                                        29.872073,
                                        34.787799,
                                        33.239591,
                                        33.67338,
                                        28.572251,
                                        35.564617,
                                        28.999353,
                                        28.775027,
                                        25.240486,
                                        24.656846
                                    ],
                                    "label_list": [
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        1,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0
                                    ],
                                    "label_list_value": [
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG"
                                    ],
                                    "mxci_outlier": [
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false
                                    ],
                                    "mxci_score": [
                                        -0.995759,
                                        -0.994086,
                                        -1.170483,
                                        -1.000157,
                                        -1.114642,
                                        -0.960577,
                                        -3.615435,
                                        -1.329766,
                                        -1.025345,
                                        -1.18989,
                                        -0.982927,
                                        -1.948876,
                                        -0.95381,
                                        -6.398448,
                                        -0.987711,
                                        -0.985923,
                                        -1.036056,
                                        -0.980723,
                                        -0.974206,
                                        -0.970379,
                                        -0.998832,
                                        -0.98743,
                                        -1.010239,
                                        -1.002648,
                                        -1.110276,
                                        -1.008332,
                                        -1.068823,
                                        -0.989765,
                                        -0.986588,
                                        -0.994647,
                                        -1.150514,
                                        -1.007025,
                                        -1.008833,
                                        -0.950674,
                                        -1.00273,
                                        -0.987222,
                                        -1.03911,
                                        -0.998396,
                                        -1.862227,
                                        -1.002559,
                                        -1.835598,
                                        -1.049184,
                                        -1.337156,
                                        -0.991126,
                                        -0.985923,
                                        -1.142857,
                                        -0.996229,
                                        -0.985717,
                                        -0.995952,
                                        -0.994782,
                                        -0.997408,
                                        -0.985278,
                                        -1.002635,
                                        -1.002498,
                                        -0.973089,
                                        -1.044969,
                                        -1.000759,
                                        -0.999514,
                                        -0.999155,
                                        -1.101485,
                                        -1.086582,
                                        -0.985687,
                                        -0.9991,
                                        -1.143425,
                                        -2.585144,
                                        -0.994013,
                                        -1.100695,
                                        -1.107989,
                                        -0.989381,
                                        -1.004488,
                                        -0.981001,
                                        -1.08187,
                                        -0.98545,
                                        -1.310429,
                                        -1.028159,
                                        -0.988203,
                                        -0.992349,
                                        -0.982674,
                                        -1.062965,
                                        -0.986996,
                                        -0.971096,
                                        -1.056908,
                                        -0.993594,
                                        -0.984632
                                    ],
                                    "mxci_threshold": [
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448,
                                        -6.398448
                                    ],
                                    "prediction_list": [
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        1,
                                        1,
                                        0,
                                        0,
                                        0,
                                        1,
                                        0,
                                        1,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        1,
                                        0,
                                        1,
                                        0,
                                        1,
                                        0,
                                        0,
                                        1,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        1,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        1,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0,
                                        0
                                    ],
                                    "prediction_list_value": [
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "OK",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG",
                                        "NG"
                                    ],
                                    "start_time_list": [
                                        "2021-04-15 03:14:49",
                                        "2021-04-15 05:08:43",
                                        "2021-04-15 06:04:43",
                                        "2021-04-15 06:18:43",
                                        "2021-04-15 06:46:43",
                                        "2021-04-15 07:00:44",
                                        "2021-04-15 07:28:44",
                                        "2021-04-15 19:04:41",
                                        "2021-04-15 19:46:40",
                                        "2021-04-15 21:38:38",
                                        "2021-04-16 00:12:38",
                                        "2021-04-16 00:26:38",
                                        "2021-04-16 03:42:35",
                                        "2021-04-16 05:08:41",
                                        "2021-04-16 05:36:40",
                                        "2021-04-16 06:04:39",
                                        "2021-04-16 06:46:38",
                                        "2021-04-16 07:42:36",
                                        "2021-04-16 10:02:34",
                                        "2021-04-16 12:50:32",
                                        "2021-04-16 13:04:32",
                                        "2021-04-16 15:24:33",
                                        "2021-04-16 16:34:32",
                                        "2021-04-16 18:08:43",
                                        "2021-04-16 20:28:42",
                                        "2021-04-16 21:24:40",
                                        "2021-04-16 23:30:41",
                                        "2021-04-17 03:00:38",
                                        "2021-04-17 04:10:36",
                                        "2021-04-17 06:04:41",
                                        "2021-04-17 07:28:38",
                                        "2021-04-17 07:42:37",
                                        "2021-04-17 07:56:37",
                                        "2021-04-17 08:24:36",
                                        "2021-04-17 08:38:36",
                                        "2021-04-17 08:52:36",
                                        "2021-04-17 17:54:42",
                                        "2021-04-17 18:50:41",
                                        "2021-04-17 19:04:40",
                                        "2021-04-17 19:46:38",
                                        "2021-04-17 20:42:36",
                                        "2021-04-17 22:48:38",
                                        "2021-04-17 23:30:37",
                                        "2021-04-18 00:54:36",
                                        "2021-04-18 01:36:36",
                                        "2021-04-18 02:04:36",
                                        "2021-04-18 03:56:38",
                                        "2021-04-18 04:40:44",
                                        "2021-04-18 05:22:43",
                                        "2021-04-18 05:50:42",
                                        "2021-04-18 07:00:40",
                                        "2021-04-18 07:42:39",
                                        "2021-04-18 08:38:37",
                                        "2021-04-18 09:20:37",
                                        "2021-04-18 10:30:35",
                                        "2021-04-18 12:22:35",
                                        "2021-04-18 14:14:33",
                                        "2021-04-18 14:28:32",
                                        "2021-04-18 15:24:32",
                                        "2021-04-18 17:26:42",
                                        "2021-04-18 21:38:40",
                                        "2021-04-19 00:54:39",
                                        "2021-04-19 01:50:53",
                                        "2021-04-19 02:04:53",
                                        "2021-04-19 03:14:51",
                                        "2021-04-19 06:32:43",
                                        "2021-04-19 07:56:43",
                                        "2021-04-19 10:02:41",
                                        "2021-04-19 20:42:41",
                                        "2021-04-19 23:16:41",
                                        "2021-04-20 00:12:42",
                                        "2021-04-20 03:56:41",
                                        "2021-04-20 09:20:46",
                                        "2021-04-20 09:34:46",
                                        "2021-04-20 10:02:46",
                                        "2021-04-20 10:16:45",
                                        "2021-04-20 12:36:43",
                                        "2021-04-20 13:32:43",
                                        "2021-04-20 14:56:42",
                                        "2021-04-20 15:10:42",
                                        "2021-04-20 17:12:43",
                                        "2021-04-20 19:32:42",
                                        "2021-04-20 20:56:42",
                                        "2021-04-21 02:04:41"
                                    ],
                                    "test_use_list": [
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        true,
                                        true,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        true,
                                        true,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        false,
                                        true,
                                        false,
                                        true,
                                        false,
                                        true,
                                        false,
                                        false
                                    ],
                                    "tool": "AFIEX300DPR"
                                }
                            ],
                            "f1_score": 0.659341
                        }
                    }
                ],
                "description": "Successful response",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;


            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId
                }

            })
                .then(function (response) {

                    
                    if (response.data.status == "OK") {

                        self.HAChartDatas = response.data.data;

                        if (self.method == "") {
                            if (self.HAChartDatas.length > 0) {
                                self.method = self.HAChartDatas[0].method;

                            }
                        }

                        var arTmp = self.HAChartDatas.filter(function (item, index) {

                            if (item.method == self.method) {
                                self.currentHAChartDatas = item.method_result;

                                self.drawHAhart(self.currentHAChartDatas.confusion_label, self.currentHAChartDatas.confusion_matrix, "HA_HeatmapChart");
                                return item.method_result;
                            }

                        });

                        self.ClearECharts();
                        self.DrawLOFChart2();

                    } else {
                        alertify.success("get data fail. error message = " + response.data.data.message);
                    }
                })  

        },
        getPChartDatas: function () {
            var apiUrl = "/modeling";
            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data:
                    [{
                        method: "XGB",
                        method_result: {
                            weighted_macro_score: 70,
                            confusion_label: ['OK', 'NG', 'test1', 'test2', 'test3'],
                            confusion_matrix: [[0, 1, 5, 2, 3], [0, 0, 1, 4, 0], [1, 3, 0, 0, 5], [0, 0, 0, 0, 3], [5, 2, 1, 10, 1]],
                            //confusion_label: ["NG_motor", "NG_pump", "OK"],
                            //confusion_matrix: [[1, 2, 3], [4, 5, 6], [7, 8, 9]],
                            data: [{
                                tool: "IEX200",
                                chamber: "AXI_Y",
                                start_time_list: ["2020-01-06 16:16:36", "2020-01-06 16:26:36", "2020-01-06 16:36:36", "2020-01-06 16:46:36", "2020-01-06 16:56:36"],
                                test_use_list: [true, false, true, false, true],
                                label_list: [1, 2, 3, 4, 5],
                                prediction_list: [2, 1, 3, 3, 5],
                                mxci_score: [-0.95, -0.9, -1.20, -1.01, -1.62],
                                mxci_threshold: [-0.98, -0.97, -1.00, -1.02, -1.12],
                                mxci_outlier: [false, false, true, false, true]
                            },
                            {
                                tool: "IEX200R",
                                chamber: "AXI_Z2",
                                start_time_list: ["2020-01-07 16:16:36", "2020-01-07 16:26:36", "2020-01-07 16:36:36", "2020-01-07 16:46:36", "2020-01-07 16:56:36"],
                                test_use_list: [true, false, true, false, true],
                                label_list: [5, 4, 3, 2, 1],
                                prediction_list: [2, 4, 3, 2, 1],
                                mxci_score: [-3.95, -3.9, -4.20, -4.01, -4.62],
                                mxci_threshold: [-3.98, -3.97, -4.00, -4.02, -4.12],
                                mxci_outlier: [false, false, true, false, true]
                            }]
                        }
                    },
                        {

                            method: "RF",
                            method_result: {
                                weighted_macro_score: 80,
                                confusion_label: ["NG_motor", "NG_pump", "OK"],
                                confusion_matrix: [[7, 8, 9], [1, 2, 3], [4, 5, 6]],
                                data: [
                                    {
                                        tool: "IEX100R",
                                        chamber: "AXI_Z",
                                        start_time_list: ["2020-01-0816:16:36", "2020-01-08 16:26:36", "2020-01-08 16:36:36", "2020-01-08 16:46:36", "2020-01-08 16:56:36"],
                                        test_use_list: [true, false, true, false, true],
                                        label_list: [1, 2, 3, 4, 5],
                                        prediction_list: [1, 2, 3, 3, 5],
                                        mxci_score: [-0.95, -0.9, -1.20, -1.01, -1.62],
                                        mxci_threshold: [-0.98, -0.97, -1.00, -1.02, -1.12],
                                        mxci_outlier: [false, false, true, false, true]
                                    },
                                    {
                                        tool: "IEX200R",
                                        chamber: "AXI_Z2",
                                        start_time_list: ["2020-01-07 16:16:36", "2020-01-07 16:26:36", "2020-01-07 16:36:36", "2020-01-07 16:46:36", "2020-01-07 16:56:36"],
                                        test_use_list: [true, false, true, false, true],
                                        label_list: [5, 4, 3, 2, 1],
                                        prediction_list: [2, 4, 3, 2, 1],
                                        mxci_score: [-2.95, -2.9, -2.20, -2.01, -2.62],
                                        mxci_threshold: [-2.98, -2.97, -2.00, -2.02, -2.12],
                                        mxci_outlier: [false, false, true, false, true]
                                    }
                                ]
                            }
                        },
                        {
                            method: "SVM",
                            method_result: {
                                weighted_macro_score: 70,
                                confusion_label: ["NG_motor", "NG_pump", "OK"],
                                confusion_matrix: [[7, 8, 9], [4, 5, 6], [1, 2, 3]],
                                data: [
                                    {
                                        tool: "IEX100R",
                                        chamber: "AXI_Z",
                                        start_time_list: ["2020-01-0816:16:36", "2020-01-08 16:26:36", "2020-01-08 16:36:36", "2020-01-08 16:46:36", "2020-01-08 16:56:36"],
                                        test_use_list: [true, false, true, false, true],
                                        label_list: [1, 2, 3, 4, 5],
                                        prediction_list: [2, 4, 3, 4, 5],
                                        mxci_score: [-0.95, -0.9, -1.20, -1.01, -1.62],
                                        mxci_threshold: [-0.98, -0.97, -1.00, -1.02, -1.12],
                                        mxci_outlier: [false, false, true, false, true]
                                    },
                                    {
                                        tool: "IEX200R",
                                        chamber: "AXI_Z2",
                                        start_time_list: ["2020-01-07 16:16:36", "2020-01-07 16:26:36", "2020-01-07 16:36:36", "2020-01-07 16:46:36", "2020-01-07 16:56:36"],
                                        test_use_list: [true, false, true, false, true],
                                        label_list: [5, 4, 3, 2, 1],
                                        prediction_list: [2, 4, 3, 2, 1],
                                        mxci_score: [-2.95, -2.9, -2.20, -2.01, -2.62],
                                        mxci_threshold: [-2.98, -2.97, -2.00, -2.02, -2.12],
                                        mxci_outlier: [false, false, true, false, true]
                                    }
                                ]
                            }
                        }]
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;


            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId
                }

            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.PModelDatas = response.data.data;
                        //self.drawHAChart();//畫熱力圖
   
                        //get F1Score
                        var MaxF1Score = Math.max.apply(null, self.PModelDatas.map(function (o) {
                            return o.method_result.weighted_macro_score;
                        })) //4


                        var arTmp = self.PModelDatas.filter(function (item, index) {
                            if (item.method_result.weighted_macro_score == MaxF1Score) 
                                self.method = item.method;
                            if (item.method == self.method) {
                                self.currentPData = item;

                                //self.drawHAhart(self.currentPData.confusion_label, self.currentPData.confusion_matrix, "HA_HeatmapChart");
                                return item.method_result;
                            }

                        })

                        self.selectPMethod(self.currentPData);
                        
                    }
                })
        },
        DrawChart: function () {
            var self = this;
            if (self.modeltype == "anomaly_detection") {
                self.getADChartDatas();
            } else if (self.modeltype == "health_assessment") {

                
                //if (self.method == "" || self.method == null)
                //    self.method = self.getRatioItem();
                //if (self.method == "") {
                //    alertify.error("Please Select Modeling Algorithm !!");
                //    return;
                //}

                
                self.ClearECharts();                
                self.DrawLOFChart2();
            }
            else if (self.modeltype == "prognostic") {
                
                //if (self.method == "" || self.method == null)
                //    self.method = self.getRatioItem();
                //if (self.method == "") {
                //    alertify.error("Please Select Modeling Algorithm !!");
                //    return;
                //}
                self.ClearECharts();
                self.DrawLOFChart3();
            }
        },
        getRatioItem: function () {
            var self = this;
            var _name = "";
            if (self.modeltype == "prognostic") {
                _name = "PMethod";
            } else if (self.modeltype == "health_assessment") {
                _name = "gender";
            }
           
            var obj = document.getElementsByName(_name);
            
            var selected = [];
            for (var i = 0; i < obj.length; i++) {
               
                if (obj[i].checked) {
                    selected.push(obj[i].value);
                }
            }
            


           

            return selected.join();
        },
        ClearECharts: function () {
            //alert(modeltype)
            if (document.getElementById("EChart1") != null) {
                var myChart1 = echarts.init(document.getElementById("EChart1"), 'default');
                myChart1.clear();
            }
            if (document.getElementById("EChart2") != null) {
                var myChart2 = echarts.init(document.getElementById("EChart2"), 'default');
                myChart2.clear();
            }
            if (document.getElementById("EChart3") != null) {
                var myChart3 = echarts.init(document.getElementById("EChart3"), 'default');
                myChart3.clear();
            }
            if (document.getElementById("EChart4") != null) {
                var myChart4 = echarts.init(document.getElementById("EChart4"), 'default');
                myChart4.clear();
            }
            if (document.getElementById("EChart5") != null) {
                var myChart5 = echarts.init(document.getElementById("EChart5"), 'default');
                myChart5.clear();
            }
            if (document.getElementById("EChart6") != null) {
                var myChart6 = echarts.init(document.getElementById("EChart6"), 'default');
                myChart6.clear();
            }
            if (document.getElementById("EChart7") != null) {
                var myChart7 = echarts.init(document.getElementById("EChart7"), 'default');
                myChart7.clear();
            }
        },
        RadioClick: function () {
            var self = this;
            self.isFromRadio = true;
            self.ToolID = "";
            self.Chamber = "";
            self.Chamber = [];
            self.ClearECharts();
            
            
            if (self.modeltype == "health_assessment") {
                self.method = self.getRatioItem();
                var arTmp = self.HAChartDatas.filter(function (item) {

                    if (item.method == self.method) {
                        self.currentHAChartDatas = item.method_result;


                        self.drawHAhart(self.currentHAChartDatas.confusion_label, self.currentHAChartDatas.confusion_matrix, "HA_HeatmapChart");   
                        return item.method_result;
                    }

                });  
                
            } else if (self.modeltype == "prognostic") {
                self.method = self.getRatioItem();
                var arTmp = self.currentPData.filter(function (item) {

                    if (item.method == self.method) {
                        self.currentPData = item.method_result;


                        self.drawHAhart(self.currentPData.confusion_label, self.currentHAChartDatas.confusion_matrix, "HA_HeatmapChart");
                        return item.method_result;
                    }

                });
                            
            }
            self.getTools();   

           
            
        },
        DrawLOFChart2: function () {

            //var arColor = ['#00B0F0', '#00EACD', '#43A047', '#92D050', '#D05052', '#FF7800', '#FFFF00', '#A349A4', '#F06292', '#7E57C2', '#02B9C4', '#5292B3', '#DAF7A6', '#49ff33', '#b9e7ff', '#83B9C7', '#2ACDC9', '#FFD000', '#7CFEF0', '#d7f96e'];
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            var self = this;

            var _series = [], _legend = [], _xAxis = [], _upper = [], _lower = [];
            var _NGData = [], _MXCI = [];
            var _Testing = [];
            var _series2 = [];
            _legend.push("Prediction Value");
            _legend.push("Real Value");
            _legend.push("Testing");
           

            for (var i = 0; i < self.HAChartDatas.length; i++) {
                if (self.method == self.HAChartDatas[i].method) {
                    for (var j = 0; j < self.HAChartDatas[i].method_result.data.length; j++) {
                        if (self.ToolID == self.HAChartDatas[i].method_result.data[j].tool && self.Chamber == self.HAChartDatas[i].method_result.data[j].chamber) {
                            self.currentHAData = self.HAChartDatas[i].method_result.data[j];
                            _xAxis = self.HAChartDatas[i].method_result.data[j].start_time_list;
                            _series.push({ name: 'Real Value', data: self.HAChartDatas[i].method_result.data[j].label_list, type: 'line', symbol: 'none', smooth: true, itemStyle: { color: '#99ff99' } });//arColor[_series.length]
                            _series.push({ name: 'Prediction Value', data: self.HAChartDatas[i].method_result.data[j].prediction_list, type: 'line', symbol: 'none', smooth: true, itemStyle: { color: arColor[8] } });
                            _series2.push({ name: 'Health Value', data: self.HAChartDatas[i].method_result.data[j].health_score_list, type: 'line', symbol: 'none', smooth: true, itemStyle: { color: arColor[_series2.length] } });
                            _MXCI.push({ name: 'MXCI', data: self.HAChartDatas[i].method_result.data[j].mxci_score, type: 'scatter', itemStyle: { color: arColor[_MXCI.length] } });
                            _MXCI.push({ name: 'MXCI_Threshold', data: self.HAChartDatas[i].method_result.data[j].mxci_threshold, type: 'line', symbol: 'none', smooth: true, itemStyle: { color: '#FF9326' } });
                            for (var k = 0; k < self.HAChartDatas[i].method_result.data[j].mxci_outlier.length; k++) {
                                if (self.HAChartDatas[i].method_result.data[j].mxci_outlier[k] == true) {
                                    _NGData.push(self.HAChartDatas[i].method_result.data[j].label_list[k]);
                                } else {
                                    _NGData.push(null);
                                }
                                if (self.HAChartDatas[i].method_result.data[j].test_use_list[k] == true) {
                                    _Testing.push(self.HAChartDatas[i].method_result.data[j].label_list[k]);
                                } else {
                                    _Testing.push(null);
                                }

                            }//for (var k = 0; k < self.HAChartDatas[i].method_result.data[j].mxci_outlier.length; k++) {
                            _series.push({
                                name: 'Testing', data: _Testing, type: 'scatter', symbol: 'triangle', smooth: true, 
                                symbolSize: (rawValue, params) => {
                                    if (rawValue == undefined)
                                        return 0
                                    else
                                        return 10
                                },
                                itemStyle: {
                                    color: function (params) {
                                        //if (params.value != undefined)
                                            return '#66ccff'
                                        //else
                                        //    return 'rgba(185, 255, 115,0)';


                                    },
                                     


                                }
                            });
                            _MXCI.push({
                                name: 'NG', data: _NGData, type: 'scatter',  itemStyle: {
                                    color: '#F85256' } });
                        }//if (self.ToolID == self.HAChartDatas[i].method_result.data[j].tool && self.Chamber == self.HAChartDatas[i].method_result.data[j].chamber) {

                    }//for (var j = 0; j < self.HAChartDatas[i].method_result.data.length; j++) {
                }//if (self.method == self.HAChartDatas[i].method) {
            }//for (var i = 0; i < self.HAChartDatas.length; i++) {

            if (_series.length > 0 || _series2.length > 0 || _MXCI.length > 0) {
                self.DrawECharts("EChart3", "", _series, _legend, _xAxis, "", "");

                _legend = [];
                _legend.push("Health Value");
                self.DrawECharts("EChart4", "", _series2, _legend, _xAxis, "", "");

                _legend = [];
                _legend.push("MXCI");
                _legend.push("MXCI_Threshold");
                _legend.push("NG");
                self.DrawECharts("EChart5", "", _MXCI, _legend, _xAxis, "", "");
            } else {
                alertify.success("Not Data Found !!");
            }
        },
        DrawLOFChart3: function () {
            var self = this;
            if (self.PModelDatas == null || self.PModelDatas.length == 0)
                self.getPChartDatas();
            //var arColor = ['#00B0F0', '#00EACD', '#43A047', '#92D050', '#D05052', '#FF7800', '#FFFF00', '#A349A4', '#F06292', '#7E57C2', '#02B9C4', '#5292B3', '#DAF7A6', '#49ff33', '#b9e7ff', '#83B9C7', '#2ACDC9', '#FFD000', '#7CFEF0', '#d7f96e'];
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            var self = this;

            var _series = [], _legend = [], _xAxis = [], _upper = [], _lower = [];
            var _NGData = [], _MXCI = [];
            var _Testing = [];
            var _series2 = [];
            _legend.push("Prediction Value");
            _legend.push("Real Value");
            _legend.push("Testing");
            
            for (var i = 0; i < self.PModelDatas.length; i++) {
                if (self.method == self.PModelDatas[i].method) {
                    for (var j = 0; j < self.PModelDatas[i].method_result.data.length; j++) {
                        if (self.ToolID == self.PModelDatas[i].method_result.data[j].tool && self.Chamber == self.PModelDatas[i].method_result.data[j].chamber) {
                            self.currentPData2 = self.PModelDatas[i].method_result.data[j];
                            _xAxis = self.PModelDatas[i].method_result.data[j].start_time_list;
                            _series.push({ name: 'Prediction Value', data: self.PModelDatas[i].method_result.data[j].prediction_list, type: 'scatter', symbol: 'diamond', smooth: true, itemStyle: { color: arColor[4] } });
                            _series.push({ name: 'Real Value', data: self.PModelDatas[i].method_result.data[j].label_list, type: 'scatter', symbol: 'circle', smooth: true, itemStyle: { color: '#99ff99' } });
                            
                            
                            _MXCI.push({ name: 'MXCI', data: self.PModelDatas[i].method_result.data[j].mxci_score, type: 'scatter', itemStyle: { color: arColor[_MXCI.length] } });
                            _MXCI.push({ name: 'MXCI_Threshold', data: self.PModelDatas[i].method_result.data[j].mxci_threshold, type: 'line', symbol: 'none', smooth: true, itemStyle: { color: '#FF9326' } });
                            for (var k = 0; k < self.PModelDatas[i].method_result.data[j].mxci_outlier.length; k++) {
                                if (self.PModelDatas[i].method_result.data[j].mxci_outlier[k] == true) {
                                    _NGData.push(self.PModelDatas[i].method_result.data[j].mxci_score[k]);
                                } else {
                                    _NGData.push(null);
                                }
                                if (self.PModelDatas[i].method_result.data[j].test_use_list[k] == true) {
                                    _Testing.push(self.PModelDatas[i].method_result.data[j].label_list[k]);
                                } else {
                                    _Testing.push(null);
                                }

                            }//for (var k = 0; k < self.PModelDatas[i].method_result.data[j].mxci_outlier.length; k++) {
                            _series.push({
                                name: 'Testing', data: _Testing, type: 'scatter', symbol: 'triangle', smooth: true,
                                symbolSize: (rawValue, params) => {
                                    if (rawValue == undefined)
                                        return 0
                                    else
                                        return 10
                                },
                                itemStyle: {
                                    color: function (params) {
                                        //if (params.value != undefined)
                                        return '#66ccff'
                                        //else
                                        //    return 'rgba(185, 255, 115,0)';


                                    },



                                }
                            });


                            _MXCI.push({ name: 'NG', data: _NGData, type: 'scatter', itemStyle: { color: '#F85256' } });
                        }//if (self.ToolID == self.PModelDatas[i].method_result.data[j].tool && self.Chamber == self.PModelDatas[i].method_result.data[j].chamber) {

                    }//for (var j = 0; j < self.PModelDatas[i].method_result.data.length; j++) {
                }//if (self.method == self.PModelDatas[i].method) {
            }//for (var i = 0; i < self.PModelDatas.length; i++) {

            if (_series.length > 0 || _MXCI.length > 0) {
                self.DrawECharts("EChart6", "", _series, _legend, _xAxis, "Time", "Label");

                _legend = [];
                _legend.push("MXCI");
                _legend.push("MXCI_Threshold");
                _legend.push("NG");
                self.DrawECharts("EChart7", "", _MXCI, _legend, _xAxis, "DateTime", "");
            //} else {
            //    alertify.success("Not Data Found !!");
            }
        },
        DrawECharts: function (_chartid, _titlename, _series, _legend, _xAxis, _xAxisName, _yAxisName) {
            var myChart = echarts.init(document.getElementById(_chartid), 'default');
            myChart.clear();
            var self = this;
            var _type = 'value';
            var _interval = null;

            if (self.modeltype == "health_assessment" && _chartid != "EChart4") //|| self.modeltype == "anomaly_detection"
                _interval = 1;
            if ((self.modeltype == "prognostic" && _chartid == "EChart6") || (self.modeltype == "health_assessment" && _chartid == "EChart3"))
                _type = 'category';
            /*  去除加载缓冲图 */
            myChart.showLoading({
                text: 'Loading...',
                textStyle: { fontSize: 30, color: '#444' },
                effectOption: { backgroundColor: 'rgba(0, 0, 0, 0)' }
            });

            var option = {
                
                backgroundColor: '#545655',//背景色
                tooltip: {
                    trigger: 'axis',
                    textStyle: {
                        fontSize: 11
                    },
                    formatter: function (params) {
                        
                        var result = params[0].name + '<br>';
                        if (self.modeltype == "health_assessment" || self.modeltype == "prognostic") {
                            var labels, predictions;
                            if (self.modeltype == "health_assessment") {
                                labels = self.currentHAData.label_list_value;
                                predictions = self.currentHAData.prediction_list_value;
                            } else if (self.modeltype == "prognostic") {
                                labels = self.currentPData2.label_list_value;
                                predictions = self.currentPData2.prediction_list_value;
                            }
                            var iRow = params[0].dataIndex;
                            params.forEach(function (item) {

                                if ((item.data != null && item.data != undefined)) {
                                    result += '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + item.color + '"></span>';
                                    if (item.seriesName == "Real Value")
                                        result += item.seriesName + " : " + '<span style="color:#ccffff;font-family: arial;">' + item.data + " (" + labels[iRow] + ")</span><br>";
                                    else if (item.seriesName == "Prediction Value")
                                        result += item.seriesName + " : " + '<span style="color:#ccffff;font-family: arial;">' + item.data + " (" + predictions[iRow] + ")</span><br>";
                                    else {

                                        result += item.seriesName + " : " + '<span style="color:#ccffff;font-family: arial;">' + item.data + "</span><br>"
                                    }
                                }
                                //return result;
                                //if (parseFloat(item.data) >= 0) { result += item.seriesName + " : " + '<span style="color:#e30101">' + item.data + "</span><br>" }
                                //else if (parseFloat(item.data) < 0) { result += item.seriesName + " : " + '<span style="color:#049500">' + item.data + "</span><br>" }
                                //result += "date_time:" + ST + ' ~ ' + ET + '<br>';

                               
                            });
                        } else {
                            params.forEach(function (item) {
                                if ((item.data != null && item.data != undefined)) {
                                    result += '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + item.color + '"></span>';
                                    result += item.seriesName + " : " + '<span style="color:#ccffff;font-family: arial;">' + item.data + "</span><br>";
                                }
                            });
                        }
          
                        
                        return result;
                    }
                    

                },
                legend: {
                    show: true,
                    //type: 'scroll',
                    orient: 'vertical',
                    //x: 'right',
                    //y: 'top',
                    borderWidth: 1,
                    padding: 2,
                    itemGap: 2,
                    right: '1%',
                    top: '10%',

                    
                    data: _legend,
                    selected: {


                    },
                    bottom: '50%',
                    textStyle: {
                        color: '#CDEDED',
                        fontSize: '10'
                    },

                    //selected: 1
                },
                grid: {
                    x: '7%',
                    y: '7%',
                    width: '80%',
                    height: '60%',
                    show: false,
                    borderColor: 'red'
                },
                toolbox: {
                    show: true,
                    feature: {
                        mark: { show: true },
                        dataZoom: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#ec7063'
                                }
                            }
                        },
                        dataView: {
                            show: false, readOnly: false, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#e59866'
                                }
                            }
                        },
                        restore: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#8e44ad'
                                }
                            }
                        },
                        saveAsImage: {
                            show: true, type: 'png', excludeComponents: ['toolbox'], pixelRatio: 2, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#2ecc71',
                                    shadowColor: 'rgba(0, 0, 0, 0.5)',
                                    shadowBlur: 10
                                }
                            }
                        }
                    }
                },
                xAxis: [
                    {
                        name: _xAxisName,
                        nameLocation: 'middle',
                        nameGap: 125,
                        type: 'category',
                        triggerEvent: true,
                        boundaryGap: true,
                        data: _xAxis,



                        axisTick: {
                            show: false,
                            alignWithLabel: true
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变x轴颜色
                        axisLine: {
                            show: true,
                            onZero: false,
                            position: 'end',
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        //  改变x轴字体颜色和大小
                        axisLabel: {
                            show: true,
                            rotate: 90,
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                    }
                ],

                yAxis: [
                    {
                        //  隐藏y轴
                        name: _yAxisName,
                        nameLocation: 'middle',
                        nameGap: 55,
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        onZero: false,
                        onZeroAxisIndex: false,
                        // 去除y轴上的刻度线
                        axisTick: {
                            show: false
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变y轴字体颜色和大小
                        axisLabel: {
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            }, formatter: function (value, index) {
                                if (self.modeltype == "prognostic" && _chartid == "EChart6") {

                                    var labels, predictions;
                                    predictions = self.currentPData2.prediction_list_value;
                                    labels = self.currentPData2.label_list_value;

                                    for (var i = 0; i < self.currentPData2.label_list.length; i++) {

                                        if (parseInt(value) == parseInt(self.currentPData2.label_list[i]))
                                            return labels[i];

                                    }//for (var i = 0; i < self.currentPData2.length; i++) {


                                } else if (self.modeltype == "health_assessment" && _chartid == "EChart3") {
                                    var labels, predictions;
                                    labels = self.currentHAData.label_list_value;
                                    predictions = self.currentHAData.prediction_list_value;


                                    for (var i = 0; i < self.currentHAData.label_list.length; i++) {

                                        if (parseInt(value) == parseInt(self.currentHAData.label_list[i]))
                                            return labels[i];

                                    }//for (var i = 0; i < self.currentHAData.length; i++) {
                                }else
                                    return value;
                            },
                        },
                        type: _type,
                        interval: _interval,
                        triggerEvent: true
                    }
                ],

                dataZoom: [{
                    type: 'inside',
                    start: 0,
                    end: 100
                }, {
                    start: 0,
                    end: 100,
                    handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                    handleSize: '80%',
                    handleStyle: {
                        color: '#fff',
                        shadowBlur: 3,
                        shadowColor: 'rgba(0, 0, 0, 0.6)',
                        shadowOffsetX: 2,
                        shadowOffsetY: 2
                    }
                }],
                series: _series
            };


            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option, true);


        },

        selectPMethod: function (data) {            
            var self = this;
            self.isFromRadio = true;
            self.currentPData = data;
            //self.drawPChart();
            self.drawHAhart(self.currentPData.method_result.confusion_label, self.currentPData.method_result.confusion_matrix,"HeatmapChart");
            self.ToolID = "";
            self.Chamber = "";
            //self.Chamber = [];
            //self.method = self.getRatioItem();
            self.ClearECharts();
            self.getTools();
        },   

        drawHAhart: function (labels,points,id) {
            var self = this;
            var labels = labels;
            var points = points;
            var data = [];

            //準備點位
            for (var i = 0; i < points.length; i++) {
                for (var j = 0; j < points[i].length; j++) {
                    var point = [j, labels.length - 1 - i, points[i][j]];
                    data.push(point);
                }
            }


            //找到陣列的最大值
            var maxRow = points.map(function (row) { return Math.max.apply(Math, row); });
            var max = Math.max.apply(null, maxRow);


            var axis = labels.slice(0);
            var xAxis = labels;
            var yAxis = axis.reverse();

            // 基于准备好的dom，初始化echarts实例           
            var myChart = echarts.init(document.getElementById(id), 'default');
            myChart.clear();

            /*  去除加载缓冲图 */
            myChart.showLoading({
                text: 'Loading...',
                textStyle: { fontSize: 30, color: '#444' },
                effectOption: { backgroundColor: 'rgba(0, 0, 0, 0)' }
            });


            data = data.map(function (item) {
                return [item[0], item[1], item[2] || '-'];
            });

            option = {
                tooltip: {
                    position: 'top'
                },
                animation: false,
                grid: {
                    height: '50%',
                    left: '20%',                   
                    top: '10%'
                },
                xAxis: {
                    type: 'category',
                    data: xAxis,
                    splitArea: {
                        show: true
                    },
                    //  改变x轴字体颜色和大小
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#CDEDED'
                        },
                    }
                },
                yAxis: {
                    type: 'category',
                    data: yAxis,
                    splitArea: {
                        show: true
                    },                 

                    //  改变x轴字体颜色和大小
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#CDEDED'
                        },
                        width: '100%',
                    }
                },
                visualMap: {
                    min: 0,
                    max: max,
                    calculable: true,
                    orient: 'horizontal',
                    left: 'center',
                    bottom: '15%',
                    textStyle: {
                        color: '#CDEDED'
                    }
                },
                series: [{
                    //name: 'Punch Card',
                    type: 'heatmap',
                    data: data,
                    label: {
                        fontSize: 15,
                        color: '#000000',
                        show: true
                    },
                    emphasis: {
                        itemStyle: {

                            shadowBlur: 10,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'

                        }
                    }
                }]
            };

            // 使用刚指定的配置项和数据显示图表。
            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option, true);

        },
        backClick: function () {
            var self = this;
            alertify.confirm("Are you sure want to leave the [Model Result] page and go back to the previous step??",
                function (e) {
                    if (e) {
                        //OK
                        //window.location.href = "/Project/FeatureSelection";
                        CreateProjectLayoutApp.backStatus();
                    } else {
                        //Cancel                      
                    }
                });
        },

        checkToolChamberHasChartData: function () {
            var self = this;
            var tempTools = [];
            var tempChambers = [];

            $.each(self.ChartDatas, function (index, object) {
                $.each(object.method_result.data, function (idx, obj) {                    
                    var toolIdx = self.ToolIDs.findIndex(o => o.Key == obj.tool);

                    if (toolIdx > -1) {
                        tempTools.push(self.ToolIDs[toolIdx]);

                        var chamberIdx = tempChambers.findIndex(o => o == obj.chamber);

                        if (chamberIdx == -1) {
                            tempChambers.push(obj.chamber);
                        }

                      
                    }

                })
            })

            self.ToolIDs = tempTools;
            self.Chambers = tempChambers;
            if (self.ToolID == "") self.ToolIDs[0].Key;
            if (self.Chamber == "") self.Chambers[0];         
           

        },

        //20210331-新增需求:要顯示Method與值       
        get_method: function () {

            //var apiUrl = "/feature_selection/get_method_list";
            var apiUrl = "/feature_selection";
            //用來模擬API的資料，實際上線不會執行這段

            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "code": 200, "data": { "anomaly_detection_method": "LOF", "method": "Variance", "method_list": ["Variance"], "n_neighbors": 10, "percentage": 20 }, "description": "get statistical success", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    model_id: store.getters.getCurrentModelId,
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {                       
                       
                        self.method = response.data.data.method;                       
                        self.method_para = parseInt(response.data.data.percentage).toString();

                        if (store.getters.getCurrentModelType.toLowerCase() == "anomaly_detection") {                            
                            self.showModelingAlgorithm = true;
                            self.modeling_method = response.data.data.anomaly_detection_method;
                            self.n_neighbors = response.data.data.n_neighbors;                                              
                        }
                    }
                })
        },

        //20210420-新增需求:如果ToolChamber有一個分數是B就不能上線
        getAllToolChamberScore: function () {

            var self = this;
            $.each(self.ChartDatas[0].method_result.data, function (index, value) {
                console.log(value);

                var scoreLevel = self.judg_Score(value.anomaly_score_list);

                //用來控制是否要顯示Online切換鈕
                if (scoreLevel == "B") {
                    CreateProjectLayoutApp.isBadScoreLevel = true;
                }

                if (self.ChartDatas[0].method_result.data[index].scoreLevel)
                    self.ChartDatas[0].method_result.data[index].scoreLevel = scoreLevel;
                else 
                    self.ChartDatas[0].method_result.data[index]["scoreLevel"] = scoreLevel;
            });
        },

        //2021-04-15 Add by Jane:新增判斷分數
        judg_Score: function (scores) {

            var scoreLevel = null;

            console.log("***judg_Score***");

            console.log(scores);

            var self = this;

            //計算總值
            var sum = scores.reduce(function (accumulator, currentValue) {
                return accumulator + currentValue;
            }, 0);

            console.log("Sum:" + sum);

            var avg = sum / scores.length;

            console.log("avg:" + avg);

            var badScoreList = scores.filter(function (el) {
                return el < self.badScore;
            });

            console.log("badScoreCount:" + badScoreList.length);

            var badScorePCT = badScoreList.length / scores.length;

            console.log("badScorePCT:" + badScorePCT);

            //判斷分數
            //A + : Anomaly Score平均大於80分, 且無任何一筆資料分數低於50分
            //A  : 不在A+和B的判斷評分範圍內，皆評分為A
            //B   : Anomaly Score低於50分的比率高於5 %           

            if (avg >= self.goodScore && badScoreList.length == 0)
                scoreLevel = "A+";
            else if (badScorePCT >= 0.05)
                scoreLevel = "B";
            else
                scoreLevel = "A";


            return scoreLevel;
        }
    }
})