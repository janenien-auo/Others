﻿var app = new Vue({
    el: '#app',
    data: {
       
    },   
    mounted: function () {
        var self = this;
        LayoutApp.showLoading = true;
        self.getProjectInfo();       
    },
    methods: {
        getProjectInfo: function () {
            var self = this;           
            LayoutApp.getProjectInfo(self.redriectPage);
        },
        redriectPage: function () {
            LayoutApp.redriectPage(true);
        }
    }
})