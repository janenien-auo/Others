﻿var app = new Vue({
    el: '#app', 
    store: store,
    data: {      
        pageInfo: {}
    },
    mounted: function () {
        store.commit("setDefaultProjectId");
        store.commit("setDefaultModelId");
        store.commit("setProjectInfo");  


        var self = this;
        self.getStatusInfo();
    },
    methods: {       
        getStatusInfo: function () {
            var self = this;
            if (store.getters.getCurrentDataSource == "continuous" && store.getters.getOfflineModelStatus > 600) {
                var pageInfo = store.getters.getStatusInfosConti.find(function (page) {
                    return page.offline_model_status == store.getters.getOfflineModelStatus;
                });
                self.pageInfo = pageInfo;
            }
            else if (store.getters.getCurrentDataSource == "raw_data" && store.getters.getOfflineModelStatus > 2000) {
                var pageInfo = store.getters.getStatusInfosRawData.find(function (page) {
                    return page.offline_model_status == store.getters.getOfflineModelStatus;
                });
                self.pageInfo = pageInfo;
            }
            else {
                var pageInfo = store.getters.getStatusInfos.find(function (page) {
                    return page.offline_model_status == store.getters.getOfflineModelStatus;
                });
                self.pageInfo = pageInfo;
            }


          
            if (!self.pageInfo.extensionInfo) {
                
                window.location.href = self.pageInfo.url;
            }

            store.commit('setShowLoading', false); 
        }
    }
})