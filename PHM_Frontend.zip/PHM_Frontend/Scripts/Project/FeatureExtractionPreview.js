﻿var app = new Vue({
    el: '#app',  
    data: {
        ToolIDs: [],
        ToolID: "",
        Chambers: [],
        Chamber: "",
        AllParameters: [],
        Parameters: [],
        Parameter: "",
        Spectrum: "",
        Spectrums: [],
        Statistical: "", 
        Statisticals: [],
        ChartDatas: [],
        AutoShowChart:true,
    },
    mounted: function () {
        var self = this;      
        self.getTools();
        LayoutApp.showLoading = false;
    },
    methods: {       
        getTools: function () {
            
            var apiUrl = "/dropitem/tool_chamber";
            //'/dropitem/tool_chamber?project_id=10&model_id=5'
            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: [
                    {
                        Chamber: [
                            "AXI_Y"
                        ],
                        Key: "IEX200",
                        Value: 1
                    }
                    ,
                    {
                        Chamber: [
                            "AXI_Z"
                        ],
                        Key: "IEX201",
                        Value: 2
                    }
                ]

            });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'get',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                params: {
                    project_id: LayoutApp.currentProjectId,
                    model_id: LayoutApp.currentModelId,
                }
            })
                .then(function (response) {
                    
                    if (response.data.status == "OK") {
                        
                        self.ToolIDs = response.data.data;

                        if (self.AutoShowChart && self.ToolIDs.length > 0) {
                            self.ToolID = self.ToolIDs[0].Key;
                            self.getChambers();
                        }
                        
                        
                    } else {
                        alertify.success("get data fail. error message = " + response.data.data.message);                        
                    }
                })               
        },
        getChambers: function (event) {

            var self = this;
            self.Chamber = "";
            self.Chambers = [];
            self.Parameter = "";
            self.Parameters = [];
            self.Spectrum = "";
            self.Spectrums = [];
            self.Statistical = "";
            self.Statisticals = [];

            //alert(Object.keys(self.ToolIDs).length);
            let arChamber = self.ToolIDs.filter(function (item, index) {
                //alert(item.Key)
                if (item.Key == self.ToolID)
                    return item.Chamber;
            })

            self.Chambers = arChamber[0].Chamber;
            if (self.AutoShowChart && self.Chambers.length > 0) {
                self.Chamber = self.Chambers[0];
                self.getParameters();
            }
        },
        getParameters: function (event) {

            var self = this;
            self.Parameter = "";
            self.Parameters = [];
            self.Spectrum = "";
            self.Spectrums = [];
            self.Statistical = "";
            self.Statisticals = [];

            var apiUrl = "/spectrum_statistical/get_list";
            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            //LayoutApp.currentProjectId
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data:
                {
                    parameter: [
                        {
                            Key: "CT",
                            spectrum: [
                                { Item: "fft", method: ["mean", "std"] },
                                { Item: "psd", method: ["var", "rms"] },
                                { Item: "wavelet", method: ["skewness"] }
                            ]
                        },
                        {
                            Key: "Vib",
                            spectrum: [
                                { Item: "wavelet", method: ["skewness"] },
                                { Item: "psd", method: ["var", "rms"] }
                            ]
                        }
                    ]   
                }


            });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            var self = this;


            axios({
                method: 'get',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                params: {
                    model_id: LayoutApp.currentModelId
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {

                        self.Parameters = response.data.data.parameter;
                        
                        if (self.AutoShowChart && self.Parameters.length > 0) {
                            self.Parameter = self.Parameters[0].key;
                            self.getSpectrums();
                        }

                    } else {
                        alertify.success("get data fail. error message = " + response.data.data.message);    
                    }
                })              

        },
        getSpectrums: function (event) {
            //Array.prototype.unique = function () {
            //    let arr = [];
            //    for (let i = 0; i < this.length; i++) {
            //        if (!arr.includes(this[i])) {
            //            arr.push(this[i]);
            //        }
            //    }
            //    return arr;
            //}

            var self = this;
            var self = this;
            self.Spectrum = "";
            self.Spectrums = [];
            self.Statistical = "";
            self.Statisticals = [];
            var arrTmp = [];
            let arSpectrum = self.Parameters.filter(function (item, index) {
                
                if (item.key == self.Parameter) {

                    self.Spectrums = item.spectrum;
                    return;
                }
            })
           
            if (self.AutoShowChart && self.Spectrums.length > 0) {
                self.Spectrum = self.Spectrums[0].item;
                self.getStatisticals();
            }


        },
        getStatisticals: function (event) {

            var self = this;
            var self = this;

            self.Statistical = "";
            self.Statisticals = [];
            var arrTmp = [];
            let arSpectrum = self.Parameters.filter(function (item, index) {

                if (item.key == self.Parameter) {
                    //alert(item.spectrum.length)
                    //return item.spectrum
                    for (var i = 0; i < item.spectrum.length; i++) {
                        if (item.spectrum[i].item == self.Spectrum) {
                            self.Statisticals = item.spectrum[i].statistical;
                        }
                    }
                    return;


                }
            })
            if (self.AutoShowChart && self.Statisticals.length > 0) {
                self.Statistical = self.Statisticals[0];
                self.QueryData();
            }



        },
        backClick: function () {
            var self = this;
            alertify.confirm("Are you sure want to leave the [Feature Extraction Preview] page and go back to the previous step??",
                function (e) {
                    if (e) {
                        //OK
                        window.location.href = "/Project/FeatureExtraction";
                    } else {
                        //Cancel                      
                    }
                });
        },
        nextClick: function () {
            var self = this;

            alertify.confirm("Are you sure want to leave the [Feature Extraction Preview] page and go to the next step??",
                function (e) {
                    if (e) {
                        //OK

                        // window.location.href = "/Project/DataLabeling";
                        LayoutApp.nextStatus();
                        //self.save(function () { window.location.href = "/Project/DataLabeling"; });

                    } else {
                        //Cancel                      
                    }
                });
        },
        QueryData: function () {
            var self = this;

            if (self.ToolID == "") {
                alertify.error("Please Select Tool !!");
                return;
            }
            if (self.Chamber == "") {
                alertify.error("Please Select Chamber !!");
                return;
            }
            if (self.Parameter == "") {
                alertify.error("Please Select Parameter !!");
                return;
            }
            if (self.Spectrum == "") {
                alertify.error("Please Select Spectrum !!");
                return;
            }

            if (self.Statistical == "") {
                alertify.error("Please Select Statistical !!");
                return;
            }

            var apiUrl = "/spectrum_statistical";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data:[

                    {
                        name: "Mean1",
                        value: [5.5, 15, 7.6, 25, 8.5, 16.2, 18.4, 19.5, 22.5, 13.6, 24.2, 26.4],

                    }, {
 
                        name: "Mean2",
                    
                        value: [1, 10, 2, 20, 4, 11, 14, 15, 16, 8, 19, 21],

                    }
                ]


            });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            var self = this;


            axios({
                method: 'get',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                params: {
                    project_id: LayoutApp.currentProjectId,
                    model_id: LayoutApp.currentModelId,
                    tool: self.ToolID,
                    chamber: self.Chamber,
                    parameter: self.Parameter,
                    spectrum: self.Spectrum,
                    statistical: self.Statistical
                }

            })
                .then(function (response) {
                    if (response.data.status == "OK") {


                        self.ChartDatas = response.data.data;

                        self.DrawChart();
                    } else {
                        alertify.error("get data fail. error message = " + response.data.data.message);
                    }
                })             


        },
        DrawChart: function () {
            //var arColor = ['#00B0F0', '#00EACD', '#43A047', '#92D050', '#D05052', '#FF7800', '#FFFF00', '#A349A4', '#F06292', '#7E57C2', '#02B9C4', '#5292B3', '#DAF7A6', '#49ff33', '#b9e7ff', '#83B9C7', '#2ACDC9', '#FFD000', '#7CFEF0', '#d7f96e'];
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            var self = this;
            
            var _series = [], _legend = [], _xAxis = [];
            for (var i = 0; i < self.ChartDatas.length; i++) {
                _xAxis = [];
                _legend.push(self.ChartDatas[i].name);
                _series.push({ name: self.ChartDatas[i].name, data: self.ChartDatas[i].value, type: 'line', symbol: '', smooth: true, itemStyle: { color: arColor[i] } });
                for (var j = 0; j < self.ChartDatas[i].value.length; j++) {
                    _xAxis.push(j + 1);
                }
            }
            var iTotalPoint = _xAxis.length;
            var myChart = echarts.init(document.getElementById("EChart1"), 'default');
            myChart.clear();

            /*  去除加载缓冲图 */
            myChart.showLoading({
                text: 'Loading...',
                textStyle: { fontSize: 30, color: '#444' },
                effectOption: { backgroundColor: 'rgba(0, 0, 0, 0)' }
            });
            
            var option = {
                backgroundColor: '#545655',//背景色
                tooltip: {
                    trigger: 'axis',
                    textStyle: {
                        fontSize: 11
                    },
                    formatter: function (params) {

                        var result = params[0].name + '<br>';
                        params.forEach(function (item) {
                            result += '<span style="display:inline-block;margin-right:5px;border-radius:10px;width:9px;height:9px;background-color:' + item.color + '"></span>';
                            result += item.seriesName + " : " + '<span style="color:#ccffff;font-family: arial;">' + parseFloat(item.data.toFixed(6)) + "</span><br>";
                        });


                        return result;
                    }
                },

                legend: {
                    //type: 'scroll',
                    orient: 'vertical',
                    //x: 'right',
                    //y: 'top',
                    borderWidth: 2,
                    padding: 2,
                    itemGap: 5,
                    right: '1%',
                    top: '10%',

                    color: '#02B9C4',
                    data: _legend,
                    selected: {
                        

                    },
                    bottom: '50%',
                    textStyle: {
                        color: '#CDEDED',
                        fontSize: '10'
                    },

                    //selected: 1
                }, grid: {
                    x: '7%',
                    y: '7%',
                    width: '85%',
                    height: '73%',
                    show: false,
                    borderColor: 'red'
                },
                toolbox: {
                    show: true,
                    feature: {
                        mark: { show: true },
                        dataZoom: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#ec7063'
                                }
                            }
                        },
                        dataView: {
                            show: false, readOnly: false, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#e59866'
                                }
                            }
                        },
                        restore: {
                            show: true,iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#8e44ad'
                                }
                            }},
                        saveAsImage: {
                            show: true, type: 'png', excludeComponents: ['toolbox'], pixelRatio: 2, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#2ecc71',
                                    shadowColor: 'rgba(0, 0, 0, 0.5)',
                                    shadowBlur: 10
                                }
                            } }
                    }
                },
                xAxis: [
                    {
                        type: 'category',
                        triggerEvent: true,
                        boundaryGap: true,
                        data: _xAxis,



                        axisTick: {
                            show: false,
                            alignWithLabel: true
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变x轴颜色
                        axisLine: {
                            show: true,
                            onZero: false,
                            position: 'end',
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        //  改变x轴字体颜色和大小
                        axisLabel: {
                            show: true,
                            rotate: 90,
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                    }
                ],

                yAxis: [
                    {
                        //  隐藏y轴
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },

                        // 去除y轴上的刻度线
                        axisTick: {
                            show: false
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变y轴字体颜色和大小
                        axisLabel: {
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                        type: 'value',
                        triggerEvent: true
                    }
                ],

                dataZoom: [{
                    type: 'inside',
                    start: 0,
                    end: 100
                }, {
                    start: 0,
                        end: 100,
                    handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                    handleSize: '80%',
                    handleStyle: {
                        color: '#fff',
                        shadowBlur: 3,
                        shadowColor: 'rgba(0, 0, 0, 0.6)',
                        shadowOffsetX: 2,
                        shadowOffsetY: 2
                    }
                }],
                series: _series
            };

            
            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option, true);
            
        }
    }
})