﻿var app = new Vue({
    el: '#app', //el為要綁定的div的id(已設定完成)  
    data: {     
        //該頁會使用道的變數請統一放在這裡
        n_cluster: 0,
        n_clusters: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
        offline_model_status: 0,
        imgbase64: "",
        cluster: "",
        clusters: [],
        datalist: [],
        clusterdata: [],
        showEditor: true,
        showLabeling: true,
        showInfo: true,
    },
    mounted: function () {
        LayoutApp.showLoading = true;
        var self = this;     
        self.getProjectInfo();   

        LayoutApp.showLoading = false;
    },
    methods: {
        //Function請寫在這裡
        getProjectInfo: function () {

            var apiUrl = "/project";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                code: 200,
                data: [
                    {
                        ai365_project_name: "qqq",
                        application: "Robot",
                        fab: "L5C",
                        function: "GGG",
                        itime: "2019-12-31 11:02:03",
                        model_id: 5,
                        model_type: "Health Assessment",
                        offline_model_status: 600,
                        //process_type: "Array",
                        stage: "Array",
                        tool_type: "Test",
                        project_id: 4,
                        user_empno: "ewrt"
                    }
                ],
                description: "Get Project list success",
                status: "OK"
            });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'get',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                params: {
                    "project_id": LayoutApp.currentProjectId
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        var itemdata = response.data.data.project_list[0];
                        self.offline_model_status = parseInt(itemdata.offline_model_status);
                        console.log(self.offline_model_status);
                        if (self.offline_model_status <= 600) {
                            self.showEditor = true;
                            self.showLabeling = self.showInfo = false;
                        }
                        else if (self.offline_model_status == 601) {
                            self.showLabeling = true;
                            self.showEditor = self.showInfo = false;
                        }
                        else if (self.offline_model_status == 603) {    // Fail
                            self.showLabeling = true;
                            self.showEditor = self.showInfo = false;
                            $("#lblMsgLabeling").val($("#lblMsgLabeling").val() + " (Fail)");
                        }
                        else if (self.offline_model_status >= 602) {
                            self.showEditor = self.showInfo = true;
                            self.showLabeling = false;
                        }

                        if (self.showInfo) {
                            self.getData();
                        }
                    }
                    else
                        alertify.error("get data fail. error message = " + response.data.data.message);

                    LayoutApp.showLoading = false;
                })               

        },

        getData: function () {

            var apiUrl = "/data_labeling";

            var self = this;
            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                code: 200,
                data: {
                    clusters: {
                        c_0: {
                            chamber: [
                                "AXI_X"
                            ],
                            cluster_percentage: 66.66666666666667,
                            count: 2,
                            distance: 0.41649329726499396,
                            percentage: [
                                100.0
                            ],
                            tool: [
                                "IEX300"
                            ]
                        },
                        c_1: {
                            chamber: [
                                "AXI_X"
                            ],
                            cluster_percentage: 33.333333333333336,
                            count: 1,
                            distance: 0.0,
                            percentage: [
                                100.0
                            ],
                            tool: [
                                "IEX300"
                            ]
                        }
                    },
                    image_base64: "iVBORw0KGgoAAAANSUhEUgAAAoAAAAHgCAYAAAA10dzkAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAPYQAAD2EBqD+naQAAADl0RVh0U29mdHdhcmUAbWF0cGxvdGxpYiB2ZXJzaW9uIDMuMC4zLCBodHRwOi8vbWF0cGxvdGxpYi5vcmcvnQurowAAIABJREFUeJzt3X9w0+dhx/GPJWab2LGAOMg2U2sbaFgGWI0NijNIu0VFZL0uXJKe4bgaXK7c6I2WUyhgAjaMbCaEcV5qB28sPwhdGi+7jt3lOG+prr5bEgVfTTjWJmSEwRkCEsapJSyC3FraHxzKVGwwxLYsnvfrTlf50fN9eL530endryU5Ix6PxwUAAABjWFK9AQAAAIwtAhAAAMAwBCAAAIBhCEAAAADDEIAAAACGIQABAAAMQwACAAAYhgAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhiEAAQAADEMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMMQgAAAAIYhAAEAAAxDAAIAABiGAAQAADAMAQgAAGAYAhAAAMAwBCAAAIBhCEAAAADDEIAAAACGIQABAAAMQwACAAAYhgAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhiEAAQAADEMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMMQgAAAAIYhAAEAAAxDAAIAABiGAAQAADAMAQgAAGAYAhAAAMAwBCAAAIBhCEAAAADDEIAAAACGIQABAAAMQwACAAAYhgAEAAAwzIRUbyCdxWIxnTt3TnfffbcyMjJSvR0AADAM8Xhcly5dUlFRkSwWM6+FEYBfwLlz5+RwOFK9DQAAcBvOnDmjP/zDP0z1NlKCAPwC7r77bklX/wPKy8tL8W4AAMBwhMNhORyOxOu4iQjAL+Dar33z8vIIQAAA0ozJb98y8xffAAAABiMAAQAADEMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMMQgAAAAIYhAAEAAAxDAAIAABiGAAQAADDMhFRvAEgX8bh0+XKqdwFgtNx1l5SRkepdAGODAASGIR6XFiyQ3n031TsBMFr+5E+k//ovIhBm4FfAwDBcvkz8AXe6d97hKj/MwRVA4BYFg1JOTqp3AWCkRCKS3Z7qXQBjiwAEblFODgEIAEhv/AoYAADAMAQgAACAYQhAAAAAwxCAAAAAhiEAAQAADEMAAgAAGIYABAAAMExaBWBzc7OKi4uVnZ0tl8uljo6OYR33+uuvKyMjQ0uWLEkaj8fjqqurU2FhoSZOnCi3260TJ06MxtYBAADGjbQJwNbWVnm9XtXX1+vIkSMqKyuTx+PRhQsXbnjc6dOntX79ei1cuPC6x3bt2qXnn39eLS0tOnz4sHJycuTxeHTlypXROg0AAICUS5sA3LNnj773ve+ppqZG999/v1paWnTXXXfppZdeGvKYgYEBLV++XNu3b1dpaWnSY/F4XI2NjdqyZYsee+wxzZ07V6+++qrOnTungwcPjvbpAAAApExaBGB/f786OzvldrsTYxaLRW63W36/f8jj/vqv/1pTp07VqlWrrnvs1KlTCgQCSWvabDa5XK4h14xGowqHw0k3AACAdJMWAXjx4kUNDAzI/nt/rdtutysQCAx6zNtvv60XX3xR+/btG/Txa8fdypoNDQ2y2WyJm8PhuNVTAQAASLm0CMBbdenSJX3nO9/Rvn37lJ+fP2Lr1tbWKhQKJW5nzpwZsbUBAADGyoRUb2A48vPzZbVaFQwGk8aDwaAKCgqum3/y5EmdPn1a3/rWtxJjsVhMkjRhwgR99NFHieOCwaAKCwuT1nQ6nYPuIysrS1lZWV/4fAAAAFIpLa4AZmZmqry8XD6fLzEWi8Xk8/lUWVl53fxZs2bpv//7v3X06NHE7S/+4i/0p3/6pzp69KgcDodKSkpUUFCQtGY4HNbhw4cHXRMAAOBOkRZXACXJ6/VqxYoVqqio0Pz589XY2KhIJKKamhpJUnV1taZNm6aGhgZlZ2dr9uzZScdPmjRJkpLG161bp2eeeUYzZ85USUmJtm7dqqKiouu+LxAAAOBOkjYBWFVVpe7ubtXV1SkQCMjpdKqtrS3xIY6uri5ZLLd2QXPDhg2KRCJavXq1ent7tWDBArW1tSk7O3s0TgEAAGBcyIjH4/FUbyJdhcNh2Ww2hUIh5eXlpXo7GEWRiJSbe/V+X5+Uk5Pa/QAYOTy/zcPrd5q8BxAAAAAjhwAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhiEAAQAADEMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMMQgAAAAIYhAAEAAAxDAAIAABiGAAQAADAMAQgAAGAYAhAAAMAwBCAAAIBhCEAAAADDEIAAAACGIQABAAAMQwACAAAYhgAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhkmrAGxublZxcbGys7PlcrnU0dEx5Nyf/exnqqio0KRJk5STkyOn06kDBw4kzVm5cqUyMjKSbosXLx7t0wAAAEipCanewHC1trbK6/WqpaVFLpdLjY2N8ng8+uijjzR16tTr5k+ZMkVPP/20Zs2apczMTL355puqqanR1KlT5fF4EvMWL16sl19+OfFzVlbWmJwPAABAqmTE4/F4qjcxHC6XS/PmzVNTU5MkKRaLyeFwaO3atdq0adOw1njggQf0zW9+Uzt27JB09Qpgb2+vDh48eFt7CofDstlsCoVCysvLu601kB4iESk39+r9vj4pJye1+wEwcnh+m4fX7zT5FXB/f786OzvldrsTYxaLRW63W36//6bHx+Nx+Xw+ffTRR3r44YeTHmtvb9fUqVN13333ac2aNerp6RlynWg0qnA4nHQDAABIN2nxK+CLFy9qYGBAdrs9adxut+v48eNDHhcKhTRt2jRFo1FZrVa98MIL+sY3vpF4fPHixXr88cdVUlKikydPavPmzXr00Ufl9/tltVqvW6+hoUHbt28fuRMDAABIgbQIwNt199136+jRo+rr65PP55PX61Vpaam+/vWvS5KWLl2amDtnzhzNnTtX06dPV3t7ux555JHr1qutrZXX6038HA6H5XA4Rv08AAAARlJaBGB+fr6sVquCwWDSeDAYVEFBwZDHWSwWzZgxQ5LkdDr14YcfqqGhIRGAv6+0tFT5+fn6+OOPBw3ArKwsPiQCAADSXlq8BzAzM1Pl5eXy+XyJsVgsJp/Pp8rKymGvE4vFFI1Gh3z87Nmz6unpUWFh4RfaLwAAwHiWFlcAJcnr9WrFihWqqKjQ/Pnz1djYqEgkopqaGklSdXW1pk2bpoaGBklX369XUVGh6dOnKxqN6tChQzpw4ID27t0rSerr69P27dv1xBNPqKCgQCdPntSGDRs0Y8aMpK+JAQAAuNOkTQBWVVWpu7tbdXV1CgQCcjqdamtrS3wwpKurSxbL5xc0I5GIvv/97+vs2bOaOHGiZs2apZ/85CeqqqqSJFmtVh07dkz79+9Xb2+vioqKtGjRIu3YsYNf8wIAgDta2nwP4HjE9wiZg+8JA+5cPL/Nw+t3mrwHEAAAACOHAAQAADAMAQgAAGAYAhAAAMAwBCAAAIBhCEAAAADDEIAAAACGIQABAAAMQwACAAAYhgAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhiEAAQAADEMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMMQgAAAAIYhAAEAAAxDAAIAABiGAAQAADAMAQgAAGAYAhAAAMAwBCAAAIBhCEAAAADDEIAAAACGSasAbG5uVnFxsbKzs+VyudTR0THk3J/97GeqqKjQpEmTlJOTI6fTqQMHDiTNicfjqqurU2FhoSZOnCi3260TJ06M9mkAAACkVNoEYGtrq7xer+rr63XkyBGVlZXJ4/HowoULg86fMmWKnn76afn9fh07dkw1NTWqqanRf/zHfyTm7Nq1S88//7xaWlp0+PBh5eTkyOPx6MqVK2N1WgAAAGMuIx6Px1O9ieFwuVyaN2+empqaJEmxWEwOh0Nr167Vpk2bhrXGAw88oG9+85vasWOH4vG4ioqK9NRTT2n9+vWSpFAoJLvdrldeeUVLly696XrhcFg2m02hUEh5eXm3f3IY9yIRKTf36v2+PiknJ7X7ATByeH6bh9fvNLkC2N/fr87OTrnd7sSYxWKR2+2W3++/6fHxeFw+n08fffSRHn74YUnSqVOnFAgEkta02WxyuVzDWhMAACBdTUj1Bobj4sWLGhgYkN1uTxq32+06fvz4kMeFQiFNmzZN0WhUVqtVL7zwgr7xjW9IkgKBQGKN31/z2mO/LxqNKhqNJn4Oh8O3dT4AAACplBYBeLvuvvtuHT16VH19ffL5fPJ6vSotLdXXv/7121qvoaFB27dvH9lNAgAAjLG0+BVwfn6+rFargsFg0ngwGFRBQcGQx1ksFs2YMUNOp1NPPfWUnnzySTU0NEhS4rhbWbO2tlahUChxO3PmzBc5LQAAgJRIiwDMzMxUeXm5fD5fYiwWi8nn86mysnLY68RiscSvcEtKSlRQUJC0Zjgc1uHDh4dcMysrS3l5eUk3AACAdJM2vwL2er1asWKFKioqNH/+fDU2NioSiaimpkaSVF1drWnTpiWu8DU0NKiiokLTp09XNBrVoUOHdODAAe3du1eSlJGRoXXr1umZZ57RzJkzVVJSoq1bt6qoqEhLlixJ2XkCAACMtrQJwKqqKnV3d6uurk6BQEBOp1NtbW2JD3F0dXXJYvn8gmYkEtH3v/99nT17VhMnTtSsWbP0k5/8RFVVVYk5GzZsUCQS0erVq9Xb26sFCxaora1N2dnZY35+AAAAYyVtvgdwPOJ7hMzB94QBdy6e3+bh9TtN3gMIAACAkUMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMMQgAAAAIYhAAEAAAxDAAIAABiGAAQAADAMAQgAAGAYAhAAAMAwBCAAAIBhCEAAAADDEIAAAACGIQABAAAMQwACAAAYhgAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhiEAAQAADEMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMOkVQA2NzeruLhY2dnZcrlc6ujoGHLuvn37tHDhQk2ePFmTJ0+W2+2+bv7KlSuVkZGRdFu8ePFonwYAAEBKpU0Atra2yuv1qr6+XkeOHFFZWZk8Ho8uXLgw6Pz29nYtW7ZMv/jFL+T3++VwOLRo0SJ98sknSfMWL16s8+fPJ24//elPx+J0AAAAUiYjHo/HU72J4XC5XJo3b56ampokSbFYTA6HQ2vXrtWmTZtuevzAwIAmT56spqYmVVdXS7p6BbC3t1cHDx68rT2Fw2HZbDaFQiHl5eXd1hpID5GIlJt79X5fn5STk9r9ABg5PL/Nw+t3mlwB7O/vV2dnp9xud2LMYrHI7XbL7/cPa43Lly/rt7/9raZMmZI03t7erqlTp+q+++7TmjVr1NPTM6J7BwAAGG8mpHoDw3Hx4kUNDAzIbrcnjdvtdh0/fnxYa2zcuFFFRUVJEbl48WI9/vjjKikp0cmTJ7V582Y9+uij8vv9slqt160RjUYVjUYTP4fD4ds8IwAAgNRJiwD8onbu3KnXX39d7e3tys7OTowvXbo0cX/OnDmaO3eupk+frvb2dj3yyCPXrdPQ0KDt27ePyZ4BAABGS1r8Cjg/P19Wq1XBYDBpPBgMqqCg4IbH7t69Wzt37tR//ud/au7cuTecW1paqvz8fH388ceDPl5bW6tQKJS4nTlz5tZOBAAAYBxIiwDMzMxUeXm5fD5fYiwWi8nn86mysnLI43bt2qUdO3aora1NFRUVN/13zp49q56eHhUWFg76eFZWlvLy8pJuAAAA6SYtAlCSvF6v9u3bp/379+vDDz/UmjVrFIlEVFNTI0mqrq5WbW1tYv6zzz6rrVu36qWXXlJxcbECgYACgYD6+vokSX19ffrRj36k9957T6dPn5bP59Njjz2mGTNmyOPxpOQcAQAAxkLavAewqqpK3d3dqqurUyAQkNPpVFtbW+KDIV1dXbJYPu/ZvXv3qr+/X08++WTSOvX19dq2bZusVquOHTum/fv3q7e3V0VFRVq0aJF27NihrKysMT03AACAsZQ23wM4HvE9Qubge8KAOxfPb/Pw+p1GvwIGAADAyCAAAQAADEMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMMQgAAAAIYhAAEAAAxDAAIAABiGAAQAADAMAQgAAGAYAhAAAMAwBCAAAIBhCEAAAADDEIAAAACGIQABAAAMQwACAAAYhgAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhiEAAQAADEMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMOkVQA2NzeruLhY2dnZcrlc6ujoGHLuvn37tHDhQk2ePFmTJ0+W2+2+bn48HlddXZ0KCws1ceJEud1unThxYrRPAwAAIKXSJgBbW1vl9XpVX1+vI0eOqKysTB6PRxcuXBh0fnt7u5YtW6Zf/OIX8vv9cjgcWrRokT755JPEnF27dun5559XS0uLDh8+rJycHHk8Hl25cmWsTgsAAGDMZcTj8XiqNzEcLpdL8+bNU1NTkyQpFovJ4XBo7dq12rRp002PHxgY0OTJk9XU1KTq6mrF43EVFRXpqaee0vr16yVJoVBIdrtdr7zyipYuXXrTNcPhsGw2m0KhkPLy8r7YCWJci0Sk3Nyr9/v6pJyc1O4HwMjh+W0eXr/T5Apgf3+/Ojs75Xa7E2MWi0Vut1t+v39Ya1y+fFm//e1vNWXKFEnSqVOnFAgEkta02WxyuVxDrhmNRhUOh5NuAAAA6SYtAvDixYsaGBiQ3W5PGrfb7QoEAsNaY+PGjSoqKkoE37XjbmXNhoYG2Wy2xM3hcNzqqQAAAKRcWgTgF7Vz5069/vrr+rd/+zdlZ2ff9jq1tbUKhUKJ25kzZ0ZwlwAAAGNjQqo3MBz5+fmyWq0KBoNJ48FgUAUFBTc8dvfu3dq5c6d+/vOfa+7cuYnxa8cFg0EVFhYmrel0OgddKysrS1lZWbd7GgAAAONCWlwBzMzMVHl5uXw+X2IsFovJ5/OpsrJyyON27dqlHTt2qK2tTRUVFUmPlZSUqKCgIGnNcDisw4cP33BNAACAdJcWVwAlyev1asWKFaqoqND8+fPV2NioSCSimpoaSVJ1dbWmTZumhoYGSdKzzz6ruro6vfbaayouLk68ry83N1e5ubnKyMjQunXr9Mwzz2jmzJkqKSnR1q1bVVRUpCVLlqTsPAEAAEZb2gRgVVWVuru7VVdXp0AgIKfTqba2tsSHOLq6umSxfH5Bc+/everv79eTTz6ZtE59fb22bdsmSdqwYYMikYhWr16t3t5eLViwQG1tbV/ofYIAAADjXdp8D+B4xPcImYPvCQPuXDy/zcPrd5q8BxAAAAAjhwAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhiEAAQAADEMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMMQgAAAAIYhAAEAAAxDAAIAABiGAAQAADAMAQgAAGAYAhAAAMAwBCAAAIBhCEAAAADDEIAAAACGIQABAAAMQwACAAAYhgAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhkmbAGxublZxcbGys7PlcrnU0dEx5Nxf//rXeuKJJ1RcXKyMjAw1NjZeN2fbtm3KyMhIus2aNWs0TwEAAGBcSIsAbG1tldfrVX19vY4cOaKysjJ5PB5duHBh0PmXL19WaWmpdu7cqYKCgiHX/eM//mOdP38+cXv77bdH6xQAAADGjbQIwD179uh73/ueampqdP/996ulpUV33XWXXnrppUHnz5s3T88995yWLl2qrKysIdedMGGCCgoKErf8/PzROgUAAIBxY9wHYH9/vzo7O+V2uxNjFotFbrdbfr//C6194sQJFRUVqbS0VMuXL1dXV9cN50ejUYXD4aQbAABAuhn3AXjx4kUNDAzIbrcnjdvtdgUCgdte1+Vy6ZVXXlFbW5v27t2rU6dOaeHChbp06dKQxzQ0NMhmsyVuDofjtv99AACAVBn3AThaHn30UX3729/W3Llz5fF4dOjQIfX29upf/uVfhjymtrZWoVAocTtz5swY7hgAAGBkTEj1Bm4mPz9fVqtVwWAwaTwYDN7wAx63atKkSfrKV76ijz/+eMg5WVlZN3xPIQAAQDoY91cAMzMzVV5eLp/PlxiLxWLy+XyqrKwcsX+nr69PJ0+eVGFh4YitCQAAMB6N+yuAkuT1erVixQpVVFRo/vz5amxsVCQSUU1NjSSpurpa06ZNU0NDg6SrHxz54IMPEvc/+eQTHT16VLm5uZoxY4Ykaf369frWt76lL3/5yzp37pzq6+tltVq1bNmy1JwkAADAGEmLAKyqqlJ3d7fq6uoUCATkdDrV1taW+GBIV1eXLJbPL2aeO3dOX/3qVxM/7969W7t379bXvvY1tbe3S5LOnj2rZcuWqaenR/fee68WLFig9957T/fee++YnhsAAMBYy4jH4/FUbyJdhcNh2Ww2hUIh5eXlpXo7GEWRiJSbe/V+X5+Uk5Pa/QAYOTy/zcPrdxq8BxAAAAAjiwAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhiEAAQAADEMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMMQgAAAAIYhAAEAAAxDAAIAABiGAAQAADAMAQgAAGAYAhAAAMAwBCAAAIBhCEAAAADDEIAAAACGIQABAAAMQwACAAAYhgAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhkmbAGxublZxcbGys7PlcrnU0dEx5Nxf//rXeuKJJ1RcXKyMjAw1NjZ+4TUBAADuFGkRgK2trfJ6vaqvr9eRI0dUVlYmj8ejCxcuDDr/8uXLKi0t1c6dO1VQUDAiawIAANwpMuLxeDzVm7gZl8ulefPmqampSZIUi8XkcDi0du1abdq06YbHFhcXa926dVq3bt2IrXlNOByWzWZTKBRSXl7ebZwZ0kUkIuXmXr3f1yfl5KR2PwBGDs9v8/D6nQZXAPv7+9XZ2Sm3250Ys1gscrvd8vv942ZNAACAdDEh1Ru4mYsXL2pgYEB2uz1p3G636/jx42O6ZjQaVTQaTfwcDodv698HAABIpXF/BXA8aWhokM1mS9wcDkeqtwQAAHDLxn0A5ufny2q1KhgMJo0Hg8EhP+AxWmvW1tYqFAolbmfOnLmtfx8AACCVxn0AZmZmqry8XD6fLzEWi8Xk8/lUWVk5pmtmZWUpLy8v6QYAAJBuxv17ACXJ6/VqxYoVqqio0Pz589XY2KhIJKKamhpJUnV1taZNm6aGhgZJVz/k8cEHHyTuf/LJJzp69Khyc3M1Y8aMYa0JAABwp0qLAKyqqlJ3d7fq6uoUCATkdDrV1taW+BBHV1eXLJbPL2aeO3dOX/3qVxM/7969W7t379bXvvY1tbe3D2tNAACAO1VafA/geMX3CJmD7wkD7lw8v83D63cavAcQAAAAI4sABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMMQgAAAAIYhAAEAAAxDAAIAABiGAAQAADAMAQgAAGAYAhAAAMAwBCAAAIBhCEAAAADDEIAAAACGIQABAAAMQwACAAAYhgAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhiEAAQAADEMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMMQgAAAAIZJqwBsbm5WcXGxsrOz5XK51NHRccP5b7zxhmbNmqXs7GzNmTNHhw4dSnp85cqVysjISLotXrx4NE8BAAAg5dImAFtbW+X1elVfX68jR46orKxMHo9HFy5cGHT+u+++q2XLlmnVqlV6//33tWTJEi1ZskS/+tWvkuYtXrxY58+fT9x++tOfjsXpAAAApExGPB6Pp3oTw+FyuTRv3jw1NTVJkmKxmBwOh9auXatNmzZdN7+qqkqRSERvvvlmYuzBBx+U0+lUS0uLpKtXAHt7e3Xw4MHb2lM4HJbNZlMoFFJeXt5trYH0EIlIublX7/f1STk5qd0PgJHD89s8vH6nyRXA/v5+dXZ2yu12J8YsFovcbrf8fv+gx/j9/qT5kuTxeK6b397erqlTp+q+++7TmjVr1NPTM/InAAAAMI5MSPUGhuPixYsaGBiQ3W5PGrfb7Tp+/PigxwQCgUHnBwKBxM+LFy/W448/rpKSEp08eVKbN2/Wo48+Kr/fL6vVet2a0WhU0Wg08XM4HP4ipwUAAJASaRGAo2Xp0qWJ+3PmzNHcuXM1ffp0tbe365FHHrlufkNDg7Zv3z6WWwQAABhxafEr4Pz8fFmtVgWDwaTxYDCogoKCQY8pKCi4pfmSVFpaqvz8fH388ceDPl5bW6tQKJS4nTlz5hbPBAAAIPXSIgAzMzNVXl4un8+XGIvFYvL5fKqsrBz0mMrKyqT5kvTWW28NOV+Szp49q56eHhUWFg76eFZWlvLy8pJuAAAA6SYtAlCSvF6v9u3bp/379+vDDz/UmjVrFIlEVFNTI0mqrq5WbW1tYv4Pf/hDtbW16e/+7u90/Phxbdu2Tb/85S/1V3/1V5Kkvr4+/ehHP9J7772n06dPy+fz6bHHHtOMGTPk8XhSco4AAABjIW3eA1hVVaXu7m7V1dUpEAjI6XSqra0t8UGPrq4uWSyf9+xDDz2k1157TVu2bNHmzZs1c+ZMHTx4ULNnz5YkWa1WHTt2TPv371dvb6+Kior9N5c4AAAJmElEQVS0aNEi7dixQ1lZWSk5RwAAgLGQNt8DOB7xPULm4HvCgDsXz2/z8PqdRr8CBgAAwMggAAEAAAxDAAIAABiGAAQAADAMAQgAAGAYAhAAAMAwBCAAAIBhCEAAAADDEIAAAACGIQABAAAMQwACAAAYhgAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhiEAAQAADEMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMMQgAAAAIYhAAEAAAxDAAIAABiGAAQAADAMAQgAAGAYAhAAAMAwBCAAAIBhCEAAAADDpFUANjc3q7i4WNnZ2XK5XOro6Ljh/DfeeEOzZs1Sdna25syZo0OHDiU9Ho/HVVdXp8LCQk2cOFFut1snTpwYzVMAAABIubQJwNbWVnm9XtXX1+vIkSMqKyuTx+PRhQsXBp3/7rvvatmyZVq1apXef/99LVmyREuWLNGvfvWrxJxdu3bp+eefV0tLiw4fPqycnBx5PB5duXJlrE4LAABgzGXE4/F4qjcxHC6XS/PmzVNTU5MkKRaLyeFwaO3atdq0adN186uqqhSJRPTmm28mxh588EE5nU61tLQoHo+rqKhITz31lNavXy9JCoVCstvteuWVV7R06dKb7ikcDstmsykUCikvL2+EzhTjUSQi5eZevd/XJ+XkpHY/AEYOz2/z8PotTUj1Boajv79fnZ2dqq2tTYxZLBa53W75/f5Bj/H7/fJ6vUljHo9HBw8elCSdOnVKgUBAbrc78bjNZpPL5ZLf7x80AKPRqKLRaOLnUCgk6ep/SLizRSKf3w+HpYGB1O0FwMji+W2ea6/baXINbFSkRQBevHhRAwMDstvtSeN2u13Hjx8f9JhAIDDo/EAgkHj82thQc35fQ0ODtm/fft24w+EY3ongjlBUlOodABgtPL/NcunSJdlstlRvIyXSIgDHi9ra2qSrirFYTJ9++qnuueceZWRkpHBnAABguOLxuC5duqQig4s/LQIwPz9fVqtVwWAwaTwYDKqgoGDQYwoKCm44/9r/BoNBFRYWJs1xOp2DrpmVlaWsrKyksUmTJt3ayQAAgJQz9crfNWnxKeDMzEyVl5fL5/MlxmKxmHw+nyorKwc9prKyMmm+JL311luJ+SUlJSooKEiaEw6Hdfjw4SHXBAAAuBNYt23bti3VmxiOvLw8bd26VQ6HQ1lZWdq6dauOHj2qF198Ubm5uaqurlZHR0fiQx3Tpk3Tli1blJOToylTpqipqUmtra168cUXNXXqVGVkZGhgYEB/+7d/q/vvv1/9/f36wQ9+oMuXL+vHP/6xJkxIi4ujAAAAtyxtKqeqqkrd3d2qq6tTIBCQ0+lUW1tb4kMcXV1dslg+v6D50EMP6bXXXtOWLVu0efNmzZw5UwcPHtTs2bMTczZs2KBIJKLVq1ert7dXCxYsUFtbm7Kzs8f8/AAAAMZK2nwPIAAAAEZGWrwHEAAAACOHAAQAADAMAQgAAGAYAhAAYIRdu3Zp1qxZisVit3RcS0uLvvSlLyX9KVAg3RGAwE1Eo1Ft3LhRRUVFmjhxolwul956661UbwvALQiHw3r22We1ceNGWSwW9fT06LnnntPDDz+se++9V5MmTdKDDz6o1tbW645duXKl+vv79Q//8A8p2DkwOghA4CZWrlypPXv2aPny5fr7v/97Wa1W/fmf/7nefvvtVG8NwDC99NJL+t3vfqdly5ZJkvx+v55++mlNmTJFW7Zs0d/8zd/orrvu0tKlS1VfX590bHZ2tlasWKE9e/aIL87AnYKvgQFuoKOjQy6XS88995zWr18vSbpy5Ypmz56tqVOn6t13303xDgEMR1lZmebOnasDBw5Ikk6dOiWLxaIvf/nLiTnxeFxut1vvvPOOenp6lJOTk3iss7NTFRUV8vl8+rM/+7Mx3z8w0rgCCNzAv/7rv8pqtWr16tWJsezsbK1atUp+v19nzpxJ4e4ADMepU6d07NixxF+Kkq7+OdD/H3+SlJGRoSVLligajep///d/kx4rLy/XlClT9O///u9jsmdgtBGAwA28//77+spXvqK8vLyk8fnz50uSjh49moptAbgF167UP/DAAzedGwgEJEn5+fnXPfbAAw/onXfeGdnNASlCAAI3cP78eRUWFl43fm3s3LlzY70lALfo+PHjkq5e9buRTz/9VP/0T/+khQsXDvq8Ly0t1QcffDAqewTGGgEI3MBnn32mrKys68av/b3ozz77bKy3BOAW9fT0aMKECcrNzR1yTiwW0/Lly9Xb26sf//jHg86ZPHmyPvvsM12+fHm0tgqMmQmp3gAwnk2cOHHQ7/66cuVK4nEA6W/t2rVqa2vTq6++qrKyskHnXPvMZEZGxlhuDRgVXAEEbqCwsFDnz5+/bvzaWFFR0VhvCcAtuueee/S73/1Oly5dGvTx7du364UXXtDOnTv1ne98Z8h1fvOb3+iuu+7i//jhjkAAAjfgdDr1P//zPwqHw0njhw8fTjwOYHybNWuWpKufBv59zc3N2rZtm9atW6eNGzfecJ1Tp07pj/7oj0Zlj8BYIwCBG3jyySc1MDCgf/zHf0yMRaNRvfzyy3K5XHI4HCncHYDhqKyslCT98pe/TBpvbW3VD37wAy1fvlx79uy56TpHjhzRQw89NCp7BMYa7wEEbsDlcunb3/62amtrdeHCBc2YMUP79+/X6dOn9eKLL6Z6ewCGobS0VLNnz9bPf/5zffe735V09Uveq6urdc899+iRRx7RP//zPycd89BDD6m0tDTxc2dnpz799FM99thjY7p3YLQQgMBNvPrqq9q6dasOHDig3/zmN5o7d67efPNNPfzww6neGoBh+u53v6u6ujp99tlnmjhxoj744AP19/eru7s7EYX/38svv5wUgG+88Ya+9KUv8VdAcMfgT8EBAO54oVBIpaWl2rVrl1atWnVLx0ajURUXF2vTpk364Q9/OEo7BMYW7wEEANzxbDabNmzYoOeee06xWOyWjn355Zf1B3/wB/rLv/zLUdodMPa4AggAAGAYrgACAAAYhgAEAAAwDAEIAABgGAIQAADAMAQgAACAYQhAAAAAwxCAAAAAhiEAAQAADEMAAgAAGIYABAAAMAwBCAAAYBgCEAAAwDAEIAAAgGEIQAAAAMMQgAAAAIYhAAEAAAxDAAIAABiGAAQAADAMAQgAAGAYAhAAAMAwBCAAAIBhCEAAAADDEIAAAACGIQABAAAMQwACAAAYhgAEAAAwzP8BAU7wl9ZcRqsAAAAASUVORK5CYII="
                },
                description: "Successful response",
                status: "OK"
            });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            axios({
                method: 'get',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                params: {
                    project_id: LayoutApp.currentProjectId,
                    model_id: LayoutApp.currentModelId
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.imgbase64 = "data:image/png;base64, " + response.data.data.image_base64;
                        //console.log(Object.keys(response.data.data.clusters));
                        self.datalist = response.data.data.clusters;
                        self.clusters = Object.keys(self.datalist);
                    }
                    else
                        alertify.error("save data fail. error message = " + response.data.data);
                })               

        },

        Calculate: function () {

            var apiUrl = "/data_labeling/calc";

            var self = this;
            if (self.n_cluster == undefined || self.n_cluster < 2) {
                alertify.alert("missing n_cluster number");
                return;
            }

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                status: "OK",
                data: {
                    status: "OK"
                }
            });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }

            axios({
                method: 'post',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                //headers: {
                //    accept: "application/json",
                //    "content-type": "application/json;charset=UTF-8"
                //},
                data: {
                    project_id: LayoutApp.currentProjectId,
                    model_id: LayoutApp.currentModelId,
                    n_clusters: self.n_cluster
                }
                //,
                //proxy: {
                //    host: "10.97.4.1",
                //    port: 8080
                //}
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        window.location.reload();
                        //alertify.alert("calculate return status=OK")
                    }
                    else
                        alertify.error("save data fail. error message = " + response.data.data);
                })
             

        },

        changeCluster: function () {
            self = this
            //console.log(self.datalist[self.cluster]);

            self.clusterdata = []

            arTool = self.datalist[self.cluster].tool;
            arCham = self.datalist[self.cluster].chamber;
            arPercen = self.datalist[self.cluster].percentage;
            for (var i = 0; i < arTool.length; i++) {
                self.clusterdata.push({ "id": i+1, "tool": arTool[i], "chamber": arCham[i], "percentage": arPercen[i] + "%"});
            }
        },

        goPrev: function () {
            var self = this;
            alertify.confirm("Are you sure want to leave this page and go back to the previous step??",
                function (e) {
                    if (e) {
                        //OK
                        window.location.href = "/Project/FeatureExtraction";

                    } else {
                        //Cancel                      
                    }
                });
        },
        goNext: function () {
            var self = this;
            alertify.confirm("Are you sure want to leave this page and go to the next step??",
                function (e) {
                    if (e) {
                        //OK
                        //window.location.href = "/Project/SplitData";
                        LayoutApp.nextStatus();
                    } else {
                        //Cancel                      
                    }
                });
        }
    }
})