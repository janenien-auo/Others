﻿var app = new Vue({
    el: '#app', 
    store: store,
    data: {
        //該頁會使用道的變數請統一放在這裡
        testingData: 20,
        toolId: "",
        chamber: "",
        threshold: "0.05", //defualt 0.05 & 第一版不能更改
        thresholdP:0,
        label_partList: [], //所選的LabelPart 清單
        label_part: "", //所選的LabelPart
        toolList: [],
        ChartData: null,
        isShowNextStep: false,
        isShowXDICheck: false,
        isFirstTimeQuery: true,
        split_method: 'random',
    },
    mounted: function () {
        var self = this;
        store.commit('setShowLoading', false);  

        self.getSplitData();

        self.get_Project_Info();        
        self.thresholdP = parseFloat(self.threshold) * 100;       
    },
    computed: {
        getThreshold: function () {
            return this.thresholdP / 100;
        }
    },
    watch: {
        chamber: function (value) {
            var self = this;
            //console.log(value)
            //console.log(self.chamber)
            if (self.chamber != "" && self.isFirstTimeQuery) {
                self.isFirstTimeQuery = false;
                self.getPlotData()
            }
        }
    },
    computed: {
        trainingData: function () {
            return 100 - this.testingData
        },
        chamberList: {
            get: function () {
                console.log(this.toolId)
                var toolname = this.toolId;
                var item = this.toolList.find(function (item, index, array) {
                    return item.key === toolname;
                });

                if (item) {
                    this.chamber = item.chamber[0].key;

                    return item.chamber;

                } else {
                    return;
                }
            },
            set: function () {

            }
        }

    },
    methods: {

        //get Project Info
        get_Project_Info: function () {

            var apiUrl = "/project";
            //用來模擬API的資料，實際上線不會執行這段

            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "code": 200, "data": { "project_list": [{ "ai365_project_name": "JaneTest_Anomaly Detection", "application": "Robot", "chamber_merge": false, "data_source": "user_upload", "data_type": "SensorRich", "fab": "L7A", "func": "PHOTO", "itime": "2021-05-05 15:52:54", "model_id": 3637, "model_type": "anomaly_detection", "offline_model_status": 602, "project_id": 3638, "stage": "ARRAY", "status": "create", "tool_type": "TRACK", "user_deptid": "ADTEC2", "user_empno": "O1906003" }], "total_count": 1 }, "description": "Get Project list success", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }


            var self = this;
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    project_id: store.getters.getCurrentProjectId,
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        //self.fabs = response.data.data.fabs;
                        console.log(response.data.data.project_list[0]);

                        //offline_model_status
                        if (response.data.data.project_list[0].offline_model_status
                        ) {

                            var localProjectStatus = response.data.data.project_list[0].offline_model_status

                            console.log(localProjectStatus)
                            self.isShowNextStep = localProjectStatus == 602 ? true : localProjectStatus >= 700 ? true : false;
                            self.isShowXDICheck = localProjectStatus == 602 ? true : localProjectStatus >= 700 ? true : false;

                            if (self.isShowXDICheck) {
                                //取得XDI Label
                                self.getXDILabel();
                            }
                        }
                    }
                })
        },

        getSplitData: function () {
            var self = this;

            if (store.getters.getCurrentProjectId == "") {
                return;
            }

            var apiUrl = "/split_data";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "code": 200, "data": { "method": "random", "ratio": 0.2 }, "description": "Successful response", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        if (response.data.data.ratio) {
                            self.testingData = response.data.data.ratio * 100;
                            if (response.data.data.method != "")
                                self.split_method = response.data.data.method;
                        }
                    }
                })

        },

        vaildDataAndSave: function () {
            var self = this;
            this.$validator.validateAll().then(function (result) {
                if (result) {
                    self.save(function () { CreateProjectLayoutApp.redriectPage(true,null) });
                }
                else {
                    alertify.error('欄位資料填寫錯誤');
                }
            })
        },

        save: function (fn) {
            var self = this;

            var apiUrl = "/split_data";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPut(apiUrl).reply(200, { "code": 200, "data": {}, "description": "Successful response", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            axios({
                method: 'put',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    ratio: (self.testingData / 100),
                    method: self.split_method,
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        alertify.success("Save Success");
                        if (fn) {
                            setTimeout(fn, 1000);
                        }
                    }
                    else {
                        alertify.success("Save fail");
                    }
                })

        },

        //取得XDI Label
        getXDILabel: function () {

            var apiUrl = "/xdi/label";
            //用來模擬API的資料，實際上線不會執行這段

            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "code": 200, "data": [{ "label_part": "NG_Motor", "threshold": 0.05 }, { "label_part": "NG_Reducer", "threshold": 0.05 }, { "label_part": "OK", "threshold": 0.05 }], "description": "Successful response", "status": "OK" });


            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        //self.fabs = response.data.data.fabs;
                        console.log(response.data.data);
                        self.label_partList = response.data.data;

                        if (self.label_partList.length > 0) {
                            self.label_part = self.label_partList[0].label_part;
                            //mounted為頁面處理完成後馬上要做的事情，可以把原PageLoad要調用的方法寫在這裡        
                            self.getToolChamber();
                        }

                    }
                })


        },

        //取得Tool Chamber DropDown
        getToolChamber: function () {

            var apiUrl = "/xdi/tool_chamber";
            //用來模擬API的資料，實際上線不會執行這段

            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "code": 200, "data": { "tool": [{ "chamber": [{ "key": "KPC_AACVD310" }], "key": "AAIEXN00" }] }, "description": "Successful response", "status": "OK" });


            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            console.log("getToolChamber:label_part:" + self.label_part);
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    label_part: self.label_part
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        //self.fabs = response.data.data.fabs;
                        console.log(response.data.data);
                        self.toolList = response.data.data.tool;
                        if (self.toolList.length > 0) {
                            self.toolId = self.toolList[0].key;
                        }
                    }
                })
        },

        //Plot的數值
        getPlotData: function () {

            var apiUrl = "/xdi";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "code": 200, "data": { "ori": { "data_id": [25279547, 25279548, 25279549, 25279550, 25279551], "exclude": [false, false, false, false, false], "score": [0.103736, 1.598872, 0.858964, 0.437959, 0.690966], "start_time": ["2020-02-18 11:17:25", "2020-02-18 11:17:25", "2020-02-18 11:17:25", "2020-02-18 11:17:25", "2020-02-18 11:17:25"] }, "test": { "data_id": [25279549], "exclude": [false], "score": [0.858964], "start_time": ["2020-02-18 11:17:25"] }, "threshold": 0.05, "threshold_score": 1.795892, "train": { "data_id": [25279547, 25279548, 25279550, 25279551], "exclude": [false, false, false, false], "score": [0.103736, 1.598872, 0.437959, 0.690966], "start_time": ["2020-02-18 11:17:25", "2020-02-18 11:17:25", "2020-02-18 11:17:25", "2020-02-18 11:17:25"] } }, "description": "Successful response", "status": "OK" });


            if (store.getters.getEnv == 'prd') {
                mock.restore();

            }

            var self = this;
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    tool: self.toolId,
                    chamber: self.chamber,
                    label_part: self.label_part
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {

                        self.isShowNextStep = true;

                        //var training = response.data.data.training;
                        //var testing = response.data.data.testing;

                        var threshold_score = response.data.data.threshold_score;
                        var oriStartTime = response.data.data.ori.start_time;
                        var training = [];
                        var testing = [];
                        var ngData = [];
                        var thresholdData = [];


                        response.data.data.ori.start_time.forEach(function (item, index, array) {
                            //console.log(item, index, array); // 物件, 索引, 全部陣列
                            //item = item > threshold_score ? item : null;

                            var score = response.data.data.ori.score[index];

                            if (score > threshold_score) {
                                //console.log("item > threshold_score: " + item + " , " + threshold_score);
                                ngData.push(score);
                            } else {
                                ngData.push(null);
                            }

                            thresholdData.push(threshold_score);
                            training[index] = null;
                            var trainResult = response.data.data.train.start_time.find(function (trainItem, trainIndex, array) {
                                if (trainItem == item) {
                                    //training.push(response.data.data.training.score[index]);
                                    training[index] = response.data.data.train.score[trainIndex];
                                    return item;
                                }
                            });

                            testing[index] = null;
                            var testResult = response.data.data.test.start_time.find(function (testItem, testIndex, array) {
                                if (testItem == item) {
                                    testing[index] = response.data.data.test.score[testIndex];
                                    return item;
                                }
                            });


                        });

                        self.DrawChartPrepare({
                            value_y: response.data.data.ori.score,
                            value_x: response.data.data.ori.start_time,
                            trainData_y: training,
                            testData_y: testing,
                            ngData_y: ngData,
                            thresholdData: thresholdData,
                        }, response.data.data.threshold_score);
                    }
                })

        },

        backClick: function () {
            alertify.confirm("回上一步驟",
                function (e) {
                    if (e) {
                        //OK
                        //window.location.href = "/Project/FeatureEngineering";
                        CreateProjectLayoutApp.backStatus();
                    } else {
                        //Cancel                      
                    }
                });
        },
        saveClick: function () { },
        nextClick: function () {


            alertify.confirm("前往下一步驟",
                function (e) {
                    if (e) {
                        //OK
                        //window.location.href = "/Project/FeatureSelection";
                        CreateProjectLayoutApp.nextStatus();                        
                    } else {
                        //Cancel                      
                    }
                });


        },

        DrawChartPrepare: function (ChartDatas, threshold_score) {
            var self = this;
            var _series = [], _legend = ['XDI', 'NG', 'threshold'];
            var _threshold = [];

            //threshold_score
            for (var i = 0; i < ChartDatas.value_x.length; i++) {
                _threshold.push(threshold_score);
            }

            //XDI
            _series.push({
                name: 'XDI',
                data: ChartDatas.value_y,
                symbol: 'none',
                type: 'line',
                itemStyle: {
                    color: '#69FFF5'
                },

            });

            //NG 
            _series.push({ name: 'NG', data: ChartDatas.ngData_y, type: 'scatter', itemStyle: { color: '#F85256' } });

            //threshold
            _series.push({
                name: 'threshold',
                data: _threshold,
                type: 'line',
                symbol: 'none',
                smooth: true,
                itemStyle: {
                    color: '#FF9326',
                }
            });

            self.DrawECharts("EChart1", "XDI", _series, _legend, ChartDatas.value_x);
        },

        DrawECharts: function (_chartid, _titlename, _series, _legend, _xAxis) {
            var myChart = echarts.init(document.getElementById(_chartid), 'default');
            myChart.clear();

            /*  去除加载缓冲图 */
            myChart.showLoading({
                text: 'Loading...',
                textStyle: { fontSize: 30, color: '#444' },
                effectOption: { backgroundColor: 'rgba(0, 0, 0, 0)' }
            });

            var option = {
                color: ['#00B0F0', '#FF7800', '#FF7800'],
                backgroundColor: '#545655',//背景色
                tooltip: {
                    trigger: 'axis',
                    textStyle: {
                        fontSize: 11
                    }


                },
                legend: {
                    show: true,
                    //type: 'scroll',
                    orient: 'vertical',
                    //x: 'right',
                    //y: 'top',
                    borderWidth: 1,
                    padding: 2,
                    itemGap: 2,
                    right: '1%',
                    top: '10%',

                    color: '#02B9C4',
                    data: _legend,
                    selected: {


                    },
                    bottom: '50%',
                    textStyle: {
                        color: '#ffffff',
                        fontSize: '10'
                    },

                    //selected: 1
                },
                grid: {
                    x: '7%',
                    y: '7%',
                    width: '80%',
                    height: '60%',
                    show: false,
                    borderColor: 'red'
                },
                toolbox: {
                    show: true,
                    feature: {
                        mark: { show: true },
                        dataZoom: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#ec7063'
                                }
                            }
                        },
                        dataView: {
                            show: false, readOnly: false, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#e59866'
                                }
                            }
                        },
                        restore: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#8e44ad'
                                }
                            }
                        },
                        saveAsImage: {
                            show: true, type: 'png', excludeComponents: ['toolbox'], pixelRatio: 2, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#2ecc71',
                                    shadowColor: 'rgba(0, 0, 0, 0.5)',
                                    shadowBlur: 10
                                }
                            }
                        }
                    }
                },
                xAxis: [
                    {
                        type: 'category',
                        triggerEvent: true,
                        boundaryGap: true,
                        data: _xAxis,



                        axisTick: {
                            show: false,
                            alignWithLabel: true
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变x轴颜色
                        axisLine: {
                            show: true,
                            onZero: false,
                            position: 'end',
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        //  改变x轴字体颜色和大小
                        axisLabel: {
                            show: true,
                            rotate: 90,
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                    }
                ],

                yAxis: [
                    {
                        //  隐藏y轴
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        onZero: false,
                        onZeroAxisIndex: false,
                        // 去除y轴上的刻度线
                        axisTick: {
                            show: false
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变y轴字体颜色和大小
                        axisLabel: {
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                        type: 'value',
                        triggerEvent: true
                    }
                ],

                dataZoom: [{
                    type: 'inside',
                    start: 0,
                    end: 100
                }, {
                    start: 0,
                    end: 100,
                    handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                    handleSize: '80%',
                    handleStyle: {
                        color: '#fff',
                        shadowBlur: 3,
                        shadowColor: 'rgba(0, 0, 0, 0.6)',
                        shadowOffsetX: 2,
                        shadowOffsetY: 2
                    }
                }],
                series: _series
            };


            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option, true);
        }
    }
})