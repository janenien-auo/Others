﻿/*
˙循環顯示下方區塊資料
˙Icon旁顯示Tool Name
˙Chamber旁顯示Chamber Name
˙上排RadioBtn移到ToolName旁邊，代表資料上傳的格式
˙【Add Data】新增一行讓User輸入資料，欄位內容參考下方說明
˙【Label欄位】顯示OK和NG，先由前端設定列舉資料
˙【Machine Part】參考FlaskAPI文件(頁籤-UI項目列表與參數範圍)
˙【Select Data欄位】眼球Icon點了顯示已選檔案List
˙【Select】選擇欲上傳的檔案，限制檔案類型(csv)、暫不限制檔案數量
˙【Delete】API-Flask-需新增API
˙【Upload】實際上傳檔案，上傳檔案是呼叫API-Flask-/Data [Post]
˙【Back】:回到前一步，提示視窗(提醒文字由芳蓉提供)確認User是否要放棄編輯(可能有些檔案傳到一半)
˙【Save】:因為已再上方清單各自上傳檔案，所以此按鈕移除
˙【Next】:如果有尚未上傳完成要提示，所有Tool Chamber都要有上傳資料，沒有的話要提示，並轉導到03_Data Preview/Exclude
*/
var app = new Vue({
    el: '#app', //el為要綁定的div的id(已設定完成)  
    store: store,
    data: {      
        //該頁會使用道的變數請統一放在這裡
        data_type: "SensorRich",
        marchinepartlist: [],      
        datalist: [],
        //filecontents: [] // upload file 觸發 event 時, 先將內容取出放在此陣列中
        tool: "",// 給 filelist 用
        chamber: "",// 給 filelist 用
        filelist: [], // item file list // 給 filelist 用
        machine_part_setempty: true, // 預設是 OK, 所以要給 true (OK 沒有 machine_part_setempty)
        uploadPercentage: 0,
        modelType: store.getters.getCurrentModelType
    },
    mounted: function () {      
        var self = this;           
        self.Init();  
        store.commit('setShowLoading', false);            
    },
    methods: {
        //Function請寫在這裡
        Init: function () {
            self = this;

            self.getMachinePart();

            // 已存在 project_id, 要顯示已存在的值
            //if (LayoutApp.env != 'prd') {
            //    LayoutApp.currentProjectId = "2";
            //    LayoutApp.currentModelId = "5";
            //}
            if (store.getters.getCurrentProjectId != "" && store.getters.getCurrentModelId != "") {
                self.getData();
            }
            else {
                
            }

            //// 為了要取得 project 的 model_type (如果為 'anomaly_detection' 則要 disable NG label 選項)
            //LayoutApp.getProjectInfo(self.setNewLabel_NG);
        },

        getMachinePart: function () {
            var apiUrl = "/dropitem";

            //用來模擬API的資料，實際上線不會執行這段
            var axiosMachinePart = axios.create();
            let mock = new AxiosMockAdapter(axiosMachinePart);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: [{
                    key: "Motor",
                    value: "Motor"
                },
                {
                    key: "Reducer",
                    value: "Reducer"
                }]
            });

            //if (LayoutApp.env == 'prd') {
            //    mock.restore();
            //}

            var self = this;
            axiosMachinePart({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                //headers: {
                //    'Access-Control-Allow-Origin': '*'
                //},
                //proxy: {
                //    host: "10.97.4.1",
                //    post: 8080
                //},
                params: {
                    "key": "MarchiePart"
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.marchinepartlist = response.data.data;
                    }
                    else
                        alertify.error("get data fail. error message = " + response.data.data.message);
                })
                .catch(function (err) {
                    //TODO:Error Handle
                    console.log(err)
                    alertify.error(err);
                })

        },

        getData: function () {
            var apiUrl = "/data/collection";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "code": 200, "data": { "data_type": "SensorRich", "tool": [{ "chamber": [{ "item": [{ "data_collection_info_id": 4435, "label": "OK", "machine_part": "" }], "key": "COATER" }], "key": "AAIEX100" }] }, "description": "Successful response", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                //headers: {
                //    "content-type": "application/json",
                //    "Access-Control-Allow-Origin": "*",
                //    //"Access-Control-Allow-Headers": "X-Requested-With,Content-Type",
                //    //"Access-Control-Allow-Methods": "PUT,POST,GET,DELETE,OPTIONS"
                //},
                //proxy: {
                //    host: "10.97.4.1",
                //    post: 8080
                //},
                params: {
                    "project_id": store.getters.getCurrentProjectId,
                    "model_id": store.getters.getCurrentModelId
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.data_type = response.data.data.data_type;
                        self.datalist = response.data.data.tool;

                        for (var i = 0; i < self.datalist.length; i++) {
                            for (var j = 0; j < self.datalist[i].chamber.length; j++) {
                                if (!self.datalist[i].chamber[j].uploadPercentage) {
                                    self.datalist[i].chamber[j]["uploadPercentage"] = 0;
                                }   

                                if (!self.datalist[i].chamber[j].marchinepart) {
                                    self.datalist[i].chamber[j]["marchinepart"] = [];
                                } 
                            }
                        }

                        //console.log(self.datalist);
                    }
                    else
                        alertify.error("get data fail. error message = " + response.data.data.message);

                    // 確保物件已被渲染
                    Vue.nextTick()
                        .then(function () {
                            // DOM updated
                            // 200319 (要確定取回資料渲染物件後才能呼叫) 為了要取得 project 的 model_type (如果為 'anomaly_detection' 則要 disable NG label 選項)
                            store.commit("setProjectInfo", self.setNewLabel_NG);                           
                        })
                })
                .catch(function (err) {
                    //TODO:Error Handle
                    console.log(err)
                    alertify.error(err);
                })

        },

        GetFileList: function (tool, chamber, data_collection_info_id) {
            store.commit('setShowLoading', true);   

            var apiUrl = "/data/collection_files";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "code": 200, "data": [{ "file_name": "NG_Vibration_19-04-29_1931.tdms.csv_4.csv" }, { "file_name": "NG_Vibration_19-04-29_1931.tdms.csv_3.csv" }, { "file_name": "NG_Vibration_19-04-29_1931.tdms.csv_2.csv" }, { "file_name": "NG_Vibration_19-04-29_1931.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1931.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1930.tdms.csv_4.csv" }, { "file_name": "NG_Vibration_19-04-29_1930.tdms.csv_3.csv" }, { "file_name": "NG_Vibration_19-04-29_1930.tdms.csv_2.csv" }, { "file_name": "NG_Vibration_19-04-29_1930.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1930.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1928.tdms.csv_2.csv" }, { "file_name": "NG_Vibration_19-04-29_1928.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1928.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1859.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1858.tdms.csv_3.csv" }, { "file_name": "NG_Vibration_19-04-29_1858.tdms.csv_2.csv" }, { "file_name": "NG_Vibration_19-04-29_1858.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1858.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1855.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1855.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1852.tdms.csv_2.csv" }, { "file_name": "NG_Vibration_19-04-29_1852.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1852.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1851.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1851.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1850.tdms.csv_4.csv" }, { "file_name": "NG_Vibration_19-04-29_1850.tdms.csv_3.csv" }, { "file_name": "NG_Vibration_19-04-29_1850.tdms.csv_2.csv" }, { "file_name": "NG_Vibration_19-04-29_1850.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1850.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1848.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1848.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1847.tdms.csv_4.csv" }, { "file_name": "NG_Vibration_19-04-29_1847.tdms.csv_3.csv" }, { "file_name": "NG_Vibration_19-04-29_1847.tdms.csv_2.csv" }, { "file_name": "NG_Vibration_19-04-29_1847.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1847.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1845.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1845.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1844.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1844.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1843.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1843.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1842.tdms.csv_4.csv" }, { "file_name": "NG_Vibration_19-04-29_1842.tdms.csv_3.csv" }, { "file_name": "NG_Vibration_19-04-29_1842.tdms.csv_2.csv" }, { "file_name": "NG_Vibration_19-04-29_1842.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1842.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1841.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1841.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1840.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1840.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1839.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1839.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1838.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1838.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1837.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1835.tdms.csv_2.csv" }, { "file_name": "NG_Vibration_19-04-29_1835.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1835.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1833.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1833.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1831.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1830.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1830.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1829.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1829.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1828.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1828.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1827.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1827.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1825.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1825.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1823.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1823.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1820.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1820.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1819.tdms.csv_0.csv" }, { "file_name": "NG_Vibration_19-04-29_1818.tdms.csv_1.csv" }, { "file_name": "NG_Vibration_19-04-29_1818.tdms.csv_0.csv" }], "description": "Successful response", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            self.tool = tool; // 給 filelist 用
            self.chamber = chamber;// 給 filelist 用            
            
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    "project_id": store.getters.getCurrentProjectId,
                    "model_id": store.getters.getCurrentModelId,
                    "data_collection_info_id": data_collection_info_id
                }
            })
                .then(function (response) {                    
                    if (response.data.status == "OK") {
                        self.filelist = response.data.data;
                        //console.log(self.datalist);

                      
                        $.fancybox.open({
                            src: '../Incloude/UploadFiles_FileList.html',
                            type: 'iframe',
                            iframe: {
                                preload: false,
                                css: { width: "1000px" }
                            }                            
                        });
                        store.commit('setShowLoading', false);                        

                    }
                    else
                        alertify.error("get data fail. error message = " + response.data.data.message);
                })               

        },

        openCheckData: function () {
            store.commit('setShowLoading', true);    
         
            $.fancybox.open({
                src: '../Project/CheckData',
                type: 'iframe',
                iframe: {
                    preload: false,
                    css: { width: "80%" }
                },
                opts: {
                    afterShow: function (instance, current) {
                        $('.fancybox-content')[0].style.height = "100%"
                        store.commit('setShowLoading', false);   
                    }
                }
            });


        },

        changeMarchinepart: function (idx_tool, idx_chamber) {
            var self = this;
            self.$set(self.datalist[idx_tool].chamber, idx_chamber, self.datalist[idx_tool].chamber[idx_chamber]);
        },


        // 如果該 project 的 model type = 'anomaly_detection' (在前一頁的 projectinfo 設定), 則 Label 不能選 NG
        setNewLabel_NG: function () {
            if (store.getters.getCurrentModelType == "anomaly_detection") {
                $("input[id^=rdoOK]").attr('disabled', false);
                $("input[id^=rdoNG]").attr('disabled', true);
            }
            else if (store.getters.getCurrentModelType == "health_assessment") {
                $("input[id^=rdoOK]").attr('disabled', false);
                $("input[id^=rdoNG]").attr('disabled', false);
            }
            else if (store.getters.getCrrentModelType == "prognostic") {
                $("input[id^=rdoOK]").attr('disabled', false);
                $("input[id^=rdoNG]").attr('disabled', false);
            }
        },
        changeLabel: function (tool, chamber) {
            var id_Label = 'radNewLabel_' + tool + '_' + chamber;
            var id_MachinePart = 'NewMachinePart_' + tool + '_' + chamber;
            //alert(id_MachinePart);

            var self = this;
            if ($("input[name=" + id_Label + "]:checked").val() == "OK") {
                $("#" + id_MachinePart).hide();
                self.machine_part_setempty = true;
            }
            else {
                $("#" + id_MachinePart).show();
                self.machine_part_setempty = false;
            }

            if ($("input[name=" + id_Label + "]:checked").val() == "NG") {
                if (store.getters.getCurrentModelType == "anomaly_detection") {
                    $("#" + id_MachinePart).hide();
                    self.machine_part_setempty = true;
                }
                else if (store.getters.getCurrentModelType == "health_assessment") {
                    $("#" + id_MachinePart).hide();
                    self.machine_part_setempty = true;
                }
                else if (store.getters.getCurrentModelType == "prognostic") {
                    $("#" + id_MachinePart).show();
                    self.machine_part_setempty = false;
                }
            }
        },

        changeFile: function (id) {
            //for (var idx = 0; idx < this.$refs["File_" + id][0].files.length; idx++) {
            //    (function (file) {
            //        var name = file.name;
            //        var reader = new FileReader();
            //        reader.onload = function (e) {
            //            // get file content  
            //            var text = e.target.result;
            //            //var li = document.createElement("li");
            //            //li.innerHTML = name + "____" + text;
            //            //ul.appendChild(li);
            //            self.filecontents.push(window.btoa(unescape(encodeURIComponent(text))));
            //        }
            //        reader.readAsText(file, "UTF-8");
            //    })(this.$refs["File_" + id][0].files[idx]);
            //}
            ////for (var i = 0; i < files.length; i++) { //for multiple files          
            ////    (function (file) {
            ////        var name = file.name;
            ////        var reader = new FileReader();
            ////        reader.onload = function (e) {
            ////            // get file content  
            ////            var text = e.target.result;
            ////            //var li = document.createElement("li");
            ////            //li.innerHTML = name + "____" + text;
            ////            //ul.appendChild(li);
            ////            self.filecontents.push(window.btoa(unescape(encodeURIComponent(arrayBuffer))));
            ////        }
            ////        reader.readAsText(file, "UTF-8");
            ////    })(files[i]);
            ////}
        },
        AddNew: function (tool, chamber) {
            var self = this;
            
            self.data_type = $($('input[name=data_type]:checked')).val();
            if (self.data_type == undefined || self.data_type == "") {
                alertify.alert("missing data_type");
                return;
            }

            var id = tool + '_' + chamber;
            var arFiles = this.$refs["File_" + id][0].files;
            if (arFiles.length == 0) {
                alertify.alert("no file(s) selected.");
                return;
            }
            
            //console.log($("#NewMachinePart_" + id).val());
            console.log($("input[name=radNewLabel_" + id + "]:checked").val());
            var label_id = 'radNewLabel_' + id;
            //var machine_part_id = '#NewMachinePart_' + id;
            var trProgressBar = '#tr_' + id;
            $(trProgressBar).show();
            //console.log(this.$refs["File_" + id][0].files);

            
            //var bSucess = true;
            //// 因為 this.$refs["File_" + id][0].files 是 object 不是 array, 所以用 for
            ////$.each(this.$refs["File_" + id][0].files, function (idx, val) {
            ////    bSucess = bSucess | self.uploadFile(val[idx]);
            ////});

            var currentMarchinepart = "";

            $.each(self.datalist, function (idxTool, objTool) {
                $.each(objTool.chamber, function (idxChamber, objChamber) {
                    if (objTool.key == tool && objChamber.key == chamber) {
                        currentMarchinepart = objChamber.marchinepart[0];
                    }
                });

            });




            //for (var idx = 0; idx < arFiles.length; idx++) {
            //bSucess = bSucess |
                self.uploadFile(
                    arFiles,
                    tool, 
                    chamber,
                    $($('input[name=' + label_id + ']:checked')).val(),
                    currentMarchinepart,// //$(machine_part_id).val(),                   
                    //++idx,
                    1,
                    arFiles.length);
            //}

            //// 在 changeFile 中取出到 self.filecontents
            //for (var idx = 0; idx < self.filecontents.length; idx++) {
            //    bSucess = bSucess | self.uploadFile(self.filecontents[idx], tool, chamber, $($('input[name=' + label_id+']:checked')).val(), $(machine_part_id).val(), ++idx, self.filecontents.length);
            //}
        },
        uploadFile: function (files, tool, chamber, label, machine_part, chunk_no, chunk_total) {
            var self = this;
            var apiUrl = "/data";

            var formData = new FormData();
            formData.append("model_id", store.getters.getCurrentModelId);
            formData.append("tool", tool);
            formData.append("chamber", chamber);
            formData.append("data_type", self.data_type);
            formData.append("label", label);
            // 選 OK, 則 machine_part 給空字串
            //if (self.machine_part_setempty)
            //    formData.append("machine_part", "");
            //else
            //    formData.append("machine_part", machine_part);

            if (store.getters.getCurrentModelType == "prognostic" && label == "NG") 
                formData.append("machine_part", machine_part);
            else
                formData.append("machine_part", "");

            formData.append("chunk_no", chunk_no);
            formData.append("chunk_total", chunk_total);
            formData.append("file_1", files[chunk_no - 1]);

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, { "code": 200, "data": { "data_collection_info_id": 4435 }, "description": "Successful response", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;

            var trProgressBar = '#tr_' + tool + '_' + chamber;
            axios({
                method: 'post',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                headers: {
                    'Content-Type': 'multipart/form-data'
                },
                data: formData,
                onUploadProgress: function (progressEvent) {
                    // 單一檔案的 progress : (progressEvent.loaded / progressEvent.total)
                    // 已處理檔案數 / 總檔案數檔案的 progress : (chunk_no / chunk_total) 

                    /*Mark by Jane:Fix進度條混用的問題*/
                    //self.uploadPercentage = parseInt(
                    //    Math.round(((progressEvent.loaded / progressEvent.total) * (1 / chunk_total) + ((chunk_no - 1) / chunk_total)) * 100));
                    //console.log(self.uploadPercentage);
                    //if (self.uploadPercentage >= 100) {
                    //    var trProgressBar = '#tr_' + tool + '_' + chamber;
                    //    $(trProgressBar).hide();//.find('tr #tr_' + tool + '_' + chamber).hide();
                    //}


                    /*Add by Jane:進度條ByTool Chamber顯示 */
                    var tmpUploadPercentage = parseInt(
                        Math.round(((progressEvent.loaded / progressEvent.total) * (1 / chunk_total) + ((chunk_no - 1) / chunk_total)) * 100));

                    var toolIndex = self.datalist.findIndex(function (d) {
                        return d.key.toLowerCase() == tool.toLowerCase()
                    });

                    var chamberIndex = self.datalist[toolIndex].chamber.findIndex(function (d) {
                        return d.key.toLowerCase() == chamber.toLowerCase()
                    });           

                    self.datalist[toolIndex].chamber[chamberIndex].uploadPercentage = tmpUploadPercentage;

                    //動態雙向綁定
                    self.$set(self.datalist,toolIndex, self.datalist[toolIndex]);                   

                    console.log(tool + " " +chamber+" "+tmpUploadPercentage);
                    if (tmpUploadPercentage >= 100) {
                        
                        $(trProgressBar).hide();//.find('tr #tr_' + tool + '_' + chamber).hide();

                        //Bar隱藏後就歸零
                        self.datalist[toolIndex].chamber[chamberIndex].uploadPercentage = 0;
                    }


                }.bind(this)
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        //console.log(self.datalist.tool);
                        if (chunk_no < chunk_total)
                            self.uploadFile(files, tool, chamber, label, machine_part, chunk_no + 1, chunk_total)
                        if (chunk_no == chunk_total) {
                            self.getData();
                        }
                        else {
                            //
                        }
                    }
                    else {
                        alertify.error("get data fail. error message = " + response.data.data.message);
                        $(trProgressBar).hide();
                    }                       
                }).
                catch(function (err) {
                    $(trProgressBar).hide();
                })          

        },

        Delete: function (tool, chamber, data_collection_info_id, item) {
            var apiUrl = "/data";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onDelete(apiUrl).reply(200, { "code": 200, "data": {}, "description": "Successful response", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'delete',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    "project_id": store.getters.getCurrentProjectId,
                    "model_id": store.getters.getCurrentModelId,
                    "data_collection_info_id": data_collection_info_id
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        //console.log(self.datalist.tool);
                        v_c =
                            $.grep(
                                $.grep(self.datalist, function (otool) { return otool.key === tool; })[0].chamber,
                                function (ocham) { return ocham.key === chamber; })[0];
                        v_c.item = v_c.item.filter(function (elem) {
                            return elem != item;
                        });//resul
                    }
                    else
                        alertify.error("get data fail. error message = " + response.data.data.message);
                })               

            //$.each(self.datalist, function (i_t, v_t) {
            //    if (v_t.key == tool) {
            //        $.each(v_t.chamber, function (i_c, v_c) {
            //            if (v_c.key == chamber) {
            //                $.each(v_c.item, function (i_i, v_i) {
            //                    if (v_i.data_collection_info_id == data_collection_info_id) {
            //                        // 移除 server 上的資料 (同步呼叫)
            //                        self.delItem(data_collection_info_id);
            //                        // 更新 local variable
            //                        v_c.item.splice(i_i, 1);
            //                    }
            //                });
            //            }
            //        });
            //    }
            //});
            ////alert(data_collection_info_id);
        },
        xxxxxRemoveItem: function (ary, key, val, remove) {
            $.each(ary, function (idx, val) {
                if (ary[idx][key] == val) {
                    if (remove == true)
                        array.splice(key, 1);
                    else
                        return ary[idx]
                }
            })
        },
        xxxxdelItem: function (data_collection_info_id) {
            var apiUrl = "/data";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onDelete(apiUrl).reply(200, {
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'delete',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    "project_id": store.getters.getCurrentProjectId,
                    "model_id": store.getters.getCurrentModelId,
                    "data_collection_info_id": data_collection_info_id
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        //console.log(self.datalist.tool);
                    }
                    else
                        alert("get data fail. error message = " + response.data.data.message);
                })               

        },

        goPrev: function () {
            var self = this;
            alertify.confirm("Are you sure want to leave this page and go back to the previous step??",
                function (e) {
                    if (e) {
                        //OK
                        //window.location.href = "/Project/ProjectInfo";
                        CreateProjectLayoutApp.backStatus();

                    } else {
                        //Cancel                      
                    }
                });
        },
        goNext: function () {
            var self = this;
            alertify.confirm("Are you sure want to leave this page and go to the next step??",
                function (e) {
                    if (e) {
                        //OK
                        //window.location.href = "/Project/CheckData";
                        store.commit("setCurrentDataType", self.data_type);                       
                        CreateProjectLayoutApp.nextStatus();
                    } else {
                        //Cancel                      
                    }
                });
        }

    }
})

//function newFunction(tool) {
//    var self = this;
//    var oTool = $.grep(self.datalist, function(t) { return t.key === tool; });
//    return { oTool, self };
//}
