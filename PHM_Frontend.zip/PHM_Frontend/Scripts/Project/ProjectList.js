﻿

var app = new Vue({
    el: '#app',
    store: store,
    data: {   
        StartTime:'',
        applications: [],
        application: "",
        fabs: [],
        fab: "",
        stages: [],
        stage: "",
        functions: [],
        func: "",
        projectList: [],
        keyWord: "",
        selected: [],
        allSelected: false,
        Pagination: {
            current_page: 1,
            page_size:10,
            total:0
        }
     

    },
    mounted: function () {
        var self = this;       
        self.getProjectList();
        self.getApplications();
        self.getFabs(); 
        store.commit('setShowLoading', false);       
    },  
    methods: {

        
        //Get Applications
        getApplications: function () {            
            var self = this;
            self.applications = store.getters.getApplications;
        },

        //Get Fabs
        getFabs: function () {

            //var apiUrl = "/DropItem";
            var apiUrl = "/api/Basicinfor/GetFabs";

            //用來模擬API的資料，實際上線不會執行這段           
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "status": "OK", "data": [{ "fab": "C4A" }, { "fab": "C5D" }, { "fab": "C5E" }, { "fab": "C6C" }, { "fab": "L3C" }, { "fab": "L3D" }, { "fab": "L4A" }, { "fab": "L4B" }, { "fab": "L5A" }, { "fab": "L5B" }, { "fab": "L5C" }, { "fab": "L5D" }, { "fab": "L6A" }, { "fab": "L6B" }, { "fab": "L6K" }, { "fab": "L7A" }, { "fab": "L7B" }, { "fab": "L8A" }, { "fab": "L8B" }, { "fab": "M01" }, { "fab": "M02" }, { "fab": "M11" }], "message": null });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'get',               
                url: apiUrl,             
                params: {
                    //key:"Fab"
                    SITEID: "TC"
                }
                })
                .then(function (response) {
                    if (response.data.status == "OK")
                        self.fabs = response.data.data;
                })   
        },

        //選擇Fab後所觸發的事件
        selectFab: function () {
            var self = this;
            self.getStages();
        },

        //Get Modules
        getStages: function () {

            //var apiUrl = "/DropItem";
            var apiUrl = "/api/Basicinfor/GetModules";

            var dataType = "APC,CONTINUOUS";

            //用來模擬API的資料，實際上線不會執行這段          
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "status": "OK", "data": [{ "stage": "ARRAY" }, { "stage": "CELL" }, { "stage": "CF" }], "message": null });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
                 axios({
                     method: 'get',                    
                     url: apiUrl,             
                     params: {
                         //key: "process_type"
                         FabSite: self.fab,
                         DataType: dataType
                     }
                 })
                .then(function (response) {
                    if (response.data.status == "OK")
                        self.stages = response.data.data;
                })  
        },

        //選擇Stage後所觸發的事件
        selectStage: function () {
            var self = this;
            self.getFunctions();
        },

        //Get Functions
        getFunctions: function () {

            //var apiUrl = "/DropItem";
            var apiUrl = "/api/Basicinfor/GetFunctions";
            var dataType = "APC,CONTINUOUS";

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "status": "OK", "data": [{ "func": "INT" }, { "func": "TF" }, { "func": "PHOTO" }, { "func": "FA" }, { "func": "ETCH" }, { "func": "MVA" }, { "func": "HR" }, { "func": "FAC" }], "message": null });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'get',               
                url: apiUrl,               
                params: {                  
                    FabSite: self.fab,
                    ProcessType: self.stage,
                    DataType: dataType
                }
                })
                .then(function (response) {
                    if (response.data.status == "OK")
                        self.functions = response.data.data;
                })              
        },

        //選擇Function後所觸發的事件
        selectFunction: function () {
            var self = this;

            //Mark by Jane:改成統一由Search按鈕搜尋
            //self.getProjectList();
        },

        //Get ProjectList
        getProjectList: function (page) {

            var apiUrl = "/project";  

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "code": 200, "data": { "project_list": [{ "ai365_project_name": "JaneTest", "application": "Robot", "chamber_merge": false, "data_source": "user_upload", "data_type": "SensorRich", "fab": "L6A", "func": "PHOTO", "itime": "2021-05-07 13:05:36", "model_id": 3771, "model_type": "health_assessment", "offline_model_status": 301, "project_id": 3772, "stage": "ARRAY", "status": "create", "tool_type": "TRACK", "user_deptid": "ADTEC2", "user_empno": "O1906003" }, { "ai365_project_name": "JaneTest_Anomaly Detection", "application": "Robot", "chamber_merge": false, "data_source": "user_upload", "data_type": "SensorRich", "fab": "L6A", "func": "PHOTO", "itime": "2021-05-07 10:29:10", "model_id": 3754, "model_type": "anomaly_detection", "offline_model_status": 802, "project_id": 3755, "stage": "ARRAY", "status": "create", "tool_type": "TRACK", "user_deptid": "ADTEC2", "user_empno": "O1906003" }, { "ai365_project_name": "JaneTest", "application": "Robot", "chamber_merge": false, "data_source": "user_upload", "data_type": "SensorRich", "fab": "L6A", "func": "PHOTO", "itime": "2021-05-06 15:32:19", "model_id": 3735, "model_type": "anomaly_detection", "offline_model_status": 802, "project_id": 3736, "stage": "ARRAY", "status": "create", "tool_type": "TRACK", "user_deptid": "ADTEC2", "user_empno": "O1906003" }, { "ai365_project_name": "JaneTest_Anomaly Detection", "application": "Robot", "chamber_merge": false, "data_source": "user_upload", "data_type": "SensorRich", "fab": "L7A", "func": "PHOTO", "itime": "2021-05-05 15:52:54", "model_id": 3637, "model_type": "anomaly_detection", "offline_model_status": 802, "project_id": 3638, "stage": "ARRAY", "status": "create", "tool_type": "TRACK", "user_deptid": "ADTEC2", "user_empno": "O1906003" }, { "ai365_project_name": "JaneTest_raw_data_Anomaly Detection_Pumb_ChamberMerge_True", "application": "Pump", "chamber_merge": true, "data_source": "raw_data", "data_type": "RawData", "fab": "L6A", "func": "PHOTO", "itime": "2021-05-04 10:02:35", "model_id": 3595, "model_type": "anomaly_detection", "offline_model_status": 2200, "project_id": 3596, "stage": "ARRAY", "status": "create", "tool_type": "TRACK", "user_deptid": "ADTEC2", "user_empno": "O1906003" }, { "ai365_project_name": "JaneTest_Health Assessment", "application": "Robot", "chamber_merge": false, "data_source": "user_upload", "data_type": "SensorRich", "fab": "L6A", "func": "PHOTO", "itime": "2021-05-04 09:11:29", "model_id": 3593, "model_type": "health_assessment", "offline_model_status": 200, "project_id": 3594, "stage": "ARRAY", "status": "create", "tool_type": "TRACK", "user_deptid": "ADTEC2", "user_empno": "O1906003" }, { "ai365_project_name": "JaneTest_20210503_AnomalyDetection", "application": "MOTOR", "chamber_merge": false, "data_source": "user_upload", "data_type": "", "fab": "L8A", "func": "PHOTO", "itime": "2021-05-03 09:35:03", "model_id": 3522, "model_type": "anomaly_detection", "offline_model_status": 100, "project_id": 3523, "stage": "ARRAY", "status": "create", "tool_type": "ROBOT_DB", "user_deptid": "ADTEC2", "user_empno": "O1906003" }, { "ai365_project_name": "JaneTest-Prod-Prognostic", "application": "Pump", "chamber_merge": false, "data_source": "user_upload", "data_type": "SensorRich", "fab": "L8A", "func": "PHOTO", "itime": "2021-04-16 13:13:20", "model_id": 3232, "model_type": "prognostic", "offline_model_status": 700, "project_id": 3233, "stage": "ARRAY", "status": "create", "tool_type": "TRACK", "user_deptid": "AITED2", "user_empno": "1524464" }, { "ai365_project_name": "JaneTest_Prod_HA_20210416_1055", "application": "Robot", "chamber_merge": false, "data_source": "user_upload", "data_type": "", "fab": "L8A", "func": "PHOTO", "itime": "2021-04-16 10:54:55", "model_id": 3228, "model_type": "health_assessment", "offline_model_status": 100, "project_id": 3229, "stage": "ARRAY", "status": "create", "tool_type": "SCANNER", "user_deptid": "AITED2", "user_empno": "1524464" }, { "ai365_project_name": "JaneTest_Prod_20210416", "application": "Robot", "chamber_merge": false, "data_source": "user_upload", "data_type": "", "fab": "L8A", "func": "PHOTO", "itime": "2021-04-16 10:53:04", "model_id": 3227, "model_type": "anomaly_detection", "offline_model_status": 100, "project_id": 3228, "stage": "ARRAY", "status": "create", "tool_type": "TRACK", "user_deptid": "AITED2", "user_empno": "1524464" }], "total_count": 44 }, "description": "Get Project list success", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }                    
            var self = this;   

            //避免User在其他頁點選查詢造成沒有資料，統一導向第一頁
            if (page)
                self.Pagination.current_page = page;


            
           
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,                
                params: {       
                    page_no: self.Pagination.current_page,
                    page_size: self.Pagination.page_size,
                    keyword: self.keyWord,
                    func: self.func,
                    fab: self.fab,
                    application: self.application,
                    stage: self.stage                                
                }
            })          
                .then(function (response) {

                  
               if (response.data.status == "OK") {
                        self.Pagination.total = response.data.data.total_count;
                        self.projectList = response.data.data.project_list; 

                   if (self.projectList.length == 0) {
                       alertify.error("No data");
                   }


                        for (var i = 0; i < self.projectList.length; i++) {
                            var offline_model_status = "";
                            var statusInfos = [];

                            //add by amanda 2020-10-01 09:23
                            if (self.projectList[i].data_source == "continuous" && self.projectList[i].offline_model_status == 100)
                                self.projectList[i].offline_model_status = 1000;



                            if (self.projectList[i].data_source == "continuous" && self.projectList[i].offline_model_status >= 1000)
                                statusInfos = store.getters.getStatusInfosConti;
                            else if (self.projectList[i].data_source == "raw_data" && self.projectList[i].offline_model_status >= 2000) {
                                statusInfos = store.getters.getStatusInfosRawData;
                            }
                            else
                                statusInfos = store.getters.getStatusInfos;


                            for (var j = 0; j < statusInfos.length; j++) {
                                if (statusInfos[j].offline_model_status == self.projectList[i].offline_model_status) {
                                    offline_model_status = statusInfos[j].statusName;
                                    break;
                                }
                            }

                            if (self.projectList[i].project_status) {
                                self.projectList[i].project_status = offline_model_status;
                            }
                            else {
                                self.projectList[i]["project_status"] = offline_model_status;
                            }
                        }

                    }
                })               
        },

        //Edit Project
        viewProject: function (row) {
            //window.location.href = "/Project/RedriectUrl" + "?projectid=" + row.project_id + "&modelid=" + row.model_id;    

            if (row.data_source == "continuous" && row.offline_model_status > 1000)
                window.location.href = "/ProjectConti/RedriectContiUrl" + "?projectid=" + row.project_id + "&modelid=" + row.model_id;
            else if (row.data_source == "raw_data" && row.offline_model_status >= 2000)
                window.location.href = "/ProjectRawData/RedriectRawDataUrl" + "?projectid=" + row.project_id + "&modelid=" + row.model_id;
            else
                window.location.href = "/Project/RedriectUrl" + "?projectid=" + row.project_id + "&modelid=" + row.model_id;    
        } ,
        viewProjectConti: function (row) {
            
            if (row.data_source == "continuous") {
                store.getters.getOfflineModelStatus = 1500;
                window.location.href = "/ProjectConti/RedriectContiUrl" + "?projectid=" + row.project_id + "&modelid=" + row.model_id;
            }
            else if (row.data_source == "raw_data") {
                store.commit('setOfflineModelStatus', 2000);             
                window.location.href = "/ProjectRawData/RedriectRawDataUrl" + "?projectid=" + row.project_id + "&modelid=" + row.model_id;
            }
        },
        //Delete Project
        deleteProject: function (row) {           

            var apiUrl = "/project";
            var self = this;

            if (row.project_id)
                self.selected = [row.project_id];

            if (row.user_deptid != store.getters.getUserInfo.UserDeptID) {
                alertify.alert("Sorry,you do not have permission to delete.");
                return;
            }

            var msg = "Are you want to delete project id " + row.project_id +"?"

            alertify.confirm(msg,
                function (e) {
                    if (e) {
                        //OK   

                        store.commit('setShowLoading', true);     

                        //用來模擬API的資料，實際上線不會執行這段                        
                        let mock = new AxiosMockAdapter(axios);
                        mock.onDelete(apiUrl).reply(200, { "code": 200, "data": {}, "description": "Delete Project success", "status": "OK" });

                        if (store.getters.getEnv == 'prd') {
                            mock.restore();
                        }

                     
                        axios({
                            method: 'delete',
                            baseURL: store.getters.getOfflineApiUrl,
                            url: apiUrl,
                            data: {
                                project_id: self.selected                              
                            }
                        })
                        .then(function (response) {     
                            store.commit('setShowLoading', false);     

                            if (response.data.status == "OK") {
                                alertify.success("Delete Success");
                                self.getProjectList();
                            }
                            else {
                                alertify.alert("Delete Fail");
                            }
                        }) 

                     

                    } else {
                        //Cancel    
                        return;
                    }
                });   

           
        },

        //選擇全部的按鈕
        selectAll: function () {
            var self = this;

            self.selected = [];

            if (!self.allSelected) {
                for (p in self.projectList) {
                    self.selected.push(self.projectList[p].project_id);
                }
            }

           
        },

        //換頁
        handleChangePage: function (val) {
            var self = this;
            self.Pagination.current_page = val;
            self.getProjectList();          
        },

        //新增NewProject的按鈕
        createNew: function () {
            store.commit('clearCurrentProjectInfo', function () {
                window.location.href = "/Project/ProjectInfo";
            });                 
        }
    }


})