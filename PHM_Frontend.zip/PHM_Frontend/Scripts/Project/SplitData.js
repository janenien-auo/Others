﻿var app = new Vue({
    el: '#app', //el為要綁定的div的id(已設定完成)  
    data: {           
        testingData: 20
    },
    computed: {
        trainingData: function () {
            return 100 - this.testingData
        }
    },
    mounted: function () {
        var self = this;
        self.getSplitData();
        LayoutApp.showLoading = false;
    },
    methods: {
        getSplitData: function () {
            var self = this;
            
            if (LayoutApp.currentProjectId == "") {
                return;
            }        

            var apiUrl = "/split_data";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: {
                    project_id: 230,
                    ratio: 0.3
                }
            });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }
          
            axios({
                method: 'get',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                params: {
                    project_id: LayoutApp.currentProjectId,
                    model_id: LayoutApp.currentModelId
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {   
                        if (response.data.data.ratio) {
                            self.testingData = response.data.data.ratio * 100;
                        } 
                    }                    
                })
              
        },    

        backClick: function () {
            var self = this;
            alertify.confirm("捨棄編輯中的內容，並回上一步驟?",
                function (e) {
                    if (e) {
                        //OK
                        window.location.href = "/Project/DataLabeling";
                    } else {
                        //Cancel                      
                    }
                });
        },

        saveClick: function () {
            var self = this;

            alertify.confirm("儲存編輯中的內容?",
                function (e) {
                    if (e) {
                        //OK
                        self.vaildDataAndSave();
                    } else {
                        //Cancel                      
                    }
                });
        },

        nextClick: function () {
            var self = this;

            alertify.confirm("儲存編輯內容，並前往下一步驟?",
                function (e) {
                    if (e) {
                        //OK
                        self.vaildDataAndSave(function () { LayoutApp.nextStatus(); });
                    } else {
                        //Cancel                      
                    }
                });

        },

        vaildDataAndSave: function (fn) {
            var self = this;
            this.$validator.validateAll().then(function (result) {
                if (result) {
                    self.save(fn);
                }
                else {
                    alertify.error('欄位資料填寫錯誤');
                }
            })
        },

        save: function (fn) {
            var self = this;         

            var apiUrl = "/split_data";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPut(apiUrl).reply(200, {
                status: "OK"
            });

            if (LayoutApp.env == 'prd') {
                mock.restore();
            }
          
            axios({
                method: 'put',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                data: {
                    project_id: LayoutApp.currentProjectId,
                    model_id: LayoutApp.currentModelId,
                    ratio: (self.testingData/100)
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        alertify.success("Save Success");
                        if (fn) {
                            setTimeout(fn, 500);                           
                        }
                    }
                    else {
                        alertify.success("Save fail");
                    }
                })
               
        }
    }
})