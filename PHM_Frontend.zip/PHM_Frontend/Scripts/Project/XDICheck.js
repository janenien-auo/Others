﻿var app = new Vue({
    el: '#app', //el為要綁定的div的id(已設定完成)  
    data: {
        step: 10,//注意:這個變數不能移除要給畫面控制Step用
        //該頁會使用道的變數請統一放在這裡
        toolId: "",
        chamber: "",
        threshold: "0.05", //defualt 0.05 & 第一版不能更改
        label_partList: [], //所選的LabelPart 清單
        label_part: "", //所選的LabelPart
        toolList: [],
        ChartData: null,        
        isShowNextStep: false
    },
    mounted: function () {
        var self = this;
        LayoutApp.step = self.step - 1;        

        self.isShowNextStep = LayoutApp.currentProjectStatus == 802 ? true : LayoutApp.currentProjectStatus >= 900 ? true : false;

        //取得XDI Label
        self.getXDILabel();
        LayoutApp.showLoading = false;

    },
    computed: {        
        
        chamberList: {
            get: function () {
                console.log(this.toolId)
                var toolname = this.toolId;
                var item = this.toolList.find(function (item, index, array) {
                    return item.key === toolname;
                });
                
                if (item) {                    
                    this.chamber = item.chamber[0].key;

                    return item.chamber;
                    
                } else {
                    return;
                }
            },
            set: function () {
                    
            }                                                
        }
    },
    methods: {

        //取得XDI Label
        getXDILabel: function () {
       
            var apiUrl = "/xdi/label";
            //用來模擬API的資料，實際上線不會執行這段
           
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: [
                    {
                        label_part: "ok",
                        threshold: 0.05
                    },
                    {
                        label_part: "ng_motor",
                        threshold: 0.05
                    },
                    {
                        label_part: "ng_pump",
                        threshold: 0.05
                    }
                ]
            });

    
            if(LayoutApp.env == 'prd') {
                mock.restore();
            }

            var self = this;
            
            axios({
                method: 'get',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                params: {
                    project_id : LayoutApp.currentProjectId,
                    model_id: LayoutApp.currentModelId
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        //self.fabs = response.data.data.fabs;
                        console.log(response.data.data);
                        self.label_partList = response.data.data;
                        
                        if (self.label_partList.length > 0) {
                            self.label_part = self.label_partList[0].label_part;                            
                            //mounted為頁面處理完成後馬上要做的事情，可以把原PageLoad要調用的方法寫在這裡        
                            self.getToolChamber();
                        }

                    }
                })              


        },

        //取得Tool Chamber DropDown
        getToolChamber: function () {
            
            var apiUrl = "/xdi/tool_chamber";
            //用來模擬API的資料，實際上線不會執行這段
                        
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                status: "OK",
                data: {
                    tool: [
                        {
                            key: "RIE200",
                            Value: 1,
                            chamber: [
                                 {
                                    key: "AXI_X",
                                    value: 1
                                }, {
                                    key: "AXI_Z",
                                    value: 2
                                }
                            ]
                        },
                        {
                            key: "RIE300",
                            Value: 2,
                            chamber: [                                
                                 {
                                     key: "AXI_2",
                                    value: 1
                                }, {
                                     key: "AXI_3",
                                    value: 2
                                }
                            ]
                        }
                    ]
                }
            });

            
            if (LayoutApp.env == 'prd') {
                mock.restore();                
            }
            
            var self = this;
            console.log("getToolChamber:label_part:" + self.label_part);
            axios({
                method: 'get',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                params: {
                    project_id: LayoutApp.currentProjectId,
                    model_id: LayoutApp.currentModelId,
                    label_part: self.label_part                    
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        //self.fabs = response.data.data.fabs;
                        console.log(response.data.data);
                        self.toolList = response.data.data.tool;                        
                        if (self.toolList.length > 0) {
                            self.toolId = self.toolList[0].key;
                        }                        
                    }
                })              
        },

        //Plot的數值
        getPlotData: function () {

            var apiUrl = "/xdi";            

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                
                status: "OK",
                data: {
                    threshold: 0.05,
                    threshold_score: 8,
                    ori: {
                        data_id: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                        score: [1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 7.7, 8.8, 9.9, 11],
                        exclude_data_id: [true, false, false, true, false, true, false, false, true, false],
                        start_time: ['2020-01-06 16:26:36', '2020-01-06 16:36:36', '2020-01-06 16:46:36', '2020-01-06 16:56:36',
                            '2020-01-06 17:06:36', '2020-01-06 17:16:36', '2020-01-06 17:26:36', '2020-01-06 17:36:36',
                            '2020-01-06 17:46:36', '2020-01-06 17:56:36']
                    },
                    training: {
                        data_id: [1, 3, 4, 5, 6, 8, 10],
                        score: [1.1, 3.3, 4.4, 5.5, 6.6, 8.8, 11],
                        start_time: ['2020-01-06 16:26:36', '2020-01-06 16:46:36', '2020-01-06 16:56:36', '2020-01-06 17:06:36',
                            '2020-01-06 17:16:36', '2020-01-06 17:36:36', '2020-01-06 17:56:36']
                    },
                    testing: {
                        data_id: [2, 7, 9],
                        score: [2.2, 7.7, 9.9],
                        start_time:['2020-01-06 16:36:36', '2020-01-06 17:26:36',  '2020-01-06 17:46:36']
                    }
                }                
            });

            
            if (LayoutApp.env == 'prd') {
                mock.restore();
                
            }            
            
            var self = this;
            
            axios({
                method: 'get',
                baseURL: LayoutApp.apiUrlDomain,
                url: apiUrl,
                params: {
                    project_id: LayoutApp.currentProjectId,
                    model_id: LayoutApp.currentModelId,                    
                    tool: self.toolId,
                    chamber: self.chamber,
                    label_part: self.label_part                    
                }
            })
            .then(function (response) {
                if (response.data.status == "OK") {
                    
                    self.isShowNextStep = true;

                    //var training = response.data.data.training;
                    //var testing = response.data.data.testing;
                    
                    var threshold_score = response.data.data.threshold_score;                    
                    var oriStartTime = response.data.data.ori.start_time;
                    var training = [];
                    var testing = [];                    
                    var ngData = [];
                    var thresholdData = [];

                    
                    response.data.data.ori.start_time.forEach(function (item, index, array) {
                        //console.log(item, index, array); // 物件, 索引, 全部陣列
                        //item = item > threshold_score ? item : null;

                        var score = response.data.data.ori.score[index];

                        if (score > threshold_score) {
                            //console.log("item > threshold_score: " + item + " , " + threshold_score);
                            ngData.push(score);
                        } else {
                            ngData.push(null);
                        }

                        thresholdData.push(threshold_score);
                        training[index] = null;
                        var trainResult = response.data.data.train.start_time.find(function (trainItem, trainIndex, array) {
                            if (trainItem == item) {                                                                
                                //training.push(response.data.data.training.score[index]);
                                training[index] = response.data.data.train.score[trainIndex];
                                return item;   
                            }                  
                        });    

                        testing[index] = null;
                        var testResult = response.data.data.test.start_time.find(function (testItem, testIndex, array) {
                            if (testItem == item) {                                
                                testing[index] = response.data.data.test.score[testIndex];
                                return item;   
                            }
                        });    
                        
                        
                    });

                    self.DrawChartPrepare({
                        value_y: response.data.data.ori.score,
                        value_x: response.data.data.ori.start_time,
                        trainData_y: training,
                        testData_y: testing,
                        ngData_y: ngData,
                        thresholdData:thresholdData,
                    }, response.data.data.threshold_score);
                }
            })
          
        },

        backClick: function () {            
            alertify.confirm("回上一步驟",
                function (e) {
                    if (e) {
                        //OK
                        window.location.href = "/Project/SplitData";
                    } else {
                        //Cancel                      
                    }
                });
        },
        saveClick: function () {},
        nextClick: function () {            
  

            alertify.confirm("前往下一步驟",
                function (e) {
                    if (e) {
                        //OK
                        //window.location.href = "/Project/FeatureSelection";
                        LayoutApp.nextStatus();
                    } else {
                        //Cancel                      
                    }
                });


        },
        
        DrawChartPrepare: function (ChartDatas, threshold_score) {
            var self = this;            
            var _series = [], _legend = ['XDI', 'NG', 'threshold'];
            var _threshold = [];

            //threshold_score
            for (var i = 0; i < ChartDatas.value_x.length; i++) {
                _threshold.push(threshold_score);
            }

            //XDI
            _series.push({
                name: 'XDI',
                data: ChartDatas.value_y,
                symbol: 'none',
                type: 'line',
                itemStyle: {
                    color: '#69FFF5'
                },

            });
          
            //NG 
            _series.push({ name: 'NG', data: ChartDatas.ngData_y, type: 'scatter', itemStyle: { color: '#F85256' } });

            //threshold
            _series.push({
                name: 'threshold',
                data: _threshold,
                type: 'line',
                symbol: 'none',
                smooth: true,
                itemStyle: {
                    color: '#FF9326',
                }
            });

            self.DrawECharts("EChart1", "XDI", _series, _legend , ChartDatas.value_x);                       
        },

        DrawECharts: function (_chartid, _titlename, _series, _legend, _xAxis) {
            var myChart = echarts.init(document.getElementById(_chartid), 'default');
            myChart.clear();

            /*  去除加载缓冲图 */
            myChart.showLoading({
                text: 'Loading...',
                textStyle: { fontSize: 30, color: '#444' },
                effectOption: { backgroundColor: 'rgba(0, 0, 0, 0)' }
            });

            var option = {
                color: ['#00B0F0', '#FF7800', '#FF7800'],
                backgroundColor: '#545655',//背景色
                tooltip: {
                    trigger: 'axis',
                    textStyle: {
                        fontSize: 11
                    }


                },
                legend: {
                    show: true,
                    //type: 'scroll',
                    orient: 'vertical',
                    //x: 'right',
                    //y: 'top',
                    borderWidth: 1,
                    padding: 2,
                    itemGap: 2,
                    right: '1%',
                    top: '10%',

                    color: '#02B9C4',
                    data: _legend,
                    selected: {


                    },
                    bottom: '50%',
                    textStyle: {
                        color: '#ffffff',
                        fontSize: '10'
                    },

                    //selected: 1
                },
                grid: {
                    x: '7%',
                    y: '7%',
                    width: '80%',
                    height: '60%',
                    show: false,
                    borderColor: 'red'
                },
                toolbox: {
                    show: true,
                    feature: {
                        mark: { show: true },
                        dataZoom: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#ec7063'
                                }
                            }
                        },
                        dataView: {
                            show: false, readOnly: false, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#e59866'
                                }
                            }
                        },
                        restore: {
                            show: true, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#8e44ad'
                                }
                            }
                        },
                        saveAsImage: {
                            show: true, type: 'png', excludeComponents: ['toolbox'], pixelRatio: 2, iconStyle: {
                                normal: {
                                    //color: 'white',//设置颜色
                                    borderColor: '#2ecc71',
                                    shadowColor: 'rgba(0, 0, 0, 0.5)',
                                    shadowBlur: 10
                                }
                            }
                        }
                    }
                },
                xAxis: [
                    {
                        type: 'category',
                        triggerEvent: true,
                        boundaryGap: true,
                        data: _xAxis,



                        axisTick: {
                            show: false,
                            alignWithLabel: true
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变x轴颜色
                        axisLine: {
                            show: true,
                            onZero: false,
                            position: 'end',
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        //  改变x轴字体颜色和大小
                        axisLabel: {
                            show: true,
                            rotate: 90,
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                    }
                ],

                yAxis: [
                    {
                        //  隐藏y轴
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: '#DFFFBF',
                                width: 2,//这里是为了突出显示加上的，可以去掉
                            }
                        },
                        onZero: false,
                        onZeroAxisIndex: false,
                        // 去除y轴上的刻度线
                        axisTick: {
                            show: false
                        },
                        // 控制网格线是否显示
                        splitLine: {
                            show: false,
                            //  改变轴线颜色
                            lineStyle: {
                                // 使用深浅的间隔色
                                color: ['red']
                            }
                        },
                        //  改变y轴字体颜色和大小
                        axisLabel: {
                            textStyle: {
                                color: '#ffffff',
                                fontSize: '12'
                            },
                        },
                        type: 'value',
                        triggerEvent: true
                    }
                ],

                dataZoom: [{
                    type: 'inside',
                    start: 0,
                    end: 100
                }, {
                    start: 0,
                    end: 100,
                    handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                    handleSize: '80%',
                    handleStyle: {
                        color: '#fff',
                        shadowBlur: 3,
                        shadowColor: 'rgba(0, 0, 0, 0.6)',
                        shadowOffsetX: 2,
                        shadowOffsetY: 2
                    }
                }],
                series: _series
            };


            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option, true);
        }
    }
})