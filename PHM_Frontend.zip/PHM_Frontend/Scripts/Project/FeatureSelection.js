﻿var app = new Vue({
    el: '#app', 
    store: store,
    data: {
        //該頁會使用道的變數請統一放在這裡
        method: "",
        method_para: 20,
        methodList: [],
        ChartData: null,
        model_type: "",
        modeling_method: "",
        modeling_method_list: store.getters.getModelingAlgorithm,
        n_neighbors: 0,     
        canGoNextStep: false,
        algorithm_type: "default",
        algorithms: [],
        chooseAlgorithm: null,
        algorithm_versions: [],
        chooseVersion: null,
        isShowCustomAlgorithm: store.getters.getIsShowCustomAlgorithm
    },
    mounted: function () {
        store.commit('setShowLoading', false);  
        var self = this;    
        self.get_Project_Info();
        //self.get_method_list();

        //自訂演算法-取演算法和版本
        self.getProjectAlgorithm();
        self.getAlgorithmList();  
      
    },
    computed: {
        n_neighborsTitle: function () {

            if (this.modeling_method =="PCA_T2") {
                return "n_neighbors: " + this.modeling_method+" (%)";
            } else {
                return "n_neighbors: " + this.modeling_method + "";
            }
            
        }
    },
    methods: {

        //get Project Info
        get_Project_Info: function () {

            var apiUrl = "/project";
            //用來模擬API的資料，實際上線不會執行這段

            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "code": 200,
                "data": {
                    "project_list": [
                        {
                            "project_id": 123,
                            "model_id": 123,
                            "ai365_project_name": "sam_test_53_conti",
                            "data_source": "continuous",
                            "data_type": "Continuous",
                            "application": "Robot",
                            "model_type": "anomaly_detection",
                            "fab": "L6A",
                            "stage": "ARRAY",
                            "func": "PHOTO",
                            "tool_type": "TRACK",
                            "chamber_merge": true,
                            "algorithm_type": "",
                            "status": "online",
                            "offline_model_status": 1301,
                            "user_empno": "O1909013",
                            "itime": "2020-10-21 14:27:52"
                        }
                    ],
                    "total_count": 1
                },
                "description": "Get Project list success",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            
            var self = this;
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    project_id: store.getters.getCurrentProjectId,
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        //self.fabs = response.data.data.fabs;
                        console.log(response.data.data.project_list[0]);                        
                        self.model_type = response.data.data.project_list[0].model_type;

                        self.get_method_list();
                        
                        //offline_model_status
                        if (response.data.data.project_list[0].offline_model_status &&
                            (response.data.data.project_list[0].offline_model_status == 702 || response.data.data.project_list[0].offline_model_status >= 800)
                        ) {
                            self.canGoNextStep = true;
                        }
                    }
                })              
        },

        //取得選單清單
        get_method_list: function () {

            //var apiUrl = "/feature_selection/get_method_list";
            var apiUrl = "/feature_selection";
            //用來模擬API的資料，實際上線不會執行這段

            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "code": 200,
                "data": {
                    "anomaly_detection_method": "",
                    "method": "Variance",
                    "method_list": [
                        "Variance"
                    ],
                    "n_neighbors": 10,
                    "percentage": 20
                },
                "description": "get statistical success",
                "status": "OK"
            });
            
            if (store.getters.getEnv == 'prd') {
                mock.restore();                
            }
            
            var self = this;
            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {                   
                    model_id: store.getters.getCurrentModelId,                    
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        //self.fabs = response.data.data.fabs;
                        console.log(response.data.data);
                        
                        self.methodList = response.data.data.method_list;
                        
                        self.method = response.data.data.method;
                        //self.method_para = (parseFloat(response.data.data.percentage) * 100).toString();
                        self.method_para = parseInt(response.data.data.percentage).toString();
                                                        
                        if (self.model_type.toLowerCase() == "anomaly_detection") {
                            //show Choose a Modeling Algorithm Div
                            $("#ModelingAlgorithm").show();                            
                            self.modeling_method = response.data.data.anomaly_detection_method;
                            self.n_neighbors = response.data.data.n_neighbors;

                            //2.預設為：Anomaly Detect預設用Variance; 其餘用Lasso                            
                        }                        
                    }
                })             
        },

        //驗證資料
        calc_feature_selection_score_Vaild: function () {
            var self = this;
            self.vaildDataAndCallack("method_para",self.calc_feature_selection_score);
        },

        //取得Plot的數值
        calc_feature_selection_score: function () {

                        
            if (isNaN(this.method_para) || this.method_para == '') {

                alertify.error('Percentage is not a number.');
                return;
            }

            store.commit('setShowLoading', true);     
            
            var apiUrl = "/feature_selection";            

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                "code": 200,
                "data": {
                    "feature": [
                        "CT_WP_Skewness_aaaaada",
                        "Vibration_WP_Skewness_dadadda",
                        "Vibration_WP_Skewness_addaaad",
                        "CT_WP_Skewness_dddaaaa",
                        "CT_WP_Skewness_ddadada",
                        "CT_WP_Skewness_aadddaa",
                        "CT_WP_Skewness_addadaa",
                        "CT_WP_Skewness_daaddaa",
                        "CT_WP_Skewness_daaadda",
                        "CT_WP_Skewness_addaddd",
                        "CT_WP_Skewness_dddddda"

                    ],
                    "score": [
                        0.24728221442227338,
                        0.11484017908607125,
                        0.11411780659007711,
                        0.03557932608525096,
                        0.034548003059891766,
                        0.027766450785099803,
                        0.025032622512699148,
                        0.022629288215322903,
                        0.01982516145332959,
                        0.013875533997664755,
                        0.01203435093839751,
                        0.010541611701165717
                    ],
                    "use": [
                        true,
                        true,
                        true,
                        true,
                        true,
                        true,
                        true,
                        true,
                        true,
                        true,
                        true
                    ]
                },
                "description": "get statistical success",
                "status": "OK"
            });


            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            var self = this;
            axios({
                method: 'post',
                baseURL: store.getters.getOfflineApiUrl,                
                url: apiUrl,
                data: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    method: self.method,
                    method_para: self.method_para
                }

            })
                .then(function (response) {
                    store.commit('setShowLoading', false);     

                    if (response.data.status == "OK") {                        
                        
                        //Y 值
                        var seriesData = [];                        

                        //X Label值
                        var XLabel = [];  
                                               
                        //回傳資料需要做反序
                        for (var i = 0, len = response.data.data.use.length - 1; i <= len; i++) {
                            var val = response.data.data.score[len - i];
                            if (response.data.data.use[len - i]) {
                                seriesData.push({ value: val, itemStyle: { color: '#E15457' } });
                            } else {
                                seriesData.push({ value: val, itemStyle: { color: '#D7DA8B' } });
                            }

                            XLabel.push(response.data.data.feature[len - i]);
                        }

                        self.canGoNextStep = true;
                        //self.DrawChart({ value_x: response.data.data.feature, value_y: seriesData });
                        self.DrawChart({ value_x: XLabel, value_y: seriesData });
                    }
                })             
        },

        //Next : do modeling_calc 建模
        modeling_calc: function (fn) {

            var self = this;

            var apiUrl = "/modeling";

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPost(apiUrl).reply(200, {
                status: "OK",
            });


            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            axios({
                method: 'post',                
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                headers: { 'Content-Type': 'application/json' },
                data: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    method: self.modeling_method,                    
                    params: {
                        n_neighbors: self.n_neighbors
                    }
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {

                        //self.nextClick();
                        if (fn) {
                            setTimeout(fn, 1000);
                        }
                    } else {
                        alertify.error("更新失敗");
                        //self.nextClick();
                    }
                })             
        },

        DrawChart: function (ChartDatas) {
            var self = this;
            var arColor = ['#00B0F0', '#00EACD', '#43A047', '#92D050', '#D05052', '#FF7800', '#FFFF00', '#A349A4', '#F06292', '#7E57C2', '#02B9C4', '#5292B3', '#DAF7A6', '#49ff33', '#b9e7ff', '#83B9C7', '#2ACDC9', '#FFD000', '#7CFEF0', '#d7f96e'];

            var myChart = echarts.init(document.getElementById("EChart1"), 'dark');
            myChart.clear();

            /*  去除加载缓冲图 */
            myChart.showLoading({
                text: 'Loading...',
                textStyle: { fontSize: 30, color: '#444' },
                effectOption: { backgroundColor: 'rgba(0, 0, 0, 0)' }
            });

            var _series = [], _legend = [];

            _series.push({ name: 'train', data: ChartDatas.value_y, connectNulls: true, type: 'bar', symbol: ['none', 'arrow'], smooth: true, itemStyle: {} });
            var iStart = 100 - Math.round((20 / parseInt(ChartDatas.value_y.length)) * 100);

            var option = {
                backgroundColor: '#545655',//背景色
                title: {
                    text: 'Feature Selection ' + self.method + " " + self.method_para + "%",
                    textStyle: { color: 'white' },

                    //subtext: '',
                    left: 'center'
                },
                grid: { containLabel: true },
                xAxis: {
                    type: 'value', data: ChartDatas.value_y,
                    //  改变x轴颜色
                    axisLine: {
                        show: true,
                        onZero: false,
                        position: 'end',
                        lineStyle: {
                            color: '#DFFFBF',
                            width: 2,//这里是为了突出显示加上的，可以去掉
                        }
                    },
                    // 控制网格线是否显示
                    splitLine: {
                        show: false,
                        //  改变轴线颜色
                        lineStyle: {
                            // 使用深浅的间隔色
                            color: ['red']
                        }
                    },
                    axisTick: {
                        show: false,
                        alignWithLabel: true
                    },
                },
                yAxis: {
                    type: 'category', data: ChartDatas.value_x, axisLine: {
                        show: true,
                        lineStyle: {
                            color: '#DFFFBF',
                            width: 2,//这里是为了突出显示加上的，可以去掉
                        }
                    },
                    // 去除y轴上的刻度线
                    axisTick: {
                        show: false
                    },
                },
                dataZoom: [
                    {
                        type: 'slider',
                        xAxisIndex: 0,
                        filterMode: 'empty'
                    },
                    {
                        type: 'slider',
                        yAxisIndex: 0,
                        filterMode: 'empty',
                        start: iStart,
                        end: 100
                    },
                    {
                        type: 'inside',
                        xAxisIndex: 0,
                        filterMode: 'empty'
                    },
                    {
                        type: 'inside',
                        yAxisIndex: 0,
                        filterMode: 'empty',
                        start: iStart,
                        end: 100
                    }
                ],
                series: _series
            };


            myChart.hideLoading();  // 隐藏 loading 效果
            myChart.setOption(option, true);
        },

        vaildDataAndCallack: function (field,callback) {
            var self = this;
            this.$validator.validate(field).then(function (result) {
                if (result) {
                    // 如果 callback 是個函式就呼叫它
                    if (typeof callback === 'function') {
                        callback();
                    }
                }
                else {
                    alertify.error('Wrong DataType!');
                }
            })
        },

     
        saveClick: function () { },
        nextClickConfirm: function () {
            var self = this;
            
            if (!self.canGoNextStep) {
                alertify.error('Please adjust the threshold according to your requirements and Update it!');
                return;
            }

            if (self.algorithm_type == "default" && self.model_type == "anomaly_detection") {

                if (isNaN(self.n_neighbors) || self.n_neighbors == '') {
                    alertify.error('n_neighbors is not a number.');
                    return;
                } else {
                    if (self.modeling_method == "LOF") {
                        //n_neighbors(LOF)(1, 20, 1)
                        if (self.n_neighbors < 1 || self.n_neighbors > 20) {
                            alertify.error('LOF n_neighbors value need between 1~20');
                            return;
                        }

                    } if (self.modeling_method == "PCA_T2") {
                        //explained_variance(PCA_T2)(50, 100, 1)
                        if (self.n_neighbors < 50 || self.n_neighbors > 100) {
                            alertify.error('PCA_T2 n_neighbors value need between 50~100');
                            return;
                        }
                    }
                }
            }                        

            alertify.confirm("儲存編輯內容，並前往下一步驟",
                function (e) {
                    if (e) {
                        //OK

                        //20210330-新增儲存Algorithm資訊
                        if (self.algorithm_type == "default") {
                            self.modeling_calc(function () {
                                CreateProjectLayoutApp.redriectPage(true, null)

                            });
                        }
                        else {
                            self.postProjectAlgorithm().then(function () {
                                self.updateStatus(801).then(function () {
                                    alertify.success("Save Sussess");
                                    window.location.href = "/Project/ModelResult" + "?projectid=" + store.getters.getCurrentProjectId + "&modelid=" + store.getters.getCurrentModelId;
                                });                                
                            });
                        }                 
                       
                    } else {
                        //Cancel                      
                        return;
                    }
                });
        },
        xxxnextClick: function () {
            //window.location.href = "/Project/ModelResult";
            CreateProjectLayoutApp.nextStatus();          
        },

        backClick: function () {


            alertify.confirm("捨棄編輯中的內容，並回上一步驟",
                function (e) {
                    if (e) {
                        //OK

                        //window.location.href = "/Project/DataProcess";
                        CreateProjectLayoutApp.backStatus();
                    } else {
                        //Cancel                      
                        return;
                    }
                });
        },

        //取出該Project設定的Algorithm
        getProjectAlgorithm: function () {

            var self = this;
            var apiUrl = "/project/algorithm";

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, { "code": 200, "data": { "algorithm_id": null, "algorithm_package_id": null, "algorithm_type": "" }, "description": "Successful response", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    model_id: store.getters.getCurrentModelId
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK" && response.data.algorithm_id) {
                        self.chooseAlgorithm = response.data.algorithm_id;
                        self.chooseVersion = response.data.chooseVersion;
                    }
                })
        },

        //取Algorithm List
        getAlgorithmList: function () {

            var self = this;

            var apiUrl = "/algorithm/info_list";

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "data": {
                    "algorithm_list": [
                        {
                            "algorithm_id": 16,
                            "algorithm_name": "sam_test",
                            "algorithm_type": "raw_data_pipeline",
                            "author": "sam",
                            "author_deptid": "a1",
                            "description": "test",
                            "introduction_doc_name": null,
                            "itime": "2021-05-06 14:05:51",
                            "model_type": "anomaly_detection",
                            "utime": "2021-05-06 14:05:51"
                        },
                        {
                            "algorithm_id": 15,
                            "algorithm_name": "JaneTest_20210506",
                            "algorithm_type": "predict_only",
                            "author": "O1906003",
                            "author_deptid": "ADTEC2",
                            "description": "JaneTest_20210506",
                            "introduction_doc_name": null,
                            "itime": "2021-05-06 10:22:24",
                            "model_type": "anomaly_detection",
                            "utime": "2021-05-06 10:22:24"
                        }
                    ]
                },
                "code": 200,
                "description": "",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    page_no: 1,
                    page_size: 100
                }
            })
                .then(function (response) {

                    if (response.data.status == "OK") {

                        //必須要符合的algorithm_type和model_type
                        var algorithm_list = response.data.data.algorithm_list.filter(function (item) {
                            //因目前頁面是raw data建立資料的步驟，所以這邊固定取raw_data_pipeline的資料
                            return item.algorithm_type == 'predict_only' && item.model_type == store.getters.getCurrentModelType;
                        });
                        self.algorithms = algorithm_list;
                    }
                })

        },

        //取Algorithm Version
        getAlgorithmVerisonList: function () {

            var self = this;

            var apiUrl = "/algorithm/package_list";

            //用來模擬API的資料，實際上線不會執行這段            
            let mock = new AxiosMockAdapter(axios);
            mock.onGet(apiUrl).reply(200, {
                "code": 200,
                "data": {
                    "total_count": 25,
                    "version_list": [
                        {
                            "itime": "2021-03-04 10:02:31",
                            "package_description": "ffff",
                            "status": "accept",
                            "system_message": "",
                            "version": 72
                        },
                        {
                            "itime": "2021-03-03 16:53:20",
                            "package_description": "",
                            "status": "accept",
                            "system_message": "",
                            "version": 71
                        }
                    ]
                },
                "description": "Successful response",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }

            axios({
                method: 'get',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                params: {
                    algorithm_id: self.chooseAlgorithm,
                    page_no: 1,
                    page_size: 100
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        //必須要符合的可使用的狀態
                        var algorithm_versions = response.data.data.version_list.filter(function (item) {
                            //因目前頁面是raw data建立資料的步驟，所以這邊固定取raw_data_pipeline的資料
                            return item.status != 'reject';
                        });

                        self.algorithm_versions = algorithm_versions;    
                    }
                })
        },

        //觸發Algorithm Change事件
        changeAlgorithm: function () {
            this.getAlgorithmVerisonList();
        },

        //儲存演算法資訊
        postProjectAlgorithm: function () {

            var self = this;
                       

            return new Promise(function (resolve, reject) {


                if (self.chooseAlgorithm == null || self.chooseVersion == null) {
                    alertify.alert("Please select Algorithm and Version");
                    reject();
                }

                var apiUrl = "/project/algorithm";

                //用來模擬API的資料，實際上線不會執行這段            
                let mock = new AxiosMockAdapter(axios);
                mock.onPost(apiUrl).reply(200, {
                    "data": {
                    },
                    "code": 200,
                    "description": "",
                    "status": "OK"
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }

                axios({
                    method: 'post',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    data: {
                        model_id: store.getters.getCurrentModelId,
                        algorithm_type: self.algorithm_type,
                        algorithm_id: self.chooseAlgorithm,
                        version: self.chooseVersion
                    }
                })
                    .then(function (response) {
                        resolve();
                    })
                    .catch(function () {
                        reject();
                    })
            });
        },

        //更新Project Status
        updateStatus: function (status) {

            return new Promise(function (resolve, reject) {

                //呼叫更新狀態API
                var apiUrl = "/model_training";

                //用來模擬API的資料，實際上線不會執行這段
                let mock = new AxiosMockAdapter(axios);
                mock.onPut(apiUrl).reply(200, {
                    "data": {},
                    "code": 200,
                    "description": "",
                    "status": "OK"
                });

                if (store.getters.getEnv == 'prd') {
                    mock.restore();
                }


                axios({
                    method: 'put',
                    baseURL: store.getters.getOfflineApiUrl,
                    url: apiUrl,
                    data: {
                        project_id: store.getters.getCurrentProjectId,
                        model_id: store.getters.getCurrentModelId,
                        offline_model_status: status
                    }
                })
                    .then(function (response) {
                        resolve();
                    })
            });
        }
    }
})