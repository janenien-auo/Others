﻿var app = new Vue({
    el: '#app', //el為要綁定的div的id(已設定完成)  

    mounted: function () {
        var self = this;
        self.DrawChart();
    },
    methods: {
        DrawChart: function () {
            var arColor = ['#69FFF5', '#03C9C9', '#2E9233', '#75FFA8', '#B9FF73', '#AC72BF', '#FC97B1', '#F9519F', '#06A9C6', '#75FFA8', '#25F8BE'];
            var myChart1 = echarts.init(document.getElementById('PieChart'));
            var myChart2 = echarts.init(document.getElementById('PieChart2'));
            var myChart3 = echarts.init(document.getElementById('PieChart3'));
            var myChart4 = echarts.init(document.getElementById('PieChart4'));
            var myChart5 = echarts.init(document.getElementById('PieChart5'));
            var myChart6 = echarts.init(document.getElementById('PieChart6'));
            myChart1.showLoading();  // 开启 loading 效果
            myChart2.showLoading();  // 开启 loading 效果
            myChart3.showLoading();  // 开启 loading 效果
            myChart4.showLoading();  // 开启 loading 效果
            myChart5.showLoading();  // 开启 loading 效果
            myChart6.showLoading();  // 开启 loading 效果

            var option1 = {

                series: [
                    {
                        type: "gauge",
                        center: ["50%", "45%"], // 仪表位置
                        radius: "80%", //仪表大小
                        startAngle: 200, //开始角度
                        endAngle: -20, //结束角度
                        axisLine: {
                            show: false,
                            lineStyle: { // 属性lineStyle控制线条样式
                                color: [
                                    [0.5, new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
                                        offset: 1,
                                        color: "#E75F25" // 50% 处的颜色
                                    }, {
                                        offset: 0.8,
                                        color: "#D9452C" // 40% 处的颜色
                                    }], false)], // 100% 处的颜色
                                    [0.7, new echarts.graphic.LinearGradient(0, 0, 1, 0, [{
                                        offset: 1,
                                        color: "#FFC539" // 70% 处的颜色
                                    }, {
                                        offset: 0.8,
                                        color: "#FE951E" // 66% 处的颜色
                                    }, {
                                        offset: 0,
                                        color: "#E75F25" // 50% 处的颜色
                                    }], false)],
                                    [0.9, new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                        offset: 1,
                                        color: "#C7DD6B" // 90% 处的颜色
                                    }, {
                                        offset: 0.8,
                                        color: "#FEEC49" // 86% 处的颜色
                                    }, {
                                        offset: 0,
                                        color: "#FFC539" // 70% 处的颜色
                                    }], false)],
                                    [1, new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                        offset: 0.2,
                                        color: "#1CAD52" // 92% 处的颜色
                                    }, {
                                        offset: 0,
                                        color: "#C7DD6B" // 90% 处的颜色
                                    }], false)]
                                ],
                                width: 10
                            }
                        },
                        splitLine: {
                            show: false
                        },
                        axisTick: {
                            show: false
                        },
                        axisLabel: {
                            show: false
                        },
                        pointer: { //指针样式
                            length: '45%'
                        },
                        detail: {
                            show: false
                        }
                    },
                    {
                        type: "gauge",
                        center: ["50%", "45%"], // 默认全局居中
                        radius: "70%",
                        startAngle: 200,
                        endAngle: -20,
                        axisLine: {
                            show: true,
                            lineStyle: { // 属性lineStyle控制线条样式
                                color: [ //表盘颜色
                                    [0.5, "#DA462C"],//0-50%处的颜色
                                    [0.7, "#FF9618"],//51%-70%处的颜色
                                    [0.9, "#FFED44"],//70%-90%处的颜色
                                    [1, "#20AE51"]//90%-100%处的颜色
                                ],
                                width: 30//表盘宽度
                            }
                        },
                        splitLine: { //分割线样式（及10、20等长线样式）
                            length: 30,
                            lineStyle: { // 属性lineStyle控制线条样式
                                width: 2
                            }
                        },
                        axisTick: { //刻度线样式（及短线样式）
                            length: 20
                        },
                        axisLabel: { //文字样式（及“10”、“20”等文字样式）
                            color: "black",
                            distance: 5 //文字离表盘的距离
                        },
                        detail: {
                            formatter: "{score|{value}%}",
                            offsetCenter: [0, "60%"],
                            backgroundColor: '20AE51',//'#FFEC45',
                            height: 30,
                            rich: {
                                score: {
                                    color: "white",
                                    fontFamily: "微软雅黑",
                                    fontSize: 32
                                }
                            }
                        },
                        data: [{
                            value: 100,

                            label: {
                                textStyle: {
                                    fontSize: 12
                                },

                            }
                        }]
                    }
                ]
            };
            myChart1.hideLoading();  // 隐藏 loading 效果
            myChart1.setOption(option1);


            var option2 = {
                tooltip: {
                    formatter: '{a} <br/>{b} : {c}%'
                },
                //toolbox: {
                //    feature: {
                //        restore: {},
                //        saveAsImage: {}
                //    }
                //},
                series: [
                    {
                        name: 'Health Assessment',
                        type: 'gauge',
                        detail: { formatter: '{value}%' },
                        data: [{ value: 50, name: 'Health Assessment' }],
                        min: 0,
                        max: 100,
                        startAngle: 180,
                        endAngle: 0,
                        clockwish: true,
                        title: {
                            textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
                                fontWeight: 'bolder',
                                fontSize: 18,
                                fontStyle: 'italic',
                                color: '#fff',
                                shadowColor: '#fff', //默认透明
                                shadowBlur: 10
                            }
                        },

                    }
                ]
            };



            myChart2.hideLoading();  // 隐藏 loading 效果
            myChart2.setOption(option2);

            var option3 = {
                //backgroundColor: '#f',
                tooltip: {
                    formatter: "{a} <br/>{b} : {c}%"
                },
                //toolbox: {
                //    feature: {
                //        restore: {},
                //        saveAsImage: {}
                //    }
                //},
                series: [
                    {
                        name: 'Prognostic',
                        type: 'gauge',
                        min: 1,
                        max: 100,
                        detail: { formatter: '{value}%' },
                        axisLine: {            // 座标轴线
                            lineStyle: {       // 属性lineStyle控制线条样式
                                color: [[0.2, '#ff4500'], [0.80, '#1e90ff'], [4, 'lime']],
                                width: 3,
                                shadowColor: '#fff', //默认透明
                                shadowBlur: 10
                            }
                        },
                        axisLabel: {            // 座标轴小标记
                            distance: 8,
                            fontSize: 12,
                            formatter: function (v) {
                                return v.toFixed(0);
                            },
                        },
                        axisTick: {            // 座标轴小标记
                            length: 15,        // 属性length控制线长
                            lineStyle: {       // 属性lineStyle控制线条样式
                                color: 'auto',
                                shadowColor: '#fff', //默认透明
                                shadowBlur: 10
                            }
                        },
                        splitLine: {           // 分隔线
                            length: 25,         // 属性length控制线长
                            lineStyle: {       // 属性lineStyle（详见lineStyle）控制线条样式
                                width: 3,
                                color: '#fff',
                                shadowColor: '#fff', //默认透明
                                shadowBlur: 10
                            }
                        },
                        pointer: {           // 分隔线
                            shadowColor: '#fff', //默认透明
                            shadowBlur: 5
                        },
                        title: {
                            textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
                                fontWeight: 'bolder',
                                fontSize: 18,
                                fontStyle: 'italic',
                                color: '#fff',
                                shadowColor: '#fff', //默认透明
                                shadowBlur: 10
                            }
                        },
                        data: [{ value: 6, name: 'Prognostic' }]
                    }
                ]
            };

            myChart3.hideLoading();  // 隐藏 loading 效果
            myChart3.setOption(option3);


            var option4 = {
                title: {
                    //text: '水球图',
                },
                //backgroundColor: '#151934',
                series: [{
                    type: 'liquidFill',
                    radius: '70%',
                    color: ['#195ba6'],
                    center: ['50%', '50%'],
                    data: [0.6544, 0.6544, 0.6544],//[0.4544, 0.4544, 0.4544, 0.4544, 0.4544],
                    backgroundStyle: {
                        borderWidth: 2,
                        borderColor: '#1789fb',
                        color: '#1c233f',
                    },
                    outline: {
                        itemStyle: {
                            borderWidth: 5,
                            borderColor: '#1789fb',
                            borderType: 'dashed',
                        }
                    },
                    label: {
                        normal: { //此处没有生效，本地生效
                            textStyle: {
                                fontSize: 20,
                                color: '#e6e6e6',
                            },
                        },
                    },
                },
                    //{

                    //    type: 'liquidFill',
                    //    radius: '20%',
                    //    color: ['#884046'],
                    //    center: ['50%', '50%'],
                    //    data: [0.6, 0.6, 0.6, 0.6, 0.6],
                    //    backgroundStyle: {
                    //        borderWidth: 2,
                    //        borderColor: '#eb5c4d',
                    //        color: '#1c233f',
                    //    },
                    //    outline: {
                    //        itemStyle: {
                    //            borderWidth: 5,
                    //            borderColor: '#eb5c4d',
                    //            borderType: 'dashed',
                    //        }
                    //    },
                    //    label: {
                    //        normal: { // 同上
                    //            textStyle: {
                    //                fontSize: 20,
                    //                color: '#e6e6e6',
                    //            },
                    //        },
                    //    },

                    //},
                    //{

                    //    type: 'liquidFill',
                    //    radius: '20%',
                    //    color: ['#8a7e4e'],
                    //    center: ['75%', '50%'],
                    //    data: [1, 1, 1, 1, 1],
                    //    backgroundStyle: {
                    //        borderWidth: 2,
                    //        borderColor: '#f0d25c',
                    //        color: '#1c233f',
                    //    },
                    //    outline: {
                    //        itemStyle: {
                    //            borderWidth: 5,
                    //            borderColor: '#f0d25c',
                    //            borderType: 'dashed',
                    //        }
                    //    },
                    //    label: {
                    //        normal: { // 同上
                    //            textStyle: {
                    //                fontSize: 20,
                    //                color: '#e6e6e6',
                    //            },
                    //        },
                    //    },

                    //}
                ]
            };

            myChart4.hideLoading();  // 隐藏 loading 效果
            myChart4.setOption(option4);



            var option5 = {
                title: {
                    text: '预算 vs 開銷',
                    subtext: '',
                    x: 'center',
                    y: 'top',
                    textAlign: 'left',
                    textStyle: {
                        color: '#fff',
                        fontStyle: 'normal',
                        fontWeight: 'lighter',
                        fontFamily: 'san-serif',
                        fontSize: 18
                    }
                },
                tooltip: {
                    trigger: 'axis'
                },
                legend: {
                    orient: 'vertical',
                    x: 'right',
                    y: 'bottom',
                    data: ['预算分配', '實際開銷']
                },
                toolbox: {
                    show: true,
                    feature: {
                        mark: { show: true },
                        dataView: { show: true, readOnly: false },
                        restore: { show: true },
                        saveAsImage: { show: true }
                    }
                },
                polar: [
                    {
                        indicator: [
                            { text: '銷售', max: 6000 },
                            { text: '管理', max: 16000 },
                            { text: '資訊技術', max: 30000 },
                            { text: '客服', max: 38000 },
                            { text: '研發', max: 52000 },
                            { text: '市場', max: 25000 }
                        ]
                    }
                ],
                calculable: true,
                series: [
                    {
                        name: '预算 vs 開銷',
                        type: 'radar',
                        data: [
                            {
                                value: [4300, 10000, 28000, 35000, 50000, 19000],
                                name: '预算分配'
                            },
                            {
                                value: [5000, 14000, 28000, 31000, 42000, 21000],
                                name: '實際開銷'
                            }
                        ]
                    }
                ]
            };


            myChart5.hideLoading();  // 隐藏 loading 效果
            myChart5.setOption(option5);


            var option6 = {
                title: {
                    //text: '水球图',
                },
                //backgroundColor: '#151934',
                series: [
                    //    {
                    //    type: 'liquidFill',
                    //    radius: '70%',
                    //    color: ['#195ba6'],
                    //    center: ['50%', '50%'],
                    //    data: [0.6544, 0.6544, 0.6544],//[0.4544, 0.4544, 0.4544, 0.4544, 0.4544],
                    //    backgroundStyle: {
                    //        borderWidth: 2,
                    //        borderColor: '#1789fb',
                    //        color: '#1c233f',
                    //    },
                    //    outline: {
                    //        itemStyle: {
                    //            borderWidth: 5,
                    //            borderColor: '#1789fb',
                    //            borderType: 'dashed',
                    //        }
                    //    },
                    //    label: {
                    //        normal: { //此处没有生效，本地生效
                    //            textStyle: {
                    //                fontSize: 20,
                    //                color: '#e6e6e6',
                    //            },
                    //        },
                    //    },
                    //},
                    //{

                    //    type: 'liquidFill',
                    //    radius: '70%',
                    //    color: ['#884046'],
                    //    center: ['50%', '50%'],
                    //    data: [0.6, 0.6, 0.6, 0.6, 0.6],
                    //    backgroundStyle: {
                    //        borderWidth: 2,
                    //        borderColor: '#eb5c4d',
                    //        color: '#1c233f',
                    //    },
                    //    outline: {
                    //        itemStyle: {
                    //            borderWidth: 5,
                    //            borderColor: '#eb5c4d',
                    //            borderType: 'dashed',
                    //        }
                    //    },
                    //    label: {
                    //        normal: { // 同上
                    //            textStyle: {
                    //                fontSize: 20,
                    //                color: '#e6e6e6',
                    //            },
                    //        },
                    //    },

                    //},
                    {

                        type: 'liquidFill',
                        radius: '70%',
                        color: ['#8a7e4e'],
                        center: ['50%', '50%'],
                        data: [1, 1, 1, 1, 1],
                        backgroundStyle: {
                            borderWidth: 2,
                            borderColor: '#f0d25c',
                            color: '#1c233f',
                        },
                        outline: {
                            itemStyle: {
                                borderWidth: 5,
                                borderColor: '#f0d25c',
                                borderType: 'dashed',
                            }
                        },
                        label: {
                            normal: { // 同上
                                textStyle: {
                                    fontSize: 20,
                                    color: '#e6e6e6',
                                },
                            },
                        },

                    }
                ]
            };

            //var option7 = {
            //    series: [{
            //        color: ["#00F5FF", "#DCDCDC"],
            //        name: '访问来源',
            //        type: 'pie',
            //        radius: ['60%', '70%'],
            //        avoidLabelOverlap: false,
            //        label: {
            //            normal: {
            //                show: true,
            //                position: 'center'
            //            },
            //            emphasis: {
            //                show: true,
            //                textStyle: {
            //                    fontSize: '30',
            //                    fontWeight: 'bold'
            //                }
            //            }
            //        },
            //        labelLine: {
            //            normal: {
            //                show: false
            //            }
            //        },
            //        data: [{
            //            value: 75,
            //            name: '75%',
            //            label: {
            //                normal: {
            //                    textStyle: {
            //                        fontSize: '60',
            //                        fontWeight: 'bold'
            //                    }
            //                }
            //            },
            //        },
            //        {
            //            value: 25,
            //            name: '未上線率',
            //            label: {
            //                normal: {
            //                    textStyle: {
            //                        fontSize: '20',
            //                        color: '#999',
            //                        fontWeight: 'bold'
            //                    },
            //                    padding: [150, 0, 0, 0]
            //                }
            //            },
            //        }
            //        ]
            //    }]
            //};

            myChart6.hideLoading();  // 隐藏 loading 效果
            myChart6.setOption(option6);


        },
    }
})