﻿/*定義axios config*/
var onlineConfig = {  
    baseURL: store.getters.getOnlineApiUrl,
    headers: {      
        "phm_user_id": store.getters.getUserInfo.UserId
}
}

/*定義axios config*/
var offlineConfig = { 
    baseURL: store.getters.getOfflineApiUrl,
    headers: { "phm_user_id": store.getters.getUserInfo.UserId }
}

/*定義axios Request*/
var estoneRequest = axios.create(onlineConfig);
var updateProjectRequest = axios.create(offlineConfig);
var dropdownListRequest = axios.create(onlineConfig);
var onlineModelListRequest = axios.create(onlineConfig);
var toolMappingListRequest = axios.create(onlineConfig);
var dataHealthRequest = axios.create(onlineConfig);
var eStoneEventRequest = axios.create(onlineConfig);
var closeEStoneRequest = axios.create(onlineConfig);
var getRecordHistoryRequest = axios.create(onlineConfig);
var getRecordDropdownlistRequest = axios.create(onlineConfig);



/* 以下是實際發送API Request */

function estoneGroupList(query, isTest) {

    var apiUrl = "/estone_group_list";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(estoneRequest);
    mock.onGet(apiUrl).reply(200, {

        status: "OK",
        data: {
            "group_list":
                [
                    {
                        "group_name": "a",
                        "members": ["a1", "a2", "a3"]
                    },
                    {
                        "group_name": "b",
                        "members": ["b1", "b2", "b3"]
                    },
                    {
                        "group_name": "c",
                        "members": ["c1", "c2", "c3"]
                    },
                    {
                        "group_name": "d",
                        "members": ["d1", "d2", "d3"]
                    },
                    {
                        "group_name": "e",
                        "members": ["e1", "e2", "e3"]
                    },
                    {
                        "group_name": "f",
                        "members": ["f1", "f2", "f3"]
                    },
                    {
                        "group_name": "g",
                        "members": ["g1", "g2", "g3"]
                    },
                    {
                        "group_name": "h",
                        "members": ["h1", "h2", "h3"]
                    },
                    {
                        "group_name": "i",
                        "members": ["i1", "i2", "i3"]
                    }
                ]
        }
    });

    if (!isTest) {
        mock.restore();
    }

    return estoneRequest.get(apiUrl, { params: query} );  

}

function getBasicInfoDropdownList(isTest) {
    var apiUrl = "/dropitem/online_filter";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(dropdownListRequest);
    mock.onGet(apiUrl).reply(200, {
        status: "OK",
        data: {
            select_item:
                [
                    {
                        fab: "L5C",
                        stage: [
                            {
                                stage_name: "ARRAY",
                                function_list: ["ETCH", "INT", "PHOTO", "TF",]
                            },
                            {
                                stage_name: "CELL",
                                function_list: ["BEOL", "FAC", "ODF", "PI", "SLM"]
                            },
                            {
                                stage_name: "CF",
                                function_list: ["FAC", "ITO", "PHOTO", "TF"]
                            }
                        ]
                    },
                    {
                        fab: "L6A",
                        stage: [
                            {
                                stage_name: "ARRAY",
                                function_list: ["ETCH", "FA", "FAC", "INT", "PHOTO", "TF"]
                            },
                            {
                                stage_name: "CELL",
                                function_list: ["BEOL", "CELL_N3", "CELL_TEST", "CUTTING", "FA", "FAC", "ODF", "PI"]
                            },
                            {
                                stage_name: "CF",
                                function_list: ["CF", "FA", "FAC", "ITO", "PHOTO"]
                            }
                        ]
                    }
                ]
        }
    });

    if (!isTest) {
        mock.restore();
    }
    
    return dropdownListRequest.get(apiUrl);     
}

function getOnlineModelList(query, isTest) {

    var apiUrl = "/online_model_list";

    //用來模擬API的資料，實際上線不會執行這段            
    var mock = new AxiosMockAdapter(onlineModelListRequest);
    mock.onGet(apiUrl).reply(200, {
        status: "OK",

        "data": {
            "model_list": [
                {
                    "project_id": 1,
                    "model_id": 1,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Jane",
                    "online_status": "online",
                    "data_health": {
                        "online_count": 5,
                        "no_data_count": 2,
                        "feature_abnormal_count": 1
                    },
                    "predict_result": "0",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES10",
                        "COATER1"
                    ]
                },
                {
                    "project_id": 2,
                    "model_id": 2,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L6B",
                    "stage": "Array",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Jane",
                    "online_status": "online",
                    "data_health": {
                        "online_count": 10,
                        "no_data_count": 3,
                        "feature_abnormal_count": 1
                    },
                    "predict_result": "10",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES20",
                        "COATER1"
                    ]
                },
                {
                    "project_id": 3,
                    "model_id": 3,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L7B",
                    "stage": "Array",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Joyce",
                    "online_status": "stop",
                    "data_health": {
                        "online_count": 10,
                        "no_data_count": 0,
                        "feature_abnormal_count": 0
                    },
                    "predict_result": "0",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES20",
                        "COATER1"
                    ]
                },
                {
                    "project_id": 4,
                    "model_id": 10,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L7A",
                    "stage": "Array",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Joyce",
                    "online_status": "offline",
                    "data_health": {
                        "online_count": 10,
                        "no_data_count": 5,
                        "feature_abnormal_count": 3
                    },
                    "predict_result": "20",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES30",
                        "COATER2"
                    ]
                },
                {
                    "project_id": 5,
                    "model_id": 10,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L6B",
                    "stage": "Array",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Joyce",
                    "online_status": "offline",
                    "data_health": {
                        "online_count": 10,
                        "no_data_count": 5,
                        "feature_abnormal_count": 3
                    },
                    "predict_result": "20",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES40",
                        "COATER2"
                    ]
                },
                {
                    "project_id": 6,
                    "model_id": 1,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L5B",
                    "stage": "CELL",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Amanda",
                    "online_status": "offline",
                    "data_health": {
                        "online_count": 5,
                        "no_data_count": 2,
                        "feature_abnormal_count": 1
                    },
                    "predict_result": "0",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES40",
                        "COATER2"
                    ]
                },
                {
                    "project_id": 7,
                    "model_id": 2,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L5C",
                    "stage": "CF",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Amanda",
                    "online_status": "online",
                    "data_health": {
                        "online_count": 10,
                        "no_data_count": 3,
                        "feature_abnormal_count": 1
                    },
                    "predict_result": "10",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES50",
                        "COATER3"
                    ]
                },
                {
                    "project_id": 8,
                    "model_id": 3,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Sam",
                    "online_status": "stop",
                    "data_health": {
                        "online_count": 10,
                        "no_data_count": 0,
                        "feature_abnormal_count": 0
                    },
                    "predict_result": "0",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES50",
                        "COATER3"
                    ]
                },
                {
                    "project_id": 9,
                    "model_id": 4,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Sam",
                    "online_status": "stop",
                    "data_health": {
                        "online_count": 10,
                        "no_data_count": 5,
                        "feature_abnormal_count": 3
                    },
                    "predict_result": "20",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES50",
                        "COATER3"
                    ]
                },
                {
                    "project_id": 10,
                    "model_id": 4,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Sam",
                    "online_status": "online",
                    "data_health": {
                        "online_count": 10,
                        "no_data_count": 5,
                        "feature_abnormal_count": 3
                    },
                    "predict_result": "20",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES50",
                        "COATER4"
                    ]
                },
                {
                    "project_id": 11,
                    "model_id": 10,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Joyce",
                    "online_status": "offline",
                    "data_health": {
                        "online_count": 10,
                        "no_data_count": 5,
                        "feature_abnormal_count": 3
                    },
                    "predict_result": "20",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES60",
                        "COATER4"
                    ]
                },
                {
                    "project_id": 12,
                    "model_id": 1,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Amanda",
                    "online_status": "stop",
                    "data_health": {
                        "online_count": 5,
                        "no_data_count": 2,
                        "feature_abnormal_count": 1
                    },
                    "predict_result": "0",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES60",
                        "COATER4"
                    ]
                },
                {
                    "project_id": 13,
                    "model_id": 2,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Amanda",
                    "online_status": "stop",
                    "data_health": {
                        "online_count": 10,
                        "no_data_count": 3,
                        "feature_abnormal_count": 1
                    },
                    "predict_result": "10",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES60",
                        "COATER4"
                    ]
                },
                {
                    "project_id": 14,
                    "model_id": 3,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Sam",
                    "online_status": "offline",
                    "data_health": {
                        "online_count": 10,
                        "no_data_count": 0,
                        "feature_abnormal_count": 0
                    },
                    "predict_result": "0",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES70",
                        "COATER4"
                    ]
                },
                {
                    "project_id": 15,
                    "model_id": 4,
                    "ai365_project_name": "Test",
                    "model_type": "Anomaly Detection",
                    "application": "Robot",
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "tool_type": "Robot_LD",
                    "user_name": "Sam",
                    "online_status": "offline",
                    "data_health": {
                        "online_count": 10,
                        "no_data_count": 5,
                        "feature_abnormal_count": 3
                    },
                    "predict_result": "20",
                    "e_stone_event_count": 3,
                    "update_time": "2020-06-03 12:34:56",
                    "online_time": "2020-06-03 12:34:56",
                    "tool_chamber_flat_unique_list": [
                        "FAMRES70",
                        "COATER5"
                    ]
                }
            ]
        },
    });

    if (!isTest) {
        mock.restore();
    }  

    return onlineModelListRequest.get(apiUrl, { params: query  });      

}

function getToolMappingList(query, isTest) {
    
    var apiUrl = "/model_setting";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(toolMappingListRequest);
    mock.onGet(apiUrl).reply(200, {
        code: 200,
        data: {
            "online_status": "offline",
            "alarm_rule": "1/1",
            "alarm_notify_group_name_list": ["c"],
            tool_chamber_list: [{
                tool_job_mapping_id: 0,
                tool_id: "AAIEX100",
                chamber: "SB_WIND",
                source: 'User Maintain',
                use: false
            },
            {
                tool_job_mapping_id: 1,
                tool_id: "ABIEX200",
                chamber: "axi_x1",
                source: 'E-Stone',
                use: false
            },
            {
                tool_job_mapping_id: 2,
                tool_id: "ABIEX300",
                chamber: "axi_x2",
                source: 'User Maintain',
                use: false
            },
            {
                tool_job_mapping_id: 3,
                tool_id: "ABIEX400",
                chamber: "axi_x1",
                source: 'User Maintain',
                use: false
            },
            {
                tool_job_mapping_id: 4,
                tool_id: "ABIEX500",
                chamber: "axi_x2",
                source: 'E-Stone',
                use: false
            },
            {
                tool_job_mapping_id: 5,
                tool_id: "ABIEX600",
                chamber: "axi_x1",
                source: 'E-Stone',
                use: false
            },
            {
                tool_job_mapping_id: 6,
                tool_id: "ABIEX700",
                chamber: "axi_x2",
                source: 'E-Stone',
                use: false
            },
            {
                tool_job_mapping_id: 7,
                tool_id: "ABIEX800",
                chamber: "axi_x1",
                source: 'E-Stone',
                use: false
            },
            {
                tool_job_mapping_id: 8,
                tool_id: "ABIEX900",
                chamber: "axi_x1",
                source: 'E-Stone',
                use: false
            },
            {
                tool_job_mapping_id: 9,
                tool_id: "ABIEX1000",
                chamber: "axi_x1",
                source: 'E-Stone',
                use: false
            },
            {
                tool_job_mapping_id: 10,
                tool_id: "ABIEX1100",
                chamber: "axi_x2",
                source: 'E-Stone',
                use: true
            },
            {
                tool_job_mapping_id: 11,
                tool_id: "ABIEX1200",
                chamber: "axi_x3",
                source: 'E-Stone',
                use: true
            },
            {
                tool_job_mapping_id: 12,
                tool_id: "ABIEX1300",
                chamber: "axi_x4",
                source: 'User Maintain',
                use: true
            },
            {
                tool_job_mapping_id: 13,
                tool_id: "ABIEX1400",
                chamber: "axi_x1",
                source: 'User Maintain',
                use: true
            },
            {
                tool_job_mapping_id: 14,
                tool_id: "ABIEX1500",
                chamber: "axi_x2",
                source: 'User Maintain',
                use: true
            },
            {
                tool_job_mapping_id: 15,
                tool_id: "ABIEX1600",
                chamber: "axi_x1",
                source: 'User Maintain',
                use: true
            },
            {
                tool_job_mapping_id: 16,
                tool_id: "ABIEX1700",
                chamber: "axi_x2",
                source: 'User Maintain',
                use: true
            },
            {
                tool_job_mapping_id: 17,
                tool_id: "ABIEX1800",
                chamber: "axi_x1",
                source: 'E-Stone',
                use: true
            },
            {
                tool_job_mapping_id: 18,
                tool_id: "ABIEX1900",
                chamber: "axi_x2",
                source: 'E-Stone',
                use: true
            }
            ]
        },
        description: "",
        status: "OK"
    });

    if (!isTest) {
        mock.restore();
    }  

    return toolMappingListRequest.get(apiUrl, { params: query }); 
}

function postToolMappingList(data, isTest) {

    var apiUrl = "/model_setting";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(toolMappingListRequest);
    mock.onPost(apiUrl).reply(200, {
        data: {},
        code: 200,
        description: "test",
        status: "OK"
    });

    if (!isTest) {
        mock.restore();
    }


    return toolMappingListRequest.post(apiUrl, data); 

    //return axios({
    //    method: 'PATCH',
    //    baseURL: domainUrl,
    //    url: apiUrl,
    //    data: data
    //})
}

function getToolChamberDataHealth(query, isTest) {

    var apiUrl = "/tool_chamber_data_health";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(dataHealthRequest);
    mock.onGet(apiUrl).reply(200, {
        "data": {
            "tool_chamber_list": [
                {
                    "tool_id": "Tool_1",
                    "chamber": "Chamber_1",
                    "data_health_status": "OK"
                },
                {
                    "tool_id": "Tool_2",
                    "chamber": "Chamber_2",
                    "data_health_status": "no_data"
                },
                {
                    "tool_id": "Tool_3",
                    "chamber": "Chamber_3",
                    "data_health_status": "feature_abnormal"
                },
               
                {
                    "tool_id": "Tool_4",
                    "chamber": "Chamber_4",
                    "data_health_status": "OK"
                },
                {
                    "tool_id": "Tool_5",
                    "chamber": "Chamber_5",
                    "data_health_status": "no_data"
                },
                {
                    "tool_id": "Tool_6",
                    "chamber": "Chamber_6",
                    "data_health_status": "feature_abnormal"
                },
                {
                    "tool_id": "Tool_7",
                    "chamber": "Chamber_7",
                    "data_health_status": "OK"
                },
                {
                    "tool_id": "Tool_8",
                    "chamber": "Chamber_8",
                    "data_health_status": "no_data"
                },
                {
                    "tool_id": "Tool_9",
                    "chamber": "Chamber_9",
                    "data_health_status": "feature_abnormal"
                },
                {
                    "tool_id": "Tool_10",
                    "chamber": "Chamber_10",
                    "data_health_status": "OK"
                },
                {
                    "tool_id": "Tool_11",
                    "chamber": "Chamber_11",
                    "data_health_status": "no_data"
                },
                {
                    "tool_id": "Tool_12",
                    "chamber": "Chamber_12",
                    "data_health_status": "feature_abnormal"
                },
                {
                    "tool_id": "Tool_13",
                    "chamber": "Chamber_13",
                    "data_health_status": "OK"
                },
                
            ]
        },
        "code": 200,
        "description": "",
        "status": "OK"
    });

    if (!isTest) {
        mock.restore();
    }

    return dataHealthRequest.get(apiUrl, { params: query });    
}

function updateProjectOnline(data, isTest) {

    var self = this;

    var apiUrl = "/offline_to_online";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(updateProjectRequest);
    mock.onPost(apiUrl).reply(200, {

        status: "OK",
        data: {},
        code: 200,
        description: ""
    });


    if (!isTest) {
        mock.restore();
    }
       
    return updateProjectRequest.post(apiUrl,data);      

}

function getEStoneEventList(query, isTest) {
    var apiUrl = "/event_list";

    //用來模擬API的資料，實際上線不會執行這段            
    let mock = new AxiosMockAdapter(eStoneEventRequest);
    mock.onGet(apiUrl).reply(200, {
        status: "OK",
        data: {
           
            event_list: [
                
                    {
                    "event_id": 1,
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "ai365_project_name": "JaneTest",
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_1",
                    "label": "label_1",
                    "machine_part": "machine_part_1",
                    "notify_time": "2019-12-31 10:58:30",
                    "event_status": "open",
                    "model_type":"model_type"
                    },               
                {
                    "event_id": 2,
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "ai365_project_name": "JaneTest",
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_1",
                    "label": "label_1",
                    "machine_part": "machine_part_1",
                    "notify_time": "2019-12-31 10:58:30",
                    "event_status": "open",
                    "model_type": "model_type"
                },
                {
                    "event_id": 3,
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "ai365_project_name": "JaneTest",
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_2",
                    "label": "label_1",
                    "machine_part": "machine_part_1",
                    "notify_time": "2019-12-31 10:58:30",
                    "event_status": "open",
                    "model_type": "model_type"
                },
                {
                    "event_id": 4,
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "ai365_project_name": "JaneTest",
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_2",
                    "label": "label_1",
                    "machine_part": "machine_part_1",
                    "notify_time": "2019-12-31 10:58:30",
                    "event_status": "open",
                    "model_type": "model_type"
                },
                {
                    "event_id": 5,
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "ai365_project_name": "JaneTest",
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_2",
                    "label": "label_1",
                    "machine_part": "machine_part_1",
                    "notify_time": "2019-12-31 10:58:30",
                    "event_status": "open",
                    "model_type": "model_type"
                },
                {
                    "event_id": 6,
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "ai365_project_name": "JaneTest",
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_3",
                    "label": "label_1",
                    "machine_part": "machine_part_1",
                    "notify_time": "2019-12-31 10:58:30",
                    "event_status": "close",
                    "model_type": "model_type"
                },
                {
                    "event_id": 7,
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "ai365_project_name": "JaneTest",
                    "tool_id": "tool_id_2",
                    "chamber": "chamber_1",
                    "label": "label_1",
                    "machine_part": "machine_part_1",
                    "notify_time": "2019-12-31 10:58:30",
                    "event_status": "open",
                    "model_type": "model_type"
                },
                {
                    "event_id": 8,
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "ai365_project_name": "JaneTest",
                    "tool_id": "tool_id_2",
                    "chamber": "chamber_1",
                    "label": "label_1",
                    "machine_part": "machine_part_1",
                    "notify_time": "2019-12-31 10:58:30",
                    "event_status": "close",
                    "model_type": "model_type"
                },
                {
                    "event_id": 9,
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "ai365_project_name": "JaneTest",
                    "tool_id": "tool_id_2",
                    "chamber": "chamber_2",
                    "label": "label_1",
                    "machine_part": "machine_part_1",
                    "notify_time": "2019-12-31 10:58:30",
                    "event_status": "open",
                    "model_type": "model_type"
                },
                {
                    "event_id": 10,
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "ai365_project_name": "JaneTest",
                    "tool_id": "tool_id_2",
                    "chamber": "chamber_2",
                    "label": "label_1",
                    "machine_part": "machine_part_1",
                    "notify_time": "2019-12-31 10:58:30",
                    "event_status": "open",
                    "model_type": "model_type"
                },
                {
                    "event_id": 11,
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "ai365_project_name": "JaneTest",
                    "tool_id": "tool_id_2",
                    "chamber": "chamber_3",
                    "label": "label_1",
                    "machine_part": "machine_part_1",
                    "notify_time": "2019-12-31 10:58:30",
                    "event_status": "open",
                    "model_type": "model_type"
                },
                {
                    "event_id": 12,
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "ai365_project_name": "JaneTest",
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_3",
                    "label": "label_1",
                    "machine_part": "machine_part_1",
                    "notify_time": "2019-12-31 10:58:30",
                    "event_status": "close",
                    "model_type": "model_type"
                },
                {
                    "event_id": 13,
                    "fab": "L5C",
                    "stage": "Array",
                    "func": "PHOTO",
                    "ai365_project_name": "JaneTest",
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_3",
                    "label": "label_1",
                    "machine_part": "machine_part_1",
                    "notify_time": "2019-12-31 10:58:30",
                    "event_status": "close",
                    "model_type": "model_type"
                },
            ]
        }
    });

    if (!isTest) {
        mock.restore();
    }      

    return eStoneEventRequest.get(apiUrl, { params: query }); 


}

function postMaintainRecord(data, isTest) {

    var apiUrl = "/maintain";

    //用來模擬API的資料，實際上線不會執行這段
    var mock = new AxiosMockAdapter(closeEStoneRequest);
    mock.onPost(apiUrl).reply(200, {
        data: {},
        code: 200,
        description: "test",
        status: "OK"
    });

    if (!isTest) {
        mock.restore();
    }


    return closeEStoneRequest.post(apiUrl, data);
   
}

function getRecordHistoryList(query, isTest) {
    var apiUrl = "/maintain_list";

    //用來模擬API的資料，實際上線不會執行這段            
    let mock = new AxiosMockAdapter(getRecordHistoryRequest);
    mock.onGet(apiUrl).reply(200, {
        status: "OK",
        data: {
            maintain_list: [
                {
                    "maintain_id": 1,                    
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_1",
                    "event_type": "event_type",
                    "component": "component",
                    "alarm_code": "alarm_code_1",
                    "solution":"solution",
                    "action_time": "2019-12-31 10:58:30",
                    "note": "note",
                    "source": "source"
                  
                },
                {
                    "maintain_id": 2,                   
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_1",
                    "event_type": "event_type",
                    "component": "component",
                    "alarm_code": "alarm_code_1",
                    "solution": "solution",
                    "action_time": "2019-12-31 10:58:30",
                    "note": "note",
                    "source": "source"
                },
                {
                    "maintain_id": 3,                    
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_2",
                    "event_type": "event_type",
                    "component": "component",
                    "alarm_code": "alarm_code_1",
                    "solution": "solution",
                    "action_time": "2019-12-31 10:58:30",
                    "note": "note",
                    "source": "source"
                },
                {
                    "maintain_id": 4,                  
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_2",
                    "event_type": "event_type",
                    "component": "component",
                    "alarm_code": "alarm_code_1",
                    "solution": "solution",
                    "action_time": "2019-12-31 10:58:30",
                    "note": "note",
                    "source": "source"
                },
                {
                    "maintain_id": 5,                   
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_2",
                    "event_type": "event_type",
                    "component": "component",
                    "alarm_code": "alarm_code_1",
                    "solution": "solution",
                    "action_time": "2019-12-31 10:58:30",
                    "note": "note",
                    "source": "source"
                },
                {
                    "maintain_id": 6,                   
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_3",
                    "event_type": "event_type",
                    "component": "component",
                    "alarm_code": "alarm_code_1",
                    "solution": "solution",
                    "action_time": "2019-12-31 10:58:30",
                    "note": "note",
                    "source": "source"
                },
                {
                    "maintain_id": 7,                   
                    "tool_id": "tool_id_2",
                    "chamber": "chamber_1",
                    "event_type": "event_type",
                    "component": "component",
                    "alarm_code": "alarm_code_1",
                    "solution": "solution",
                    "action_time": "2019-12-31 10:58:30",
                    "note": "note",
                    "source": "source"
                },
                {
                    "maintain_id": 8,                   
                    "tool_id": "tool_id_2",
                    "chamber": "chamber_1",
                    "event_type": "event_type",
                    "component": "component",
                    "alarm_code": "alarm_code_1",
                    "solution": "solution",
                    "action_time": "2019-12-31 10:58:30",
                    "note": "note",
                    "source": "source"
                },
                {
                    "maintain_id": 9,                   
                    "tool_id": "tool_id_2",
                    "chamber": "chamber_2",
                    "event_type": "event_type",
                    "component": "component",
                    "alarm_code": "alarm_code_1",
                    "solution": "solution",
                    "action_time": "2019-12-31 10:58:30",
                    "note": "note",
                    "source": "source"
                },
                {
                    "maintain_id": 10,                  
                    "tool_id": "tool_id_2",
                    "chamber": "chamber_2",
                    "event_type": "event_type",
                    "component": "component",
                    "alarm_code": "alarm_code_1",
                    "solution": "solution",
                    "action_time": "2019-12-31 10:58:30",
                    "note": "note",
                    "source": "source"
                },
                {
                    "maintain_id": 11,                   
                    "tool_id": "tool_id_2",
                    "chamber": "chamber_3",
                    "event_type": "event_type",
                    "component": "component",
                    "alarm_code": "alarm_code_1",
                    "solution": "solution",
                    "action_time": "2019-12-31 10:58:30",
                    "note": "note",
                    "source": "source"
                },
                {
                    "maintain_id": 12,                    
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_3",
                    "event_type": "event_type",
                    "component": "component",
                    "alarm_code": "alarm_code_1",
                    "solution": "solution",
                    "action_time": "2019-12-31 10:58:30",
                    "note": "note",
                    "source": "source"
                },
                {
                    "maintain_id": 13,                   
                    "tool_id": "tool_id_1",
                    "chamber": "chamber_3",
                    "event_type": "event_type",
                    "component": "component",
                    "alarm_code": "alarm_code_1",
                    "solution": "solution",
                    "action_time": "2019-12-31 10:58:30",
                    "note": "note",
                    "source": "source"
                },
            ]
        }
    });

    if (!isTest) {
        mock.restore();
    }

    return getRecordHistoryRequest.get(apiUrl, { params: query }); 

}

function getRecordDropdownlist(query, isTest) {
    var apiUrl = "/tool_chamber_list_for_maintain";

    //用來模擬API的資料，實際上線不會執行這段            
    let mock = new AxiosMockAdapter(getRecordDropdownlistRequest);
    mock.onGet(apiUrl).reply(200, {
        status: "OK",
        data: {
            "tool_list": [
                {
                    "key": "IEX200",
                    "chamber_list": [
                        {
                            "key": "IEX200_AXI_Y1"
                        },
                        {
                            "key": "IEX200_AXI_Y2"
                        },
                        {
                            "key": "IEX200_AXI_Y3"
                        }

                    ]
                },
                {
                    "key": "IEX300",
                    "chamber_list": [
                        {
                            "key": "IEX300_AXI_Y1"
                        },
                        {
                            "key": "IEX300_AXI_Y2"
                        },
                        {
                            "key": "IEX300_AXI_Y3"
                        }
                    ]
                },
                {
                    "key": "IEX400",
                    "chamber_list": [
                        {
                            "key": "IEX400_AXI_Y1"
                        },
                        {
                            "key": "IEX400_AXI_Y2"
                        },
                        {
                            "key": "IEX400_AXI_Y3"
                        }
                    ]
                }
            ]
        }
    });

    if (!isTest) {
        mock.restore();
    }

    return getRecordDropdownlistRequest.get(apiUrl, { params: query });

}



function errorHandle(error) {
    logError(error);

    store.commit('setShowLoading', false);


    if (error.response.status) {
        if (error.response.data.description) {
            alertify.error(error.response.data.description);
        }
        else {
            alertify.error("呼叫API失敗");
        }

    }
    else if (error.response.data.status) {
        alertify.error(error.response.data.description);
    }
    return Promise.reject(error)

}

//監聽axios發生的錯誤
estoneRequest.interceptors.response.use(function (response) {
    return response;
}, function (error) {
    return errorHandle(error);    
    })

//監聽axios發生的錯誤
dropdownListRequest.interceptors.response.use(function (response) {
    return response;
}, function (error) {
    return errorHandle(error);
    })

//監聽axios發生的錯誤
onlineModelListRequest.interceptors.response.use(function (response) {
    return response;
}, function (error) {
    return errorHandle(error);
    })

//監聽axios發生的錯誤
toolMappingListRequest.interceptors.response.use(function (response) {
    return response;
}, function (error) {
    return errorHandle(error);
    })

//監聽axios發生的錯誤
dataHealthRequest.interceptors.response.use(function (response) {
    return response;
}, function (error) {
    return errorHandle(error);
})

//監聽axios發生的錯誤
updateProjectRequest.interceptors.response.use(function (response) {
    return response;
}, function (error) {
    return errorHandle(error);    
    })

//監聽axios發生的錯誤
eStoneEventRequest.interceptors.response.use(function (response) {
    return response;
}, function (error) {
    return errorHandle(error);
    })

//監聽axios發生的錯誤
closeEStoneRequest.interceptors.response.use(function (response) {
    return response;
}, function (error) {
    return errorHandle(error);
    })

//監聽axios發生的錯誤
getRecordHistoryRequest.interceptors.response.use(function (response) {
    return response;
}, function (error) {
    return errorHandle(error);
    })

//監聽axios發生的錯誤
getRecordDropdownlistRequest.interceptors.response.use(function (response) {
    return response;
}, function (error) {
    return errorHandle(error);
})