﻿var app = new Vue({
    el: '#app', 
    store:store,
    data: {
        username: "",
        password:""
    },   
    mounted: function () {
        var self = this;        
    },
    methods: {
        login: function () {      
            var self = this;
            store.dispatch("login", {
                username: self.username,
                password: self.password
                ,callback: self.WebFuncUsedLog
            });  

           
        },
        WebFuncUsedLog: function () {


            var data = {
                Fab: store.getters.getUserInfo.UserSite.replace('L', ''),
                LogSrv: "PHM", //Reaver說此欄位已經沒有使用，但是必填
                UserName: store.getters.getUserInfo.InputAccount,
                SiteName: store.getters.getUserInfo.UserSite,
                OrgID: store.getters.getUserInfo.UserDeptID,
                FunctionName: "PHM", //FunctionName 和 Url 會設定在API Server的Config檔，不可任意更動，要更動需通知Reaver
                Url: "/Home/Index"
            };        
          

            var _Url =
                "http://10.96.18.10/APC_WEB_API/APC_API/WebUsedLog/Put_WebFuncUsedLog";

            $.ajax({
                url: _Url,
                type: "post",
                dataType: "json",
                data: JSON.stringify(data),               
                contentType: "application/json; charset=utf-8",
                success: function (responseData, textStatus, jqXHR) {
                    //var value = jqXHR.status; // 200
                    console.log("Login - webUsed -Response");
                    console.log(responseData);
                }
                //,
                //error: function (xmlRequest) {
                //    alert(
                //        xmlRequest.status +
                //        " \n\r " +
                //        xmlRequest.statusText +
                //        "\n\r" +
                //        xmlRequest.responseText
                //    );
                //}
            });
        }

    }
})