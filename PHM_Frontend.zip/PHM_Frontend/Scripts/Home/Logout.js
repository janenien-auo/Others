﻿var app = new Vue({
    el: '#app', 
    data: {       
    },
    mounted: function () {

    },
    methods: {
        logout: function () {
            UserInfoApp.logout();    
        }
    }
})