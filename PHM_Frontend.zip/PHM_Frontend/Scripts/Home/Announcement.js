﻿var app = new Vue({
    el: '#app', 
    data: {
        folderDomain:'http://aaapc005:888/PHM_OpenDoc/Announcement',       
        currentAnnouncement: {},
        currentFolder:'',   
        announcements:[]
    },
    mounted: function () {
        var self = this;
        self.getAnnouncements();
        self.chooseFolder(self.announcements[0]);
    },
    methods: {    
        chooseFolder: function (data) {
            var self = this;
            self.currentAnnouncement = data;
            self.currentFolder = data.show_title;    
        },

        getAnnouncements: function () {
            var self = this;
            self.announcements = [];

            store.dispatch('getAnnouncements');

            self.announcements = store.getters.getAnnouncements;
        },


        getFileIcon: function (fileName) {

            var fileType = fileName.split('.').pop();


            switch (fileType) {
                case 'pptx':
                case 'ppt':
                    {                       
                        return 'fas fa-file-powerpoint';
                    }
                case 'pdf':               
                    {
                        return 'fas fa-file-pdf';
                    }
                case 'avi':
                case 'mp4':
                    {
                        return 'far fa-file-video';
                    }
                case 'xlsx':
                case 'xls':
                    {                        
                        return 'far fa-file-excel';
                    }
                case 'doc':
                case 'docx':
                    {                       
                        return 'far fa-file-word';
                    }

                default:
                    return 'far fa-file';
            } 



        }
    }
})