﻿var app = new Vue({
    el: '#app',
    store: store,
    data: {
        functionList: [
            {
                url: "/ProjectConti/ProjectContiList",
                name: "Conti data Setting",
                icon: "fas fa-cogs",
                status: "open",
                id: ""
            }
            //,   
            //{
            //    url: "/ProjectRawData/ProjectRawDataList",
            //    name: "Raw data Setting",
            //    icon: "fas fa-cogs",
            //    status: "open",
            //    id: ""
            //},
            //{
            //    url: "/CustomAlgorithm/AlgorithmList",
            //    name: "Algorithm Setting",
            //    icon: "fas fa-cogs",
            //    status: "open",
            //    id: ""
            //}  
        ]
    },
    mounted: function () {
        var self = this;
        self.init();
        store.commit('setShowLoading', false);    
    },
    methods: {
        init: function () {                    

            var authkey = getUrlParameterByName('authkey', window.location.href.toLowerCase());
            if (!authkey) authkey = window.localStorage.getItem('authkey');

            if (authkey) {
                window.localStorage.setItem('authkey', authkey);
            }

            this.getFunctionList();
        },

        getFunctionList: function () {
            if (store.getters.getIsShowRawDatafunc) {
                this.functionList.push({
                    url: "/ProjectRawData/ProjectRawDataList",
                    name: "Raw data Setting",
                    icon: "fas fa-cogs",
                    status: "open",
                    id: ""
                });
            }

            if (store.getters.getIsShowCustomAlgorithm) {
                this.functionList.push({
                    url: "/CustomAlgorithm/AlgorithmList",
                    name: "Algorithm Setting",
                    icon: "fas fa-cogs",
                    status: "open",
                    id: ""
                });
            }
            


        },


        linkFunc: function (url) {

            if (!url)
                return;

            window.location = url;

        },

        setStyle: function (status) {

            switch (status) {

                case "open":
                    return "";
                case "close":
                    return "opacity:0.3";
                default:
                    return;
            }
        },

        validateImage: function (url) {
            var img = new Image();
            var self = this;

            img.onerror = function () {
                self.userInfo.PhotoUrl = "/_img/person-empty-png.png";
            };
            img.src = url;

        }



    }
})