﻿var app = new Vue({
    el: '#app', 
    data: {
        folderDomain:'http://aaapc005:888/PHM_OpenDoc/TrainingMaterials',
        folders: [],
        currentFolder:'',
        currentFiles: []

    },
    mounted: function () {
        var self = this;
        self.getFolderFiles();
    },
    methods: {     
        getFolderFiles: function () {
            var self = this;
            axios({
                method: 'get',
                baseURL: "",
                url: "/api/File/GetTrainingMaterials"
            })
            .then(function (response) {
                if (response.data.status == "OK") {
                    self.folders = response.data.data;
                    if (self.folders.length > 0) {
                        self.currentFolder = self.folders[0].Folder;
                        self.currentFiles = self.folders[0].Files;
                    }                
                }
            })
        },

        chooseFolder: function (data) {
            var self = this;
            self.currentFolder = data.Folder;
            self.currentFiles = data.Files;
        },

        getFileIcon: function (fileName) {

            var fileType = fileName.split('.').pop();


            switch (fileType) {
                case 'pptx':
                case 'ppt':
                    {                       
                        return 'fas fa-file-powerpoint';
                    }
                case 'pdf':               
                    {
                        return 'fas fa-file-pdf';
                    }
                case 'avi':
                case 'mp4':
                    {
                        return 'far fa-file-video';
                    }
                case 'xlsx':
                case 'xls':
                    {                        
                        return 'far fa-file-excel';
                    }
                case 'doc':
                case 'docx':
                    {                       
                        return 'far fa-file-word';
                    }

                default:
                    return 'far fa-file';
            } 



        }
    }
})