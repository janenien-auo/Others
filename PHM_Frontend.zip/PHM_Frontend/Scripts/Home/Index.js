﻿var app = new Vue({
    el: '#app',
    store,
    data: {
        functionList: store.getters.getFunctionList
    },
    mounted: function () {
        var self = this;
        self.init();
    },
    methods: {
        init: function () {

            //document.getElementById("downloadGuide").href = document.getElementById("downloadGuide").href + '?v=' + Date.now();

            var authkey = getUrlParameterByName('authkey', window.location.href.toLowerCase());
            if (!authkey) authkey = window.localStorage.getItem('authkey');

            if (authkey) {

                window.localStorage.setItem('authkey', authkey);

            }
        },


        linkFunc: function (url) {

            if (!url)
                return;

            window.location = url;

        },

        setStyle: function (status) {

            switch (status) {

                case "open":
                    return "";
                case "close":
                    return "opacity:0.3";
                default:
                    return;
            }
        },

        validateImage: function (url) {
            var img = new Image();
            var self = this;

            img.onerror = function () {
                self.userInfo.PhotoUrl = "/_img/person-empty-png.png";
            };
            img.src = url;

        }



    }
})