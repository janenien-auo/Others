﻿//var logError = require('Log').logError;
//var getUrlParameterByName = require('UrlHelper').getUrlParameterByName;

var AnnouncementApp = new Vue({
    el: "#AnnouncementApp",   
    store:store,
    data: {      
        announcements: []        
    },
    created: function () {
        this.getAnnouncements();
    },
    mounted: function () {
        var self = this;  
        self.init();
    },
    methods: {
        init: function () {   
            if (this.announcements.length > 0) {  
                $('.marquee').marquee({
                    //duration in milliseconds of the marquee   
                    duration: 40000,
                    //gap in pixels between the tickers   
                    //gap: 50,                   
                    //'left' or 'right'   
                    direction: 'left',
                    //true or false - should the marquee be duplicated to show an effect of continues flow   
                    duplicated: true
                });               
            }
        },

        getAnnouncements: function () {
            var self = this;
            self.announcements = [];

            store.dispatch('getAnnouncements');

            var tempAnnouncements = store.getters.getAnnouncements;

            $.each(tempAnnouncements, function (index, object) {
                if (object.format == 'word') {
                    $.each(object.contents, function (idx, obj) {
                        if (obj.show_top_info && obj.show_top_info.start_time && obj.show_top_info.end_time) {

                            //比對在公告的時間內才會顯示
                            if (moment(new Date()).isSameOrAfter(obj.show_top_info.start_time) && moment(new Date()).isSameOrBefore(obj.show_top_info.end_time)) {
                                self.announcements.push(obj.content);
                            }
                        }
                    }); 
                }
            });          

        },

        redirctUrl: function () {
            window.location.href = "/Home/Announcement";
        }


    }



});