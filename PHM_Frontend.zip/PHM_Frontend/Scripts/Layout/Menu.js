﻿

w3.includeHTML(function () {

    var MenuApp = new Vue({
        el: "#MenuApp",
        store: store,
        data: {
            functionList: store.getters.getFunctionList
        },
        mounted: function () {

        },
        methods: {
            linkFunc: function (url) {

                if (!url)
                    return;

                window.location = url;

            },
            setStyle: function (status) {

                switch (status) {

                    case "open":
                        return "";
                    case "close":
                        return "opacity:0.3";
                    default:
                        return;
                }
            },
        }
    });

})

