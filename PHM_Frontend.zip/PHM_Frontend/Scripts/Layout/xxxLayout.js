﻿Vue.use(VeeValidate);

var LayoutApp = new Vue({  
    el: "#LayoutApp",  
    data: {
        env: "prd",//控制環境,
        homePage:"/Home/Index",
        showBackgroundData: false,
        showLoading: false,//控制是否要顯示Loading
        apiUrlDomain: "http://tcapcphmd01:8000", //呼叫API的連結          
        currentProjectId: "",
        currentModelId: "",
        currentModelType: "",
        currentProjectStatus: 0,
        currentDataType: "",
        currentProjectInfo: {},
        applications: ["Robot", "Pump"],
        marchieParts: ["Motor", "Reducer"],
        spectrumMethodInfos: [
            {
                patameter: "FFT",
                spectrum: "Fast Fourier Transform",
                explain: "FFT computes the Discrete Fourier Transform of a sequence."
            },
            {
                patameter: "PSD",
                spectrum: "Power Spectral Density",
                explain:
                    "PSD describe the distribution of power into frequency components composing that signal."
            },
            {
                patameter: "DWT",
                spectrum: "Discrete Wavelet Transform",
                explain:
                    "DWT is any wavelet transform for which the wavelets are discretely sampled."
            },
            {
                patameter: "WP",
                spectrum: "Wavelet Packets",
                explain:
                    "WP is a wavelet transform where the discrete-time(sampled) signal is passed through more filters than the DWT."
            }
        ],
        statisticalInfos: [
            {
                abbreviation: "Entropy",
                fullname: "Information entropy",
                explain:
                    "Information entropy is the average rate at which information is produced by a stochastic source of data."
            },
            //20200206-總立告知移除
            //{
            //    abbreviation: "Peak2peak",
            //    fullname: "Peak to Peak",
            //    explain: "Peak2peak is the range of values (maximum - minimum)"
            //},
            {
                abbreviation: "Std",
                fullname: "Standard deviation",
                explain:
                    "Standard deviation is a measure of the amount of variation or dispersion of a set of values"
            },
            {
                abbreviation: "Var",
                fullname: "Variance",
                explain:
                    "Variance is the expectation of the squared deviation of a random variable from its mean."
            },
            {
                abbreviation: "Rms",
                fullname: "Root Mean Square",
                explain: "RMS is defined as the square root of the mean square."
            },
            {
                abbreviation: "Mean",
                fullname: "",
                explain: "Mean is the sum of the values divided by the number of values"
            },
            {
                abbreviation: "Skewness",
                fullname: "",
                explain:
                    "Skewness is a measure of the asymmetry of the probability distribution of a real-valued random variable about its mean"
            },
            {
                abbreviation: "Kurtosis",
                fullname: "",
                explain:
                    "Kurtosis is a measure of the 'tailedness' of the probability distribution of a real-valued random variable."
            },
            {
                abbreviation: "Quantile_5",
                fullname: "",
                explain:
                    "Compute the 5-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Quantile_25",
                fullname: "",
                explain:
                    "Compute the 25-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Quantile_50",
                fullname: "",
                explain:
                    "Compute the 50-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Quantile_75",
                fullname: "",
                explain:
                    "Compute the 75-th quantile of the data along the specified axis"
            },
            {
                abbreviation: "Quantile_95",
                fullname: "",
                explain:
                    "Compute the 95-th quantile of the data along the specified axis"
            }
        ],
        modelingAlgorithm: [
            {
                model: "n_neighbors",
                algorithm: "LOF"
            },
            {
                model: "explained_variance",
                algorithm: "PCA_T2"
            }
        ], 
        createProjectStepInfo: [],       
        statusInfos: [
            {
                isShowStep: true,
                showStep: "1",
                title: "Project Register",
                offline_model_status: 100,
                statusName: "Project Register",
                url: "/Project/ProjectInfo",
                needToUpdateStatus: true,
                nextStatus: 200,
                mainStep: true,
                dataTypes: ["SensorRich", "Feature"]
            },
            {
                isShowStep: true,
                showStep: "2",
                title: "Data Collection",
                offline_model_status: 200,
                statusName: "Data Collection",
                url: "/Project/UploadFiles",
                needToUpdateStatus: true,
                nextStatus: 300,
                mainStep: true,
                dataTypes: ["SensorRich", "Feature"]
            },
            {
                isShowStep: true,
                showStep: "3",
                title: "Feature Engineering",
                offline_model_status: 300,
                statusName: "Feature Engineering",
                url: "/Project/FeatureEngineering",
                needToUpdateStatus: false, 
                nextStatus: 600,
                mainStep: true,
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                showStep: "3",
                title: "Feature Engineering",             
                offline_model_status: 301,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                offline_model_status: 303,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/Project/FeatureEngineering",
                    updateStatus: 300,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["SensorRich"]
            }, 
            {
                isShowStep: false,
                showStep: "3",
                title: "Feature Engineering",
                offline_model_status: 400,
                statusName: "Feature Engineering",
                url: "/Project/FeatureEngineering",
                needToUpdateStatus: false,
                nextStatus: 600,
                mainStep: true,
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                offline_model_status: 401,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                offline_model_status: 403,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/Project/FeatureEngineering",
                    updateStatus: 400,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["SensorRich"]
            }, 
            {
                isShowStep: false,
                showStep: "3",
                title: "Feature Engineering",
                offline_model_status: 500,
                statusName: "Feature Engineering",
                url: "/Project/FeatureEngineering",
                needToUpdateStatus: false,
                nextStatus: 600,
                mainStep: true,
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                offline_model_status: 501,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["SensorRich"]
            },
            {
                isShowStep: false,
                offline_model_status: 503,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/Project/FeatureEngineering",
                    updateStatus: 500,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["SensorRich"]
            }, 
            {
                isShowStep: true,
                showStep: "4",
                title: "Data Process",
                offline_model_status: 600,
                statusName: "Data Process",
                url: "/Project/DataProcess",
                needToUpdateStatus: false,
                nextStatus: 700,
                mainStep: true,
                dataTypes: ["SensorRich", "Feature"]
            },
            {
                isShowStep: false,
                offline_model_status: 601,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["SensorRich", "Feature"]
            },
            {
                isShowStep: false,             
                title: "Data Process",
                offline_model_status: 602,
                statusName: "Data Process",
                url: "/Project/DataProcess",
                needToUpdateStatus: true,
                nextStatus: 700,
                mainStep: false,
                dataTypes: ["SensorRich", "Feature"]
            },  
            {
                isShowStep: false,
                offline_model_status: 603,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/Project/DataProcess",
                    updateStatus: 600,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["SensorRich", "Feature"]
            },           
            {
                isShowStep: true,
                showStep: "5",
                title: "Feature Selection",
                offline_model_status: 700,
                statusName: "Feature Selection",
                url: "/Project/FeatureSelection",
                needToUpdateStatus: false,
                nextStatus: 702, //nextStatus主要控制要去哪一頁  
                mainStep: true,
                dataTypes: ["SensorRich", "Feature"]
            },
            {
                isShowStep: false,
                offline_model_status: 701,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["SensorRich", "Feature"]
            },
            {
                isShowStep: false,
                offline_model_status: 702,
                statusName: "Feature Selection",
                url: "/Project/FeatureSelection",
                needToUpdateStatus: false,
                nextStatus: 800, //nextStatus主要控制要去哪一頁  
                mainStep: false,
                dataTypes: ["SensorRich", "Feature"]
            },
            {
                isShowStep: false,
                offline_model_status: 703,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/Project/FeatureSelection",
                    updateStatus: 700,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["SensorRich", "Feature"]
            },
            {
                isShowStep: true,
                showStep: "6",
                title: "Modeling",
                offline_model_status: 800,
                statusName: "Modeling",
                url: "/Project/ModelResult",
                dataTypes: ["SensorRich", "Feature"]
            },
            {
                isShowStep: false,
                offline_model_status: 801,
                statusName: "Training Data",
                url: "/Project/WaitingandMailAlert",
                extensionInfo: {
                    backUrl: "/Project/ProjectList",
                    backUrlBtnName: "Back To ProjectList",
                    msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
                },
                dataTypes: ["SensorRich", "Feature"]
            },
            {
                isShowStep: false,
                offline_model_status: 802,
                statusName: "Model Result",
                url: "/Project/ModelResult",
                dataTypes: ["SensorRich", "Feature"]
            },
            {
                isShowStep: false,
                offline_model_status: 803,
                statusName: "Training Error",
                url: "/Error/Error",
                extensionInfo: {
                    needToResetStatus: true,
                    backUrlBtnName: "To Reset Data",
                    backUrl: "/Project/FeatureSelection",
                    updateStatus: 902,
                    msg: "Training Data Error,please reset data to training,thanks."
                },
                dataTypes: ["SensorRich", "Feature"]
            }



            //{
            //    isShowStep: true,
            //    showStep: "1",
            //    title: "Project Register",                            
            //    offline_model_status: 100,
            //    statusName: "Project Register",
            //    url: "/Project/ProjectInfo",
            //    needToUpdateStatus: true,
            //    nextStatus: 200,
            //    mainStep: true,
            //    dataTypes: ["SensorRich","Feature"]
            //},
            //{
            //    isShowStep: true,
            //    showStep: "2",
            //    title: "Upload File",      
            //    offline_model_status: 200,
            //    statusName: "Upload File",
            //    url: "/Project/UploadFiles",
            //    needToUpdateStatus: true,
            //    nextStatus: 300,
            //    mainStep: true,
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: true,
            //    showStep: "3",
            //    title: "Check Data",    
            //    offline_model_status: 300,
            //    statusName: "Check Data",
            //    url: "/Project/CheckData",
            //    needToUpdateStatus: true,
            //    nextStatus: 400,
            //    mainStep: true,
            //    dataTypes: ["SensorRich"]
            //},
            //{
            //    isShowStep: true,
            //    showStep: "4",
            //    title: "Frequency Transform",   
            //    offline_model_status: 400,
            //    statusName: "Frequency Transform",
            //    url: "/Project/FrequencyTransform",
            //    needToUpdateStatus: false,
            //    nextStatus: 410,
            //    mainStep: true,
            //    dataTypes: ["SensorRich"]            
            //},
            //{
            //    isShowStep: false,
            //    offline_model_status: 401,
            //    statusName: "Training Data",
            //    url: "/Project/WaitingandMailAlert",
            //    extensionInfo: {
            //        backUrl: "/Project/ProjectList",
            //        backUrlBtnName: "Back To ProjectList",
            //        msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
            //    },
            //    dataTypes: ["SensorRich"]               
            //},
            //{
            //    isShowStep: false,
            //    offline_model_status: 403,
            //    statusName: "Training Error",
            //    url: "/Error/Error",               
            //    extensionInfo: {
            //        needToResetStatus: true,
            //        backUrlBtnName:"To Reset Data",
            //        backUrl: "/Project/FrequencyTransform",
            //        updateStatus: 400,
            //        msg:"Training Data Error,please reset data to training,thanks."
            //    },
            //    dataTypes: ["SensorRich"]
            //},
            //{
            //    isShowStep: true,
            //    showStep: "",
            //    title: "Preview",
            //    offline_model_status: 410,
            //    statusName: "Preview",
            //    url: "/Project/FrequencyTransformPreview",
            //    needToUpdateStatus: true,
            //    nextStatus: 500,
            //    mainStep: true,
            //    dataTypes: ["SensorRich"]
            //},
            //{
            //    isShowStep: true,
            //    showStep: "5",
            //    title: "Feature Extraction",
            //    offline_model_status:500,
            //    statusName: "Feature Extraction",
            //    url: "/Project/FeatureExtraction",
            //    needToUpdateStatus: false,
            //    nextStatus: 510,
            //    mainStep: true,
            //    dataTypes: ["SensorRich"]
            //},
            //{
            //    isShowStep: false,             
            //    offline_model_status:501,
            //    statusName: "Training Data",
            //    url: "/Project/WaitingandMailAlert",
            //    extensionInfo: {
            //        backUrl: "/Project/ProjectList",
            //        backUrlBtnName: "Back To ProjectList",
            //        msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
            //    },
            //    dataTypes: ["SensorRich"]
            //},
            //{
            //    isShowStep: false,              
            //    offline_model_status:503,
            //    statusName: "Training Error",
            //    url: "/Error/Error",              
            //    extensionInfo: {
            //        needToResetStatus: true,
            //        backUrlBtnName: "To Reset Data",
            //        backUrl: "/Project/FeatureExtraction",
            //        updateStatus: 500,
            //        msg: "Training Data Error,please reset data to training,thanks."
            //    },
            //    dataTypes: ["SensorRich"]
            //},
            //{
            //    isShowStep: true,
            //    showStep: "",
            //    title: "Preview",
            //    offline_model_status: 510,
            //    statusName: "Preview",
            //    url: "/Project/FeatureExtractionPreview",
            //    needToUpdateStatus: true,
            //    nextStatus: 600,
            //    mainStep: true,
            //    dataTypes: ["SensorRich"]
            //},
            //{
            //    isShowStep: true,
            //    showStep: "6",
            //    title: "Data Labeling",
            //    offline_model_status: 600,
            //    statusName: "Data Labeling",
            //    url: "/Project/DataLabeling",
            //    needToUpdateStatus: false,
            //    nextStatus: 602,
            //    mainStep: false,
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: false,
            //    offline_model_status: 601,
            //    statusName: "Training Data",
            //    url: "/Project/WaitingandMailAlert",
            //    extensionInfo: {
            //        backUrl: "/Project/ProjectList",
            //        backUrlBtnName: "Back To ProjectList",
            //        msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
            //    },
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: false,
            //    offline_model_status: 602,
            //    statusName: "Data Labeling",
            //    url: "/Project/DataLabeling",
            //    needToUpdateStatus: true,
            //    nextStatus: 700,
            //    mainStep: true,
            //    dataTypes: ["SensorRich", "Feature"]
               
            //},
            //{
            //    isShowStep: false,
            //    offline_model_status: 603,
            //    statusName: "Training Error",
            //    url: "/Error/Error",               
            //    extensionInfo: {
            //        needToResetStatus: true,
            //        backUrlBtnName: "To Reset Data",
            //        backUrl: "/Project/DataLabeling",
            //        updateStatus: 600,
            //        msg: "Training Data Error,please reset data to training,thanks."
            //    },
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: true,
            //    showStep: "7",
            //    title: "Split Data",
            //    offline_model_status: 700,
            //    statusName: "Split Data",
            //    url: "/Project/SplitData",
            //    needToUpdateStatus: false,
            //    nextStatus: 800, //nextStatus主要控制要去哪一頁  
            //    mainStep: true,
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: true,
            //    showStep: "8",
            //    title: "XDI Check",
            //    offline_model_status: 800,
            //    statusName: "XDI Check",
            //    url: "/Project/XDICheck",
            //    needToUpdateStatus: false,
            //    nextStatus: 802, //nextStatus主要控制要去哪一頁  
            //    mainStep: false,
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: false,
            //    offline_model_status: 801,
            //    statusName: "Training Data",
            //    url: "/Project/WaitingandMailAlert",
            //    extensionInfo: {
            //        backUrl: "/Project/ProjectList",
            //        backUrlBtnName: "Back To ProjectList",
            //        msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
            //    },
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: false,
            //    offline_model_status: 802,
            //    statusName: "XDI Check",
            //    url: "/Project/XDICheck",
            //    needToUpdateStatus: true,               
            //    nextStatus: 900, //nextStatus主要控制要去哪一頁  
            //    mainStep: true,
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: false,
            //    offline_model_status: 803,
            //    statusName: "Training Error",
            //    url: "/Error/Error",               
            //    extensionInfo: {
            //        needToResetStatus: true,
            //        backUrlBtnName: "To Reset Data",
            //        backUrl: "/Project/XDICheck",
            //        updateStatus: 700,
            //        msg: "Training Data Error,please reset data to training,thanks."
            //    },
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: true,
            //    showStep: "9",
            //    title: "Feature Selection",
            //    offline_model_status: 900,
            //    statusName: "Feature Selection",
            //    url: "/Project/FeatureSelection",
            //    needToUpdateStatus: false,
            //    nextStatus: 902, //nextStatus主要控制要去哪一頁  
            //    mainStep: false,
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: false,
            //    offline_model_status: 902,
            //    statusName: "Feature Selection",
            //    url: "/Project/FeatureSelection",
            //    needToUpdateStatus: false,
            //    nextStatus: 1000, //nextStatus主要控制要去哪一頁  
            //    mainStep: true,
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: false,
            //    offline_model_status: 903,
            //    statusName: "Training Error",
            //    url: "/Error/Error",
            //    extensionInfo: {
            //        needToResetStatus: true,
            //        backUrlBtnName: "To Reset Data",
            //        backUrl: "/Project/FeatureSelection",
            //        updateStatus: 900,
            //        msg: "Training Data Error,please reset data to training,thanks."
            //    },
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: true,
            //    showStep: "10",
            //    title: "Model Result",
            //    offline_model_status: 1000,
            //    statusName: "Model Result",
            //    url: "/Project/ModelResult",
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: false,
            //    offline_model_status: 1001,
            //    statusName: "Training Data",
            //    url: "/Project/WaitingandMailAlert",
            //    extensionInfo: {
            //        backUrl: "/Project/ProjectList",
            //        backUrlBtnName: "Back To ProjectList",
            //        msg: 'This step requires a long processing time.At present, the system is working on it, and the notification will be sent by email after completion.'
            //    },
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: false,
            //    offline_model_status: 1002,
            //    statusName: "Model Result",
            //    url: "/Project/ModelResult",
            //    dataTypes: ["SensorRich", "Feature"]
            //},
            //{
            //    isShowStep: false,
            //    offline_model_status: 1003,
            //    statusName: "Training Error",
            //    url: "/Error/Error",              
            //    extensionInfo: {
            //        needToResetStatus: true,
            //        backUrlBtnName: "To Reset Data",
            //        backUrl: "/Project/FeatureSelection",
            //        updateStatus: 902,
            //        msg: "Training Data Error,please reset data to training,thanks."
            //    },
            //    dataTypes: ["SensorRich", "Feature"]
            //}

        ]
        
    },
    mounted: function () {       
        var self = this;   
        self.showLoading = true;
        self.init();        
    },
    watch: {
        currentProjectId: function (value) {
            window.localStorage.setItem('projectid', value);
        },
        currentModelId: function (value) {
            window.localStorage.setItem('modelid', value);
        },
        currentModelType: function (value) {
            window.localStorage.setItem('modeltype', value);
        },
        currentDataType: function (value) {
            window.localStorage.setItem('datatype', value);
        }
    },   
    created: function () {
        
    },
    methods: {        
        init: function () {          
            var self = this; 
            if (window.location.href.toLowerCase().includes("/project/projectlist") || window.location.href.toLowerCase().includes("/home/")) {
                self.clearLocalStorage();
            }
            else if (window.location.href.toLowerCase().includes("/error/error") || window.location.href.toLowerCase().includes("/waitingandmailalert")  ) {
                self.setProjectId();
                self.setModelId();               
            }  
            else {
                self.setProjectId(function () {
                    self.setModelId();  

                    if (self.currentProjectId) {

                        self.getProjectInfo(function () {
                            self.redriectPage();
                            self.getCreateProjectHeader();
                        });
                    } else {
                        if (self.currentProjectStatus == 0 && window.location.href.toLowerCase().includes("/project/projectinfo")) {
                            self.currentProjectStatus = 100
                        }
                        else {
                            //如果ProjectId=='' 而且不是在ProjectInfo頁 先轉導到ProjectList
                            //window.location.href = "/Project/ProjectList"
                        }
                        self.getCreateProjectHeader();
                    }
                });               
              
            }
        },    

        getCreateProjectHeader: function () {
            var self = this;            
            self.createProjectStepInfo = [];

            self.statusInfos.forEach(function (item) {

                if (item.isShowStep == true) {                 
                                   
                    var className = item.url == window.location.pathname ? 'current' : (self.currentProjectStatus < item.offline_model_status || (self.currentDataType != "" && item.dataTypes.indexOf(self.currentDataType) == -1 ) ? 'disabled' : 'active');
                    
                    self.createProjectStepInfo.push({
                        title: item.title,
                        showStep: item.showStep,
                        className: className,
                        url: item.url
                    });
                }
            });
        },


        //清除瀏覽器LocalStorage
        clearLocalStorage: function (fn) {
            var self = this; 
            self.currentProjectId = '';
            self.currentModelId = '';
            self.currentModelType = '';
            self.currentProjectStatus = '';
            window.localStorage.setItem('projectid', '');
            window.localStorage.setItem('modelid', '');
            window.localStorage.setItem('modeltype', '');
            window.localStorage.setItem('datatype', '');
            //window.localStorage.setItem('projectStatus', '');
            if (fn) {
                fn()
            }
        },

        //設定ProjectId
        setProjectId: function (fn) {    

            var self = this;           

            console.log("href:" + window.location.href.toLowerCase());
            var projectId = self.getUrlParameterByName('projectid', window.location.href.toLowerCase());



            console.log("projectId:" + projectId);
            if (projectId) {
                self.currentProjectId = projectId;    

                if (fn)
                    fn();
                return;
            }         
         
            console.log("projectId2:" + self.currentProjectId);
            if (!self.currentProjectId)
                self.currentProjectId = window.localStorage.getItem('projectid');  

            console.log("projectId3:" + self.currentProjectId); 

            if (fn)
                fn();

        },

        //設定ModelId
        setModelId: function () {          
            var self = this;
            var modelId = self.getUrlParameterByName('modelid', window.location.href.toLowerCase());

            if (modelId != null) {
                self.currentModelId = modelId;
            }          

            if (self.currentModelId == '')
                self.currentModelId = window.localStorage.getItem('modelid')

        },       

        //取得Url連結的Param
        getUrlParameterByName: function (name, url) {
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return "";
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        },

        //處理Error Log
        logError: function (error) {
            var msg = "";
            if (error.isAxiosError) {
                msg = "[RequestUrl:" + error.request.responseURL + "][ResponseStatus:" + error.response.status + "][Message:" + error.message + "]";
            }
            else {
                msg = "[" + error.toString() + "][" + error.stack+"]";
            }
            $.ajax({
                type: 'POST',
                url: "/api/Log/Error",
                data: {
                    '': msg
                } 
            });           

        },      

        //確認轉導的頁面
        redriectPage: function (isForceRedirect) {

            var self = this;
            var pageInfo = self.statusInfos.find(function (page) {
                return page.offline_model_status == self.currentProjectStatus;
            });          

           

           

            setTimeout(function () {
                var projectId = self.getUrlParameterByName('projectid', window.location.href.toLowerCase());
                var modelId = self.getUrlParameterByName('modelid', window.location.href.toLowerCase());

                var url = pageInfo.url;

                if (projectId)
                    url = url + "?projectid=" + projectId + "&modelid=" + modelId;

                if (isForceRedirect) {
                    window.location.href = url;
                }
                   

                if (pageInfo.extensionInfo) {
                    window.location.href = url;
                }    

            }, 100);                 
        },

        //呼叫Project [post] 取得Project資訊
        getProjectInfo: function (fn) {            

            var self = this;

            //if (!self.currentProjectId) {
            //    alert("getProjectInfo:" + self.currentProjectId)
            //    return;
            //}
               

            //var apiUrl = "/project";

            ////用來模擬API的資料，實際上線不會執行這段
            //let mock = new AxiosMockAdapter(axios);
            //mock.onGet(apiUrl).reply(200, {
            //    code: 200,
            //    data: {
            //        total_count: 1,
            //        project_list: [
            //            {
            //                ai365_project_name: "qqq",
            //                application: "Robot",
            //                fab: "L5C",
            //                function: "GGG",
            //                itime: "2019-12-31 11:02:03",
            //                model_id: 5,
            //                model_type: "Health Assessment",
            //                offline_model_status: 100,                       
            //                stage: "Array",
            //                tool_type: "Test",
            //                project_id: 4,
            //                user_empno: "ewrt"
            //            }]
            //    },
            //    description: "Get Project list success",
            //    status: "OK"
            //});



            //if (self.env == 'prd') {
            //    mock.restore();            }

          
            //axios({
            //    method: 'get',
            //    baseURL: self.apiUrlDomain,
            //    url: apiUrl,
            //    params: {
            //        "project_id": self.currentProjectId
            //    }})
            //    .then(function (response) {
            //        if (response.data.status == "OK") {
            //            if (response.data.data.project_list[0]) {
            //                self.currentModelType = response.data.data.project_list[0].model_type;
            //                self.currentProjectStatus = response.data.data.project_list[0].offline_model_status;
            //                self.currentDataType = response.data.data.project_list[0].data_type;
            //                self.currentProjectInfo = response.data.data.project_list[0];
            //                if (fn) {
            //                    fn();
            //                }
            //            }                       
            //        }
            //        else
            //            alertify.error("get data fail. error message = " + response.data.data.message);
            //    })        



            $.ajax({
                type: 'get',
                async: false,
                url: self.apiUrlDomain +"/project",
                data: {
                    "project_id": self.currentProjectId
                },
                success: function (response) {
                    
                    if (response.data.project_list[0]) {
                        self.currentModelType = response.data.project_list[0].model_type;
                        self.currentProjectStatus = response.data.project_list[0].offline_model_status;
                        self.currentDataType = response.data.project_list[0].data_type;
                        self.currentProjectInfo = response.data.project_list[0];
                        if (fn) {
                            fn();
                        }
                    }
                  
                },
                dataType:"json"
            });
        },

        //控制下一步的轉導頁與是否更新狀態
        nextStatus: function () {     
            var self = this;
            self.showLoading = true;
          
            //取得當前的頁面資訊
            var pathName = window.location.pathname;
            var index = self.statusInfos.findIndex(function (page) {
                return page.url == pathName && page.mainStep == true;
            });
            var pageInfo = self.statusInfos[index];


            var nextStatusIndex = self.getNextStatusIndex(pageInfo.nextStatus);
            var nextPageInfo = self.statusInfos[nextStatusIndex];

            //判斷是否需要呼叫更新狀態API
            if (!pageInfo.needToUpdateStatus) {
                window.location.href = nextPageInfo.url;
                return;
            }            


            //呼叫更新狀態API
            var apiUrl = "/model_training";     
            axios({
                method: 'put',
                baseURL: self.apiUrlDomain,
                url: apiUrl,
                data: {
                    project_id: self.currentProjectId,
                    model_id: self.currentModelId,
                    offline_model_status: nextPageInfo.offline_model_status
                }
            })
            .then(function (response) {
                if (response.data.status == "OK")
                    window.location.href = nextPageInfo.url;
                else
                    alertify.alert("操作失敗，請重新操作，謝謝!");
            })          
           
        },


        getNextStatusIndex: function (status) {
            var self = this;
            var nextStatusIndex = self.statusInfos.findIndex(function (page) {
                return page.offline_model_status == status;
            });

            if (!self.currentDataType)
                self.currentDataType = window.localStorage.getItem('datatype');                   
        
            if (self.statusInfos[nextStatusIndex].dataTypes.indexOf(self.currentDataType) <= -1) {    
                return self.getNextStatusIndex(self.statusInfos[nextStatusIndex].nextStatus);
            }
            else
                return nextStatusIndex;
        }
    }
});


//window.addEventListener('beforeunload', function (e) {
//    e.preventDefault();
//    return confirm("Do you really want to close?") 
//});


//監聽頁面出現的錯誤
window.onerror = function (error) { 
    LayoutApp.showLoading = false;
    LayoutApp.logError(error);
};

//監聽在Vue內發生的錯誤
Vue.config.errorHandler = function (error) {    
    LayoutApp.showLoading = false;
    LayoutApp.logError(error);
    //alertify.error(error);
}

//監聽axios發生的錯誤
axios.interceptors.response.use(function (response) {
    return response;
}, function (error) {
    LayoutApp.logError(error);

    LayoutApp.showLoading = false;    
    if (error.response.data.status) {
        alertify.error(error.response.data.description);
    }
   
    return Promise.reject(error) // this is the important part
})
