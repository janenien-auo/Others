﻿Vue.use(VeeValidate);

var CreateProjectLayoutContiApp = new Vue({
    el: "#CreateProjectLayoutContiApp",
    store: store,
    data: {
        createProjectStepInfo: [],
        currentPageInfo: {},
        showChangeStatus: false,
        modelStatus: false,
        showStatusChangeDialog: false,
        StatusChangeDialogTitle: '',
        estoneGroupList: [],
        estoneGroup: [],
        isCanModify: true
    },
    computed: {
        showLoading: function () {
            return this.$store.getters.getShowLoading
        }
    },
    mounted: function () {
        var self = this;
        self.init();
    },
    methods: {
        init: function () {
            var self = this;

            store.commit('setShowLoading', true);
            store.commit("setDefaultProjectId");
            store.commit("setDefaultModelId");
            store.commit("setProjectInfo");
            self.getCreateProjectStepInfo();

            if (store.getters.getOfflineModelStatus < 1000) {
                //for project/ProjectList link
                self.currentPageInfo = store.getters.getStatusInfosConti.find(function (page) {
                    return page.offline_model_status == 1500;
                });
            } else {
                self.currentPageInfo = store.getters.getStatusInfosConti.find(function (page) {
                    return page.offline_model_status == store.getters.getOfflineModelStatus;
                });
            }

            //store.commit("setProjectInfo", null);  


            //if ((self.currentPageInfo.offline_model_status == 1202 || self.currentPageInfo.offline_model_status == 1302 || self.currentPageInfo.offline_model_status == 1402 || self.currentPageInfo.offline_model_status == 1502)
            //    && (store.getters.getProjectStatus == "create" || store.getters.getProjectStatus == "offline")
            //    && (window.location.pathname.toLocaleLowerCase().indexOf('segmentation') > 0 || window.location.pathname.toLocaleLowerCase().indexOf('featureengineering') > 0 || window.location.pathname.toLocaleLowerCase().indexOf('datafilter') > 0)) {
            //    self.showChangeStatus = true;
            //}
            //else {
            //    self.showChangeStatus = false;
            //}


            if ((self.currentPageInfo.offline_model_status == 1502)
                && (store.getters.getProjectStatus == "create" || store.getters.getProjectStatus == "offline")
                && (window.location.pathname.toLocaleLowerCase().indexOf('datalabeling') > 0)) {
                self.showChangeStatus = true;
            }
            else {
            self.showChangeStatus = false;
            }


            if (store.getters.getOfflineModelStatus == 0 && window.location.href.toLowerCase().includes("/project/projectinfo")) {
                store.commit('setOfflineModelStatus', 100);
            }
            else {
                self.redriectPage();
            }

        },

        getCreateProjectStepInfo: function () {
            var self = this;
            self.createProjectStepInfo = [];

            store.getters.getStatusInfosConti.forEach(function (item) {

                if (item.isShowStep == true) {

                    //var className = item.url == window.location.pathname ? 'current' :
                    //    (store.getters.getOfflineModelStatus < item.offline_model_status
                    //        || (store.getters.getCurrentDataType != "" && item.dataTypes.indexOf(store.getters.getCurrentDataType) == -1) ? 'disabled' : 'active');
                    var className = item.url == window.location.pathname ? 'current' :
                        (store.getters.getOfflineModelStatus < item.offline_model_status ? 'disabled' : 'active');
                    
                    if (store.getters.getOfflineModelStatus < 1000) {
                        if (item.url == window.location.pathname)
                            className = 'current';
                        else
                            className = 'active';
                    }
                    self.createProjectStepInfo.push({
                        title: item.title,
                        showStep: item.showStep,
                        className: className,
                        url: item.url
                    });
                }
            });
        },

        //確認轉導的頁面
        redriectPage: function (isForceRedirect, redirectUrl) {

            var self = this;



            setTimeout(function () {
                var projectId = getUrlParameterByName('projectid', window.location.href.toLowerCase());
                var modelId = getUrlParameterByName('modelid', window.location.href.toLowerCase());

                var url = self.currentPageInfo.url;

                if (!projectId) {
                    projectId = store.getters.getCurrentProjectId;
                }

                if (!modelId) {
                    modelId = store.getters.getCurrentModelId;
                }

                if (projectId) {
                    url = url + "?projectid=" + projectId + "&modelid=" + modelId;
                }

                if (redirectUrl)
                    redirectUrl = redirectUrl + "?projectid=" + projectId + "&modelid=" + modelId;


                if (isForceRedirect) {
                    if (redirectUrl)
                        window.location.href = redirectUrl;
                    else
                        window.location.href = url;
                }


                if (self.currentPageInfo.extensionInfo) {
                    window.location.href = url;
                }

            }, 100);
        },


        //控制下一步的轉導頁與是否更新狀態
        nextStatus: function () {
            var self = this;
            store.commit('setShowLoading', true);

            //取得當前的頁面資訊
            var pathName = window.location.pathname;
            var index = store.getters.getStatusInfosConti.findIndex(function (page) {
                return page.url == pathName && page.mainStep == true;
            });
            var pageInfo = store.getters.getStatusInfosConti[index];


            var nextStatusIndex = self.getNextStatusIndex(pageInfo.nextStatus);
            var nextPageInfo = store.getters.getStatusInfosConti[nextStatusIndex];

            //判斷是否需要呼叫更新狀態API
            if (!pageInfo.needToUpdateStatus) {
                window.location.href = nextPageInfo.url;
                return;
            }


            //呼叫更新狀態API
            var apiUrl = "/model_training";
            axios({
                method: 'put',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    offline_model_status: nextPageInfo.offline_model_status
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.redriectPage(true, nextPageInfo.url);
                    }
                    else
                        alertify.alert("操作失敗，請重新操作，謝謝!");
                })

        },


        getNextStatusIndex: function (status) {
            var self = this;
            var nextStatusIndex = store.getters.getStatusInfosConti.findIndex(function (page) {
                return page.offline_model_status == status;
            });

            //if (!self.currentDataType)
            //    self.currentDataType = window.localStorage.getItem('datatype');                   
            if (store.getters.getOfflineModelStatus <= 600) {

            } else {
                if (store.getters.getStatusInfosConti[nextStatusIndex].dataTypes.indexOf(store.getters.getCurrentDataType) <= -1) {
                    return self.getNextStatusIndex(store.getters.getStatusInfosConti[nextStatusIndex].nextStatus);
                }
                else
                    return nextStatusIndex;
            }
        },


        //控制前一步的轉導頁與是否更新狀態
        backStatus: function () {
            var self = this;
            store.commit('setShowLoading', true);

            //取得當前的頁面資訊
            var pathName = window.location.pathname;
            var index = store.getters.getStatusInfosConti.findIndex(function (page) {
                return page.url == pathName && page.mainStep == true;
            });
            var pageInfo = store.getters.getStatusInfosConti[index];


            var backStatusIndex = self.getBackStatusIndex(pageInfo.offline_model_status);
            var backPageInfo = store.getters.getStatusInfosConti[backStatusIndex];

            window.location.href = backPageInfo.url;
        },

        //找前一步的狀態資訊
        getBackStatusIndex: function (status) {
            var self = this;
            var currentStatusIndex = store.getters.getStatusInfosConti.findIndex(function (page) {
                return page.offline_model_status == status;
            });

            var backStatusIndex = currentStatusIndex - 1;

            //if (!self.currentDataType)
            //    self.currentDataType = window.localStorage.getItem('datatype');                   

            if (store.getters.getStatusInfosConti[backStatusIndex].dataTypes.indexOf(store.getters.getCurrentDataType) <= -1 || !store.getters.getStatusInfosConti[backStatusIndex].mainStep) {
                return self.getBackStatusIndex(store.getters.getStatusInfosConti[backStatusIndex].offline_model_status);
            }
            else
                return backStatusIndex;
        },


        //更改Model狀態
        clickChangeStatus: function () {
            var self = this;
            self.getEStoneGroupList();
            self.StatusChangeDialogTitle = self.modelStatus ? 'Are you sure turn on the model to online?' : 'Are you sure turn off the model to offline?';
            self.showStatusChangeDialog = true;
        },

        //取得EStone的發送群組
        getEStoneGroupList: function () {

            var self = this;

            estoneGroupList({
                user_id: UserInfoApp.userInfo.UserId
            },
                store.getters.getIsApiTest).then(function (response) {
                    self.estoneGroupList = response.data.data.group_list;
                })

        },

        //取消更新
        cancelStatusChange: function () {
            var self = this;
            self.modelStatus = !self.modelStatus;
            self.showStatusChangeDialog = false;
        },

        //確定更新
        confirmStatusChange: function () {
            var self = this;


            this.$validator.validateAll().then(function (result) {
                if (result) {
                    self.updateProjectOnline();
                    self.showStatusChangeDialog = false;
                }
                else {
                    alertify.error('欄位資料填寫錯誤');
                }
            })
        },

        //呼叫UpdateProject API
        updateProjectOnline: function () {

            var self = this;

            //var alarm_notify_group_name_list = [];
            //alarm_notify_group_name_list.push(self.estoneGroup);

            var data = {
                project_id: store.getters.getCurrentProjectId,
                model_id: store.getters.getCurrentModelId,
                user_id: UserInfoApp.userInfo.UserId,
                alarm_notify_group_name_list: self.estoneGroup
            };

            updateProjectOnline(data, false)
                .then(function (response) {
                    alertify.alert("更新成功");

                    window.location = "/online/onlinemodellist?fab=" + store.getters.getCurrentProjectInfo.fab + "&stage=" + store.getters.getCurrentProjectInfo.stage + "&func=" + store.getters.getCurrentProjectInfo.func;
                })
                .catch(function () {
                    self.modelStatus = false;
                })
        },

        closeDialog: function () {
            var self = this;
            self.modelStatus = !self.modelStatus;

        }
    }
});




