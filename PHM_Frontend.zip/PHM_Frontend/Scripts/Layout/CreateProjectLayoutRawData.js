﻿Vue.use(VeeValidate);

var CreateProjectLayoutRawDataApp = new Vue({
    el: "#CreateProjectLayoutRawDataApp",
    store: store,
    data: {
        createProjectStepInfo: [],
        currentPageInfo: {},
        showChangeStatus: false,
        modelStatus: false,
        showStatusChangeDialog: false,
        StatusChangeDialogTitle: '',
        estoneGroupList: [],
        estoneGroup: [],
        isCanModify: true
    },
    computed: {
        showLoading: function () {
            return this.$store.getters.getShowLoading
        }
    },
    mounted: function () {
        var self = this;
        self.init();
    },
    methods: {
        init: function () {
            var self = this;

            store.commit('setShowLoading', true);
            store.commit("setDefaultProjectId");
            store.commit("setDefaultModelId");
            store.commit("setProjectInfo");
            self.getCreateProjectStepInfo();

            if (store.getters.getOfflineModelStatus < 2000) {
                //for project/ProjectList link
                self.currentPageInfo = store.getters.getStatusInfosRawData.find(function (page) {
                    return page.offline_model_status == 2000;
                });
            } else {
                self.currentPageInfo = store.getters.getStatusInfosRawData.find(function (page) {
                    return page.offline_model_status == store.getters.getOfflineModelStatus;
                });
            }

           


            

        },

        getCreateProjectStepInfo: function () {
            var self = this;
            self.createProjectStepInfo = [];

            store.getters.getStatusInfosRawData.forEach(function (item) {

                if (item.isShowStep == true) {

                    //var className = item.url == window.location.pathname ? 'current' :
                    //    (store.getters.getOfflineModelStatus < item.offline_model_status
                    //        || (store.getters.getCurrentDataType != "" && item.dataTypes.indexOf(store.getters.getCurrentDataType) == -1) ? 'disabled' : 'active');
                    var className = item.url == window.location.pathname ? 'current' :
                        (store.getters.getOfflineModelStatus < item.offline_model_status ? 'disabled' : 'active');
                    
                    if (store.getters.getOfflineModelStatus < 1000) {
                        if (item.url == window.location.pathname)
                            className = 'current';
                        else
                            className = 'active';
                    }
                    self.createProjectStepInfo.push({
                        title: item.title,
                        showStep: item.showStep,
                        className: className,
                        url: item.url
                    });
                }
            });
        },

        //確認轉導的頁面
        redriectPage: function (isForceRedirect, redirectUrl) {

            var self = this;



            setTimeout(function () {
                var projectId = getUrlParameterByName('projectid', window.location.href.toLowerCase());
                var modelId = getUrlParameterByName('modelid', window.location.href.toLowerCase());

                var url = self.currentPageInfo.url;

                if (!projectId) {
                    projectId = store.getters.getCurrentProjectId;
                }

                if (!modelId) {
                    modelId = store.getters.getCurrentModelId;
                }

                if (projectId) {
                    url = url + "?projectid=" + projectId + "&modelid=" + modelId;
                }

                if (redirectUrl)
                    redirectUrl = redirectUrl + "?projectid=" + projectId + "&modelid=" + modelId;


                if (isForceRedirect) {
                    if (redirectUrl)
                        window.location.href = redirectUrl;
                    else
                        window.location.href = url;
                }


                if (self.currentPageInfo.extensionInfo) {
                    window.location.href = url;
                }

            }, 100);
        },


        //控制下一步的轉導頁與是否更新狀態
        nextStatus: function () {
            var self = this;
            store.commit('setShowLoading', true);

            //取得當前的頁面資訊
            var pathName = window.location.pathname;
            var index = store.getters.getStatusInfosRawData.findIndex(function (page) {
                return page.url.toLowerCase() == pathName.toLowerCase() && page.mainStep == true;
            });
            var pageInfo = store.getters.getStatusInfosRawData[index];


            var nextStatusIndex = self.getNextStatusIndex(pageInfo.nextStatus);
            var nextPageInfo = store.getters.getStatusInfosRawData[nextStatusIndex];

            //判斷是否需要呼叫更新狀態API
            if (!pageInfo.needToUpdateStatus) {
                window.location.href = nextPageInfo.url;
                return;
            }


            //呼叫更新狀態API
            var apiUrl = "/model_training"; 

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPut(apiUrl).reply(200, {
                "data": {},
                "code": 200,
                "description": "",
                "status": "OK"
            });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }


            axios({
                method: 'put',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    offline_model_status: nextPageInfo.offline_model_status
                }
            })
                .then(function (response) {
                    if (response.data.status == "OK") {
                        self.redriectPage(true, nextPageInfo.url);
                    }
                    else
                        alertify.alert("操作失敗，請重新操作，謝謝!");
                })

        },


        getNextStatusIndex: function (status) {
            var self = this;
            var nextStatusIndex = store.getters.getStatusInfosRawData.findIndex(function (page) {
                return page.offline_model_status == status;
            });


            if (store.getters.getStatusInfosRawData[nextStatusIndex].dataTypes.indexOf(store.getters.getCurrentDataType) <= -1) {
                return self.getNextStatusIndex(store.getters.getStatusInfosRawData[nextStatusIndex].nextStatus);
            }
            else
                return nextStatusIndex;

        },


        //控制前一步的轉導頁與是否更新狀態
        backStatus: function () {
            var self = this;
            store.commit('setShowLoading', true);

            //取得當前的頁面資訊
            var pathName = window.location.pathname;
            var index = store.getters.getStatusInfosRawData.findIndex(function (page) {
                return page.url == pathName && page.mainStep == true;
            });
            var pageInfo = store.getters.getStatusInfosRawData[index];


            var backStatusIndex = self.getBackStatusIndex(pageInfo.offline_model_status);
            var backPageInfo = store.getters.getStatusInfosRawData[backStatusIndex];

            window.location.href = backPageInfo.url;
        },

        //找前一步的狀態資訊
        getBackStatusIndex: function (status) {
            var self = this;
            var currentStatusIndex = store.getters.getStatusInfosRawData.findIndex(function (page) {
                return page.offline_model_status == status;
            });

            var backStatusIndex = currentStatusIndex - 1;

            //if (!self.currentDataType)
            //    self.currentDataType = window.localStorage.getItem('datatype');                   

            if (store.getters.getStatusInfosRawData[backStatusIndex].dataTypes.indexOf(store.getters.getCurrentDataType) <= -1 || !store.getters.getStatusInfosRawData[backStatusIndex].mainStep) {
                return self.getBackStatusIndex(store.getters.getStatusInfosRawData[backStatusIndex].offline_model_status);
            }
            else
                return backStatusIndex;
        },



   

        
    }
});




