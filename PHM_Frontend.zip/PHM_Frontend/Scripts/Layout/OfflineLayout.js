﻿Vue.use(VeeValidate);


var OfflineLayoutApp = new Vue({
    el: "#OfflineLayoutApp",
    store: store,
    data: {       
       
    },
    computed: {
        showLoading: function () {
            return this.$store.getters.getShowLoading
        }
    },
    created: function () {      
    },
    mounted: function () {
        var self = this;
        store.commit('setShowLoading', true);
        self.init();
    },
    methods: {
        init: function () { 
        },    

       
      
    }
});




