﻿Vue.use(VeeValidate);

var CreateProjectLayoutApp = new Vue({  
    el: "#CreateProjectLayoutApp", 
    store: store,
    data: {       
        createProjectStepInfo: [],  
        currentPageInfo: {},
        showChangeStatus:false,
        modelStatus: false,
        showStatusChangeDialog: false,
        StatusChangeDialogTitle:'',
        estoneGroupList: [],
        estoneGroup: [],
        isCanModify: true,
        isBadScoreLevel: false
    },
    computed: {
        showLoading:function() {
            return this.$store.getters.getShowLoading
        }      
    },   
    mounted: function () {  
        var self = this;       
        self.init();   
    },  
    methods: { 
        init: function () {          
            var self = this;    

            store.commit('setShowLoading', true);
            store.commit("setDefaultProjectId");
            store.commit("setDefaultModelId");
            store.commit("setProjectInfo");
            self.getCreateProjectStepInfo();

            self.currentPageInfo = store.getters.getStatusInfos.find(function (page) {
                return page.offline_model_status == store.getters.getOfflineModelStatus;
            });

            //store.commit("setProjectInfo", null);  

           
            if (self.currentPageInfo && self.currentPageInfo.offline_model_status == 802
                && (store.getters.getProjectStatus == "create" || store.getters.getProjectStatus == "offline")
                && window.location.pathname.toLocaleLowerCase().indexOf('modelresult') > 0) {              
                self.showChangeStatus = true;
            }           
            else {
                self.showChangeStatus = false;
            }


            if (store.getters.getOfflineModelStatus == 0 && window.location.href.toLowerCase().includes("/project/projectinfo")) {
                store.commit('setOfflineModelStatus', 100);
            }
            else {
                self.redriectPage();
            }
           
        },    

        getCreateProjectStepInfo: function () {
            var self = this;
            self.createProjectStepInfo = [];

            store.getters.getStatusInfos.forEach(function (item) {

                if (item.isShowStep == true) {

                    var className = item.url == window.location.pathname ? 'current' :
                        (store.getters.getOfflineModelStatus < item.offline_model_status
                            || (store.getters.getCurrentDataType != "" && item.dataTypes.indexOf(store.getters.getCurrentDataType) == -1) ? 'disabled' : 'active');


                    self.createProjectStepInfo.push({
                        title: item.title,
                        showStep: item.showStep,
                        className: className,
                        url: item.url
                    });
                }
            });
        },

        //確認轉導的頁面
        redriectPage: function (isForceRedirect,redirectUrl) {

            var self = this;

            //add by amanda 2020-10-29 14:35 取得當下project最新狀態
            store.commit("setProjectInfo");
            self.getCreateProjectStepInfo();

            self.currentPageInfo = store.getters.getStatusInfos.find(function (page) {
                return page.offline_model_status == store.getters.getOfflineModelStatus;
            });
 


            setTimeout(function () {
                var projectId = getUrlParameterByName('projectid', window.location.href.toLowerCase());
                var modelId = getUrlParameterByName('modelid', window.location.href.toLowerCase());

                var url = self.currentPageInfo.url;

                if (!projectId) {
                    projectId = store.getters.getCurrentProjectId;
                }

                if (!modelId) {
                    modelId = store.getters.getCurrentModelId;
                }

                if (projectId) {
                    url = url + "?projectid=" + projectId + "&modelid=" + modelId;                   
                }

                if (redirectUrl)
                    redirectUrl = redirectUrl + "?projectid=" + projectId + "&modelid=" + modelId;
                   

                if (isForceRedirect) {
                    if (redirectUrl)
                        window.location.href = redirectUrl;
                    else
                        window.location.href = url;
                }


                if (self.currentPageInfo.extensionInfo) {
                    window.location.href = url;

                }         

            }, 100);
        },   
              

        //控制下一步的轉導頁與是否更新狀態
        nextStatus: function () {     
            var self = this;
            store.commit('setShowLoading', true);     
          
            //取得當前的頁面資訊
            var pathName = window.location.pathname;
            var index = store.getters.getStatusInfos.findIndex(function (page) {
                return page.url == pathName && page.mainStep == true;
            });
            var pageInfo = store.getters.getStatusInfos[index];


            var nextStatusIndex = self.getNextStatusIndex(pageInfo.nextStatus);
            var nextPageInfo = store.getters.getStatusInfos[nextStatusIndex];

            //判斷是否需要呼叫更新狀態API
            if (!pageInfo.needToUpdateStatus) {
                window.location.href = nextPageInfo.url;
                return;
            }            


            //呼叫更新狀態API
            var apiUrl = "/model_training"; 

            //用來模擬API的資料，實際上線不會執行這段
            let mock = new AxiosMockAdapter(axios);
            mock.onPut(apiUrl).reply(200, { "code": 200, "data": {}, "description": "Successful response", "status": "OK" });

            if (store.getters.getEnv == 'prd') {
                mock.restore();
            }


            axios({
                method: 'put',
                baseURL: store.getters.getOfflineApiUrl,
                url: apiUrl,
                data: {
                    project_id: store.getters.getCurrentProjectId,
                    model_id: store.getters.getCurrentModelId,
                    offline_model_status: nextPageInfo.offline_model_status
                }
            })
            .then(function (response) {
                if (response.data.status == "OK") {
                    self.redriectPage(true, nextPageInfo.url);                   
                }                   
                else
                    alertify.alert("操作失敗，請重新操作，謝謝!");
            })          
           
        },


        getNextStatusIndex: function (status) {
            var self = this;
            var nextStatusIndex = store.getters.getStatusInfos.findIndex(function (page) {
                return page.offline_model_status == status;
            });

            //if (!self.currentDataType)
            //    self.currentDataType = window.localStorage.getItem('datatype');                   
        
            if (store.getters.getStatusInfos[nextStatusIndex].dataTypes.indexOf(store.getters.getCurrentDataType) <= -1) {    
                return self.getNextStatusIndex(store.getters.getStatusInfos[nextStatusIndex].nextStatus);
            }
            else
                return nextStatusIndex;
        },


        //控制前一步的轉導頁與是否更新狀態
        backStatus: function () {
            var self = this;
            store.commit('setShowLoading', true);

            //取得當前的頁面資訊
            var pathName = window.location.pathname;
            var index = store.getters.getStatusInfos.findIndex(function (page) {
                return page.url == pathName && page.mainStep == true;
            });
            var pageInfo = store.getters.getStatusInfos[index];


            var backStatusIndex = self.getBackStatusIndex(pageInfo.offline_model_status);
            var backPageInfo = store.getters.getStatusInfos[backStatusIndex];

            window.location.href = backPageInfo.url;
        },

        //找前一步的狀態資訊
        getBackStatusIndex: function (status) {
            var self = this;
            var currentStatusIndex = -1;            

            //新增Conti回前一步的邏輯
            if (store.getters.getCurrentDataType == "Continuous") {

                currentStatusIndex = store.getters.getstatusInfosConti.findIndex(function (page) {
                    return page.offline_model_status == status;
                });

                if (currentStatusIndex > -1) {
                    var backStatusIndex = currentStatusIndex - 1;                     

                    if (store.getters.getStatusInfosConti[backStatusIndex].dataTypes.indexOf(store.getters.getCurrentDataType) <= -1 || !store.getters.getStatusInfosConti[backStatusIndex].mainStep) {
                        return self.getBackStatusIndex(store.getters.getStatusInfosConti[backStatusIndex].offline_model_status);
                    }                  
                    else
                        return backStatusIndex;
                }
            }
                      

            //新增rawdata回前一步的邏輯
            if (store.getters.getCurrentDataType == "raw_data") {

                currentStatusIndex = store.getters.getStatusInfosRawData.findIndex(function (page) {
                    return page.offline_model_status == status;
                });

                if (currentStatusIndex > -1) {
                    var backStatusIndex = currentStatusIndex - 1;

                    if (store.getters.getStatusInfosRawData[backStatusIndex].dataTypes.indexOf(store.getters.getCurrentDataType) <= -1 || !store.getters.getStatusInfosRawData[backStatusIndex].mainStep) {
                        return self.getBackStatusIndex(store.getters.getStatusInfosRawData[backStatusIndex].offline_model_status);
                    }
                    else
                        return backStatusIndex;
                }
            }

            //如果狀態不在Rawdata和Conti那表示在主狀態
            currentStatusIndex = store.getters.getStatusInfos.findIndex(function (page) {
                return page.offline_model_status == status;
            });

            var backStatusIndex = currentStatusIndex - 1;           
           

            if (store.getters.getStatusInfos[backStatusIndex].dataTypes.indexOf(store.getters.getCurrentDataType) <= -1 || !store.getters.getStatusInfos[backStatusIndex].mainStep) {
                return self.getBackStatusIndex(store.getters.getStatusInfos[backStatusIndex].offline_model_status);
            }
            else
                return backStatusIndex;
        },


        //更改Model狀態
        clickChangeStatus: function () {
            var self = this;
            self.getEStoneGroupList();
            self.StatusChangeDialogTitle = self.modelStatus ? 'Are you sure turn on the model to online?' : 'Are you sure turn off the model to offline?';
            self.showStatusChangeDialog = true;  
        },

        //取得EStone的發送群組
        getEStoneGroupList: function () {

            var self = this;

            estoneGroupList({
                    user_id: UserInfoApp.userInfo.UserId
                },
                store.getters.getIsApiTest).then(function (response) {
                    self.estoneGroupList = response.data.data.group_list;
                })   
                                  
        },

        //取消更新
        cancelStatusChange: function () {
            var self = this;
            self.modelStatus = !self.modelStatus;
            self.showStatusChangeDialog = false;
        },

        //確定更新
        confirmStatusChange: function () {
            var self = this;


            this.$validator.validateAll().then(function (result) {
                if (result) {                    
                    self.updateProjectOnline();
                    self.showStatusChangeDialog = false;
                }
                else {
                    alertify.error('欄位資料填寫錯誤');
                }
            })            
        },

        //呼叫UpdateProject API
        updateProjectOnline: function () {
            
            var self = this;

            //var alarm_notify_group_name_list = [];
            //alarm_notify_group_name_list.push(self.estoneGroup);

            var data = {
                project_id: store.getters.getCurrentProjectId,
                model_id: store.getters.getCurrentModelId,
                user_id: UserInfoApp.userInfo.UserId,
                alarm_notify_group_name_list: self.estoneGroup
            };

            updateProjectOnline(data, false)
                .then(function (response) {
                    alertify.alert("更新成功");

                    window.location = "/online/onlinemodellist?fab=" + store.getters.getCurrentProjectInfo.fab + "&stage=" + store.getters.getCurrentProjectInfo.stage + "&func=" + store.getters.getCurrentProjectInfo.func;
                })
                .catch(function () {
                    self.modelStatus = false;
                }) 
        },

        closeDialog: function () {
            var self = this;
            self.modelStatus = !self.modelStatus;
          
        }
    }
});




