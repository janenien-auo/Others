﻿Vue.use(VeeValidate);


var OfflineLayoutContiApp = new Vue({
    el: "#OfflineLayoutContiApp",
    store: store,
    data: {

    },
    computed: {
        showLoading: function () {
            return this.$store.getters.getShowLoading
        }
    },
    created: function () {

    },
    mounted: function () {
        var self = this;
        store.commit('setShowLoading', true);
        self.init();
    },
    methods: {
        init: function () {

        },


    }
});




