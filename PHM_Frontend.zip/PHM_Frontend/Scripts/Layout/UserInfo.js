﻿//var logError = require('Log').logError;
//var getUrlParameterByName = require('UrlHelper').getUrlParameterByName;

var UserInfoApp = new Vue({
    el: "#UserInfoApp",   
    store:store,
    data: {      
        authKey: "",
        userInfo: {}
    },
    mounted: function () {
        var self = this;   
       

        self.checkAuthKey();

       

        self.authKey = store.getters.getAuthKey;
        self.userInfo = store.getters.getUserInfo;
    },
    watch: {      
        authKey: function (value) {
            window.localStorage.setItem('authkey', value);
        }
    },
    methods: {
        checkAuthKey: function () {
            store.dispatch("checkAuthKey");
        },  

        logout: function () {
            store.dispatch("logout");   
        } 
    }



});