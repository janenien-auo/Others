﻿Vue.use(VeeValidate);

var OnlineLayoutApp = new Vue({  
    el: "#OnlineLayoutApp", 
    store: store,
    data: {
        routers : {
            name: "Home",
            path: "/home/index",
            class: "fas fa-home",
            layer:1,
            children: [                         
                {
                    name: "Online Monitor",
                    path: "/online/onlinehome",
                    class: "fas fa-cube",
                    layer: 2,
                    children: [
                        {
                            name: "Tool List",
                            path: "/online/toollist",
                            class: "fas fa-tools",
                            layer: 3,
                            viewMode:"chart",
                            children: [
                                {
                                    name: "Tool Detail",
                                    path: "/online/tooldetail",
                                    class: "fas fa-tools",
                                    layer: 4,
                                    viewMode: "chart"
                                }
                            ]
                        }
                    ]
                },
                {
                    name: "Online Model List",
                    path: "/online/onlinemodellist",
                    class: "fas fa-cube",   
                    layer: 2,
                    children: [
                        {
                            name: "Tool Mapping",
                            path: "/online/toolmapping",
                            class: "fas fa-tools",
                            layer: 3,
                        },
                        {
                            name: "Data Health",
                            path: "/online/datahealth",
                            class: "fas fa-tools",
                            layer: 3,
                        },
                        {
                            name: "E-Stone Event List",
                            path: "/online/estoneeventlist",
                            class: "fas fa-tools",
                            layer: 3,
                            children: [
                                {
                                    name: "Close Estone",
                                    path: "/online/closeestone",
                                    class: "fas fa-tools",
                                    layer: 4
                                }
                            ]
                        },
                        {
                            name: "Record History",
                            path: "/online/recordhistory",
                            class: "fas fa-tools",
                            layer: 3,
                            children: [
                                {
                                    name: "Record Setting",
                                    path: "/online/recordsetting",
                                    class: "fas fa-tools",
                                    layer: 4
                                }
                            ]
                        }, 
                        {
                            name: "Tool List",
                            path: "/online/toollist",
                            class: "fas fa-tools",
                            viewMode: "list",
                            layer: 3,
                            children: [
                                {
                                    name: "Tool Detail",
                                    path: "/online/tooldetail",
                                    class: "fas fa-tools",
                                    viewMode: "list",
                                    layer: 4
                                }
                            ]
                        }
                    ]
                },
                {
                    name: "Training Materials",
                    path: "/home/trainingmaterials",
                    class: "fas fa-cube",
                    layer: 2
                },
                {
                    name: "Announcements",
                    path: "/home/announcement",
                    class: "fas fa-cube",
                    layer: 2
                }
            ]
        },
        currentRouters: [],
        isFindCurrentPath: false,
        fab: '',
        stage: '',
        func:'',
        toolId: '',      
        modelType: '',
        startTime: '',
        endTime: '',
        chamber:'',
        chambers: [],
        onlineHomeViewMode: 'chart',
        currenPages: [],
        needCheckLayer: false,
        preRouters:[]
    },
    computed: {
        showLoading:function() {
            return this.$store.getters.getShowLoading
        }      
    },
    watch: {
        fab: function (value) {
            if (value) {
                window.localStorage.setItem('fab', value);
            }          
        },
        stage: function (value) {
            window.localStorage.setItem('stage', value);
        },
        func: function (value) {
            window.localStorage.setItem('func', value);
        },
        toolId: function (value) {
            window.localStorage.setItem('toolId', value);
        },
        modelType: function (value) {
            window.localStorage.setItem('modelType', value);
        },
        chamber: function (value) {
            window.localStorage.setItem('chamber', value);
        },
        chambers: function (value) {
            window.localStorage.setItem('chambers', value);
        },
        startTime: function (value) {
            window.localStorage.setItem('startTime', value);
        },
        endTime: function (value) {
            window.localStorage.setItem('endTime', value);
        },
        onlineHomeViewMode: function (value) {
            window.localStorage.setItem('onlineHomeViewMode', value);
        }
    },      
    mounted: function () {       
        var self = this;   
        //store.commit('setShowLoading', true);  
        self.init();        
    },  
    methods: {        
        init: function () {
            var self = this;            
            self.setFab();
            self.setStage();
            self.setFunc();
            self.setToolId();
            self.setModelType();
            self.setChamber();
            self.setChambers();
            self.setStartTime();
            self.setEndTime();
            self.setOnlineHomeViewMode();
            self.currentRouters = [];
            self.getRouters(window.location.pathname.toLowerCase());
        }, 

        //取得路徑(給麵包屑用)
        getRouters: function (currentPath) {
            var self = this;

            self.currentRouters = [];    
            self.isFindCurrentPath = false;    

            self.currentRouters.push({
                name: self.routers.name,
                path: self.routers.path,
                class: self.routers.class
            });
            if (self.routers.path != currentPath) {              
                var currentPage = self.findCurrentPath(currentPath, self.routers.children, self.routers);
            }    
        },

        //協助查找路徑
        findCurrentPath: function (currentPath, pages, parent) {    

            var self = this;
            self.currenPages = pages;           

            pages.filter(function (item, index) {

                var checkviewMode = true;

                if (item.viewMode) {
                    checkviewMode = item.viewMode == self.onlineHomeViewMode ? true : false;
                }

                if (self.needCheckLayer) {
                    if (item.layer - 1 > self.currentRouters.length) {
                        self.currentRouters = self.preRouters.slice(0, item.layer - self.currentRouters.length);                        
                    }
                }


                if (item.path == currentPath && checkviewMode) {
                //if (item.path == currentPath) {
                    self.isFindCurrentPath = true;

                    self.currentRouters.push({
                        name: item.name,
                        path: item.path,
                        class: item.class
                    });
                    return item;
                }
                else {
                    if (self.isFindCurrentPath) return;

                    if (item.children) {
                        self.currentRouters.push({
                            name: item.name,
                            path: item.path,
                            class: item.class
                        });
                        return self.findCurrentPath(currentPath, item.children, item);
                    }
                    else {

                        if (self.currenPages.length - 1 == index) {
                           
                            self.preRouters = self.currentRouters;
                            self.currentRouters = [];
                             //第一層為首頁
                            self.currentRouters.push({
                                name: self.routers.name,
                                path: self.routers.path,
                                class: self.routers.class
                            });

                            self.needCheckLayer = true;
                        }  
                    }
                }
                   
            });   
        },             

        //設定fab
        setFab: function (fn) {

            var self = this;
            var fab = getUrlParameterByName('fab', window.location.href.toLowerCase());


            if (fab) {
                self.fab = fab;
                return;
            }

            if (!self.fab && window.localStorage.getItem('fab'))
                self.fab = window.localStorage.getItem('fab');
            else
                self.fab = '';
        },

        //設定stage
        setStage: function (fn) {

            var self = this;
            var stage = getUrlParameterByName('stage', window.location.href.toLowerCase());


            if (stage) {
                self.stage = stage;
                return;
            }

            if (!self.stage && window.localStorage.getItem('stage'))
                self.stage = window.localStorage.getItem('stage');
            else
                self.stage = '';
        },
               
        //設定function
        setFunc: function (fn) {

            var self = this;
            var func = getUrlParameterByName('func', window.location.href.toLowerCase());


            if (func) {
                self.func = func;
                return;
            }

            if (!self.func && window.localStorage.getItem('func'))
                self.func = window.localStorage.getItem('func');
            else
                self.func = '';
        },

        //設定toolId
        setToolId: function (fn) {

            var self = this;
            var toolId = getUrlParameterByName('toolId', window.location.href.toLowerCase());


            if (toolId) {
                self.toolId = toolId;
                return;
            }

            if (!self.toolId && window.localStorage.getItem('toolId'))
                self.toolId = window.localStorage.getItem('toolId');
            else
                self.toolId = '';

        },

        //設定ModelType
        setModelType: function (fn) {

            var self = this;
            var modelType = getUrlParameterByName('modelType', window.location.href.toLowerCase());


            if (modelType) {
                self.modelType = modelType;
                return;
            }

            if (!self.modelType && window.localStorage.getItem('modelType'))
                self.modelType = window.localStorage.getItem('modelType');
            else
                self.modelType = '';
        },


        //設定Chamber
        setChamber: function (fn) {

            var self = this;
            var chamber = getUrlParameterByName('chamber', window.location.href.toLowerCase());


            if (chamber) {
                self.chamber = chamber;
                return;
            }

            if (!self.chamber && window.localStorage.getItem('chamber'))
                self.chamber = window.localStorage.getItem('chamber');
            else
                self.chamber = '';
        },

        //設定Chambers
        setChambers: function (fn) {

            var self = this;
            var chambers = getUrlParameterByName('chambers', window.location.href.toLowerCase());


            if (chambers) {
                self.chambers = chambers;
                return;
            }

            if (!self.chambers && window.localStorage.getItem('chambers'))
                self.chambers = window.localStorage.getItem('chambers');
            else
                self.chambers = [];
        },


        //設定startTime
        setStartTime: function (fn) {

            var self = this;
            var startTime = getUrlParameterByName('startTime', window.location.href.toLowerCase());


            if (startTime) {
                self.startTime = startTime;
                return;
            }

            if (!self.startTime && window.localStorage.getItem('startTime'))
                self.startTime = window.localStorage.getItem('startTime');
            else
                self.startTime = '';
        },

        //設定endTime
        setEndTime: function (fn) {

            var self = this;
            var endTime = getUrlParameterByName('endTime', window.location.href.toLowerCase());


            if (endTime) {
                self.endTime = endTime;
                return;
            }

            if (!self.endTime && window.localStorage.getItem('endTime'))
                self.endTime = window.localStorage.getItem('endTime');
            else
                self.endTime = '';
        },

        //設定endTime
        setOnlineHomeViewMode: function (fn) {

            var self = this;          

            if (window.localStorage.getItem('onlineHomeViewMode'))
                self.onlineHomeViewMode = window.localStorage.getItem('onlineHomeViewMode');
          
        },

        clearCookies: function () {
            window.localStorage.setItem('fab', value);
            window.localStorage.setItem('stage', value);
            window.localStorage.setItem('func', value);
            window.localStorage.setItem('toolId', value);
            window.localStorage.setItem('modelType', value);
            window.localStorage.setItem('chambers', value);
            window.localStorage.setItem('startTime', value);
            window.localStorage.setItem('endTime', value);
            window.localStorage.setItem('onlineHomeViewMode', value);

        }
      
    }
});




