﻿
using Newtonsoft.Json;
using NLog;
using PHM_Frontend.Cache;
using PHM_Frontend.DTO.Config;
using PHM_Frontend.Repository;
using System;
using System.Collections.Generic;
using System.IO;
using System.Web;

namespace PHM_Frontend.Cache
{
    public static class PHMCache {
        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public static JsonConfig GetJsonConfig() { 


            var key = string.Format($"{CacheKey.JsonConfig}");
            var cacheData = CacheHelper.GetCacheObject(key) as JsonConfig;

            if (cacheData == null)
            {
                JsonConfig jsonConfig;
                var path = System.AppDomain.CurrentDomain.BaseDirectory;
                var fulPath = Path.Combine(path, "config.json");

                logger.Log(LogLevel.Info, fulPath);
                //string path = HttpContext.Current.Server.MapPath(@"~/config.json"); 
                using (var reader = new StreamReader(fulPath)) {
                    jsonConfig = JsonConvert.DeserializeObject<JsonConfig>(reader.ReadToEnd());
                }
                if (jsonConfig == null) return null;
                CacheHelper.SetCache(key, jsonConfig);
                return jsonConfig;
            }
            return cacheData;
        }


        public static void RemoveAll() {
            CacheHelper.RemoveAll();
        }

    }

    public static class CacheKey
    {
        public static string JsonConfig = "JsonConfig";      
    }




}
