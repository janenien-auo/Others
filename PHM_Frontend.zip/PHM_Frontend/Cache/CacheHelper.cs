﻿using System;
using System.Runtime.Caching;

namespace PHM_Frontend.Cache {
    public static class CacheHelper
    {
        //private const int defaultExpirationMins = 10;//設定過期時間
        private static ObjectCache _cache = MemoryCache.Default;
        public static object GetCacheObject(string key)
        {
            return _cache[key];
        }

        public static void SetCache(string key, object obj, int? expirationMins = null)
        {
            if (expirationMins != null)
            {
                System.DateTimeOffset dataTimeOffset = DateTimeOffset.Now.AddMinutes(expirationMins.Value);
                var policy = new CacheItemPolicy() { AbsoluteExpiration = dataTimeOffset };
                _cache.Set(key, obj, policy);
            }
            else
            {
                var policy = new CacheItemPolicy() { AbsoluteExpiration = ObjectCache.InfiniteAbsoluteExpiration };
                _cache.Set(key, obj, policy);
            }
        }

        public static void DeleteCache(string key)
        {
            _cache.Remove(key);            
        }

        public static void RemoveAll() {
            _cache= MemoryCache.Default;
        }
    }
}
