﻿using System.Web.Mvc;

namespace PHM_Frontend.Controllers {
    public class ErrorController : Controller {
        // GET: Error
        public ActionResult SupportBrowser() {
            return View();
        }

        public ActionResult ErrorHandle(string message) {
            ViewBag.Message = message; 
            return View();
        }

        public ActionResult Error() {           
            return View();
        }
    }
}