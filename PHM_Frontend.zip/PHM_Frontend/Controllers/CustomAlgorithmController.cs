﻿using PHM_Frontend.Attributes;
using System.Web.Mvc;

namespace PHM_Frontend.Controllers {
    [PHMAuthorize]
    public class CustomAlgorithmController : Controller {

        [AllowAnonymous]
        [HttpGet]
        // GET: Home
        public ActionResult AlgorithmList() {
            return View();
        }

        [AllowAnonymous]
        [HttpGet]
        //Create  Algorithm 
        public ActionResult CreateAlgorithm() {
            return View();
        }

        [AllowAnonymous]
        [HttpGet]
        //Algorithm Version List     
        public ActionResult VersionList() {
            return View();
        }

        [AllowAnonymous]
        [HttpGet]
        //Create  Version
        public ActionResult CreateVersion() {
            return View();
        }        

    }
}
