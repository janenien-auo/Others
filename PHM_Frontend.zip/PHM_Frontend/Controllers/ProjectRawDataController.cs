﻿using System.Web.Mvc;

namespace PHM_Frontend.Controllers {
    public class ProjectRawDataController : Controller
    {
        // GET: ProjectRawData
        public ActionResult ProjectRawDataList()
        {
            return View();
        }

        public ActionResult RedriectRawdataUrl() {
            return View();
        }

        public ActionResult ParameterSelectRawData() {
            return View();
        }

        public ActionResult DataFilterRawData() {
            return View();
        }

        public ActionResult FeatureEngineeringRawData() {
            return View();
        }

    }
}