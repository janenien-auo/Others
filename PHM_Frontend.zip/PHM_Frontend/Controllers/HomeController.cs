﻿using PHM_Frontend.Attributes;
using PHM_Frontend.Cache;
using System.Web.Mvc;

namespace PHM_Frontend.Controllers {
    [PHMAuthorize]
    public class HomeController : Controller
    {
        [AllowAnonymous]
        [HttpGet]
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

       
        [AllowAnonymous]
        [HttpGet]
        public ActionResult Login() {

            return View();
        }
      
        [HttpGet]
        public ActionResult Logout() {    
            return View();
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult ClearCache() {
            PHMCache.RemoveAll();
            return View();
        }

        //[AllowAnonymous]
        [HttpGet]
        public ActionResult TrainingMaterials() {
            return View();
        }

        //add by amanda 2020-09-07 10:30
        [HttpGet]
        public ActionResult UserMaintain() {
            return View();
        }


        [HttpGet]
        public ActionResult Announcement() {
            return View();
        }



    }
}