﻿using PHM_Frontend.Attributes;
using System.Web.Mvc;



namespace PHM_Frontend.Controllers {
    [PHMAuthorize]
    public class ProjectContiController : Controller {


        public ActionResult ProjectContiList() {
            return View();
        }

        public ActionResult ParameterSelect() {
            return View();
        }

        public ActionResult Imputation() {
            return View();
        }


        public ActionResult RedriectContiUrl() {
            return View();
        }

        public ActionResult FeatureEngineering() {
            return View();
        }

        public ActionResult Segmentation() {
            return View();
        }

        public ActionResult DataFilter() {
            return View();
        }
        public ActionResult DataLabeling() {
            return View();
        }

    }
}
