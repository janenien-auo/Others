﻿using Newtonsoft.Json;
using NLog;
using PHM_Frontend.Cache;
using PHM_Frontend.DTO.File;
using System.Collections.Generic;
using System.IO;
using System.Web.Http;

namespace PHM_Frontend.Controllers.api {
    public class FileController : JSendApiController {

        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();



        [HttpGet]
        public List<TrainingMaterial> GetTrainingMaterials() {


            var folderPath = PHMCache.GetJsonConfig().TrainingMaterialsFilePath;
            var currentFolder = "";
            string[] fileWithPahts;
            string currentPath = "";

            List<TrainingMaterial> trainingMaterials = new List<TrainingMaterial>();
            string[] subdirectoryEntries = Directory.GetDirectories(folderPath);

            foreach (string subdirectory in subdirectoryEntries) {
                var paths = subdirectory.Split('\\');
                currentFolder = paths[paths.Length - 1];
                currentPath = Path.Combine(folderPath, currentFolder);

                fileWithPahts = Directory.GetFiles(currentPath);


                var files = new List<string>();
                foreach (var file in fileWithPahts) {

                    //把隱藏檔過濾掉
                    FileInfo fileInfo = new FileInfo(file);
                    if ((fileInfo.Attributes & FileAttributes.Hidden) != FileAttributes.Hidden) {
                        var tmpFileInfo = file.Split('\\');
                        files.Add(tmpFileInfo[tmpFileInfo.Length - 1]);
                    }
                }
                
                trainingMaterials.Add(new TrainingMaterial() {
                    Folder = currentFolder,
                    Files = files
                });
            }


            return trainingMaterials;
        }

        [HttpGet]
        public List<AnnouncementInfo> GetAnnouncements() {


            var folderPath = PHMCache.GetJsonConfig().AnnouncementMaterialsFilePath;           
            string[] fileWithPahts;
           

            List<AnnouncementInfo> announcements = new List<AnnouncementInfo>();

            using (StreamReader r = new StreamReader(folderPath+ "\\Announcement.json")) {
                string json = r.ReadToEnd();
                announcements = JsonConvert.DeserializeObject<List<AnnouncementInfo>>(json);                 
            }                                 

            foreach (AnnouncementInfo ann in announcements) {
                if (ann.format == "file") {

                    ann.files = new List<string>();

                    fileWithPahts = Directory.GetFiles(folderPath+"\\"+ann.folder_path);

                    foreach (var file in fileWithPahts) {
                        var tmpFileInfo = file.Split('\\');
                        ann.files.Add(tmpFileInfo[tmpFileInfo.Length - 1]);
                    }  
                }
            }


            return announcements;
        }


    }
}
