﻿using cimuac;
using Newtonsoft.Json;
using NLog;
using PHM_Frontend.Cache;
using PHM_Frontend.DTO.Authentication;
using System;
using System.Web;
using System.Web.Http;
using System.Web.Security;
//using System.Web.Security;

namespace PHM_Frontend.Controllers.api {
    public class AuthenticationController : JSendApiController {

        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();

        [HttpPost]
        public RtnUAC Login([FromBody] LoginRequest req) {          
            
            RtnUAC rtnuac = new RtnUAC();
            try {

                UacFnValidatorWin fnValidaor = new UacFnValidatorWin();
                fnValidaor.Initial();
                UacAuthority uacAuthority = fnValidaor.identifyUser(cimuac.Components.Language.TW, req.username, req.password);
                SetAuth(uacAuthority, ref rtnuac);
               
            }
            catch (Exception ex) {
                rtnuac.Status = "ERROR";
                rtnuac.ErrorMsg = ex.Message;
                logger.Error(ex);
            }

            return rtnuac;
        }

        [HttpPost]
        public string Logout() {
            FormsAuthentication.SignOut();           
            return "OK";
        }


        [HttpPost]
        public RtnUAC CheckAuthorityKey([FromBody] LoginRequest req) {

            if (req==null) new ArgumentNullException("LoginRequest");
            if (string.IsNullOrEmpty(req.authorityKey)) return null;           

            RtnUAC rtnuac = new RtnUAC();
            try {
                UacFnValidatorWin fnValidaor = new UacFnValidatorWin();
                fnValidaor.Initial();
                UacAuthority uacAuthority = fnValidaor.findUserByAuthKey(cimuac.Components.Language.TW, req.authorityKey);  
                SetAuth(uacAuthority, ref rtnuac);
            }
            catch (Exception ex) {
                rtnuac.Status = "ERROR";
                rtnuac.ErrorMsg = ex.Message;
                logger.Error(ex);
                FormsAuthentication.SignOut();
            }
            return rtnuac;
        }

        private void SetAuth(UacAuthority uacAuthority, ref RtnUAC rtnuac) {

            rtnuac.Status = uacAuthority.rtnCode;
            rtnuac.ErrorMsg = uacAuthority.rtnMessage;
            if (uacAuthority.IsPass()) {

                FormsAuthentication.SetAuthCookie(uacAuthority.authkey, false);

                UserInfo userData = new UserInfo() {
                    UserId = uacAuthority.userid,
                    UserName = uacAuthority.name,
                    UserEmail = uacAuthority.email,
                    UserSite = uacAuthority.location,
                    UserDeptID = uacAuthority.deptno,
                    PhotoUrl = PHMCache.GetJsonConfig().AuthorizationSetting.UserDataServer + uacAuthority.userid + ".jpg",
                    InputAccount = uacAuthority.inputaccount
                };


                FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1,
                  uacAuthority.email,
                  DateTime.Now,
                  DateTime.Now.AddMinutes(PHMCache.GetJsonConfig().AuthorizationSetting.SessionExpirationMins),
                  true,
                  JsonConvert.SerializeObject(userData),
                  FormsAuthentication.FormsCookiePath);


                //ticket 生成 cookie
                string encTicket = FormsAuthentication.Encrypt(ticket);
                HttpCookie httpCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);

                HttpContext.Current.Request.Cookies.Add(httpCookie);
                rtnuac.UserInfo = userData;
                rtnuac.AuthorityKey = uacAuthority.authkey;
            }
            else {
                FormsAuthentication.SignOut();
            }
        }

    }
}
