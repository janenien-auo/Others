﻿using NLog;
using System.Web.Http;

namespace PHM_Frontend.Controllers.api {
    public class LogController : JSendApiController {

        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();

        //[HttpPost]
        //public void Error([FromUri] JsError req) {
        //    logger.Error($"[Msg:{req.msg}] [url:{req.url}] [line:{req.line}]");
        //}

        [HttpPost]
        public string Error([FromBody] string msg) {
            //TODO:寫到JS專屬檔案
            logger.Error(msg);
            return "";
        }


        [HttpGet]
        public string Error2(string msg) {
            //TODO:寫到JS專屬檔案
            logger.Error(msg);
            return "";
        }

    }
}
