﻿using NLog;
using PHM_Frontend.Cache;
using PHM_Frontend.DTO.Basicinfor;
using PHM_Frontend.Repository;
using System.Collections.Generic;
using System.Web.Http;

namespace PHM_Frontend.Controllers.api {
    public class BasicinforController: JSendApiController
    {
        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();
        BasicinforRepository basicinforRepository;      
        public BasicinforController() {
            
             basicinforRepository = new BasicinforRepository(PHMCache.GetJsonConfig().DBConnection.User, PHMCache.GetJsonConfig().DBConnection.Fab);
        }

        //[HttpGet]
        //public GetToolResponse xxxGetTools2() {
        //    return new GetToolResponse() { TOOLID="22"};
        //}

        //[HttpPost]
        //public List<GetToolResponse> xxxGetTools([FromUri]  GetToolRequest req) {
        //    return basicinforRepository.GetTools(req);
        //}

        [HttpGet]
        public List<GetFabsResponse> GetFabs([FromUri] GetFabsReqest req) {
            return basicinforRepository.GetFabs(req);
        }

        [HttpGet]
        public List<GetFunctionsResponse> GetFunctions([FromUri] GetFunctionsReqest req) {
            return basicinforRepository.GetFunctions(req);
        }

        //[HttpGet]
        //public List<GetFunctionsResponse> xxxGetFunctionsConti([FromUri] GetFunctionsReqest req) {
        //    return basicinforRepository.xxxGetFunctionsConti(req);
        //}

        [HttpGet]
        public List<GetModulesResponse> GetModules([FromUri] GetModulesReqest req) {    
            return basicinforRepository.GetModules(req);
        }

        //[HttpGet]
        //public List<GetModulesResponse> xxxGetModulesConti([FromUri] GetModulesReqest req) {
        //    return basicinforRepository.xxxGetModulesConti(req);
        //}

        [HttpGet]
        public List<GetToolTypesResponse> GetToolTypes([FromUri] GetToolTypesReqest req) {
            return basicinforRepository.GetToolTypes(req);
        }

        //[HttpGet]
        //public List<GetToolTypesResponse> xxxGetToolTypesConti([FromUri] GetToolTypesReqest req) {
        //    return basicinforRepository.xxxGetToolTypesConti(req);
        //}

        [HttpGet]
        public List<GetToolsResponse> GetTools([FromUri]  GetToolsReqest req) {
            return basicinforRepository.GetTools(req);
        }

        //[HttpGet]
        //public List<GetToolsResponse> xxxGetToolsConti([FromUri]  GetToolsReqest req) {
        //    return basicinforRepository.xxxGetToolsConti(req);
        //}

        [HttpGet]
        public List<GetChambersResponse> GetChambers([FromUri] GetChambersReqest req) {
            return basicinforRepository.GetChambers(req);
        }

        //[HttpGet]
        //public List<GetChambersResponse> xxxGetChambersConti([FromUri] GetChambersReqest req) {
        //    return basicinforRepository.xxxGetChambersConti(req);
        //}


    }
}
