﻿using PHM_Frontend.Filter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PHM_Frontend.Controllers.api
{
    [PHMActionFilter]
    [PHMWebApiExceptionFilter]
    public class JSendApiController : ApiController
    {

    }
}
