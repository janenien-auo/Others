﻿using PHM_Frontend.Attributes;
using System.Web.Mvc;

namespace PHM_Frontend.Controllers {
    [PHMAuthorize]
    public class OnlineController : Controller
    {       
      

        public ActionResult OnlineHome() {
            return View();
        }

        public ActionResult OnlineHomePoc() {
            return View();
        }

        public ActionResult ToolList() {
            return View();
        }

        public ActionResult ToolDetail() {
            return View();
        }       

        public ActionResult confirmModePage() {
            return View();
        }

        public ActionResult OnlineModelList() {
            return View();
        }

        public ActionResult ToolMapping() {
            return View();
        }

        public ActionResult DataHealth() {
            return View();
        }

        public ActionResult EStoneEventList() {
            return View();
        }

        public ActionResult RecordHistory() {
            return View();
        }

        public ActionResult CloseEStone() {
            return View();
        }

        public ActionResult RecordSetting() {
            return View();
        }
    }
}