﻿using PHM_Frontend.Attributes;
using System.Web.Mvc;

namespace PHM_Frontend.Controllers {
    [PHMAuthorize]
    public class ProjectController : Controller
    {       
        public ActionResult ProjectList()
        {
            return View();
        }       
       
        public ActionResult ProjectInfo() {          
            return View();
        }
     
        public ActionResult UploadFiles() {          
            return View();
        }


        public ActionResult CheckData() {            
            return View();
        }


        public ActionResult FrequencyTransform() {           
            return View();
        }


        public ActionResult FrequencyTransformPreview() {          
            return View();
        }


        public ActionResult FeatureExtraction() {          
            return View();
        }


        public ActionResult FeatureExtractionPreview() {         
            return View();
        }


        public ActionResult DataLabeling() {           
            return View();
        }


        public ActionResult SplitData() {           
            return View();
        }


        public ActionResult XDICheck() {          
            return View();
        }


        public ActionResult FeatureSelection() {           
            return View();
        }


        public ActionResult ModelResult() {           
            return View();
        }

        public ActionResult WaitingandMailAlert() {         
            return View();
        }

        public ActionResult RedriectUrl() {
            return View();
        }

        public ActionResult FeatureEngineering() {
            return View();
        }

        public ActionResult DataProcess() {
            return View();
        }

    }
}