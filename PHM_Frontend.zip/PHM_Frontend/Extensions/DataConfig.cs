﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace PHM_Frontend.Extensions {
    public class DataConfig {
        public class GetGPDB_Input {
            public string Tier { get; set; }
            public string SQL { get; set; }
            public string Zipped { get; set; }
        } //public class GetGPDB_Input

        /* 設定傳入參數列表  */
        public class InputJsonBasicinfor {
            public string user { set; get; }
            public string password { set; get; }
            public string FABSITE { set; get; }
            public string PROCESSTYPE { set; get; }
            public string DATATYPE { set; get; }
            public string MODULENAME { set; get; }
            public string TOOLVENDER { set; get; }
            public string TOOLTYPE { set; get; }
            public string ziped { set; get; }
        } //public class InputJsonBasicinfor

        public class InputJsonChamber {
            public string user { set; get; }
            public string password { set; get; }
            public string FABSITE { set; get; }
            public string TOOLID { set; get; }
            public string DATATYPE { set; get; }
            public string ziped { set; get; }
        } //public class InputJsonChamber

        /* 設定APC Open Data 收到訊息參數  */
        public class rtnMsgShell {
            rtnMsg trtnMsg = new rtnMsg();
            public rtnMsg data { get { return trtnMsg; } set { trtnMsg = value; } }
            public string CompressData { get; set; }
        } //public class rtnMsgShell

        public class rtnMsg {
            public string Status { get; set; }
            public string Message { get; set; }
            public DataTable Data { get; set; }
        } // public class rtnMsg


    }
}