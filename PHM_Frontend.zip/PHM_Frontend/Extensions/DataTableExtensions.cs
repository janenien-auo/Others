﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Reflection;



namespace PHM_Frontend.Extensions {
    public static class DataTableExtensions {


        public static IList<T> ToList<T>(this DataTable table) where T : new() {
            IList<PropertyInfo> properties = typeof(T).GetProperties().ToList();
            IList<T> result = new List<T>();

            foreach (var row in table.Rows) {
                var item = CreateItemFromRow<T>((DataRow)row, properties);
                result.Add(item);
            }

            return result;
        }

        public static IList<T> ToList<T>(this DataTable table, Dictionary<string, string> mappings) where T : new() {
            IList<PropertyInfo> properties = typeof(T).GetProperties().ToList();
            IList<T> result = new List<T>();

            foreach (var row in table.Rows) {
                var item = CreateItemFromRow<T>((DataRow)row, properties, mappings);
                result.Add(item);
            }

            return result;
        }

        private static T CreateItemFromRow<T>(DataRow row, IList<PropertyInfo> properties) where T : new() {
            T item = new T();
            Type type = item.GetType();
            foreach (var property in properties) {
                //get the property information based on the type
                System.Reflection.PropertyInfo propertyInfo = type.GetProperty(property.Name);
                //find the property type
                Type propertyType = propertyInfo.PropertyType;
                var propertyVal = Convert.ChangeType(row[property.Name], propertyType);
                property.SetValue(item, propertyVal, null);
            }
            return item;
        }

        private static T CreateItemFromRow<T>(DataRow row, IList<PropertyInfo> properties, Dictionary<string, string> mappings) where T : new() {
            T item = new T();
            foreach (var property in properties) {
                if (mappings.ContainsKey(property.Name))
                    property.SetValue(item, row[mappings[property.Name]], null);
            }
            return item;
        }

    }
}