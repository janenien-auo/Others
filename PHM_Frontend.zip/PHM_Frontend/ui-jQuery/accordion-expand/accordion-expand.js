$(document).ready(function() {
  accordion();
});

$(document).resize(function() {
  accordion();
});

// Accordion

function accordion() {
  $(".accordion-header").click(function() {
    if (
      $(this)
      .next()
      .is(":visible")
    ) {
      $(this)
        .next()
        .slideUp();
      $(this)
        .parent()
        .addClass("accordion-close");
      $(this)
        .parent()
        .removeClass("accordion-open");
    } else {
      $(".accordion-body").slideUp();
      $(".accordion-item").removeClass("accordion-open");
      $(this)
        .next()
        .slideDown();
      $(this)
        .parent()
        .addClass("accordion-open");
      $(this)
        .parent()
        .removeClass("accordion-close");
    }
  });

  $("#expand").click(function() {
    $(".accordion-body").slideDown();
    $(".accordion-item").addClass("accordion-open");
  });

  $("#collapse").click(function() {
    $(".accordion-body").slideUp();
    $(".accordion-item").removeClass("accordion-open");
  });
}