$(function() {
    $('.magic-height').magicHeight({
        itemClass: '.article'
    });
});