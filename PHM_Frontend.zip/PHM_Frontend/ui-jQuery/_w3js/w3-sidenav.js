function openNav() {
document.getElementById("w3Sidenav").style.width = "290px";
document.getElementById("w3CanvasNav").style.width = "100%";
document.getElementById("w3CanvasNav").style.opacity = "0.8";
}
function closeNav() {
document.getElementById("w3Sidenav").style.width = "0";
document.getElementById("w3CanvasNav").style.width = "0%";
document.getElementById("w3CanvasNav").style.opacity = "0";
}
function closeOffcanvas() {
document.getElementById("w3Sidenav").style.width = "0";
document.getElementById("w3CanvasNav").style.width = "0%";
document.getElementById("w3CanvasNav").style.opacity = "0";
}